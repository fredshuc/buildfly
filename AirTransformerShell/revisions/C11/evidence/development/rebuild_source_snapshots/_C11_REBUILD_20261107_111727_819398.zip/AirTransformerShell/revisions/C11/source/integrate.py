"""Compose seven explicit installed groups from pinned owner returns."""
from common import *
from accessories import h02_root
from itertools import combinations
D05=WORK/'d05/c11-d05';HYD11=WORK/'hyd_c11/hydronics/C11_HYD_T01'
ANGLE=77.701928604
GROUPS=['SHELL','DAMPERS','HEAT_EXCHANGERS','WATER_RACK','FIRST_SPOOLS','HYD_SUPPORT','THERMAL']
def moving(n):
    return n.startswith(('DAMPER_BLADE_','DAMPER_ROOT_SLEEVE_','DAMPER_SHAFT_','DAMPER_ROOT_PIN_',
        'D03_COUPLING_','D03_ACT_OUTPUT_','D03_STOP_ARM_','D05_STOP_ARM_','D05_SHAFT_'))
def key(group,path):
    leaf=path.split('/')[-1]
    if group=='HEAT_EXCHANGERS':
        tags=[t for t in path.split('/') if t in ('A_LOWER','A_UPPER','B_LOWER','B_UPPER')]
        assert len(tags)==1,path
        return tags[0]+'__'+leaf
    return leaf
def cache_scene(state):
    src=CAD/f'C11_INSTALLED_{state}.step';folder=WORK/f'installed_{state}';index=folder/'index.json'
    digest=sha(src)
    if index.exists():
        data=json.loads(index.read_text())
        if data['sha256']==digest:return folder,data['parts']
    folder.mkdir(exist_ok=True);rows=[];seen=set();valid_cache={};volume_cache={}
    for i,(path,s) in enumerate(leaves(src)):
        group=next(g for g in GROUPS if g in path.split('/'));n=key(group,path)
        assert (group,n) not in seen,(group,n);seen.add((group,n))
        # Cache only identical unlocated topology, never a near-equal proxy.
        unlocated=s.wrapped.Located(TopLoc_Location());h=hash(unlocated)
        prior=valid_cache.get(h,[]);old=next((v for t,v in prior if t.IsEqual(unlocated)),None)
        if old is None:old=bool(s.Solids()) and s.isValid();prior.append((unlocated,old));valid_cache[h]=prior
        assert old,('invalid installed part',group,n)
        v=s.Volume();f=f'{i:05}.brep';s.exportBrep(str(folder/f))
        rows.append({'name':n,'group':group,'path':path,'file':f,'bbox':bounds(s),'exact_bbox':bb(s),'volume_mm3':v})
        if i%300==0:print(state,'readback',i,flush=True)
    dump(index,{'sha256':digest,'parts':rows});return folder,rows
def run():
    hx=h02_root();assert (hx/'H02_FOUR_HX_INSTALLED.step').exists(),'Final H02 package not prepared'
    assert (HERE/'INPUTS.json').exists(),'Freeze input manifest before integration'
    rows=json.loads((WORK/'shell/index.json').read_text());parts={r['name']:cq.Shape.importBrep(str(WORK/'shell'/r['file'])) for r in rows}
    assert all(f'C11_{b}_POCKET_FRONT_CLOSURE' in parts for b in 'AB')
    save(parts,CAD/'C11_SHELL_DESIGN.step')
    save({r['name']:parts[r['name']] for r in rows if r['changed']},CAD/'C11_CHANGED_SHELL_DESIGN.step')
    normalized=named(D05/'cad/C11_D05_DAMPERS_NORMALIZED_P.step');report={}
    # Explicit owner-requested fixed-seat hole, retained as a C11 delta.
    # No moving blade, shaft, structural post or generic intersecting body is cut.
    cutter=named(hx/'H02_HOST_OPENING_TOOLS_REFERENCE.step')['B_UPPER_W2_VENT_INNER']
    name='DAMPER_SEAT_B_UPPER_DEEP_O';old=normalized[name]
    normalized[name]=old.cut(cutter).clean();assert normalized[name].isValid()
    table(HERE/'C11_DAMPER_INTERFACE_CHANGES.csv',[{'part':name,'operation':'H02 B upper W2 vent registered D14 passage; fixed2mm seat only','removed_mm3':old.Volume()-normalized[name].Volume(),'status':'C11 integration candidate; local sealing/pocket/crown compatibility HOLD; D05 pinned source retained unchanged'}])
    for state in ['S1','S2']:
        dampers={}
        for n,s in normalized.items():
            tag=next((f'{b}_{l}' for b in 'AB' for l in ('LOWER','UPPER') if f'{b}_{l}' in n),None)
            if tag and moving(n) and ((tag[0]=='B')==(state=='S1')):
                x,z=(610,342) if 'LOWER' in tag else (-500,1385);s=s.rotate((x,0,z),(x,1,z),ANGLE)
            dampers[n]=s
        dp=CAD/f'C11_DAMPERS_{state}.step';save(dampers,dp,(.18,.55,.65))
        paths=[('SHELL',CAD/'C11_SHELL_DESIGN.step'),('DAMPERS',dp),('HEAT_EXCHANGERS',hx/'H02_FOUR_HX_INSTALLED.step'),
          ('WATER_RACK',HYD/'S2_RACK.step'),('FIRST_SPOOLS',hx/'H02_EIGHT_FIRST_SPOOLS.step'),
          ('HYD_SUPPORT',HYD11/'cad/C11_HYD_RACK_SUPPORT.step'),('THERMAL',HYD/'W2_ADDITIONAL_INSULATION.step')]
        combine(paths,CAD/f'C11_INSTALLED_{state}.step')
        report[state]={'output_sha256':sha(CAD/f'C11_INSTALLED_{state}.step'),'groups':{g:{'source_basename':p.name,'sha256':sha(p)} for g,p in paths},
          'status':'INTEGRATED_REVIEW_CANDIDATE_NOT_GEOMETRY_ACCEPTED','excluded_reference_tools':['H02_HOST_OPENING_TOOLS_REFERENCE','C11_THERMAL_HOLE_REQUEST','service and motion envelopes']}
        dump(E/'integration_build.json',report);print('Composed',state,flush=True)
    for state in ['S1','S2']:
        _,rows=cache_scene(state);report[state]['counts']={g:sum(r['group']==g for r in rows) for g in GROUPS};report[state]['total_occurrences']=len(rows)
    dump(E/'integration_build.json',report)
if __name__=='__main__':run()
