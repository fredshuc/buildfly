"""Read-only C10 interface inventory for C11; scratch outputs are not releases."""
from pathlib import Path
import sys,json
HERE=Path(__file__).resolve().parents[1]
WS=HERE.parents[3]
old=WS/'C10_INTEGRATION_GIT/AirTransformerShell/revisions/C10'
sys.path.insert(0,str(old/'source'))
from common import *
from build import cache_host
out=Path(__file__).resolve().parents[1]/'.work'
out.mkdir(exist_ok=True)
base=cache_host('S1')
shell={**base['SHELL'],**named(CAD/'C10_CHANGED_SHEET_AND_GLANDS.step')}
report={}
for n,s in shell.items():
    b=bb(s)
    report[n]={'bbox':b,'volume_mm3':s.Volume(),'solids':len(s.Solids())}
(out/'shell_inventory.json').write_text(json.dumps(report,indent=2))
print('Shell inventory',len(shell),flush=True)
hx={}
for n,s in leaves(HX/'H01_FOUR_HX_INSTALLED.step'):
    if any(t in n for t in ('AIR_EDGE','FRAME','POST','FOOT','C05','SEAL','LAND','CARRIER','VENT','DRAIN')):
        hx[n]={'bbox':bb(s),'volume_mm3':s.Volume()}
(out/'hx_interfaces.json').write_text(json.dumps(hx,indent=2))
print('HX interface inventory',len(hx),flush=True)
