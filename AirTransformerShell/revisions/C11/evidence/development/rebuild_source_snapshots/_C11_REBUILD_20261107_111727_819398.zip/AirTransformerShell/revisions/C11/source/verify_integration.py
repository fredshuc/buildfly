"""All installed group pairs, explicit design contacts, and new internal pairs."""
from integrate import *
from itertools import combinations
from collections import defaultdict
TOL=.001
def run(state):
    folder,rows=cache_scene(state);groups=defaultdict(dict);meta=defaultdict(dict)
    for r in rows:
        groups[r['group']][r['name']]=cq.Shape.importBrep(str(folder/r['file']));meta[r['group']][r['name']]=r
    report={'state':state,'assembly_sha256':sha(CAD/f'C11_INSTALLED_{state}.step'),'threshold_mm3':TOL,
      'group_counts':{g:len(v) for g,v in groups.items()},'checks':{},'status':'CHECK_IN_PROGRESS'}
    inputs=json.loads((E/'integration_build.json').read_text());prior=json.loads((E/'integration_S1.json').read_text()) if state=='S2' and (E/'integration_S1.json').exists() else None
    def screen(ga,gb,left=None,same=False,allowed=None):
        a=groups[ga] if left is None else left;b=groups[gb];hits=[];contacts=[];count=0;seen=set()
        for n,s in a.items():
            boxa=bounds(s)
            for m,t in b.items():
                if ga==gb and n==m:continue
                if same and tuple(sorted((n,m))) in seen:continue
                if same:seen.add(tuple(sorted((n,m))))
                if not overlap(boxa,meta[gb][m]['bbox'],-1e-5):continue
                count+=1
                try:v=s.intersect(t).Volume()
                except Exception as e:hits.append([n,m,'KERNEL_ERROR '+str(e)]);continue
                if v>TOL:
                    pair=frozenset((n,m));reason=allowed.get(pair) if allowed else None
                    (contacts if reason else hits).append([n,m,v,reason] if reason else [n,m,v])
        return {'candidate_pairs':count,'unexpected':hits,'explicit_design_contacts':contacts}
    for a,b in combinations(sorted(groups),2):
        label=a+'_x_'+b
        if prior and 'DAMPERS' not in (a,b) and all(inputs['S1']['groups'][g]['sha256']==inputs['S2']['groups'][g]['sha256'] for g in (a,b)):
            res=dict(prior['checks'][label]);res['reuse_basis']='Both exact source group STEP hashes identical to S1; all occurrences read back in S2'
        else:res=screen(a,b)
        report['checks'][label]=res;dump(E/f'integration_{state}.json',report);print(state,label,res['candidate_pairs'],len(res['unexpected']),flush=True)
    data=json.loads((E/'shell_build.json').read_text());changed=set(data['changes'])&set(groups['SHELL'])
    allowed={frozenset((r['a'],r['b'])):r['purpose'] for r in data['contacts']}
    report['checks']['SHELL_NEW_INTERNAL']=screen('SHELL','SHELL',{n:groups['SHELL'][n] for n in changed},True,allowed)
    soft=json.loads((D05/'evidence/static_check.json').read_text())[state]['exact_soft_pairs']
    assert len(soft)==12
    allowed={frozenset((a,b)):'D05 explicit compliant contact; reference volume '+str(v) for a,b,v in soft}
    res=screen('DAMPERS','DAMPERS',same=True,allowed=allowed)
    actual={frozenset((a,b)):v for a,b,v,_ in res['explicit_design_contacts']}
    res['reference_volume_checks']=[{'a':a,'b':b,'owner_mm3':v,'actual_mm3':actual.get(frozenset((a,b))),'within_0p1mm3':frozenset((a,b)) in actual and abs(actual[frozenset((a,b))]-v)<.1} for a,b,v in soft]
    assert all(r['within_0p1mm3'] for r in res['reference_volume_checks'])
    report['checks']['DAMPERS_INTERNAL']=res
    for g in ['FIRST_SPOOLS','HYD_SUPPORT','THERMAL']:
        report['checks'][g+'_INTERNAL']=screen(g,g,same=True)
        dump(E/f'integration_{state}.json',report);print(state,g,'internal',len(report['checks'][g+'_INTERNAL']['unexpected']),flush=True)
    # H02 adds/removes material in pressure paths. Test the actual supplied
    # added material, not whole replacement headers overlapping inherited braze
    # joints. Every other group was tested against the FULL installed HX above.
    hx=h02_root();delta=named(hx/'H02_NEW_MATERIAL.step');allowed={}
    for core in ['A_LOWER','A_UPPER','B_LOWER','B_UPPER']:
        pairs=[('H02_COND_GUTTER','H02_COND_OUTLET_D18')]
        for w in ('W1','W2'):pairs += [(w+'_VENT_HEADER_LINE',w+'_D35_END_PIPE'),(w+'_VENT_NEAR_PICKUP',w+'_D35_END_PIPE'),(w+'_VENT_HEADER_LINE',w+'_VENT_NEAR_PICKUP'),(w+'_DRAIN_LINE',w+'_D35_END_PIPE')]
        for a,b in pairs:allowed[frozenset((core+'__'+a,core+'__'+b))]='Pinned H02 welded pressure/collector joint; fluid-bore evidence remains owner scoped'
    # Delta suffixes identify a removed-material reconstruction of an existing
    # part. Do not compare a part's added material with its own complete body.
    actual={n.removesuffix('_NEW_MATERIAL'):s for n,s in delta.items()}
    res=screen('HEAT_EXCHANGERS','HEAT_EXCHANGERS',actual,False,allowed)
    report['checks']['HX_ADDED_MATERIAL_INTERNAL']=res
    report['pocket_closures_present']=[f'C11_{bed}_POCKET_FRONT_CLOSURE' in groups['SHELL'] for bed in 'AB']
    report['inherited_pocket_closures']=[]
    report['status']='FAIL_OPEN_INTERFACES' if any(r['unexpected'] for r in report['checks'].values()) else 'GEOMETRY_PASS_WITHIN_STATED_SCOPE_ONLY'
    dump(E/f'integration_{state}.json',report);print('Finished',state,report['status'],flush=True)
if __name__=='__main__':run(sys.argv[1] if len(sys.argv)>1 else 'S1')
