"""Auditable engineering allocations. No test or supplier acceptance is implied."""
from common import *
import csv

def csvfile(name,rows):
 fields=list(dict.fromkeys(k for r in rows for k in r))
 with (ROOT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def run():
 data={};clear=[]
 # Specified new shaft material is 1.4542 / 17-4PH H1150, not a claim about
 # the unidentified original M2 material. Also retain a 304 sensitivity.
 LA,LB=857,872
 allocations={'two_length_tolerances':.30,'two_support_location_tolerances':.30,
              'two_gauged_axial_plays':.40,'elastic_axial_motion':.15,
              'inward_support_thermal_motion':.60,'measurement_reserve':.10}
 for case,delta,alpha in [('normal_80C',60,13e-6),('fault_200C',180,13e-6),('304_sensitivity_200C',180,18e-6)]:
  thermal=(LA+LB)*alpha*delta;remaining=9-sum(allocations.values())-thermal
  row={'id':'F4_'+case,'nominal_mm':9,'thermal_mm':thermal,**allocations,'worst_remaining_mm':remaining,
       'status':'conditional on specified material, temperature and support bounds; physical dry fit NOT RUN'}
  clear.append(row)
 data['F4']={'fixed_bearing_centres_Y':[-869,869],'free_end_Y':[-12,-3],'effective_lengths_mm':[LA,LB],
   'shaft_material':'1.4542 H1150, purchased certificate required; design alpha=13e-6/K, G>=65 GPa',
   'cold_gap_at_20C_mm':'9.0 +/-0.6 before axial play; >=8.0 when both shafts pushed inward',
   'bearing':'6006 30x55x13, fixed outer, centre unchanged; inner 3015DU 30x34x15 floats axially',
   'axial_play_each_mm':[.10,.20],'fault_note':'200C is a mechanical collision screening envelope, NOT an operating rating for seals or bearings',
   'upper_note':'Upper free tips also shortened 4 mm; upper original axial location remains an OPEN inherited interface'}
 # Conservative free strip ignores beneficial reinforcement. Load is per
 # 1 mm width; travel permitted only with residual differential <=25 Pa.
 E,t,rho,g=190000,.95,8000,9.81
 def deflect(L,pressure):return (pressure/1e6)*L**4/(8*E*t**3/12)
 L=215.6-16.5
 grav=deflect(L,rho*g*t/1000);air=deflect(L,25)
 # Both actual ribs are 19380 mm3 and extend 570 mm in Y. Conservatively
 # put their entire per-strip weight at the free tip and ignore stiffness.
 ribs=(2*19380*8e-6*9.81/570)*L**3/(3*E*t**3/12)
 f5={'blade_profile':.15,'shaft_axis_mount':.20,'bearing_radial':.08,'rotor_runout':.10,
     'HX_installation_allocation':.40,'HX_local_profile_allocation':.20,'relative_frame_deflection_allocation':.20,
     'relative_thermal_motion_allocation':.30,'gravity_deflection_bound':grav,'rib_gravity_tip_bound':ribs,
     '25Pa_air_deflection_bound':air,'deposit_dynamic_reserve':.05}
 critical=json.loads((ROOT/'evidence/critical_clearance.json').read_text())
 nominal=min(r['continuous_conservative']['mm'] for r in critical.values())
 clear.append({'id':'F5_upper_full_stroke','nominal_mm':nominal,**f5,'worst_remaining_mm':nominal-sum(f5.values()),
  'status':'CONDITIONAL; H01 and Shell tolerance/deflection allocations are not owner-signed'})
 overlap_mm=min(c['edge_overlap'] for r in critical.values() for c in r['coverage'])
 clear.append({'id':'F5_window_overlap','nominal_mm':overlap_mm,'in_plane_total_closure_mm':.85,
               'worst_remaining_mm':overlap_mm-.85,'seal_band_mm':3,'band_inner_offset_mm':0,
               'worst_effective_band_mm':min(3,overlap_mm-.85),'status':'nominal uncovered area=0 both ports/beds; imprint and leak test NOT RUN'})
 root={'seat_relief_machining':.10,'seat_to_axis_assembly':.15,'sleeve_radius':.05,'runout':.10,
       'bearing_radial':.08,'shaft_bending':.10,'thermal':.05,'support_deflection':.20}
 clear.append({'id':'F6_root_steel','nominal_mm':2.2,**root,'worst_remaining_mm':2.2-sum(root.values()),'status':'allocated manufacturing clearance; verify dry/hot'})
 pipe={'relief_radius':.10,'HX_pipe_location_allocation':.50,'pipe_form_allocation':.35,'shell_to_seat':.20,
       'thermal_relative':.15,'keeper_deflection':.10}
 clear.append({'id':'D04_steel_to_W2','nominal_mm':3.,**pipe,'worst_remaining_mm':3-sum(pipe.values()),'status':'conditional on HX pipe tolerance and thermal movement'})
 from hardware import pin_centre
 px,pz=pin_centre('A_LOWER',1)
 spacer_gap=math.hypot(px-570,pz-362)-5-5.25
 clear.append({'id':'STOP_lower_spacer','nominal_mm':spacer_gap,
   'profile_pattern_two_bolt_bore_floats_and_elastic_total_mm':1.0,'worst_remaining_mm':spacer_gap-1.0,
   'status':'static round-envelope lower bound, both beds; include bolt/spacer radial float; gauge >=0.8 mm after M6 preload4..6kN'})
 # Exact CAD first contacts, and separately the stop load path. Full actuator
 # stall reacts at the outboard arm. It is NOT applied through 0.8 m of shaft
 # past an already-engaged stop. Downstream forcing is bounded independently.
 motion=json.loads((ROOT/'evidence/full_motion.json').read_text())
 stoprows=[]
 stop={'jig_setting_deg':.04,'D_flat_lost_motion_deg':.10,'wear_allowance_deg':.02,
       'arm_pin_bracket_elastic_deg':.04,'local_drive_stub_twist_deg':.015,
       'downstream_20Nm_shaft_twist_deg':.18,'dynamic_overtravel_deg':.04}
 for tag,result in motion.items():
  lower='LOWER' in tag;rad=220 if lower else 215.6;Ll=rad-16.5
  # At an outward stop the tip has already seated on its gasket. Do not use
  # the free-flight beam model and the seal-supported model simultaneously.
  # This 0.60 mm additional edge movement is an explicit proof-test gate.
  geometric_mm=.55+.60
  uncertainty=math.degrees(math.asin(geometric_mm/rad))+.0001
  for mode,row in result['first_undesigned'].items():
   earliest=row['travel_deg']-uncertainty;limit=sum(stop.values())
   stoprows.append({'valve':tag,'end':mode,'nominal_stop_angle_deg':0 if mode=='P' else THETA,
     'directional_first_collision_travel_deg':row['travel_deg'],'first_collision_angle_deg':row['angle_deg'],
     'moving_part':row['moving'],'fixed_part':row['fixed'],'collision_uncertainty_deg':uncertainty,
     'earliest_worst_collision_travel_deg':earliest,**stop,'worst_stop_travel_deg':limit,
     'remaining_angle_deg':earliest-limit,'actuator_max_design_Nm':60,'strength_design_Nm':75,
     'status':'CONDITIONAL: limits are design requirements, OEM maximum and physical proof not confirmed'})
  assert result['first_undesigned'] and not result['unexpected_contacts'],tag
 csvfile('C11_DAMPERS_STOP_LIMITS.csv',stoprows)
 # Structural first-principles checks. No FE.
 T=75000;F=T/30;Z=3*26**2/6;I=3*26**3/12
 torque={'design_stall_Nm':60,'strength_load_Nm':75,'pin_force_N':F,'stop_arm_S355_bending_MPa':F*18/Z,
   'arm_R2_root_Kt1p5_peak_MPa':1.5*F*18/Z,
   'D10_Dprofile_pin_S355_bending_MPa':F*5/75,'D10_Dprofile_pin_shear_MPa':F/75,
   'flat_contact_effective_area_mm2':12,'flat_contact_pressure_MPa':F/12,
   'upper_4mm_pin_carrier_bearing_MPa':F/(4*10),
   'upper_stop_plate_weld_torsional_MPa':T*math.hypot(52,40)/(1.2*(4*52**3/3+4*40*52**2+4*40**3/3+4*52*40**2)),
   'arm_D_flat_bearing_MPa':T/(9*(2*math.sqrt(12**2-9**2))*3),
   'S355_allowable_MPa':355/1.5,'shaft_17_4_design_allowable_MPa':600/1.5,
   'arm_tip_elastic_mm':F*18**3/(3*210000*I),
   'pin_local_elastic_mm':F*5**3/(3*210000*400),
   'dynamic_model':'J<=0.30 kg m2; speed<=6 deg/s; with k>=6800 Nm/rad, energy bound overtravel<0.04 deg',
   'downstream_load_basis':'1000 Pa on <=0.15 m2 at <=0.12 m + gravity <=1.5 Nm <20 Nm; 60 Nm actuator stall is reacted locally by arm/pin',
   'two_load_cases':'moving: deltaP<=25 Pa and free strip bending; stopped: deltaP<=1000 Pa, seal-supported edge, extra compression<=0.60 mm must be proved',
   'root_pin_joint':'Retained two crosspins and sleeve: existing strength/material not supplier-qualified; full drivetrain torque proof remains required'}
 data['stop_strength']=torque
 data['F5']={'nominal_mm':nominal,'gravity_mm':grav,'air_25Pa_mm':air,'remaining_mm':nominal-sum(f5.values())}
 csvfile('C11_DAMPERS_CLEARANCE_STACK.csv',clear)
 # Twelve named rubbing pairs only. Face adjacencies and end-position seat
 # contacts are separately listed, not hidden inside a generic whitelist.
 sealgeom=json.loads((ROOT/'evidence/seal_geometry.json').read_text());seals=[]
 for bed in 'AB':
  for level in ('LOWER','UPPER'):
   tag=f'{bed}_{level}'
   seals.append({'id':tag+'_ROOT_LIP','pair_A':f'DAMPER_ROOT_LIP_{tag}_O','pair_B':f'DAMPER_ROOT_SLEEVE_{tag}_0_O',
    'states':'S1/S2; full travel','material':'WACKER ELASTOSIL R401/40 S, molded/extruded and postcured',
    'free_radial_mm':4.25,'installed_radial_mm':4.0,'nominal_compression_percent':100*.25/4.25,
    'active_contact':'two 7-degree longitudinal lands; R16.25 free / R16.5 sleeve; rest bore R17',
    'retention':'bond stationary R20.5 backing; split/end joints bonded, not rotor; pair-specific dry running torque <=6 Nm per complete valve',
    'qualification':'OPEN: actual CTE/friction/wear not characterized; conservative free-expansion hot interference can become negative'})
   for end in ('IN','OUT'):
    n=f'DAMPER_ROOT_END_SEAL_{tag}_{end}_O';row=sealgeom[n]
    seals.append({'id':tag+'_ROOT_'+end,'pair_A':n,'pair_B':f'DAMPER_SHAFT_{tag}_0_O','states':'S1/S2; full travel',
     'material':'WACKER ELASTOSIL R401/40 S','free_radial_mm':6,'installed_radial_mm':5.5,
     'nominal_compression_percent':100*.5/6,'allocated_cold_hot_compression_percent':'2 to 13',
     'active_contact':json.dumps(row['axial_contact_bands_global_Y_mm'])+' global Y, two 2 mm bands; free bore D29.00',
     'qualification':'design dimensions; molding tolerance, hot contact, friction and life NOT TESTED'})
   for pos in ('DEEP','SLOPED'):
    seals.append({'id':tag+'_'+pos,'pair_A':f'DAMPER_SEAL_{tag}_{pos}_O','pair_B':f'DAMPER_BLADE_{tag}_0_O',
     'states':'closing endpoint only','material':'Rogers BISCO HT-870, batch-selected/sliced 6.20 +/-0.15 mm',
     'free_normal_mm':6.2,'installed_normal_mm':'4.0 nominal CAD; powered/loaded acceptance 3.8 to 5.1',
     'compression_percent':'normal15.70..40.16; fault proof max46.46 with minimum remaining gap3.4','active_contact':'3 mm outward ring starting at aperture edge',
     'retention':'bond continuous to steel, scarf joint at low-load upper side; peel coupon on actual coating',
     'qualification':'require batch stress<=80 kPa at 47% compression; this is an added acceptance requirement, not a supplier guarantee'})
 for bed in 'AB':
  seals.append({'id':'D04_'+bed+'_BOOT','pair_A':f'D04_{bed}_WET_BOOT','pair_B':'both gland halves / copper W2 / rear sheet / Pin static pad',
   'material':'DOWSIL 7091 neutral alkoxy FIPG','free_normal_mm':'wet mold, not compression foam','installed_normal_mm':'web 1.00 +/-0.15; pipe lip axial 3.00 +/-0.30',
   'active_contact':'full circumference; A side return 8 mm; B return onto Pin seat',
   'retention':'2 mm inner/outer keepers, M4 studs, D05 D10x1 load pads; +/-100 N design; +/-200 N proof test',
   'qualification':'copper/coating/VMQ/foam adhesion, condensation and hot-cycle coupons NOT RUN; displacement requirement +/-0.5 mm'})
 csvfile('C11_DAMPERS_SEAL_REGISTER.csv',seals)
 loads=[]
 for bed in 'AB':
  sign=-1 if bed=='A' else 1
  for level in ('LOWER','UPPER'):
   tag=f'{bed}_{level}';x,z=axis(tag);yy=959 if level=='LOWER' else 925
   loads.append({'valve':tag,'mass_upper_bound_kg':10,'CG_X_mm':x,'CG_Y_mm':sign*yy,'CG_Z_mm':z,
    'gravity_N':98.1,'transport_3g_N':294.3,'stall_My_Nm':60,'strength_My_Nm':75,
    'support_Mx_3g_Nm':294.3*(yy-833.5)/1000,'M6_pattern_local_XZ_mm':'(+/-40,+/-20)',
    'installed_abs_Y_max_mm':1014 if level=='LOWER' else 980,'actuator_pull_mm':130,
    'service_abs_Y_max_mm':1144 if level=='LOWER' else 1110,
    'path':'lower: saddle -> RHS arm -> web -> bearing carrier -> M6/spacers -> bracket -> M8/crush sleeves -> Shell rail' if level=='LOWER' else
           'upper: housing M6 -> stop-plate/bracket welded sandwich -> original bracket feet -> Shell frame',
    'status':'DESIGN UPPER BOUND; actual OEM mass/CG/max torque and Shell weld/frame acceptance pending'})
 csvfile('C11_DAMPERS_ACTUATOR_LOADS.csv',loads)
 data['support']={'lower_RHS_40x20x3_I_mm4':18892,'lower_arm_3g_bending_MPa':294.3*97/1889.2,
   'lower_spacer_1_1_OD_mm':10.5,'lower_spacer_1_1_bore_mm':6.6,'lower_spacer_1_1_length_mm':28,
   'lower_spacer_M6_preload_acceptance_N':[4000,6000],
   'lower_spacer_compression_MPa':6000/(math.pi*(10.45**2-6.7**2)/4),
   'lower_arm_3g_tip_deflection_mm':294.3*97**3/(3*200000*18892),
   'upper_bracket_material':'S355, original3mm +1mm weld shim +4mm stop plate; perimeter effective a=1.2, leg>=2.7 over the1mm step',
   'upper_unperforated_3mm_strip_stress_MPa':294.3*(925-833.5)/(110*3**2/6),
   'upper_reinforced_min_net_32x8_stress_MPa':294.3*(925-833.5)/(32*8**2/6),
   'upper_sandwich_weld_shear_MPa':(294.3*(925-833.5)/5)/(1.2*2*(104+80)),
   'joint_note':'first-principles strip/weld bounds, not FE; load path into Shell and <0.2 mm relative frame deflection require Shell confirmation'}
 data['D04_retention']={'design_axial_each_direction_N':100,'proof_each_direction_N':200,'air_pressure_Pa':1000,
   'pressure_force_N':math.pi*22.5**2*.001,'M4_clamping_torque_above_prevailing_Nm':.30,'K_friction_range':[.15,.25],
   'M4_prevailing_torque_acceptance_Nm':[.03,.05],'M4_total_applied_torque_Nm':[.33,.35],
   'preload_N':[300,500],'stud_plus_service_max_N':550,'M4_tensile_MPa':550/8.78,
   'stud_weld_a_mm':.6,'stud_weld_capacity_at_90MPa_N':.6*math.pi*4*90,
   'stud_weld_combined_equivalent_stress_MPa':math.sqrt((550/(.6*math.pi*4))**2+3*(350/(2*math.pi*2**2*.6))**2),
   'load_pad_D10x1_perimeter_weld_a_mm':.4,'load_pad_weld_capacity_N':.4*math.pi*10*90,
   'sheet_punch_capacity_N':math.pi*10*1.5*77,'keeper_bending_MPa':6*50*16/(26*2**2),
   'keeper_tip_deflection_mm':4*50*16**3/(200000*26*2**3),
   'inner_keeper_weld':'two 20 mm edge seams, a=0.6, y=pipe centre +/-13, z=1082.35 to1102.35',
   'preload_path':'stud -> nut -> 2 mm keeper -> D10 pad -> stud. The rear sheet is not an unsupported preload washer.',
   'all_tests':'NOT RUN'}
 # Interface dimensions and explicit ownership.
 delta=[
  {'interface':'lower + upper bare central tips','before':'A -8 / B -7 Y; 1 mm','after':'A -12 / B -3 Y; 9 mm','tolerance':'length +/-0.15 each; installation +/-0.15 each','owner':'Dampers; upper axial location is inherited/open'},
  {'interface':'lower axial location','before':'14 mm bearing interface without defined shaft retention','after':'6006 fixed at |Y|869; D40 shoulder at |Y|857.5..862.5; A30 groove D28.6 at875.6..877.2; DU inner float','tolerance':'axial play 0.10..0.20 measured, select inner-race shim if needed','owner':'Dampers'},
  {'interface':'root steel','before':'0.602631 mm nominal','after':'R18.70 steel relief to R16.50 sleeve =2.20 mm','tolerance':'relief +0.10/-0; axis location +/-0.15; sleeve radial +/-0.05','owner':'Dampers'},
  {'interface':'upper blade','before':'end R216 / middle R220','after':'end 50 mm strips R213.60 / middle550 mm R215.60','tolerance':'profile +/-0.15; sheet1.00 +/-0.05; flatness0.20','owner':'Dampers; H01 unmoved'},
  {'interface':'upper seal overlap','before':'5.992486 end overlap','after':str(overlap_mm)+' overlap; aperture unchanged; 3.0 contact ring','tolerance':'in-plane relative closure allocation0.85','owner':'Dampers; HX allocation unsigned'},
  {'interface':'four stops','before':'two lower D6 pins / 3 mm narrow arm; no upper stops','after':'four3mm S355 arms,tongue26,R2 roots; D10 keyed pins with0.5mm contact flat; upper4mm backing+1mm weld shim','tolerance':'jig set +/-0.04 deg incl wire-EDM and pin clocking; shaft D-flat backlash<=0.10 deg; contact imprint>=12mm2','owner':'Dampers'},
  {'interface':'lower carrier spacer _1_1','before':'OD14, ID6.6, L28','after':'OD10.50, ID6.60, L28; same bolt centre and bearing span','tolerance':'OD+/-0.05, bore+0.10/-0, length+/-0.05; S355; verified M6 preload4..6kN','owner':'Dampers'},
  {'interface':'B upper drive','before':'housing Y855..965','after':'Y870..980; shaft dry end+15; A/B upper coupling inner end|Y|854.5','tolerance':'bearing, root, ports and external maximum unchanged','owner':'Dampers'},
  {'interface':'Pin pocket interface','before':'bare contact at X-506.5; Shell front return absent','after':'Pin back plane X-506.50; Shell candidate faceX-510; gap3.50; free5mm gasket; 3mm inward band','tolerance':'gap+/-0.15; free+/-0.15; flatness0.10 locally','owner':'Shell owns front closure, compression spacers and nuts; proposal reference only'},
  {'interface':'Pin pocket M4 studs','before':'none','after':'X-521.5..-506.5, Z1155; A Y-774.5/-736; B60.5/128','tolerance':'position +/-0.10; weld forbidden on removable seat perimeter except these registered stud pads','owner':'Dampers studs; Shell mating D4.5 ears'},
  {'interface':'D04 M4 preload','before':'bare stud on1.5 mm sheet','after':'D10x1 welded pad atX-502.5..-501.5; keeper D11.6x1 heel relief','tolerance':'pad thickness1.00 +/-0.05; heel relief+0.10/-0; no pipe contact','owner':'Dampers; rear sheet weld acceptance Shell'},
 ]
 csvfile('C11_DAMPERS_INTERFACE_DELTA.csv',delta)
 feedback=[]
 for tag in (f'{b}_{l}' for b in 'AB' for l in ('LOWER','UPPER')):
  for state,angle in [('P',0),('R',THETA)]:
   feedback.append({'valve':tag,'mode':state,'shaft_angle_deg':angle,'P_switch':int(state=='P'),'R_switch':int(state=='R'),
    'absolute_angle_enable_window_deg':'+/-0.25 around unloaded calibrated endpoint',
    'ports':'Pin and Pout open; Rin and Rout shut' if state=='P' else'Rin and Rout open; Pin and Pout shut',
    'logic':'both fans unloaded; speed proof + |deltaP|<=25 Pa before motion; all 4 target switches + opposite released + independent shaft angles + water ack before restart',
    'state':'encoder and control hardware not yet selected/commissioned; 80 deg switch actuation is never a travel permission'})
 csvfile('C11_DAMPERS_END_FEEDBACK.csv',feedback)
 service=json.loads((ROOT/'evidence/service.json').read_text());svc=[]
 for name,row in service['components'].items():
  svc.append({'step':name,'removed':';'.join(row['removed_or_tool_target']),'hits':json.dumps(row['penetrations']),
              'status':'geometry pass' if not row['penetrations'] else'OPEN'})
 for bed,rows in service['pin_route'].items():
  for row in rows:svc.append({'step':bed+'_'+row['step'],'vector_mm':str(row['vector']),
     'removed':';'.join(row['required_absent']),'hits':json.dumps(row['hits']),'status':'conditional: inlet floor/wrap/pocket must be demountable; roof removed'})
 csvfile('C11_DAMPERS_PIN_SERVICE_ENVELOPE.csv',svc)
 data['manufacture_release']=False
 data['open_interfaces']=['actual actuator torque/mass/temperature and full drivetrain proof',
   'H01 positioning/profile and Shell relative motion allocations not signed',
   'root lip material hot preload / dry friction / life not qualified; conservative unrestrained thermal bound does not prove contact',
   'Shell pocket/front closure and removable inlet duct joints must be integrated, not just hidden in a service scene',
   'upper inherited bearing axial location not detailed by this lower-shaft retention change',
   'physical dry fit, loaded stop proof, imprint, leak, thermal cycle and life tests not run']
 dump(ROOT/'evidence/engineering.json',data)
 print('Engineering tables written',flush=True)

if __name__=='__main__':run()
