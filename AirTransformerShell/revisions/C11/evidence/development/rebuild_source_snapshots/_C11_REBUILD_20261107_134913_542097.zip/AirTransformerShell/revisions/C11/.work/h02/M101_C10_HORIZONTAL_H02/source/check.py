"""Exact delta checks against both C10 states; retain every raw host hit."""
from common import *
from functools import lru_cache
# Broad phase for long routed tubes: union of segment boxes avoids treating
# the empty inside of an L-shaped route as filled material. Padding30 exceeds
# tube radius + bend radius + maximum tangent trim; exact booleans still follow.
_ROUTE_BOXES={}
for rr in json.loads((OUT/'ROUTES.json').read_text())['small_bore']:
    pp=rr['points_A_LOWER']; max_trim=0
    for aa,bb,cc in zip(pp,pp[1:],pp[2:]):
        u=(V(*bb)-V(*aa)).normalized();v=(V(*cc)-V(*bb)).normalized()
        max_trim=max(max_trim,6*math.tan(math.acos(max(-1,min(1,u.dot(v))))/2))
    assert max_trim+6+3<30
    for kk,placement in PLACEMENTS.items():
        dy=placement['translation'][1]+64.725;dz=placement['translation'][2]-840
        pts=[(p[0],p[1]+dy,p[2]+dz) for p in pp]
        label=rr['port']+('_VENT_HEADER_LINE' if rr['function']=='VENT' else '_DRAIN_LINE')
        _ROUTE_BOXES[kk+'__'+label]=[[min(a[i],b[i])-30 for i in range(3)]+[max(a[i],b[i])+30 for i in range(3)] for a,b in zip(pts,pts[1:])]
def screen(left,right,exclude=None):
    rb={n:bounds(s) for n,s in right.items()};hits=[];count=0
    for index,(n,s) in enumerate(left.items()):
        if index%40==0:print('screen',len(left),len(right),index,n,flush=True)
        b=bounds(s)
        for m,t in right.items():
            if n==m or (exclude and exclude(n,m)):continue
            if overlap(b,rb[m]) and (n not in _ROUTE_BOXES or any(overlap(q,rb[m]) for q in _ROUTE_BOXES[n])):
                count+=1
                try:v=s.intersect(t).Volume()
                except Exception as e:hits.append([n,m,'ERROR '+str(e)]);continue
                if v>.001:hits.append([n,m,round(v,5)])
    return {'pairs':count,'hits':hits}
def main():
    delta=read(OUT/'H02_NEW_MATERIAL.step');svc=read(OUT/'H02_WATER_SERVICE.step')
    cuts=read(OUT/'H02_HOST_OPENING_TOOLS_REFERENCE.step')
    core=read(OUT/'H02_SINGLE_CORE.step');ch=json.loads((OUT/'CHANGE_REGISTER.json').read_text())
    h01_spools=read(OUT/'H02_EIGHT_FIRST_SPOOLS.step')
    unchanged=core # full final core is the internal obstruction set
    fixed_hx={k+'__'+n:s.moved(loc(p['translation'])) for k,p in PLACEMENTS.items() for n,s in unchanged.items()}
    report={'input_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [OUT/'H02_SINGLE_CORE.step',OUT/'H02_NEW_MATERIAL.step',OUT/'H02_WATER_SERVICE.step',OUT/'H02_HOST_OPENING_TOOLS_REFERENCE.step',OUT/'H02_EIGHT_FIRST_SPOOLS.step']},'threshold_mm3':.001,'route_broadphase':'Union of segment AABBs padded30mm; each route asserts bend tangent trim+R6+OD6radius <30mm. Exact intersections follow.','states':{},'notes':['Regression scope: exact newly added material versus full final cores, first spools and both C10 hosts. Existing material is covered by RT5 baseline. Header/end-pipe drilling removes material only. Full replacement bodies are delivered separately.']}
    # Core welded collector contacts and tube-to-boss insertion remain explicitly
    # identified below. They cannot excuse any host or moving-envelope intersection.
    def joined(n,m):
        a=n.split('__');b=m.split('__')
        if a[0]!=b[0]:return False
        x,y=a[-1],b[-1]
        pair=frozenset((x,y))
        if pair in [frozenset(('H02_COND_GUTTER','H02_COND_OUTLET_D18'))]:return True
        if x[:2]!=y[:2]:return False
        pressure=frozenset((x[3:],y[3:]))
        return pressure in [frozenset(q) for q in [
            ('VENT_HEADER_LINE','D35_END_PIPE'),('VENT_NEAR_PICKUP','D35_END_PIPE'),
            ('VENT_HEADER_LINE','VENT_NEAR_PICKUP'),('DRAIN_LINE','D35_END_PIPE')]]
        return False
    canonical={n:s for n,s in delta.items() if n.startswith('A_LOWER__')}
    canonical_fixed={n:s for n,s in fixed_hx.items() if n.startswith('A_LOWER__')}
    own=screen(canonical,canonical_fixed,lambda n,m:n.removesuffix('_NEW_MATERIAL')==m or (m<=n and m in delta))
    cross=screen(delta,fixed_hx,lambda n,m:n.split('__')[0]==m.split('__')[0])
    spool=screen(delta,h01_spools)
    report['internal_scope']='One canonical unhanded core exact-tested; transformed pairs replicated to four identical occurrences. Cross-core and spool pairs exact-tested in world coordinates.'
    hits=[[n.replace('A_LOWER__',k+'__'),m.replace('A_LOWER__',k+'__'),v] for k in PLACEMENTS for n,m,v in own['hits']]
    report['internal_raw']={'pairs':own['pairs']*4+cross['pairs']+spool['pairs'],'canonical_exact_pairs':own['pairs'],'hits':hits+cross['hits']+spool['hits']}
    report['internal_unjoined']={'pairs':report['internal_raw']['pairs'],'hits':[r for r in report['internal_raw']['hits'] if not joined(r[0],r[1])]}
    dump(OUT/'evidence/CHECKS_FINAL.json',report)
    print('internal checkpoint',len(report['internal_raw']['hits']),len(report['internal_unjoined']['hits']),flush=True)
    for state in ('S1','S2'):
        host={r['name']:cq.Shape.importBrep(str(WORK/state/r['file'])) for r in json.loads((WORK/state/'index.json').read_text())}
        raw=screen(delta,host)
        # Subtract a named opening tool ONLY if it intersects a hit host part.
        # All requested cuts are a separate owner action, never a silent revision.
        candidate=dict(host); cut_records=[]
        for host_name in sorted(set(x[1] for x in raw['hits'])):
            h=host[host_name];original=h.Volume()
            # Only sheet/gasket/retainer wall penetrations, never frame/shaft/rack.
            if any(s in host_name for s in ['F_POST','C09_A_POST','SHAFT','S2_','FS_','Q_','ACTUATOR','BLADE']):continue
            for cn,c in cuts.items():
                if overlap(bounds(h),bounds(c)):
                    v=h.intersect(c).Volume()
                    if v>.001:
                        h=h.cut(c);cut_records.append({'part':host_name,'tool':cn,'removed_mm3':v})
            candidate[host_name]=h
        service=screen(svc,{**candidate,**fixed_hx,**h01_spools,**delta},lambda n,m:
            # Intended access to own valve/adapter and own hose station only.
            (n.split('__')[0].startswith(m.split('__')[0]+'_') and m.split('__')[-1].startswith(n.split('__')[0][len(m.split('__')[0])+1:]+'_') and ('CALEFFI' in m or 'ADAPTER' in m)) or
            (n==m.split('__')[0]+'__COND_HOSE_RELEASE' and m.endswith('__H02_COND_OUTLET_D18')))
        report['states'][state]={'raw_material':raw,'opening_requests':cut_records,'candidate_material':screen(delta,candidate),'service':service}
        dump(OUT/'evidence/CHECKS_FINAL.json',report)
        print(state,'raw',len(raw['hits']),'candidate',len(report['states'][state]['candidate_material']['hits']),'service',len(service['hits']),flush=True)
    motion={r['name']:cq.Shape.importBrep(str(WORK/'motion'/r['file'])) for r in json.loads((WORK/'motion/index.json').read_text())}
    report['motion_and_legacy_service']=screen(delta,motion)
    wraps={n:s for n,s in read(H01/'H01_TOOL_AND_REMOVAL.step').items() if n.endswith(('WET_BAY_COMMON_BOOT','INSULATION_SPLIT_COVER'))}
    wraps.update(read(C10/'.work/hyd/HYD_S2/W2_ADDITIONAL_INSULATION.step'))
    report['existing_insulation_intersections_for_owner_reseal']=screen(delta,wraps)
    dump(OUT/'evidence/CHECKS_FINAL.json',report)
    print('internal',len(report['internal_unjoined']['hits']),'motion',len(report['motion_and_legacy_service']['hits']),flush=True)
if __name__=='__main__':main()
