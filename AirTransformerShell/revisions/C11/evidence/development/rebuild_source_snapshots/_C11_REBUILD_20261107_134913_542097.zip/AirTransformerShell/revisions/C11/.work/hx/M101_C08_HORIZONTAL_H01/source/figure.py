"""Plot the evaluated end-pipe centerlines in installed bed-A coordinates."""
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
from matplotlib.patches import Rectangle
from build import OUT,end,RACK,FACE
fig,axes=plt.subplots(2,1,figsize=(10.5,8.5),layout='constrained')
for w,color in [('W1','#12698b'),('W2','#bc672d')]:
    path=end(w,'wire')
    points=[path.positionAt(i/300) for i in range(301)]
    gx=[644-p.z for p in points]; gy=[-64.725-p.y for p in points]
    axes[0].plot(gx,gy,color=color,lw=3,label=w)
    axes[0].plot([gx[-1],RACK],[gy[-1]]*2,color=color,ls='--',lw=3)
    for stage in [840,1175]:
        zz=[stage-p.x for p in points]
        axes[1].plot(gx,zz,color=color,lw=3)
        axes[1].plot([gx[-1],RACK],[zz[-1]]*2,color=color,ls='--',lw=3)
        axes[1].scatter(gx[-1],zz[-1],c=color,s=23)
axes[0].add_patch(Rectangle((-640,-845),80,40,fc='#526573',alpha=.5))
axes[0].add_patch(Rectangle((-640,-805),22,60,fc='#526573',alpha=.5))
axes[0].text(-635,-838,'A post',fontsize=9)
axes[0].legend(loc='upper right')
axes[0].set(title='Plan at either stage | actual end-pipe centerlines',ylabel='Machine Y (mm)',ylim=(-860,-535))
axes[1].set(title='Side elevation | four ports per bed; stage spacing 335 mm',ylabel='Machine Z (mm)',xlabel='Machine X (mm)',ylim=(480,1190))
for ax in axes:
    for x,label in [(-500,'inner wall'),(-650,'skin'),(-735,'old P0'),(RACK,'new joint')]:
        ax.axvline(x,color='#727e84',ls=':',lw=1)
        ax.text(x,ax.get_ylim()[1],label,va='top',ha='right',rotation=90,fontsize=8)
    ax.set_xlim(-890,-420)
    ax.spines[['top','right']].set_visible(False)
fig.suptitle('C08 H01 | bed A horizontal water ends and first removable spools',fontsize=15)
fig.savefig(OUT/'H01_INTERFACE.png',dpi=160)
