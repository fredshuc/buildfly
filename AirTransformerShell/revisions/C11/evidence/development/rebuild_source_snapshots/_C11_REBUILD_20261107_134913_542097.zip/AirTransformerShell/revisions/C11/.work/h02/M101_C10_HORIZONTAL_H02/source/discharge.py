"""Temporary drain/bleed hose routes and collection work zones, not operating BOM."""
from common import *
from build import pipe_route
from check import screen
rows=list(csv.DictReader((OUT/'SERVICE_AND_SHELL_PORTS.csv').open()))
shapes={};routes=[]
for r in rows:
    if r['kind']=='CONDENSATE':continue
    face=json.loads(r['sealing_shoulder'].replace('(', '[').replace(')', ']'))
    x,y,z=face;lane=-895 if r['id']=='A_UPPER_W2_DRAIN' else -850;sgn=-1 if r['id'].startswith('A_') else 1
    # One hose per station; final vessel mouths are staggered. Remove before
    # spool work and core withdrawal. Bend radius 66 mm is a candidate minimum requiring hose-maker acceptance.
    i=(0 if 'LOWER' in r['id'] else 4)+(0 if '_W1_' in r['id'] else 2)+(0 if r['kind']=='VENT' else 1)
    yy=sgn*(1160+i*25)
    pts=[(x-29,y,z),(lane,y,z-2),(lane,yy,z-12),(-1150,yy,z-17),(-1150,yy,360)]
    shapes[r['id']+'__HOSE_OD22_RESERVATION']=pipe_route(pts,11,0,bend_radius=66)
    routes.append({'id':r['id'],'polyline_vertices':pts,'OD_envelope_mm':22,'ID_provisional_mm':15,'bend_radius_candidate_mm':66,'kind':'temporary service hose reservation, confirm hose + clamp on OEM barb','receiver':'open separate labelled measuring vessel; hose mouth not immersed'})
for bed,sgn in [('A',-1),('B',1)]:
    shapes[bed+'__VESSEL_WORK_ZONE']=box(-1350,-1400 if sgn<0 else 1130,0,400,300,340)
result=save(shapes,'H02_TEMPORARY_DISCHARGE_SERVICE');dump(OUT/'evidence/DISCHARGE_BUILD.json',result);dump(OUT/'TEMPORARY_DISCHARGE_ROUTES.json',routes)
# Temporary zones are checked against physical C10 host and all H02 cores/spools.
core=read(OUT/'H02_SINGLE_CORE.step');physical={k+'__'+n:s.moved(loc(p['translation'])) for k,p in PLACEMENTS.items() for n,s in core.items() if not n.startswith(('FIN_','C0','C1','C2','C3'))}
physical.update(read(OUT/'H02_EIGHT_FIRST_SPOOLS.step'));report={}
for state in ('S1','S2'):
    host={r['name']:cq.Shape.importBrep(str(WORK/state/r['file'])) for r in json.loads((WORK/state/'index.json').read_text())}
    def own(n,m):
        core=n.split('_W')[0];port=n.split('_W')[1][0] if '_W' in n else ''
        return m.startswith(core+'__W'+port+'_') and 'CALEFFI' in m
    report[state]=screen(shapes,{**physical,**host},own)
    report[state]['input_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [OUT/'H02_SINGLE_CORE.step',OUT/'H02_EIGHT_FIRST_SPOOLS.step',OUT/'H02_TEMPORARY_DISCHARGE_SERVICE.step']}
    print(state,'discharge',len(report[state]['hits']),flush=True)
    dump(OUT/'evidence/DISCHARGE_CHECKS.json',report)
