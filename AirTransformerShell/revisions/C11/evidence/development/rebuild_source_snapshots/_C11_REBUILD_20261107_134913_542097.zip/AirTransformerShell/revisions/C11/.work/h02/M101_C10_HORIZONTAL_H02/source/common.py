"""H02 HX-only prototype detailing, mm. Parent products are immutable."""
import platform
def _no_wmi(*args): raise OSError('Process-local WMI fallback')
platform._wmi_query = _no_wmi
import sys, json, csv, math, hashlib
from pathlib import Path
import cadquery as cq
from step_io import leaves, bounds, overlap, nearest
OUT = Path(__file__).resolve().parents[1]
ROOT = OUT/'repro_inputs' if (OUT/'repro_inputs').exists() else OUT.parents[1]
H01 = ROOT/'HX/M101_C08_HORIZONTAL_H01'
C10 = ROOT/'C10_INTEGRATION_GIT/AirTransformerShell/revisions/C10'
WORK = OUT/'_work' if (OUT/'repro_inputs').exists() else ROOT/'HX_C10_H02_WORK'
V = cq.Vector
def dump(path,data): Path(path).write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf8')
def csvwrite(path,rows):
    with Path(path).open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
def read(path):
    # Cache only exact STEP imports, addressed by source SHA256. CAD assertions
    # and export readback remain independent; cache is not a design artifact.
    path=Path(path)
    if path.parent!=OUT:return {n.split('/')[-2]:s for n,s in leaves(path)}
    digest=hashlib.sha256(path.read_bytes()).hexdigest();folder=WORK/'step_cache'/digest
    index=folder/'index.json'
    if index.exists():
        rows=json.loads(index.read_text());print('Exact STEP cache',path.name,flush=True)
        return {r['name']:cq.Shape.importBrep(str(folder/r['file'])) for r in rows}
    shapes={n.split('/')[-2]:s for n,s in leaves(path)}
    folder.mkdir(parents=True,exist_ok=True);rows=[]
    for i,(n,s) in enumerate(shapes.items()):
        filename=f'{i:04d}.brep';s.exportBrep(str(folder/filename));rows.append({'name':n,'file':filename})
    dump(index,rows)
    return shapes
def box(x,y,z,dx,dy,dz): return cq.Solid.makeBox(dx,dy,dz,V(x,y,z))
def cyl(p,d,r,h):return cq.Solid.makeCylinder(r,h,V(*p),V(*d))
def tube(p,d,ro,ri,h):return cyl(p,d,ro,h).cut(cyl(p,d,ri,h))
def save(parts,name):
    print('EXPORT START',name,len(parts),flush=True)
    a=cq.Assembly(name=name)
    for n,s in parts.items():a.add(s.located(cq.Location()),name=n,loc=s.location())
    p=OUT/(name+'.step');a.save(str(p))
    print('READBACK START',name,p.stat().st_size,flush=True)
    solids=cq.importers.importStep(str(p)).val().Solids()
    unique=set(s.located(cq.Location()) for s in solids)
    assert all(s.isValid() for s in unique),name
    print('STEP',name,len(solids),'valid',flush=True)
    return {'file':p.name,'solids':len(solids),'unique':len(unique),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def sweep_poly(points,ro,ri=0):
    # Mitered routing envelope. Fabricated tube joints must follow drawing process.
    segments=[]
    for a,b in zip(points,points[1:]):
        d=V(*b)-V(*a)
        if d.Length>1e-6:segments.append(cyl(a,d.toTuple(),ro,d.Length))
    s=segments[0].fuse(*segments[1:])
    for p in points[1:-1]:s=s.fuse(cq.Solid.makeSphere(ro,V(*p),angleDegrees1=-90,angleDegrees2=90))
    if ri:
        bore=[]
        for a,b in zip(points,points[1:]):
            d=V(*b)-V(*a)
            if d.Length>1e-6:bore.append(cyl(a,d.toTuple(),ri,d.Length))
        for p in points[1:-1]:bore.append(cq.Solid.makeSphere(ri,V(*p),angleDegrees1=-90,angleDegrees2=90))
        s=s.cut(*bore)
    return s.clean()
def loc(t):return cq.Location(V(*t),V(1,0,-1),180)
PLACEMENTS=json.loads((H01/'PLACEMENTS.json').read_text())
