"""Sweep a signed translation exactly by extrusion of boundary faces (a union of end solids and face prisms).
Mating faces in contact at the start are allowed; threshold 0.001 mm3. Lift across a service plane above the rack.
python removal.py S1_DIR S2_DIR"""
from pathlib import Path
import csv,sys,json,math
from cad_io import cq,named,leaves,bb,overlaps
from OCP.BRepPrimAPI import BRepPrimAPI_MakePrism
from OCP.gp import gp_Vec
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib
def bounds(s):b=Bnd_Box();BRepBndLib.Add_s(s.wrapped,b,False);return b.Get()
src,out=map(Path,sys.argv[1:]);rack=named(out/'S2_RACK.step')
# Common fixed steel, excluding moving H01 bodies after specified unjointing.
S={state:dict(leaves(src/('H01_INSTALLED_'+state+'.step'))) for state in ['S1','S2']}
obs={n:s for state,gg in S.items() for n,s in gg.items() if '/HOST/' in n or '/H01_FOUR_CORES/' in n or '/FIRST_SPOOLS/' in n}
obs.update(rack);boxes={n:bounds(s) for n,s in obs.items()}
def step(s,v,ignore):
 a=bounds(s);cover=[a[i]+min(v[i],0) for i in range(3)]+[a[i+3]+max(v[i],0) for i in range(3)]
 hits=[];elig=[(k,t) for k,t in obs.items() if k not in ignore and overlaps(cover,boxes[k])]
 if not elig:return hits
 seg=[s,s.translate(v)]
 for f in s.Faces():
  try:
   o=cq.Shape.cast(BRepPrimAPI_MakePrism(f.wrapped,gp_Vec(*v)).Shape())
   if o.Volume()>.001:seg+=o.Solids()
   elif o.Solids() and abs(o.Volume())>.001:seg += [cq.Shape.cast(x.wrapped.Reversed()) for x in o.Solids()]
  except:raise
 for k,t in elig:
  for w in seg:
   if overlaps(bounds(w),boxes[k]):
    vv=abs(w.intersect(t).Volume())
    if vv>.001:hits.append([k,round(vv,3)]);break
 return hits
def solve(tag,shape,ignore,patterns):
 reasons=[]
 for path in patterns:
  pos=shape
  for v in path:
   hits=step(pos,v,ignore)
   if hits:reasons.append(hits[0]);break
   pos=pos.translate(v)
  else:return {'moves_mm':path,'pass':True}
 return {'pass':False,'test_hits':reasons[:15]}
report={}
for b in 'AB':
 # Separate the two H01 boot halves and remove both working H01 centre sections per HX instructions.
 # Moving rack-side tail stays with pipe; fixed HX tail remains an obstacle. Other two ports untouched.
 work=['FS_Q','LOW_W2_FS','Q_UP_W1'];removed=set()
 for name in work:
  tag=b+'_'+name;shape=rack[tag];bonded=[]
  ignore={tag,*removed}
  for hxport in (b+'_L_W2',b+'_U_W1'):
   for k,v in obs.items():
    if hxport+'__' in k and '/FIRST_SPOOLS/' in k and 'FIXED_HX_TAIL' not in k:
     ignore.add(k)
     if 'FIXED_RACK_TAIL' in k and ((name=='LOW_W2_FS' and 'L_W2' in hxport) or (name=='Q_UP_W1' and 'U_W1' in hxport)):bonded.append(v)
     elif 'FIXED_RACK_TAIL' in k and k not in removed:
      # Tail for the other still-present end pipe remains fixed.
      if name=='FS_Q' or (name=='LOW_W2_FS' and 'U_W1' in hxport) or (name=='Q_UP_W1' and 'L_W2' in hxport):ignore.discard(k)
  if bonded:shape=cq.Compound.makeCompound([shape]+bonded)
  sign=1 if name=='FS_Q' else -1
  pats=[[(0,sign*dy,0),(0,0,1150)] for dy in [12,42,80,125,180,225,290,390,510]]
  # Clearing a single component in maintenance may require a horizontal intermediate offset.
  pats+= [[(0,sign*dy,0),(dx,0,0),(0,0,1150)] for dy in [16,45,85,125,180] for dx in [-65,65,-145,145]]
  got=solve(tag,shape,ignore,pats);report[tag]=got;print(tag,got,flush=True)
  if not got['pass']:break
  removed.add(tag)
  for k in ignore:
   if 'FIXED_RACK_TAIL' in k and bonded and (('L_W2' in k and name=='LOW_W2_FS') or ('U_W1' in k and name=='Q_UP_W1')):removed.add(k)
(out/'spool_service.json').write_text(json.dumps(report,indent=2))
