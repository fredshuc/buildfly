"""Package a review candidate only after geometry checks; never releases manufacture."""
import json,hashlib,zipfile,os,csv
from pathlib import Path
OUT=Path(__file__).resolve().parents[1]
ROOT=OUT/'repro_inputs' if (OUT/'repro_inputs').exists() else OUT.parents[1]
def read(n):return json.loads((OUT/n).read_text(encoding='utf8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,d):(OUT/n).write_text(json.dumps(d,indent=2,ensure_ascii=False),encoding='utf8')
build=read('evidence/BUILD.json');check=read('evidence/CHECKS_FINAL.json');spool=read('evidence/SPOOL_CHECKS.json')
flow=read('evidence/BRANCH_FLOW_CHECK.json');support=read('evidence/COLLECTOR_SUPPORT_CHECK.json');four=read('evidence/FOUR_CORE_READBACK.json')
mat=read('evidence/MATING_LAND.json');discharge=read('evidence/DISCHARGE_CHECKS.json')
for file,digest in check['input_sha256'].items():assert sha(OUT/file)==digest,('stale final check',file)
assert flow['core_sha256']==sha(OUT/'H02_SINGLE_CORE.step')
assert support['core_sha256']==sha(OUT/'H02_SINGLE_CORE.step')
for r in read('evidence/MATERIAL_CHANGE.json'):
    v=r.get('source_construction_verification')
    if v:
        assert r['core_sha256']==sha(OUT/'H02_SINGLE_CORE.step') and r['added_mm3']<.001
        assert v['max_vertex_gap_mm']<1e-5 and v['volume_delta_mm3']<.001
        assert all(f['center_gap_mm']<1e-5 and f['area_delta_mm2']<.001 and f['max_surface_sample_gap_mm']<1e-5 for f in v['face_checks'])
assert four['sha256']==sha(OUT/'H02_FOUR_HX_INSTALLED.step')
assert four['core_sha256']==sha(OUT/'H02_SINGLE_CORE.step')
for r in build['exports']:assert r['sha256']==sha(OUT/r['file'])
assert all(n==build['single_core_parts'] for n in four['counts'].values())
assert all(isinstance(r[2],(int,float)) for r in check['internal_raw']['hits']), 'Internal Boolean error must not be hidden by joint allowance'
assert not check['internal_unjoined']['hits'],check['internal_unjoined']
assert not check['motion_and_legacy_service']['hits']
for state,r in check['states'].items():
    assert not r['candidate_material']['hits'],(state,r['candidate_material'])
    assert not r['service']['hits'],(state,r['service'])
for r in spool['states'].values():
    for key in ('host_material','core_material','service'):assert not r[key]['hits']
assert not spool['internal']['hits']
assert set(discharge)=={'S1','S2'}
assert all(not r['hits'] for r in discharge.values())
for r in discharge.values():
    for file,digest in r['input_sha256'].items():assert sha(OUT/file)==digest
vessel=read('evidence/VESSEL_EXCLUDED_REGION_CHECK.json');assert not vessel['hits'] and not vessel['motion_AABB_hits']
assert all(abs(r['frame_contact_fraction']-1)<1e-8 and r['core_sha256']==sha(OUT/'H02_SINGLE_CORE.step') for r in mat)
for file,digest in spool['input_sha256'].items():assert sha(OUT/file)==digest
assert support['all_nominal_gaps_le_1um']
assert all(r['actual_open_cavity_connected_solids']==1 and r['clear_bore_gauge_connected_solids']==1 and not r['clear_bore_gauge_obstructions'] for r in flow['branches'].values())
register=list(csv.DictReader((OUT/'FUNCTIONAL_28_REGISTER.csv').open(encoding='utf8')));assert len(register)==28
from collections import Counter
assert sorted(Counter(r['category'] for r in register).values())==[4,8,8,8]
summary={'status':'HX_ENGINEERING_REVIEW_CANDIDATE_ONLY','manufacture_released':False,'single_bed_cold_flow_released':False,'wet_function_confirmed':False,'physical_tests_passed':None,
 'single_core_solids':build['single_core_parts'],'four_core_solids':dict(four['counts']),'first_spool_solids':160,
 'functional_counts':dict(Counter(r['category'] for r in register)),
 'raw_host_intersections':{s:len(r['raw_material']['hits']) for s,r in check['states'].items()},
 'conditional_host_intersections':{s:len(r['candidate_material']['hits']) for s,r in check['states'].items()},
 'water_service_intersections':{s:len(r['service']['hits']) for s,r in check['states'].items()},
 'counterhold_min_mm':min(spool['counterhold_gaps_mm'].values()),'gasket_nominal_contact_fraction':1,
 'branch_minimum_clear_bore_mm':3.8,'collector_contact_samples':len(support['contact_samples']),
 'open_conditions':['Shell/D04 sealed penetrations, mounting reactions and insulation reseal; downstream four independent condensate traps/lines/receptors','Full core withdrawal with split glands and released service blocks not yet integrated','Actual gasket curve, frame material/joining and permissible clamp force; proposed seat/stop change not applied to Shell','Pressure PS, R/Rp gauges, brazing, small-tube bends/thermal flexibility, custom spool sealing/retention and proof/cycles','Residual-water and wet condensate capture/reverse-air tests; actual coated-core + collector air resistance','Inherited1.2119mm damper gap tolerance/thermal stack; rack support and provisional nozzle-load qualification']}
dump('VALIDATION_SUMMARY.json',summary)
text='# H02 最终检查记录\n\n本文件由 source/release.py 从结果生成。状态为 HX 工程复审候选，不放行承压制造、切板、热水或双床制造。\n\n'
text+='单芯 %d 个有效实体，四个位置复用同件，共 %d 个。八首段 160 个实体。\n\n'%(build['single_core_parts'],sum(four['counts'].values()))
text+='|检查|结果与边界|\n|---|---|\n'
text+='|28 项分类|8 排气 + 8 新水排 + 8 原封口组 + 4 凝水|\n'
text+='|C10 原样实体|S1 %d 对，S2 %d 对需要处理的相交；均保留原始记录|\n'%(summary['raw_host_intersections']['S1'],summary['raw_host_intersections']['S2'])
text+='|候选开孔条件|S1/S2 剩余实体相交 0；原 Shell/D04 文件没有改写，不能把这一行当成原样装机零冲突|\n'
text+='|水阀操作与临时排液|两态相交 0；临时软管实际型号、夹紧和 bend radius 待确认|\n'
text+='|首段|内部、两态装机及拆装范围相交 0；双扳名义最小距 %.2f mm|\n'%summary['counterhold_min_mm']
text+='|排气/排水腔|四类支路均为一个连续净腔，Ø3.8 连续通径无金属阻挡；不是实测放气/残液结果|\n'
text+='|密封 land|四芯各 41741.78 mm² 的名义垫片足迹得到支承；平整度和夹紧力需实测|\n'
text+='|集水支承|%d 个叶片/辅助槽接触点及各托轨段到框架接触通过；不是焊缝验收|\n'%len(support['contact_samples'])
text+='|运动|新增材料与 82 个 D03 运动/服务参考无相交；原有 1.2119 mm 公差/热态问题保留|\n'
text+='\n源输入和差分范围见 evidence/CHECKS_FINAL.json。检查阈值 0.001 mm³；只对命名的连接/焊口保留接合例外。气侧隔汽层穿越单独列出，不被当成无冲突。\n\n未完成项目见 TASK_DISPOSITION.csv 和 VALIDATION_SUMMARY.json。T 级物理试验仍为空；正式允许夹紧力与整套 PS 未签发。\n'
(OUT/'CHECK_REPORT_CN.md').write_text(text,encoding='utf8')
def csvout(name,rows):
    if not rows:return
    with (OUT/name).open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
intercepts=[]
for state,r in check['states'].items():
    for a,b,v in r['raw_material']['hits']:
        intercepts.append({'state':state,'HX_part':a,'host_part':b,'raw_overlap_mm3':v,'resolution':'only cleared in conditional named-opening model; original host unchanged','owner_acceptance':'sealed penetration/fastener hole and local strength; see opening_requests in CHECKS_FINAL.json'})
csvout('HOST_INTERCEPTS_TO_RESOLVE.csv',intercepts)
csvout('INSULATION_RESEAL_REQUEST.csv',[{'HX_part':a,'existing_wrap':b,'overlap_mm3':v,'required_action':'split or formed pass-through plus continuous vapour seal; no cold bare-metal path; owner detail required'} for a,b,v in check['existing_insulation_intersections_for_owner_reseal']['hits']])

# Manifest covers all shipped design files and exact external reconstruction inputs.
files=[]
for p in sorted(OUT.rglob('*')):
    if not p.is_file() or any(x in p.parts for x in ('__pycache__','_work','repro_inputs')):continue
    if p.name in ('MANIFEST_SHA256.json','PACKAGE_RECEIPT.json') or p.suffix in ('.zip','.pyc'):continue
    files.append((p,p.relative_to(OUT).as_posix()))
for row in read('INPUT_PROVENANCE.json')['files']:
    rel=row['workspace_relative_path']
    if rel.startswith('HX/M101_C10_HORIZONTAL_H02/'):continue
    p=ROOT/rel;assert sha(p)==row['sha256'],('input changed',rel)
    files.append((p,'repro_inputs/'+rel))
manifest=[{'path':rel,'bytes':p.stat().st_size,'sha256':sha(p)} for p,rel in files]
dump('MANIFEST_SHA256.json',manifest)
archive=OUT.parent/'HX_M101_C10_H02_RETURN_20261107.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p,rel in files:z.write(p,OUT.name+'/'+rel)
    z.write(OUT/'MANIFEST_SHA256.json',OUT.name+'/MANIFEST_SHA256.json')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in manifest:
        assert hashlib.sha256(z.read(OUT.name+'/'+row['path'])).hexdigest()==row['sha256'],row['path']
receipt={'file':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'entries':len(files)+1,'zip_crc':'PASS','all_manifest_readbacks':'PASS','status':summary['status']}
dump('PACKAGE_RECEIPT.json',receipt)
print(json.dumps(receipt,ensure_ascii=False),flush=True)
