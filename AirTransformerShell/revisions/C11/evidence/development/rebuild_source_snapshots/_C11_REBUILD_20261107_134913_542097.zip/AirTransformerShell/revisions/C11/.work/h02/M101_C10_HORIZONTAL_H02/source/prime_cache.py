from common import *
core=read(OUT/'H02_SINGLE_CORE.step')
print('Exact STEP import cached',len(core),flush=True)
