"""C11 independently supported water-island candidate. Global millimetres.
Dimensioned custom parts, not supplier internal geometry. No pressure release.
"""
from pathlib import Path
import sys,json,csv,math
from cad_io import cq,named,bb,clashes
P=Path(__file__).resolve().parents[1]; ROOT=P.parents[1]; WORK=ROOT.parent/'c11_input'
OUT=P/'cad';OUT.mkdir(exist_ok=True);EV=P/'evidence';EV.mkdir(exist_ok=True)
rack=named(WORK/'s2/HYD_S2/S2_RACK.step');v=cq.Vector
parts={};materials={};supports=[];joints=[]
def box(x,y,z,a,b,c):return cq.Solid.makeBox(a,b,c,v(x,y,z))
def cyl(p,q,r):a=v(*p);d=v(*q)-a;return cq.Solid.makeCylinder(r,d.Length,a,d.normalized())
def put(n,s,mat='steel'):assert s.isValid(),n;parts[n]=s;materials[n]=mat;return s
def tube(n,p,q,w=40,h=40,t=3):
 d=v(*q)-v(*p);s=cq.Workplane(cq.Plane(origin=p,normal=d.normalized())).rect(w,h).rect(w-2*t,h-2*t).extrude(d.Length).val();return put(n,s)
def bolt(n,x,y,z,L=35,d=8):
 put(n+'_SHANK',cyl((x,y,z),(x,y,z+L),d/2));put(n+'_HEAD',cq.Workplane('XY',origin=(x,y,z+L)).polygon(6,d*1.85).extrude(d*.65).val())
 put(n+'_NUT',cq.Workplane('XY',origin=(x,y,z)).polygon(6,d*1.85).circle(d/2).extrude(d*.8).val())
def export(dic,path):
 a=cq.Assembly(name=path.stem)
 for n,s in dic.items():a.add(s,name=n,color=cq.Color(*((.15,.2,.24) if materials.get(n)=='PIR' else (.65,.70,.74))))
 a.save(str(path))
def writecsv(p,rows):
 with p.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
# Six foot interfaces, bolted to Shell's future extension, not directly to thin floor.
feet=[]
for i,(x,y) in enumerate([(x,y) for x in [-1660,-780] for y in [-1180,-100,680]],1):
 plate=box(x-60,y-50,122,120,100,10)
 for xx in [x-40,x+40]:
  for yy in [y-30,y+30]:
   cut=cq.Workplane('XY',origin=(xx,yy,121)).slot2D(34,14,angle=0).extrude(12).val();plate=plate.cut(cut)
 put(f'FOOT_{i}',plate);tube(f'FOOT_{i}_RISER',(x,y,132),(x,y,170),60,60)
 feet.append(dict(id=f'IF-01-F{i}',x_mm=x,y_mm=y,z_mm=122,normal='0 0 -1',holes='4 x 14x34 X slots; offsets (+/-40,+/-30)',adjust_X_mm=10,adjust_Y_mm=0,adjust_Z_mm='0..5 shims',interface='Shell below Z122; Hydronics above; M12 bolts by Shell',status='candidate; reactions in load_cases.csv'))
# 60 deep by40 wide rails, end-butt crossmembers avoid solid duplication.
for i,x in enumerate([-1660,-1220,-780]):tube(f'RAIL_Y{i}',(x,-1230,200),(x,730,200),40,60)
for j,y in enumerate([-1180,-100,680]):
 for k,(x0,x1) in enumerate([(-1640,-1240),(-1200,-800)]):tube(f'RAIL_X{j}_{k}',(x0,y,200),(x1,y,200),60,40)
# Each local column sits on its own crossbar at Z280; welded saddle submodules.
cross_y=set()
def stand(tag,x,y,top,dx=0,dy=0):
 cy=round(y+dy,3)
 if cy not in cross_y:
  cross_y.add(cy)
  tube(f'CROSS_{cy}',(-1660,cy,280),(-780,cy,280),40,40)
  for k,xx in enumerate([-1660,-1220,-780]):tube(f'CROSS_{cy}_LEG{k}',(xx,cy,230),(xx,cy,260),40,40)
 # offset column where lower pipes obstruct a direct riser
 tube(tag+'_POST',(x+dx,y+dy,310),(x+dx,y+dy,top-20 if dx or dy else top),40,40)
 plate=box(x+dx-45,y+dy-22,300,90,44,10)
 for bx in [x+dx-30,x+dx+30]:
  for by in [y+dy-12,y+dy+12]:
   cutter=cyl((bx,by,250),(bx,by,320),5.5);plate=plate.cut(cutter)
   parts[f'CROSS_{cy}']=parts[f'CROSS_{cy}'].cut(cutter)
   bolt(tag+f'_BASE_{bx}_{by}',bx,by,255,60,10)
 put(tag+'_BASE_FLANGE',plate)
 if dy:put(tag+'_Y_ARM',box(x-20,min(y+dy,y),top-30,40,abs(dy),20).cut(box(x-17,min(y+dy,y)-1,top-27,34,abs(dy)+2,14)))
 if dx:put(tag+'_ARM',box(min(x+dx,x),y-20,top-30,abs(dx),40,20).cut(box(min(x+dx,x)-1,y-17,top-27,abs(dx)+2,34,14)))
 if dx or dy:tube(tag+'_CAP_RISER',(x,y,top-10),(x,y,top),40,40)
 put(tag+'_PLATE',box(x-60,y-40,top,120,80,6))
# Custom insulated cradle, two part pressure-free clamp, steel outside insulation.
# Actual pressure-component silhouette retained; fitting manufacturer contact approval is open.
def cradle(tag,target,x,y,ax,contactZ,span=60,dx=0,dy=0):
 s=rack[target]; base=contactZ-30; stand(tag,x,y,base-6,dx,dy)
 # 30mm lower bearing, cavity cut from exact installed outer dimension model.
 block=box(x-55,y-span/2,base,110,span,60).cut(s)
 low=block.intersect(box(x-60,y-span/2,base,120,span,45))
 # lower bearing alone is removable upward after tethered support engaged
 put(tag+'_BEARING',low,'PIR')
 for sign in [-1,1]:
  put(tag+f'_SIDE{sign}',box(x+sign*53-2,y-span/2,base-3,4,span,35))
  bolt(tag+f'_CLAMP{sign}',x+sign*48,y,base-6,24)
 supports.append(dict(id=tag,target=target,x=x,y=y,z=contactZ,axis=ax,type='custom insulated removable cradle',boundary='gravity; axial sliding; positive transport restraint separate',rated_N='OPEN: custom bearing creep/proof test',contact='current outer-dimension model; actual body contact permission required'))
# Selector bodies. Two elevations share Y; raise upper support on offset column.
for b,y0 in [('A',-720),('B',145)]:
 for name,y,z,dx in [('CS',y0,570,0),('CR',y0+150,625,0)]:
  cradle(b+'_SUP_'+name,b+'_XV_'+name,-1162,y,'X',z,60,dx)
 cradle(b+'_SUP_FS','FS_'+b,-930,y0+305,'Y',616.85,60)
 cradle(b+'_SUP_Q','Q_'+b,-824,y0,'Y',716.188,60,0,-100)
# Commercial PIR30 clamp dimensional envelope; custom fastener detail not claimed vendor CAD.
# Split bearing+band+ears+two bolts, 75 axial, continuous insulation.
def pipeclamp(tag,target,x,y,z,od=33.7,axis='Y'):
 R=od/2+30; L=75
 if axis!='Y':raise ValueError(axis)
 ann=cyl((x,y-L/2,z),(x,y+L/2,z),R).cut(cyl((x,y-L/2-1,z),(x,y+L/2+1,z),od/2+.15))
 for name,z0,dz in [('LOW',z-R,R),('CAP',z,R)]:put(tag+'_PIR_'+name,ann.intersect(box(x-R-1,y-L/2-1,z0,2*R+2,L+2,dz)),'PIR')
 band=cyl((x,y-12.5,z),(x,y+12.5,z),R+3).cut(cyl((x,y-13,z),(x,y+13,z),R))
 for name,z0,dz in [('LOW',z-R-3,R+3),('CAP',z,R+3)]:put(tag+'_BAND_'+name,band.intersect(box(x-R-4,y-13,z0,2*R+8,26,dz)))
 for sign in [-1,1]:
  ear=box(x+sign*(R+9)-9,y-12.5,z-3,18,25,6).cut(cyl((x+sign*(R+9),y,z-4),(x+sign*(R+9),y,z+4),4.5));put(tag+f'_EAR{sign}',ear);bolt(tag+f'_BOLT{sign}',x+sign*(R+9),y,z-9,24)
 stand(tag,x,y,z-R-9,dx=-90 if tag.startswith('HDR_HS') else 0,dy=80 if 'PIPE_MID' in tag else 0)
 supports.append(dict(id=tag,target=target,x=x,y=y,z=z,axis=axis,type='PIR30 split insulated pipe clamp; project reconstruction',boundary='axial slide +/-4mm; radial gravity support',rated_N='320 catalog envelope reference; custom hardware not certified as vendor product',contact='pipe OD+0.30 diametral clearance; foil/vapour joint'))
for b,y0 in [('A',-720),('B',145)]:
 pipeclamp(b+'_PIPE_MID',b+'_FS_Q',-824,y0+200,750)
 pipeclamp(b+'_PIPE_UP',b+'_Q_UP_W1',-930,y0-120,895)
# Hot headers and cold twin saddles.
for j,y in enumerate([-800,-100]):
 pipeclamp('HDR_HS_'+str(j),'HEADER_HS',-1400,y,789,42.4)
 pipeclamp('HDR_HR_'+str(j),'HEADER_HR',-1570,y,850,42.4)
 tag='HDR_COLD_TWIN_'+str(j);x=-1400;z0=570
 stand(tag,x,y,z0-6)
 body=box(x-55,y-37.5,z0,110,75,160)
 for zz in [622,677]:body=body.cut(cyl((x,y-38,zz),(x,y+38,zz),21.35))
 # split in X so replacement does not require sliding over a header elbow
 for side,x0 in [('L',x-55),('R',x)]:put(tag+'_'+side,body.intersect(box(x0,y-37.5,z0,55,75,160)),'PIR')
 for yy in [y-30,y+30]:
  put(tag+f'_STRAP_{yy}',box(x-58,yy-4,z0-3,116,8,3));bolt(tag+f'_BOLT_{yy}_L',x-48,yy,z0-6,35);bolt(tag+f'_BOLT_{yy}_R',x+48,yy,z0-6,35)
 supports.append(dict(id=tag,target='HEADER_CS+HEADER_CR',x=x,y=y,z=649.5,axis='Y',type='custom two-bore PIR cradle; independent removable halves',boundary='both pipes axial sliding; no pressure grip',rated_N='OPEN: 2 x 175 N design requirement',contact='42.7 bores, 55mm pitch; external 30.8mm minimum insulation'))
for tag,target,x,z in [('TA_C','TA_CR',-1400,649),('TA_H','TA_HR',-1570,822)]:cradle(tag,target,x,-1045,'Y',z,80)
writecsv(P/'C11_HYD_SUPPORT_INTERFACES.csv',feet);writecsv(P/'SUPPORT_REGISTER.csv',supports)
export(parts,OUT/'C11_HYD_RACK_SUPPORT.step')
json.dump({n:{'material':materials[n],'volume_mm3':s.Volume(),'cg_mm':s.Center().toTuple(),'bbox':bb(s)} for n,s in parts.items()},open(EV/'support_parts.json','w'),indent=2)
hits=clashes(parts,rack);json.dump({'rack_hits':hits,'count':len(parts)},open(EV/'rack_screen.json','w'),indent=2)
print('parts',len(parts),'rack hits',hits,flush=True)
