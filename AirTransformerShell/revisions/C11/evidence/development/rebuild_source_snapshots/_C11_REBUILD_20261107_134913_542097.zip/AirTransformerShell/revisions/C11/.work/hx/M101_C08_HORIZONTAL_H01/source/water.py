"""Nominal HX water topology and branch-length handoff to L2-E (mm, L, kPa)."""
import csv,json,math,hashlib
from build import OUT,BASE,P0,FACE,RACK,end,csvwrite,cq,V
def rows(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def main():
    inputs=json.loads((P0/'SHA256.json').read_text(encoding='utf-8-sig'))
    for n,h in inputs.items():
        assert hashlib.sha256((P0/n).read_bytes()).hexdigest()==h,n
    h00=cq.importers.importStep(str(BASE/(BASE.name+'_NOMINAL_FLOW.step'))).val()
    retained=h00.intersect(cq.Solid.makeBox(500,850,1080,V(0,0,0)))
    shape=retained.fuse(end('W1',True),end('W2',True)).clean()
    assert len(shape.Solids())==1 and shape.isValid()
    new_core=shape.Volume()/1e6
    Q=rows(OUT/'EIGHT_PORTS_AND_SPOOLS.csv')
    lengths={s['tag']:(float(s['spool_length_mm']),float(s['trim_existing_P0_straight_mm'])) for s in Q}
    segtag={'lower_W1_endpoint':'L_W1','lower_W2_to_FS1':'L_W2','Q2_to_upper_W1':'U_W1','upper_W2_endpoint':'U_W2'}
    new=[]
    for r in rows(P0/'branch_pressure.csv'):
        k=segtag.get(r['segment'])
        L,trim=lengths[r['bed']+'_'+k] if k else (0.,0.)
        mm=float(r['known_length_mm'])+L-trim
        assert mm>0
        new.append(dict(bed=r['bed'],mode=r['mode'],segment=r['segment'],Q_m3h=r['Q_m3h'],T_C=r['T_C'],
                        P0_length_mm=r['known_length_mm'],remove_mm=trim,add_mm=L,new_length_mm=round(mm,3),
                        straight_L=round(mm*.001*float(r['per_extra_m_L']),6),
                        straight_kPa=round(mm*.001*float(r['per_extra_m_kPa']),5),kPa_per_K=r['per_K_kPa']))
    csvwrite(OUT/'L2E_BRANCH_DELTA.csv',new)
    result={}
    for mode in ('cold','hot'):
        act=[r for r in new if r['bed']=='A' and r['mode']==mode and float(r['Q_m3h'])==2 and float(r['T_C'])==(5 if mode=='cold' else 80)]
        assert len(act)==5
        liquid=2*new_core+sum(r['straight_L'] for r in act)
        result[mode]=dict(per_bed_active_L=liquid,ideal_displacement_s_at_2m3h=liquid*1.8,
                          series_connection_pipe_straight_kPa=sum(r['straight_kPa'] for r in act))
    d=dict(H00_nominal_core_L=h00.Volume()/1e6,H01_nominal_core_L=new_core,H01_series_core_L=2*new_core,connected_valid_water_solids=1,
           scope='Ideal ID28 continuation through OEM, ID4 bleed/drain bores, nominal ID27.3 external spools. Valve/FS/Q cavities, stepped spool cavities and local K excluded. This is an inventory and straight-pipe screen.',
           per_bed=result)
    (OUT/'WATER_CHECK.json').write_text(json.dumps(d,indent=2))
    print(d)
if __name__=='__main__':main()
