"""Compose four AP214 assemblies without expanding the owner's repeated fins.
Run python compact.py HX_DIR C09R1_DIR OUTPUT STATE; read back the complete hierarchy."""
from pathlib import Path
import csv,json,sys,re,warnings,hashlib
from cad_io import cq,leaves,bb
warnings.filterwarnings('ignore',category=FutureWarning)
hx,host,out=map(Path,sys.argv[1:4]);state=sys.argv[4]
cuts=list(csv.DictReader((hx/'HOST_CUT_PROPOSAL.csv').open()))
tmp=out/('_shell_'+state+'.step');target=out/('HYD_S2_INSTALLED_'+state+'.step')
files=[tmp,hx/'H01_FOUR_HX_INSTALLED.step',out/'S2_RACK.step',hx/'H01_EIGHT_FIRST_SPOOLS.step']
if '--verify-only' not in sys.argv:
 a=cq.Assembly(name='SHELL_AND_D03_'+state)
 for path,s in leaves(host/('C09R1_INSTALLED_'+state+'.step')):
  name=path.split('/')[-2]
  if '/HEAT_EXCHANGERS' in path:continue
  if '/SHELL' in path:
   b=bb(s);pl='SKIN' if abs(b[0]+650.8)<.01 and abs(b[3]+649.3)<.01 else 'INNER' if abs(b[0]+501.5)<.01 and abs(b[3]+500)<.01 else ''
   if pl and 'SPLIT_GLAND' not in name:
    s=s.cut(*[cq.Solid.makeCylinder(float(r['diameter_mm'])/2,4,cq.Vector(float(r['cut_from_x']),float(r['y_mm']),float(r['z_mm'])),cq.Vector(1,0,0)) for r in cuts if r['layer']==pl])
  a.add(s,name=name)
 tmp=out/('_shell_'+state+'.step');a.save(str(tmp));del a
 files=[tmp,hx/'H01_FOUR_HX_INSTALLED.step',out/'S2_RACK.step',hx/'H01_EIGHT_FIRST_SPOOLS.step']
 template=(hx/'H01_FOUR_HX_INSTALLED.step').read_bytes()
 head,rest=template.split(b'DATA;\n',1);root=rest.split(b'#37 =',1)[0]
 # Keep original root's global unit system/axes; make all child placements identity.
 root=root.replace(b'FOUR_HORIZONTAL_HX',('C09R1_HYD_H01_'+state).encode())
 for n in [16,20,24,28]:
  for j,kind,val in [(n,b'CARTESIAN_POINT',b'0.,0.,0.'),(n+1,b'DIRECTION',b'0.,0.,1.'),(n+2,b'DIRECTION',b'1.,0.,0.')]:
   root=re.sub(rb'#'+str(j).encode()+rb" = "+kind+rb"\('',\([^)]*\)\);",b'#'+str(j).encode()+b' = '+kind+b"('',("+val+b"));",root)
 def shift(raw,idx):
  # All global reference identifiers are discrete STEP #integers in these OCC exports.
  return re.sub(rb'#(\d+)',lambda m:b'#'+str(int(m[1])+idx).encode(),raw)
 target=out/('HYD_S2_INSTALLED_'+state+'.step')
 with target.open('wb') as w:
  w.write(head+b'DATA;\n'+root)
  for k,p in enumerate(files):
   dat=p.read_bytes().replace(b'\r\n',b'\n').split(b'DATA;\n',1)[1].rsplit(b'ENDSEC;',1)[0]
   assert re.search(rb'#3 = SHAPE_DEFINITION_REPRESENTATION\(#4,#10\)',dat) and b'#11 = AXIS2_PLACEMENT_3D' in dat
   ids=[int(x) for x in re.findall(rb'^#(\d+) =',dat,re.M)];idx=(k+1)*1000000
   assert max(ids)<1000000
   w.write(shift(dat,idx))
   unit=200+5*k; child=['HOST','H01_FOUR_CORES','WATER_RACK','FIRST_SPOOLS'][k]
   link=f"""
 #{unit} = CONTEXT_DEPENDENT_SHAPE_REPRESENTATION(#{unit+1},#{unit+3});
 #{unit+1} = ( REPRESENTATION_RELATIONSHIP('','',#{idx+10},#10) REPRESENTATION_RELATIONSHIP_WITH_TRANSFORMATION(#{unit+2}) SHAPE_REPRESENTATION_RELATIONSHIP() );
 #{unit+2} = ITEM_DEFINED_TRANSFORMATION('','',#{idx+11},#{15+k*4});
 #{unit+3} = PRODUCT_DEFINITION_SHAPE('Placement','Placement of an item',#{unit+4});
 #{unit+4} = NEXT_ASSEMBLY_USAGE_OCCURRENCE('{k+1}','{child}','',#5,#{idx+5},$);
 """
   w.write(link.encode())
  w.write(b'ENDSEC;\nEND-ISO-10303-21;\n')
from collections import Counter
names=Counter();boxes={};rawcount=0
for p,s in leaves(target):
 group=next((k for k in ['HOST','H01_FOUR_CORES','WATER_RACK','FIRST_SPOOLS'] if k in p.split('/')),None)
 assert group,(p,'unattached product')
 names[group]+=1;rawcount+=1
 # Verify every installed HX origin relative to primary H01, using all world-space BRep placements, not local fin bounds.
 if group=='H01_FOUR_CORES':boxes[p.split('H01_FOUR_CORES/',1)[1]]=s.location().toTuple()
expect={'HOST':724,'H01_FOUR_CORES':2204,'WATER_RACK':36,'FIRST_SPOOLS':72}
assert names==expect,(names,expect)
orig={p:s.location().toTuple() for p,s in leaves(files[1])}
def suffix(p):return p[p.index('FOUR_HORIZONTAL_HX/'):]
got={suffix(p):v for p,v in boxes.items()};want={suffix(p):v for p,v in orig.items()};assert got.keys()==want.keys()
err=max(abs(a-b) for k in got for t1,t2 in zip(got[k],want[k]) for a,b in zip(t1,t2));assert err<1e-5,err
reportpath=out/('installed_'+state+'.json');report={};report.update(exported_installed_leaves=rawcount,verified_groups=names,H01_world_location_max_difference_mm_or_degree=err);reportpath.write_text(json.dumps(report,indent=2))
tmp.unlink(missing_ok=True);print(state,dict(names),'bytes',target.stat().st_size,flush=True)
