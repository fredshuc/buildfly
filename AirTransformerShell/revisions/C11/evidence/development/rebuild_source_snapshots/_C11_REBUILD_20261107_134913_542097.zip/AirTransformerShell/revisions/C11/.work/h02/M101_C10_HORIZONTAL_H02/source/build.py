"""H02: one horizontal product, accessible bleed/drain valves, gravity collector.
Nominal pressure geometry is a prototype drawing, not a rated product.
"""
from common import *

BASE_T=(644,-64.725,840)
def local(s):return s.moved(loc(BASE_T).inverse)
def translated(p,dy,dz):return (p[0],p[1]+dy,p[2]+dz)
def valve(face):
    # OEM G1/4 male end x=-18.5, seating shoulder x=-9.5, hose axis +X.
    # Shoulder is the interface datum, not the thread tip.
    s=cq.Shape.importBrep(str(WORK/'valve_repaired.brep'))
    return s.moved(cq.Location(V(face[0]-9.5,face[1],face[2]),V(0,0,1),180))
def adapter(face):
    x,y,z=face
    s=box(x,y-10,z-10,20,20,20)
    s=s.cut(cyl((x-.1,y,z),(1,0,0),6.7,10.2),cyl((x+10,y,z),(1,0,0),2,10.1),cyl((x+14,y,z),(1,0,0),3.05,6.1))
    # Integral non-pressure mounting foot: operator reaction bypasses OD6 tube.
    s=s.fuse(box(x,y-20,z-18,-650.8-x,40,8),box(-653.8,y-20,z-40,3,40,30))
    for yy in (y-12,y+12):s=s.cut(cyl((-655,yy,z-28),(1,0,0),2.75,6))
    return s.clean()
def mount_hardware(face):
    x,y,z=face
    p=box(-649.3,y-20,z-36,3,40,16)
    result={}
    for i,yy in enumerate((y-12,y+12)):
        p=p.cut(cyl((-650,yy,z-28),(1,0,0),2.75,5))
        result[f'M5_MOUNT_BOLT_{i}']=cyl((-657.8,yy,z-28),(1,0,0),4.25,4).fuse(cyl((-653.8,yy,z-28),(1,0,0),2.5,13)).clean()
        result[f'M5_MOUNT_NUT_{i}']=tube((-646.3,yy,z-28),(1,0,0),4.5,2.5,4)
    result['MOUNT_BACKING_PLATE']=p
    return result
def pipe_route(points,ro=3,ri=2,bend_radius=None):
    ps=[V(*p) for p in points]; edges=[]; last=ps[0]
    for i,p in enumerate(ps[1:-1],1):
        u=(p-ps[i-1]).normalized();v=(ps[i+1]-p).normalized()
        theta=math.acos(max(-1,min(1,u.dot(v))))
        if theta<1e-5:continue
        radius=bend_radius if bend_radius is not None else max(2*ro,6); trim=radius*math.tan(theta/2)
        assert trim<min((p-ps[i-1]).Length,(ps[i+1]-p).Length)*.8,(points,i,trim)
        a=p-u*trim;b=p+v*trim;center=a+(v-u*u.dot(v)).normalized()*radius
        mid=center+((a-center)+(b-center)).normalized()*radius
        if (a-last).Length>1e-6:edges.append(cq.Edge.makeLine(last,a))
        edges.append(cq.Edge.makeThreePointArc(a,mid,b));last=b
    edges.append(cq.Edge.makeLine(last,ps[-1]))
    wire=cq.Wire.assembleEdges(edges)
    profile=cq.Workplane(cq.Plane(origin=ps[0],normal=ps[1]-ps[0])).circle(ro)
    if ri:profile=profile.circle(ri)
    return profile.sweep(wire,isFrenet=False).val()

def collector(core,include_rails=True):
    parts={}; xb=-412.; xe=592.; ymin=-737.5; ymax=-125.5
    # 34 shingled inclined blades, 18 mm pitch, 20 mm projection, 8.5 rise.
    # Water runs down the low lip, then 1% in -X to the transverse gutter.
    for i in range(34):
        y=ymin+18*i; width=18 if i==33 else 20
        w=cq.Wire.makePolygon([V(xb,y,635),V(xb,y+width,635+.425*width),V(xb,y+width,635.6+.425*width),V(xb,y,635.6)],close=True)
        b=cq.Solid.extrudeLinear(w,[],V(xe-xb,0,(xe-xb)*.01))
        w=cq.Wire.makePolygon([V(xb,y,635),V(xb,y+.6,635),V(xb,y+.6,637.5),V(xb,y,637.5)],close=True)
        lip=cq.Solid.extrudeLinear(w,[],V(xe-xb,0,(xe-xb)*.01))
        parts[f'H02_COND_BLADE_{i:02d}']=b.fuse(lip).clean()
    # Gutter surface falls from both ends to y=-400; no outlet standpipe.
    def floorz(y):return 629+abs(y+400)*.005
    def pan_profile(x,y0,y1,low,high,dx):
        ys=[y0,-400,y1]
        pts=[V(x,y,floorz(y)+low) for y in ys]+[V(x,y,floorz(y)+high) for y in reversed(ys)]
        return cq.Solid.extrudeLinear(cq.Wire.makePolygon(pts,close=True),[],V(dx,0,0))
    # Cut the trough from one continuous V-bottom blank to avoid zero-width
    # seam joins at its low point. Rear lip high, entry lip below blade drains.
    floor=pan_profile(-428,-740,-125.5,0,9.8,26)
    floor=floor.cut(pan_profile(-427.2,-739.2,-126.3,.8,12,24.4))
    floor=floor.cut(pan_profile(-402.8,-739.2,-126.3,3.8,12,1))
    # Hole is centred at the low gutter station; ID16 invert meets the floor.
    floor=floor.fuse(pan_profile(-428,-740,-125.5,9.8,19.8,.8))
    floor=floor.cut(cyl((-430,-400,637.8),(1,0,0),8,4))
    parts['H02_COND_GUTTER']=floor.clean()
    points=[(-428,-400,637.8),(-740,-400,634.68)]
    parts['H02_COND_OUTLET_D18']=pipe_route(points,9,8)
    # Headers and return bends also get cold: capture their drips outside
    # the fin-face projection, then drain into the same open collector.
    for label,ya,yb,zbase in [('HEADER',-814,-770,645),('UBEND',-122.5,-86,638.05)]:
        x0=-428. if label=='UBEND' else -438.;length=615-x0;fall=length*.005
        w=cq.Wire.makePolygon([V(x0,ya,zbase),V(x0,yb,zbase),V(x0,yb,zbase+.8),V(x0,ya,zbase+.8)],close=True)
        g=cq.Solid.extrudeLinear(w,[],V(length,0,fall))
        for yy in (ya,yb-.8):
            w=cq.Wire.makePolygon([V(x0,yy,zbase+.8),V(x0,yy+.8,zbase+.8),V(x0,yy+.8,zbase+4.8),V(x0,yy,zbase+4.8)],close=True)
            g=g.fuse(cq.Solid.extrudeLinear(w,[],V(length,0,fall)))
        for xx,zz in [(x0,zbase),(x0+length-.8,zbase+fall)]:g=g.fuse(box(xx,ya,zz+.8,.8,yb-ya,4))
        yy=yb if label=='HEADER' else ya
        direction=1 if label=='HEADER' else -1
        cz=zbase+.8+5
        g=g.cut(cyl((-421,yy-2,cz),(0,1,0),5,4))
        endy=-736 if label=='HEADER' else -142
        branch=pipe_route([(-421,yy,cz),(-421,endy,638)],6,5)
        boretool=pipe_route([(-421,yy,cz),(-421,endy,638)],6.05,0)
        g=g.cut(boretool)
        parts['H02_COND_GUTTER']=parts['H02_COND_GUTTER'].cut(boretool).clean()
        parts['H02_COND_'+label+'_GUTTER']=g.clean()
        parts['H02_COND_'+label+'_LINK']=branch
    # Five formed comb rails contact every blade underside; weld blade/comb
    # seams. End tabs and auxiliary gutter outriggers sit on HX frame Z628.
    # This is carried by the core, with no attachment to moving dampers/fins.
    for x in ((-390,-150,90,330,582) if include_rails else ()):
        rail=box(x,-740,631,8,617,2)
        for y in (-752,-123):
            rail=rail.fuse(box(x,y,628,8,14,5))
        for i in range(34):
            y=ymin+18*i
            z0=635+(x-xb)*.01
            w=cq.Wire.makePolygon([V(x,y+.6,632.8),V(x,y+2.6,632.8),
                V(x,y+2.6,z0+2.6*.425),V(x,y+.6,z0+.6*.425)],close=True)
            # Bottom is flat against rail; top follows compound blade slope.
            tooth=cq.Solid.extrudeLinear(w,[],V(8,0,.08))
            rail=rail.fuse(tooth)
        for label,ya,yb,yr,zbase in [('HEADER',-811,-738,-802,645),('UBEND',-123,-86,-98,638)]:
            rail=rail.fuse(box(x,ya,628,8,yb-ya,2))
            top=zbase+(x+438)*.005
            w=cq.Wire.makePolygon([V(x,yr,629.8),V(x,yr+2,629.8),V(x,yr+2,top),V(x,yr,top)],close=True)
            rail=rail.fuse(cq.Solid.extrudeLinear(w,[],V(8,0,.04)))
        # Separate fabricated rail segments terminate at existing upright
        # plate tabs; weld their ends to those tabs instead of overlapping.
        for nn in ('PLATE_TAB_0_1','PLATE_TAB_1_1'):rail=rail.cut(core[nn].moved(loc(BASE_T)))
        for j,seg in enumerate(rail.Solids()):parts[f'H02_COND_RAIL_{x}_{j}']=seg.clean()
    # Main trough has two pads to the existing AIR_EDGE top face, Z628.
    for j,yy in enumerate((-700,-180)):
        pts=[V(-428,yy,628),V(-428,yy+10,628),V(-428,yy+10,floorz(yy+10)),V(-428,yy,floorz(yy))]
        parts[f'H02_COND_GUTTER_PAD_{j}']=cq.Solid.extrudeLinear(cq.Wire.makePolygon(pts,close=True),[],V(8,0,0))
    return parts,points

def main():
    print('Reading H01',flush=True)
    core=read(H01/'H01_SINGLE_CORE.step');assert len(core)==551
    removed=[]; changes={}; added={}; register=[]; lines=[]; endpoints=[]; svc={}; cuts={}
    # Retire the old vertical-orientation condensate assembly in all four cores.
    for n in list(core):
        if n.startswith(('C05_CORE_CARRIED_TRAY','C05_SHORT_DRAIN_SPIGOT','C05_TRAY_TAB','C05_TRAY_M4')):
            removed.append(n);del core[n]
    for w,x,z,yout in [('W1',162.65,677.35,-720),('W2',52.65,787.35,-570)]:
        for n in (w+'_DRAIN_BOSS',w+'_DRAIN_CLOSURE_PROXY',w+'_VENT_CAP',w+'_DRAIN_CAP'):
            removed.append(n);del core[n]
        # Replace, rather than cap over, the old axial drain drilling.
        cap=cyl((x,726.85,41),(0,0,1),17,3)
        changes[w+'_BOTTOM_CAP']=cap
        # Far crown pickup gives the horizontal header two pickup stations.
        h=core[w+'_HEADER_39_BRANCHES']
        h=h.cut(cyl((x,726.85,64),(-1,0,0),2,22))
        changes[w+'_HEADER_39_BRANCHES']=h.clean()
        # H01 terminals retain their main axes and nominal flow bore.
        e=core[w+'_D35_END_PIPE']
        e=e.cut(cyl((x-24,726.85,1100),(-1,0,0),3,6),cyl((304,655.275 if w=='W1' else 505.275,1342),(1,0,0),3,6))
        changes[w+'_D35_END_PIPE']=e.clean()
        # OD6/ID4 copper capillary, gentle rise to the wet-bay operator valve.
        # Swept bends are nominal fabrication geometry, not qualified elbow SKUs.
        far=(580,-791.575,z+14)
        near=(-456,-791.575,z+32)
        ventpoints=[far,(580,-791.575,z+26),near,(-590,-791.575,z+32.7),(-610,-390,z+33),(-655,-390,z+34),(-676,-390,z+34)]
        line=pipe_route(ventpoints)
        # Far takeoff is an external saddle with a continuous elbow, no
        # dip tube or unclosed straight-tube end at the crown.
        line=line.cut(cyl((-500,-791.575,z),(1,0,0),17,1150))
        # Near branch drills the lower wall of the vent line; blind overlap
        # of two hollow tube shells would otherwise block the bleed path.
        line=line.cut(cyl((-456,-791.575,z+23),(0,0,1),3.05,9))
        added[w+'_VENT_HEADER_LINE']=local(line.clean())
        branch=tube((-456,-791.575,z+24),(0,0,1),3,2,8)
        branch=branch.cut(cyl((-470,-791.575,z+32),(1,0,0),2,28))
        added[w+'_VENT_NEAR_PICKUP']=local(branch.clean())
        vface=(-690,-390,z+34)
        added[w+'_VENT_ADAPTER_G14']=local(adapter(vface))
        # OEM assembly contains main valve and tethered cap. Preserve each solid.
        for i,s in enumerate(valve(vface).Solids()):added[w+f'_VENT_CALEFFI538201_{i}']=local(s)
        yd=-630 if w=='W1' else -500
        drainpoints=[(-698,yout,536),(-698,yout,500),(-664,yout,500),(-664,yd,480),(-676,yd,480)]
        added[w+'_DRAIN_LINE']=local(pipe_route(drainpoints))
        dface=(-690,yd,480)
        added[w+'_DRAIN_ADAPTER_G14']=local(adapter(dface))
        for i,s in enumerate(valve(dface).Solids()):added[w+f'_DRAIN_CALEFFI538201_{i}']=local(s)
        lines.extend([{'port':w,'function':'VENT','points_A_LOWER':ventpoints,'OD_mm':6,'ID_mm':4},
                      {'port':w,'function':'DRAIN','points_A_LOWER':drainpoints,'OD_mm':6,'ID_mm':4}])
        endpoints.extend([(w,'VENT',vface),(w,'DRAIN',dface)])
        for fn,face in [('VENT',vface),('DRAIN',dface)]:
            for n,s in mount_hardware(face).items():added[w+'_'+fn+'_'+n]=local(s)
    # Fill the measured 1450 mm2 unsupported gasket footprint using HX-owned
    # coplanar lands, without moving the datum or modifying the Shell gasket.
    idx=json.loads((WORK/'S1/index.json').read_text())
    gr=next(r for r in idx if r['name']=='C09_FACE_GASKET_A_LOWER')
    gasket=cq.Shape.importBrep(str(WORK/'S1'/gr['file']))
    supported=[s.moved(loc(BASE_T)) for n,s in core.items() if n.startswith(('POST_212','AIR_EDGE_212'))]
    missing=[]
    for face in gasket.Faces():
        if face.geomType()=='PLANE' and face.normalAt().z>.99 and abs(face.Center().z-620)<1e-5:
            land=cq.Solid.extrudeLinear(face.outerWire(),face.innerWires(),V(0,0,8))
            for frame in supported:land=land.cut(frame)
            missing.extend(land.Solids())
    for i,s in enumerate(missing):added[f'H02_SEAL_LAND_PATCH_{i}']=local(s.clean())
    dump(OUT/'evidence/LAND_PATCHES.json',[{'id':i,'area_mm2':s.Volume()/8,'bounds_A_LOWER':bounds(s)} for i,s in enumerate(missing)])
    cond,condpoints=collector(core)
    # Sleeve penetrations in HX-owned plate tabs for two auxiliary drains.
    for name,ya,yb,z0 in [('PLATE_TAB_0_1',-122.5,-142,643.85),('PLATE_TAB_1_1',-770,-736,650.8)]:
        a=V(-421,ya,z0);b=V(-421,yb,638);d=(b-a).normalized()
        tool=cyl((a-d*4).toTuple(),d.toTuple(),6.5,(b-a).Length+8)
        changes[name]=core[name].cut(local(tool)).clean()
    added.update({n:local(s) for n,s in cond.items()})
    from OCP.ShapeFix import ShapeFix_Shape
    repairs=[]
    for n,s in list(added.items()):
        if 'CALEFFI' in n or not s.isValid():
            f=ShapeFix_Shape(s.wrapped);f.SetPrecision(1e-6);f.SetMaxTolerance(.01);f.Perform()
            fixed=cq.Shape.cast(f.Shape())
            repairs.append({'name':n,'before':s.isValid(),'after':fixed.isValid(),'volume_change_mm3':fixed.Volume()-s.Volume()})
            added[n]=fixed
    dump(OUT/'evidence/OEM_PLACEMENT_REPAIR.json',repairs)
    new_material=dict(added); material_change=[]
    for n,s in changes.items():
        diff=s.cut(core[n]); vol=diff.Volume()
        material_change.append({'part':n,'added_mm3':vol,'removed_mm3':core[n].cut(s).Volume()})
        if vol>.001:new_material[n+'_NEW_MATERIAL']=diff
    dump(OUT/'evidence/MATERIAL_CHANGE.json',material_change)
    core.update(changes);core.update(added)
    for n,s in {**changes,**added}.items():assert s.isValid(),n
    delta={**changes,**added}
    all_delta={}; all_new_material={}; handoff=[]; hole_rows=[]
    for k,p in PLACEMENTS.items():
        bed,level=k.split('_');dy=p['translation'][1]-BASE_T[1];dz=p['translation'][2]-BASE_T[2]
        all_delta.update({k+'__'+n:s.moved(loc(p['translation'])) for n,s in delta.items()})
        all_new_material.update({k+'__'+n:s.moved(loc(p['translation'])) for n,s in new_material.items()})
        for w,fn,face in endpoints:
            f=translated(face,dy,dz);tag=k+'_'+w+'_'+fn
            # Axial cap extraction / hose plug-in and key+glove operation.
            svc[tag+'__CAP_HOSE_ACCESS']=cyl((f[0]-110,f[1],f[2]),(1,0,0),25,90)
            svc[tag+'__KEY_HAND_ACCESS']=box(f[0]-45,f[1]-65,f[2]-25,44,65,50)
            for i,yy in enumerate((f[1]-12,f[1]+12)):
                svc[tag+f'__M5_MOUNT_TOOL_{i}']=cyl((-715,yy,f[2]-28),(1,0,0),8,57)
                name=tag+f'_MOUNT_HOLE_{i}'
                cuts[name]=cyl((-651.1,yy,f[2]-28),(1,0,0),2.75,2.2)
                hole_rows.append({'id':name,'xyz':(-650.05,yy,f[2]-28),'diameter_mm':5.5,'owner':'Shell wet-bay skin + backing interface','state':'candidate sealed two-bolt interface; skin reaction qualification required'})
            handoff.append({'id':tag,'kind':fn,'sealing_shoulder':f,'axis_out':[-1,0,0],
                            'valve':'Caleffi 538201 G1/4 A male','hose_axis_end':[f[0]-29,f[1],f[2]],
                            'recipient':'individual labelled hose to atmospheric graduated vessel; never to another water circuit or condensate trap',
                            'normal_state':'CLOSED, cap fitted; outlet cap is secondary closure'})
            register.append({'id':tag,'category':'high_point_vent' if fn=='VENT' else 'H01_low_water_drain','count_unit':1,
                             'disposition':'remote dual-crown pickups and wet-bay valve' if fn=='VENT' else 'retained low boss, tube to actual wet-bay valve',
                             'service_face':f,'verification':'CAD + mandatory fill/drain trial'})
        for w in ('W1','W2'):
            register.append({'id':k+'_'+w+'_ORIGINAL_CLOSURE','category':'original_header_drain_group','count_unit':1,
                             'disposition':'boss and loose cap deleted; original pierced end disk replaced by solid 3 mm pressure cap',
                             'service_face':'none','verification':'factory braze qualification, hydraulic proof; replacement flow path in WATER_TOPOLOGY.json'})
        register.append({'id':k+'_C05_COND','category':'C05_condensate_nozzle','count_unit':1,
                         'disposition':'old rotated pan/nozzle removed; replaced by horizontal shingled collector and D18/ID16 outlet',
                         'service_face':translated(condpoints[-1],dy,dz),'verification':'geometric drainage slope; wet capture and reverse-air test outstanding'})
        cp=translated(condpoints[-1],dy,dz)
        handoff.append({'id':k+'_COND','kind':'CONDENSATE','sealing_shoulder':cp,'axis_out':[-1/math.sqrt(1.0001),0,-.01/math.sqrt(1.0001)],
                        'valve':'none, D18 plain spigot / ID16','hose_axis_end':cp,
                        'recipient':'own continuously descending line, own pressure trap, then air-gap receptor; Shell owns downstream',
                        'normal_state':'OPEN, no isolation valve'})
        svc[k+'__COND_HOSE_RELEASE']=cyl((cp[0]-80,cp[1],cp[2]-.8),(1,0,.01),25,math.sqrt(80**2+.8**2))
        # Reference holes only, never write shell or damper owner solids.
        for item,pn in [('W1_VENT','W1_VENT_HEADER_LINE'),('W2_VENT','W2_VENT_HEADER_LINE'),('COND','H02_COND_OUTLET_D18')]:
            s=added[pn].moved(loc(p['translation']))
            planes=[('INNER',-501),('SKIN',-650)]
            if item.endswith('VENT'):planes.append(('POCKET',-583))
            for plane,X in planes:
                section=s.intersect(box(X-.75,-1000,100,1.5,2000,1400));b=bounds(section)
                Y=(b[1]+b[4])/2;Z=(b[2]+b[5])/2
                rad=math.ceil(max(b[4]-b[1],b[5]-b[2])/2+3)
                q=(X,Y,Z);name=k+'_'+item+'_'+plane
                # Condensate also traverses the folded rear-mask return.
                depth=40 if plane=='INNER' and item=='COND' else 16
                cuts[name]=cyl((X-8,Y,Z),(1,0,0),rad,depth)
                hole_rows.append({'id':name,'xyz':q,'diameter_mm':2*rad,'owner':'Shell/D04 if intercepted','state':'candidate sealed penetration; never cut frame or moving parts'})
            if item.endswith('VENT'):
                Y=-766.5+dy
                section=s.intersect(box(-800,Y-.75,100,400,1.5,1400));b=bounds(section)
                X=(b[0]+b[3])/2;Z=(b[2]+b[5])/2;rad=math.ceil(max(b[3]-b[0],b[5]-b[2])/2+3)
                name=k+'_'+item+'_WRAP_Y_NORMAL'
                cuts[name]=cyl((X,Y-8,Z),(0,1,0),rad,16)
                hole_rows.append({'id':name,'xyz':(X,Y,Z),'diameter_mm':2*rad,'owner':'Shell air-wrap wall, axis +Y','state':'candidate sealed penetration only where an actual sheet wall is intercepted'})
    assert len(register)==28
    csvwrite(OUT/'FUNCTIONAL_28_REGISTER.csv',register);csvwrite(OUT/'SERVICE_AND_SHELL_PORTS.csv',handoff)
    csvwrite(OUT/'HOST_OPENING_REQUEST.csv',hole_rows)
    dump(OUT/'ROUTES.json',{'small_bore':lines,'condensate_A_LOWER':condpoints})
    dump(OUT/'CHANGE_REGISTER.json',{'removed_per_core':removed,'replaced':list(changes),'added':list(added),'H01_end_faces_unchanged':True,'H01_first_spools_unchanged_by_this_script':True})
    exports=[]
    for parts,name in [(core,'H02_SINGLE_CORE'),(all_delta,'H02_FOUR_CORE_DELTA'),(all_new_material,'H02_NEW_MATERIAL'),(svc,'H02_WATER_SERVICE'),(cuts,'H02_HOST_OPENING_TOOLS_REFERENCE')]:
        exports.append(save(parts,name))
    dump(OUT/'evidence/BUILD.json',{'exports':exports,'single_core_parts':len(core),'functional_register_entries':28})
    print('BUILD COMPLETE',flush=True)
if __name__=='__main__':main()
