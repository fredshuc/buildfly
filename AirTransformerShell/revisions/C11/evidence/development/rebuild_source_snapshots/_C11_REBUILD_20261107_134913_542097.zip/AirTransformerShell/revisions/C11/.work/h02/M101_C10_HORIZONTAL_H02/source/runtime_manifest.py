import importlib.metadata as m,sys,json,platform
from pathlib import Path
out=Path(__file__).resolve().parents[1]
packages={}
for name in ('cadquery','cadquery-ocp','numpy','matplotlib','Pillow'):
    try:packages[name]=m.version(name)
    except m.PackageNotFoundError:packages[name]=None
(out/'REPRO_ENVIRONMENT.json').write_text(json.dumps({'python':sys.version,'implementation':sys.implementation.name,'packages':packages,'note':'CAD validity and STEP readback must be repeated on another runtime; this records the producing environment.'},indent=2),encoding='utf8')
print(packages,flush=True)
