"""Check nominal ID4 branch cavities through HX metal, one unhanded core."""
from common import *
from build import pipe_route,local
from check import screen
import ast
core=read(OUT/'H02_SINGLE_CORE.step')
metal={n:s.moved(loc((644,-64.725,840))) for n,s in core.items() if n.startswith(('W1_','W2_')) and 'CALEFFI' not in n and 'VIEGA' not in n}
ports={r['id']:ast.literal_eval(r['sealing_shoulder']) for r in csv.DictReader((OUT/'SERVICE_AND_SHELL_PORTS.csv').open())}
voids={};result={'scope':'nominal new branch ID4 cavity plus connecting H01 tap / far crown drilling, through final HX pressure metal; OEM closed valves excluded; no pressure/flow performance claim','branches':{}}
for r in json.loads((OUT/'ROUTES.json').read_text())['small_bore']:
    w,fn=r['port'],r['function'];z=677.35 if w=='W1' else 787.35
    v=pipe_route(r['points_A_LOWER'],2,0,bend_radius=6)
    if fn=='VENT':
        v=v.fuse(cyl((580,-791.575,z+10),(0,0,1),2,8),cyl((-456,-791.575,z+10),(0,0,1),2,22))
    else:
        yy=-720 if w=='W1' else -570
        v=v.fuse(cyl((-698,yy,530),(0,0,1),2,30))
    face=ports['A_LOWER_'+w+'_'+fn]
    v=v.fuse(cyl(face,(1,0,0),2,16.1)).clean()
    name=w+'_'+fn;voids[name]=v
    chk=screen({name:v},metal)
    free=v
    for hit in chk['hits']:free=free.cut(metal[hit[1]])
    gauge=pipe_route(r['points_A_LOWER'],1.9,0,bend_radius=6)
    if fn=='VENT':gauge=gauge.fuse(cyl((580,-791.575,z+10),(0,0,1),1.9,8),cyl((-456,-791.575,z+10),(0,0,1),1.9,22))
    else:gauge=gauge.fuse(cyl((-698,yy,530),(0,0,1),1.9,30))
    gauge=gauge.fuse(cyl(face,(1,0,0),1.9,16.1)).clean()
    minimum=screen({name:gauge},metal)
    result['branches'][name]={'nominal_connected_solids':len(v.Solids()),'actual_open_cavity_connected_solids':len(free.Solids()),'nominal_cavity_mm3':v.Volume(),'nominal_ID4_local_metal_intrusions':chk['hits'],'minimum_clear_bore_gauge_mm':3.8,'clear_bore_gauge_connected_solids':len(gauge.Solids()),'clear_bore_gauge_obstructions':minimum['hits'],'manufacturing_requirement':'finish/deburr brazed tee; minimum clear bore3.8mm to be physically gauged. Minor nominal ID4 tee intrusions are retained in this report, not silently zeroed.'}
    print('fluid',name,result['branches'][name],flush=True)
    dump(OUT/'evidence/BRANCH_FLOW_CHECK.json',result)
result['reference_step']=save(voids,'H02_BRANCH_FLOW_REFERENCE_A_LOWER')
result['core_sha256']=hashlib.sha256((OUT/'H02_SINGLE_CORE.step').read_bytes()).hexdigest()
dump(OUT/'evidence/BRANCH_FLOW_CHECK.json',result)
