from service_probe import *
from motion import witness

def run():
 p,c=build_parts();index=scene_index(p);report={};envelopes={}
 for bed in 'AB':
  names=[f'DAMPER_SEAT_{bed}_UPPER_DEEP_O',f'DAMPER_STATIC_GASKET_{bed}_UPPER_O',f'DAMPER_SEAL_{bed}_UPPER_DEEP_O']
  names.extend(n for n in p if n.startswith(f'D05_PIN_STUD_{bed}_'))
  removed=set(names+[n for n in p if n.startswith(f'D04_{bed}_')]+[
   f'DAMPER_ROOT_END_SEAL_{bed}_UPPER_IN_O',f'DAMPER_ROOT_END_SEAL_{bed}_UPPER_OUT_O',f'DAMPER_ROOT_LIP_{bed}_UPPER_O',
   f'AIR_PROCESS_IN_FLOOR_{bed}_O',f'AIR_PROCESS_IN_WRAP_{bed}_O'])
  removed.update(r['name'] for r in index if r['name'].startswith(f'C10_{bed}_W2_POCKET_'))
  removed.add('SKIN_DRY_ROOF_O')
  s=cq.Compound.makeCompound([p[n] for n in names])
  result=[]
  for step,vector in [('PIN_NEG_X_70',(-70,0,0)),('PIN_POS_Z_500',(0,0,500)),('PIN_NEG_X_200',(-200,0,0))]:
   env=translate_sweep(s,vector);hit=check(env,removed,index,p)
   result.append({'step':step,'vector':vector,'required_absent':sorted(removed),'hits':hit})
   envelopes[bed+'_'+step]=env
   print(bed,step,hit,flush=True);s=s.translate(vector)
  report[bed]=result
 dump(ROOT/'evidence/pin_route_probe.json',report)
 return report,envelopes

if __name__=='__main__':run()
