import ast
from pathlib import Path
p=Path(__file__).resolve().parent
for f in p.glob('*.py'):ast.parse(f.read_text(encoding='utf8'),filename=str(f))
print('All Python sources parse')
