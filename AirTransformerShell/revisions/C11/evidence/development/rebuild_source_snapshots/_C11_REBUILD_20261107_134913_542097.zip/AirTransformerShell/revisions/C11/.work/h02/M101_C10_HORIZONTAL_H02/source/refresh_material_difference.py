"""Recalculate STEP-to-STEP material difference with explicit numerical tolerance.
The 1e-5mm fuzzy tolerance addresses coincident surfaces after STEP round trips;
it does not replace any clash or dimensional clearance criterion.
"""
from common import *
from OCP.GeomAPI import GeomAPI_ProjectPointOnSurf
from OCP.BRep import BRep_Tool
core=read(OUT/'H02_SINGLE_CORE.step');base=read(H01/'H01_SINGLE_CORE.step')
ch=json.loads((OUT/'CHANGE_REGISTER.json').read_text())
new={n:core[n] for n in ch['added']};mc=[]
for n in ch['replaced']:
    reference=core[n];verification=None
    if n.endswith('D35_END_PIPE'):
        w=n[:2];x=162.65 if w=='W1' else 52.65
        reference=base[n].cut(cyl((x-24,726.85,1100),(-1,0,0),3,6),cyl((304,655.275 if w=='W1' else 505.275,1342),(1,0,0),3,6)).clean()
        # The kernel subtracts these independently imported coincident shells
        # incorrectly, returning their full volumes. Reconstruct the two drills
        # from the immutable source, and verify the imported geometry separately.
        expected_faces=reference.Faces();unmatched=list(expected_faces);face_tests=[]
        for face in core[n].Faces():
            candidates=[f for f in unmatched if f.geomType()==face.geomType()]
            mate=min(candidates,key=lambda f:(f.Center()-face.Center()).Length+abs(f.Area()-face.Area()))
            center=(mate.Center()-face.Center()).Length;area=abs(mate.Area()-face.Area());samples=[]
            for aa,bb in ((face,mate),(mate,face)):
                u0,u1,v0,v1=aa.uvBounds();surface=BRep_Tool.Surface_s(bb.wrapped)
                for fu in (.2,.5,.8):
                    for fv in (.2,.5,.8):
                        point=aa.positionAt(u0+(u1-u0)*fu,v0+(v1-v0)*fv)
                        samples.append(GeomAPI_ProjectPointOnSurf(point.toPnt(),surface).LowerDistance())
            face_tests.append({'type':face.geomType(),'center_gap_mm':center,'area_delta_mm2':area,'max_surface_sample_gap_mm':max(samples)})
            assert center<1e-5 and area<.001 and max(samples)<1e-5,(n,face_tests[-1]);unmatched.remove(mate)
        assert not unmatched
        vertex=max([reference.distance(v) for v in core[n].Vertices()]+[core[n].distance(v) for v in reference.Vertices()])
        volume_delta=abs(core[n].Volume()-reference.Volume());assert vertex<1e-5 and volume_delta<.001
        verification={'method':'source two-drill construction plus all face areas/centroids, bidirectional 3x3 surface samples, all vertices and volume; independent coincident-shell boolean is unreliable and retained in END_PIPE_ROUNDTRIP_AUDIT.json','max_vertex_gap_mm':vertex,'volume_delta_mm3':volume_delta,'face_checks':face_tests}
    diff=reference.cut(base[n],tol=1e-5);removed=base[n].cut(reference,tol=1e-5);vol=diff.Volume()
    row={'core_sha256':hashlib.sha256((OUT/'H02_SINGLE_CORE.step').read_bytes()).hexdigest(),'part':n,'added_mm3':vol,'removed_mm3':removed.Volume(),'STEP_comparison_fuzzy_tolerance_mm':1e-5};row['source_construction_verification']=verification;mc.append(row);print({k:v for k,v in row.items() if k!='source_construction_verification'},flush=True)
    if 'D35_END_PIPE' in n or 'HEADER_39' in n or 'PLATE_TAB' in n:assert vol<.001,(n,vol)
    if vol>.001:new[n+'_NEW_MATERIAL']=diff
all_new={k+'__'+n:s.moved(loc(p['translation'])) for k,p in PLACEMENTS.items() for n,s in new.items()}
result=save(all_new,'H02_NEW_MATERIAL');dump(OUT/'evidence/MATERIAL_CHANGE.json',mc)
build=json.loads((OUT/'evidence/BUILD.json').read_text());build['exports']=[result if r['file']==result['file'] else r for r in build['exports']];dump(OUT/'evidence/BUILD.json',build)
print('Material difference refreshed',flush=True)
