from pathlib import Path
import csv,json,hashlib,math
from cad_io import *
P=Path(__file__).resolve().parents[1];root=P.parents[1];work=root.parent/'c11_input'
new=named(P/'cad/C11_HYD_RACK_SUPPORT.step');svc=named(work/'s2/HYD_S2/S2_SERVICE.step')
remove=tuple(b+'_'+x for b in 'AB' for x in ['SUP_Q','PIPE_MID'])
h=json.load(open(P/'evidence/service_obstructions.json'))['fixed_support_vs_legacy_service']
left=[x for x in h if not x[0].startswith(remove)]
json.dump({'pre_remove_modules':remove,'original_intersection_count':len(h),'retained_intersections':left,'status':'conditional clearance of original tool volumes AFTER removing named modules; removal and auxiliary support itself UNVALIDATED'},open(P/'evidence/service_after_premoval.json','w'),indent=2)
a=cq.Assembly(name='C11_SERVICE_REFERENCE_NOT_VALIDATED_REMOVAL')
for n,s in svc.items():a.add(s,name='KEEP_OUT__'+n,color=cq.Color(1,.6,.1,.3))
for n,s in new.items():
 if n.startswith(remove):a.add(s,name='PRE_REMOVE__'+n,color=cq.Color(.85,.15,.15))
a.save(str(P/'cad/C11_HYD_SERVICE.step'))
# Scaled engineering projection with sampled edges. Reference only, no raster AI.
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
rack=named(work/'s2/HYD_S2/S2_RACK.step')
fig,axes=plt.subplots(1,2,figsize=(14,9),constrained_layout=True)
for ax,idx,labels in [(axes[0],(0,1),('X mm','Y mm')),(axes[1],(1,2),('Y mm','Z mm'))]:
 for group,col,lw in [(new,'#337ca0',.25),(rack,'#bf5a18',.6)]:
  seg=[]
  for n,s in group.items():
   for edge in s.Edges():
    try:ps=edge.discretize(8) if hasattr(edge,'discretize') else [edge.positionAt(i/8) for i in range(9)]
    except Exception:continue
    seg.append([[p.toTuple()[idx[0]],p.toTuple()[idx[1]]] for p in ps])
  ax.add_collection(LineCollection(seg,colors=col,linewidths=lw))
 ax.autoscale();ax.set_aspect('equal');ax.set_xlabel(labels[0]);ax.set_ylabel(labels[1]);ax.grid(alpha=.2)
axes[0].set_title('Plan: existing water orange / candidate support blue');axes[1].set_title('Elevation: removable local columns')
fig.suptitle('C11 Hydronics support candidate - NOT FOR MANUFACTURE',fontsize=15)
fig.savefig(P/'C11_SUPPORT_REVIEW.png',dpi=180);plt.close(fig)
# Actual calculation summary, always label estimator nature.
m=json.load(open(P/'evidence/mechanics_screen.json'))
rows=list(csv.DictReader(open(P/'load_cases.csv')))
summary={}
for case in sorted(set(r['case'] for r in rows)):
 rr=[r for r in rows if r['case']==case];summary[case]={k:[min(float(r[k]) for r in rr),max(float(r[k]) for r in rr)] for k in ['Fx_N','Fy_N','Fz_N']}
json.dump(summary,open(P/'evidence/foot_reaction_ranges.json','w'),indent=2)
# Pin all evidence files to current bytes and retain original task package hash.
inputs=[work/'AirTransformer_C11_L1_TASKS_20261107.zip',work/'s2/HYD_S2/S2_RACK.step',root/'HX/M101_C08_HORIZONTAL_H01/HX_C08_H01_HYDRONIC_RETURN.zip']+[root/f'AirTransformerShell/revisions/C10/cad/C10_INSTALLED_{s}.step' for s in ['S1','S2']]
json.dump({str(p.relative_to(root.parent)):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs},open(P/'INPUT_SHA256.json','w'),indent=2)
print('conditional service retained collisions',len(left),'mass',m['wet_mass_kg'],'feet',summary,flush=True)
