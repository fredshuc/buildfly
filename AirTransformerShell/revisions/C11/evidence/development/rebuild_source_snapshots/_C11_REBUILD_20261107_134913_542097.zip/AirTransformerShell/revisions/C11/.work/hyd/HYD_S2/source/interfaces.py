from cad_io import cq,named
from pathlib import Path
import json,csv,sys,math
out,hx=map(Path,sys.argv[1:]);r=named(out/'S2_RACK.step');sp=named(hx/'H01_EIGHT_FIRST_SPOOLS.step');ev=[];ports=list(csv.DictReader((out/'ports.csv').open()))
import ast
for b in 'AB':
 by={ (p['part'].split('_')[0],p['end']):p for p in ports if p['part'].endswith('_'+b)}
 y2=-570 if b=='A' else 295;y1=y2-150
 seq=[sp[b+'_L_W2__FIXED_RACK_TAIL'],r[b+'_LOW_W2_FS'],r[b+'_FS_STACK_1'],r['FS_'+b],r[b+'_FS_STACK_2'],r[b+'_FS_Q'],r[b+'_Q_STACK_1'],r['Q_'+b],r[b+'_Q_STACK_2'],r[b+'_Q_UP_W1'],sp[b+'_U_W1__FIXED_RACK_TAIL']]
 coords=[(-865,y2,560),ast.literal_eval(by['FS','1']['stack_pipe_end']),ast.literal_eval(by['FS','1']['center']),ast.literal_eval(by['FS','2']['center']),ast.literal_eval(by['FS','2']['stack_pipe_end']),ast.literal_eval(by['Q','1']['stack_pipe_end']),ast.literal_eval(by['Q','1']['center']),ast.literal_eval(by['Q','2']['center']),ast.literal_eval(by['Q','2']['stack_pipe_end']),(-865,y1,895)]
 for i,(s,t,p) in enumerate(zip(seq,seq[1:],coords)):
  ax=0 if i in (0,9) else 1;direction=[0,0,0];direction[ax]=1
  def end(shape):
   return [f for f in shape.Faces() if f.geomType()=='PLANE' and abs(f.normalAt().toTuple()[ax])>.99999 and abs(f.Center().toTuple()[ax]-p[ax])<.0001]
  area=sum(f.intersect(g).Area() for f in end(s) for g in end(t) if f.normalAt().dot(g.normalAt())<-.9999)
  probe=cq.Solid.makeCylinder(12.49,2,cq.Vector(*p)-cq.Vector(*direction),cq.Vector(*direction))
  occ=sum(probe.intersect(item).Volume() for item in (s,t))
  assert area>100 and occ<.001,(b,i,area,occ)
  ev.append(dict(bed=b,pair=i+1,point=p,common_face_mm2=round(area,3),bore_probe_diameter_mm=24.98,obstructed_mm3=round(occ,6)))
(out/'interface_checks.json').write_text(json.dumps(ev,indent=2));print(len(ev))
