"""CAD support-contact audit, not weld/strength certification."""
from common import *
core={n:s.moved(loc((644,-64.725,840))) for n,s in read(OUT/'H02_SINGLE_CORE.step').items()}
rails={n:s for n,s in core.items() if n.startswith('H02_COND_RAIL_')}
frame={n:s for n,s in core.items() if n.startswith(('POST_212','AIR_EDGE_212','PLATE_TAB_'))}
contacts=[]
def at(n,p):return core[n].distance(cq.Vertex.makeVertex(*p))
for x in (-390,-150,90,330,582):
    for i in range(34):
        y=-737.5+18*i+1.6;z=635+(x+4+412)*.01+.425*1.6;p=(x+4,y,z)
        vertex=cq.Vertex.makeVertex(*p);matched={n:s for n,s in rails.items() if n.startswith(f'H02_COND_RAIL_{x}_')}
        d,n=nearest(vertex,matched)
        contacts.append({'kind':'blade_to_tooth','blade':i,'rail':n,'point':p,'blade_gap_mm':at(f'H02_COND_BLADE_{i:02d}',p),'rail_gap_mm':d})
    for kind,y,z in [('HEADER',-801,645+(x+4+438)*.005),('UBEND',-97,638+(x+4+438)*.005)]:
        p=(x+4,y,z);vertex=cq.Vertex.makeVertex(*p);d,n=nearest(vertex,rails)
        contacts.append({'kind':'aux_gutter_to_rail','gutter':kind,'point':p,'gutter_gap_mm':at('H02_COND_'+kind+'_GUTTER',p),'rail_gap_mm':d})
anchor=[]
for n,s in rails.items():
    d,target=nearest(s,frame);anchor.append({'part':n,'frame':target,'gap_mm':d,'joint':'frame seating and/or welded end-face; qualified seam required'})
result={'core_sha256':hashlib.sha256((OUT/'H02_SINGLE_CORE.step').read_bytes()).hexdigest(),'contact_samples':contacts,'rail_segments_to_frame':anchor,'scope':'nominal point/shape contact only, not proof of adequate weld or frame stiffness','all_nominal_gaps_le_1um':all(v<=.001 for r in contacts for k,v in r.items() if k.endswith('gap_mm')) and all(r['gap_mm']<=.001 for r in anchor)}
dump(OUT/'evidence/COLLECTOR_SUPPORT_CHECK.json',result)
print('Collector support',len(contacts),len(anchor),result['all_nominal_gaps_le_1um'],flush=True)
