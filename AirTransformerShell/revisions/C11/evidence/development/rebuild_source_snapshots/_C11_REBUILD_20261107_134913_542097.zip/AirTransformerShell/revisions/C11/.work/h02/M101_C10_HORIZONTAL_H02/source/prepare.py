from common import *
from OCP.BRepAdaptor import BRepAdaptor_Surface
def main():
    WORK.mkdir(parents=True,exist_ok=True)
    (OUT/'evidence').mkdir(exist_ok=True)
    s=cq.importers.importStep(str(OUT/'sources/538201.stp')).val()
    print('valve bounds',bounds(s),flush=True)
    surfaces=[]
    for f in s.Faces():
        if f.geomType()=='CYLINDER':
            c=BRepAdaptor_Surface(f.wrapped).Cylinder(); ax=c.Axis()
            surfaces.append({'r':c.Radius(),'origin':ax.Location().Coord(),'axis':ax.Direction().Coord(),'b':bounds(f)})
    dump(WORK/'valve_axes.json',surfaces)
    s.exportBrep(str(WORK/'valve.brep'))
    from OCP.ShapeFix import ShapeFix_Shape
    repaired=[]; repairs=[]
    for i,b in enumerate(s.Solids()):
        f=ShapeFix_Shape(b.wrapped);f.SetPrecision(1e-6);f.SetMaxTolerance(.01);f.Perform()
        fixed=cq.Shape.cast(f.Shape());assert fixed.isValid()
        repairs.append({'solid':i,'raw_valid':b.isValid(),'repaired_valid':True,'volume_delta_mm3':fixed.Volume()-b.Volume(),'tolerance_mm':1e-6})
        repaired.extend(fixed.Solids())
    cq.Compound.makeCompound(repaired).exportBrep(str(WORK/'valve_repaired.brep'))
    dump(OUT/'evidence/OEM_CAD_REPAIR.json',repairs)
    for state in ('S1','S2'):
        dest=WORK/state; dest.mkdir(exist_ok=True)
        idx=dest/'index.json'
        inp=C10/f'cad/C10_INSTALLED_{state}.step'
        digest=hashlib.sha256(inp.read_bytes()).hexdigest();meta=dest/'input_sha256.txt'
        if idx.exists() and meta.exists() and meta.read_text()==digest and (dest/'all_bounds.json').exists():continue
        parts=list(leaves(inp))
        dump(dest/'all_bounds.json',[{'name':n,'b':bounds(s)} for n,s in parts])
        index=[]
        for i,(n,s) in enumerate(parts):
            if '/HEAT_EXCHANGERS/' in n or '/FIRST_SPOOLS/' in n:continue
            b=bounds(s)
            if b[0]>700 or b[2]>1350 or b[5]<300:continue
            p=dest/f'{i:04d}.brep';s.exportBrep(str(p))
            index.append({'path':n,'name':n.split('/')[-2],'b':b,'file':p.name})
        dump(idx,index);meta.write_text(digest)
        print(state,len(index),'cached',flush=True)
    motion=C10/'.work/D03_MOTION_AND_SERVICE.step'
    dest=WORK/'motion';dest.mkdir(exist_ok=True)
    index=[]
    for i,(n,s) in enumerate(leaves(motion)):
        p=dest/f'{i:03d}.brep';s.exportBrep(str(p))
        index.append({'path':n,'name':n.split('/')[-2],'b':bounds(s),'file':p.name})
    dump(dest/'index.json',index)
    print('motion',len(index),flush=True)
if __name__=='__main__':main()
