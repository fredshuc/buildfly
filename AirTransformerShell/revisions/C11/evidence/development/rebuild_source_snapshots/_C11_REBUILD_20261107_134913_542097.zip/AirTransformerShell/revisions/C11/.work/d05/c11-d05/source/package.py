"""Package only reviewable deliverables, with round-trip and status assertions."""
from common import *
import zipfile,csv

def run():
 exp=json.loads((ROOT/'evidence/export.json').read_text())
 stat=json.loads((ROOT/'evidence/static_check.json').read_text())
 motion=json.loads((ROOT/'evidence/full_motion.json').read_text())
 svc=json.loads((ROOT/'evidence/service.json').read_text())
 audit=json.loads((ROOT/'evidence/safety_scope_audit.json').read_text())
 for record in ('motion_export','service_export'):
  r=json.loads((ROOT/'evidence'/(record+'.json')).read_text())
  assert sha(ROOT/'cad'/r['file'])==r['sha256'],record
 pocket=json.loads((ROOT/'evidence/pocket_interface.json').read_text())
 assert all(not r['interferences'] and abs(r['supported_face_area']-r['nominal_face_area'])<.001 for r in pocket.values())
 assert len(audit['stop_working_face_proof'])==4
 assert all(r['nominal_flat_contact_area_mm2']>=12 and r['hub_clearance_mm']>0 for r in audit['stop_working_face_proof'].values())
 for state in ('S1','S2'):
  p=ROOT/'cad'/f'C11_D05_INSTALLED_{state}.step'
  assert sha(p)==exp[state]['output_sha256']
  assert not exp[state]['bad'] and not stat[state]['unexpected_penetrations']
  assert len(stat[state]['exact_soft_pairs'])==12
 assert all(not row['unexpected_contacts'] and len(row['first_undesigned'])==2 for row in motion.values())
 assert len(motion)==4 and all(r['uncovered_area']<.001 for v in motion.values() for r in v['coverage'])
 assert all(r['bbox_separation_mm']>0 for r in json.loads((ROOT/'evidence/asynchronous.json').read_text()))
 assert all(not r['penetrations'] for r in svc['components'].values())
 assert all(not r['hits'] for rows in svc['pin_route'].values() for r in rows)
 assert all(float(r['remaining_angle_deg'])>0 for r in csv.DictReader((ROOT/'C11_DAMPERS_STOP_LIMITS.csv').open(encoding='utf-8-sig')))
 eng=json.loads((ROOT/'evidence/engineering.json').read_text())
 assert eng['manufacture_release'] is False and eng['open_interfaces']
 assert all(float(r['worst_remaining_mm'])>0 for r in csv.DictReader((ROOT/'C11_DAMPERS_CLEARANCE_STACK.csv').open(encoding='utf-8-sig')))
 assert eng['stop_strength']['flat_contact_pressure_MPa']<eng['stop_strength']['S355_allowable_MPa']
 files=[p for p in ROOT.rglob('*') if p.is_file() and not any(s in p.relative_to(ROOT).parts for s in ('.work','__pycache__'))
        and p.suffix not in ('.pyc','.zip') and p.name not in ('MANIFEST.json','package.json')]
 manifest={'revision':'C11-D05','manufacture_release':False,'input_C10_sha256':HASHES,
           'files':{p.relative_to(ROOT).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)}}
 dump(ROOT/'MANIFEST.json',manifest);files.append(ROOT/'MANIFEST.json')
 dest=ROOT.parent/'C11_D05_DAMPERS_REVIEW.zip'
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in files:z.write(p,'c11-d05/'+p.relative_to(ROOT).as_posix())
 with zipfile.ZipFile(dest) as z:
  assert z.testzip() is None
  for name,info in manifest['files'].items():
   assert hashlib.sha256(z.read('c11-d05/'+name)).hexdigest()==info['sha256']
 result={'package':str(dest),'bytes':dest.stat().st_size,'sha256':sha(dest),'files':len(files),
         'zip_test_and_member_hash_readback':'PASS','manufacture_release':False}
 dump(ROOT/'evidence/package.json',result);print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':run()
