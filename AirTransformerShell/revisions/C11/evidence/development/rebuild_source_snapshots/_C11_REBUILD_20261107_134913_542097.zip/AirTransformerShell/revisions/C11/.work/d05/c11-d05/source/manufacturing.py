from changes import build_parts
from common import *
from handoff import csvfile
from drawings import dxf
from hardware import pin_centre

def run():
 p,c=build_parts();rows=[]
 for bed in 'AB':
  sign=-1 if bed=='A' else 1
  for level in ('LOWER','UPPER'):
   tag=f'{bed}_{level}';x,z=axis(tag)
   rows.append({'item':tag+'_AXIS','axis':'global Y','X_mm':x,'Z_mm':z,
      'free_end_Y_mm':-12 if bed=='A' else -3,'shaft_material':'1.4542 H1150; certificate and bearing supplier fits required',
      'drawing_tolerance':'centre relative to seat +/-0.15; length +/-0.15; journals Ra0.3-0.5'})
   for i,(dx,dz) in enumerate(((-40,-20),(-40,20),(40,-20),(40,20))):
    rows.append({'item':tag+'_M6_'+str(i),'axis':'Y','X_mm':x+dx,'Z_mm':z+dz,'hole_mm':6.6,
       'drawing_tolerance':'position +/-0.10; existing actuator pattern unchanged'})
   for i in (0,1):
    s=p[f'D05_STOP_PIN_{tag}_{i}'];b=bbox(s)
    px,pz=pin_centre(tag,i)
    rows.append({'item':tag+'_STOP_PIN_'+str(i),'axis':'Y','X_mm':px,'Z_mm':pz,
       'Y0_mm':b[1],'Y1_mm':b[4],'hole_mm':'D10 keyed profile, flat 4.5 from centre',
       'drawing_tolerance':'through wire-EDM matched D bore; interference0.002..0.010 on round portion; final endpoint +/-0.04 deg including profile/clocking error'})
   if level=='LOWER':
    rows.append({'item':tag+'_CARRIER_SPACER_1_1','axis':'Y','X_mm':570,'Z_mm':362,
      'OD_mm':10.5,'bore_mm':6.6,'length_mm':28,'material':'S355',
      'drawing_tolerance':'OD+/-0.05; bore+0.10/-0; L+/-0.05; unchangedY=+/-876..904; M6 preload4..6kN'})
    shaft=p[f'DAMPER_SHAFT_{tag}_0_O']
    section=shaft.intersect(cq.Face.makePlane(2400,2400,(x,0,z),(1,0,0)))
    dxf(section,ROOT/'drawings'/f'D05_SHAFT_{tag}_SECTION_1to1.dxf',axes=(1,2))
   for pos in ('DEEP','SLOPED'):
    s=p[f'DAMPER_SEAT_{tag}_{pos}_O']
    f=next(f for f in s.Faces() if f.innerWires());normal=f.normalAt()
    radial=normal.cross(cq.Vector(0,1,0))
    rel=f.Center()-cq.Vector(x,0,z)
    if radial.dot(rel)<0:radial=radial*-1
    # Flatten using the actual plane; U=globalY, V=radial distance from axis.
    lines=['0','SECTION','2','HEADER','9','$INSUNITS','70','4','0','ENDSEC','0','SECTION','2','ENTITIES']
    for e in f.Edges():
     count=2 if e.geomType()=='LINE' else max(64,int(e.Length()/.25))
     pp=[e.positionAt(k/(count-1)) for k in range(count)]
     for a,b in zip(pp,pp[1:]):
      va=radial.dot(a-cq.Vector(x,0,z));vb=radial.dot(b-cq.Vector(x,0,z))
      lines+=['0','LINE','8','CUT_PROFILE','10',str(a.y),'20',str(va),'30','0','11',str(b.y),'21',str(vb),'31','0']
    lines+=['0','ENDSEC','0','EOF']
    file=f'D05_SEAT_{tag}_{pos}_1to1.dxf';(ROOT/'drawings'/file).write_text('\n'.join(lines)+'\n',encoding='ascii')
    aperture=cq.Face.makeFromWires(f.innerWires()[0])
    rows.append({'item':tag+'_'+pos+'_CUT_PROFILE','DXF':file,'U':'global Y','V_X_component':radial.x,'V_Z_component':radial.z,
       'origin_X_mm':x,'origin_Z_mm':z,'thickness_mm':2,'aperture_area_mm2':aperture.Area(),
       'material':'1.4301 sheet','drawing_tolerance':'steel relief R18.70 +0.10/-0; profile +/-0.15; thickness +/-0.10; deburr R0.3; no kerf compensation in DXF'})
 for bed,ys in [('A',[-774.5,-736]),('B',[60.5,128])]:
  for y in ys:rows.append({'item':bed+'_PIN_SHELL_M4','axis':'X','X0_mm':-521.5,'X1_mm':-506.5,'Y_mm':y,'Z_mm':1155,
     'hole_mm':4.5,'drawing_tolerance':'stud position +/-0.10; Shell owns mating hole, compression stops and nuts'})
 csvfile('C11_DAMPERS_AXES_AND_HOLES.csv',rows)
 print('Axes / holes / ten additional cutting profiles generated',flush=True)

if __name__=='__main__':run()
