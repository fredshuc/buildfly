from common import *
from OCP.STEPCAFControl import STEPCAFControl_Reader,STEPCAFControl_Writer
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString as S
from OCP.XCAFDoc import XCAFDoc_DocumentTool
from OCP.TDF import TDF_LabelSequence
from OCP.TDataStd import TDataStd_Name
from OCP.gp import gp_Trsf
from OCP.TopLoc import TopLoc_Location
from OCP.STEPControl import STEPControl_AsIs
from collections import Counter
doc=TDocStd_Document(S('H02'));r=STEPCAFControl_Reader();r.SetNameMode(True)
assert r.ReadFile(str(OUT/'H02_SINGLE_CORE.step'))==1 and r.Transfer(doc)
tool=XCAFDoc_DocumentTool.ShapeTool_s(doc.Main());seq=TDF_LabelSequence();tool.GetFreeShapes(seq);assert seq.Length()==1
product=seq.Value(1);root=tool.NewShape();TDataStd_Name.Set_s(root,S('H02_FOUR_IDENTICAL_HORIZONTAL_HX'))
for k,p in PLACEMENTS.items():
    x,y,z=p['translation'];t=gp_Trsf();t.SetValues(0,0,-1,x,0,-1,0,y,-1,0,0,z)
    occ=tool.AddComponent(root,product,TopLoc_Location(t));TDataStd_Name.Set_s(occ,S(k))
tool.UpdateAssemblies();w=STEPCAFControl_Writer();w.SetNameMode(True);assert w.Transfer(root,STEPControl_AsIs)
out=OUT/'H02_FOUR_HX_INSTALLED.step';assert w.Write(str(out))==1
counts=Counter(next(k for k in PLACEMENTS if k in n.split('/')) for n,s in leaves(out))
expected=json.loads((OUT/'evidence/BUILD.json').read_text())['single_core_parts']
assert list(counts.values())==[expected]*4,counts
dump(OUT/'evidence/FOUR_CORE_READBACK.json',{'core_sha256':hashlib.sha256((OUT/'H02_SINGLE_CORE.step').read_bytes()).hexdigest(),'counts':counts,'one_product_definition':True,'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()})
print('Four identical H02 cores',counts,flush=True)
