"""Continuous conservative sweeps and exact-pose distance queries."""
from common import *
import numpy as np
from itertools import product
from scipy.spatial import ConvexHull
from OCP.BRepExtrema import BRepExtrema_DistShapeShape

def witness(a,b):
    ext=BRepExtrema_DistShapeShape(a.wrapped,b.wrapped)
    ext.Perform()
    assert ext.IsDone()
    points=[ext.PointOnShape1(1),ext.PointOnShape2(1)]
    return {'mm':ext.Value(),'points':[[p.X(),p.Y(),p.Z()] for p in points]}

def hull_sweep(shape,tag,start=0,end=THETA,intervals=64):
    x,z=axis(tag)
    bounds=bbox(shape)
    points=np.array([(v.Center().x-x,v.Center().z-z) for v in shape.Vertices()])
    radius=max(np.linalg.norm(points,axis=1))
    slices=[]
    for a,b in zip(np.linspace(start,end,intervals+1)[:-1],np.linspace(start,end,intervals+1)[1:]):
        vertices=[]
        pad=radius*(1-math.cos(math.radians(b-a)/2))+1e-6
        for angle in (a,b):
            c,s=math.cos(math.radians(angle)),math.sin(math.radians(angle))
            rotated=points@np.array([[c,-s],[s,c]])
            for off in product((-pad,pad),repeat=2):
                vertices.extend(rotated+off)
        vertices=np.array(vertices)
        hull=ConvexHull(vertices)
        wire=cq.Wire.makePolygon([cq.Vector(x+vertices[i,0],bounds[1],z+vertices[i,1]) for i in hull.vertices],close=True)
        slices.append(cq.Solid.extrudeLinear(wire,[],(0,bounds[4]-bounds[1],0)))
    return cq.Compound.makeCompound(slices)

def blade_sweep(s,tag,start=0,end=THETA,intervals=64):
    b=bbox(s)
    if 'UPPER' not in tag:
        return hull_sweep(s,tag,start,end,intervals)
    cuts=[b[1],b[1]+50,b[4]-50,b[4]]
    return cq.Compound.makeCompound([hull_sweep(s.intersect(box(b[0]-1,lo,b[2]-1,b[3]+1,hi,b[5]+1)),
                                               tag,start,end,intervals) for lo,hi in zip(cuts,cuts[1:])])

def aperture_results(parts,tag):
    blade=parts[f'DAMPER_BLADE_{tag}_0_O']
    result=[]
    for pos,angle in [('SLOPED',0),('DEEP',THETA)]:
        plate=rotate(blade,tag,angle)
        seat=parts[f'DAMPER_SEAT_{tag}_{pos}_O']
        face=next(f for f in seat.Faces() if f.innerWires())
        loop=face.innerWires()[0]
        aperture=cq.Face.makeFromWires(loop)
        blade_face=max(plate.Faces(),key=lambda f:f.Area())
        normal=face.normalAt()
        projected=blade_face.translate(normal*(loop.Center()-blade_face.Center()).dot(normal))
        result.append({'port':pos,'angle':angle,'aperture_area':aperture.Area(),
                       'uncovered_area':aperture.cut(projected).Area(),
                       'edge_overlap':loop.distance(projected.outerWire())})
    return result

def probe():
    from changes import build_parts
    parts,changed=build_parts()
    index=json.loads((ROOT/'.work/S1/index.json').read_text(encoding='utf-8'))['parts']
    results={}
    for bed in 'AB':
        for level in ('LOWER','UPPER'):
            tag=f'{bed}_{level}'
            blade=parts[f'DAMPER_BLADE_{tag}_0_O']
            sleeve=parts[f'DAMPER_ROOT_SLEEVE_{tag}_0_O']
            result={'coverage':aperture_results(parts,tag),'root':{},
                    'first_steel':{}}
            for pos in ('DEEP','SLOPED'):
                seat=parts[f'DAMPER_SEAT_{tag}_{pos}_O']
                result['root'][pos]=witness(sleeve,seat)
                # Detect steel touch beyond normal pose in each direction.
                for side,origin,sign in [('P',0,-1),('R',THETA,1)]:
                    lo,hi=0.,5.
                    if rotate(blade,tag,origin+sign*hi).distance(seat)>1e-6:
                        continue
                    for _ in range(18):
                        mid=(lo+hi)/2
                        if rotate(blade,tag,origin+sign*mid).distance(seat)>1e-6:
                            lo=mid
                        else:
                            hi=mid
                    result['first_steel'][side+'_'+pos]=[origin+sign*hi,hi]
            if level=='UPPER':
                sweep=blade_sweep(blade,tag)
                b=bbox(sweep)
                candidates=[r for r in index if r['group']=='HEAT_EXCHANGERS' and gap(b,r['bbox'])<8]
                near=None
                for r in candidates:
                    target=cq.Shape.importBrep(str(ROOT/'.work/S1'/r['file']))
                    w=witness(sweep,target)
                    print(tag,r['name'],round(w['mm'],6),flush=True)
                    if near is None or w['mm']<near['mm']:
                        near={**w,'part':r['path']}
                result['hx_sweep']=near
                print(tag,'HX',near,'candidates',len(candidates),flush=True)
            results[tag]=result
            print(tag,result['coverage'],result['root'],result['first_steel'],flush=True)
    dump(ROOT/'evidence/probe.json',results)

if __name__=='__main__':
    probe()
