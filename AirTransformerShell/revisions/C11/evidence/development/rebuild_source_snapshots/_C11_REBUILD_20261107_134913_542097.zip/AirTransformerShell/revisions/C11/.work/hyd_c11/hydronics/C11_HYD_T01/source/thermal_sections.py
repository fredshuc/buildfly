from pathlib import Path
import csv,math
from cad_io import cq
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,Rectangle
P=Path(__file__).resolve().parents[1];root=P.parents[1]
fig,axs=plt.subplots(1,3,figsize=(15,5),constrained_layout=True)
for ax,t,title in [(axs[0],5,'Existing D45: FAIL at 32/26/5 C'),(axs[1],25,'D91 hole request: NOT RELEASED')]:
 ax.add_patch(Circle((0,0),17.5+t,color='#8dc3b1'));ax.add_patch(Circle((0,0),17.5,color='#b36b40'));ax.add_patch(Circle((0,0),14,color='white'))
 ax.add_patch(Circle((0,0),22.5 if t==5 else 45.5,fill=False,ls='--',lw=2,color='#354e70'))
 ax.set_xlim(-57,57);ax.set_ylim(-57,57);ax.set_aspect('equal');ax.set_title(title);ax.set_xlabel('section mm');ax.grid(alpha=.2)
 ax.annotate(f'{t} mm insulation',xy=(0,17.5+t),xytext=(-45,50),arrowprops={'arrowstyle':'->'})
axs[2].set_xlim(0,180);axs[2].set_ylim(0,110);axs[2].axis('off')
axs[2].add_patch(Rectangle((80,10),6,90,color='#7f8c8d'));axs[2].add_patch(Rectangle((10,45),160,20,color='#b36b40'));axs[2].add_patch(Rectangle((10,65),160,20,color='#8dc3b1'));axs[2].add_patch(Rectangle((10,25),160,20,color='#8dc3b1'))
axs[2].plot([10,170],[86,86],color='#354e70',lw=3);axs[2].plot([10,140,145],[24,24,15],color='#354e70',lw=3)
axs[2].annotate('Dry side',xy=(15,5));axs[2].annotate('Wet side',xy=(125,5));axs[2].annotate('Upper seam / staggered lap',xy=(55,86),xytext=(5,102),arrowprops={'arrowstyle':'->'})
axs[2].annotate('Drip to dedicated collector\nterminal IF-04 OPEN',xy=(145,15),xytext=(90,35),fontsize=8,arrowprops={'arrowstyle':'->'})
axs[2].set_title('Axial interface REQUIREMENT (schematic)')
fig.suptitle('IF-05: thermal/vapour separation; no metal bridge; pipe positions unchanged')
fig.savefig(P/'C11_THERMAL_SECTIONS.svg');fig.savefig(P/'C11_THERMAL_SECTIONS.png',dpi=150)
a=cq.Assembly(name='C11_INNER_HOLE_REQUEST_NOT_FOR_CUTTING')
for r in csv.DictReader(open(root/'HX/M101_C08_HORIZONTAL_H01/HOST_CUT_PROPOSAL.csv')):
 if r['layer']=='INNER':a.add(cq.Solid.makeCylinder(45.5,12,cq.Vector(-510,float(r['y_mm']),float(r['z_mm'])),cq.Vector(1,0,0)),name=r['tag']+'_D91_REQUEST')
a.save(str(P/'cad/C11_THERMAL_HOLE_REQUEST.step'))
