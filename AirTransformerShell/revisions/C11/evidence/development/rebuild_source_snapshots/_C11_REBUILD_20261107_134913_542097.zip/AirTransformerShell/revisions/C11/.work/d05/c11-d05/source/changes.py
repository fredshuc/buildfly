"""D05 localized candidate geometry. All returned parts are normalized at P=0 deg."""
from common import *

TIP=213.6
CENTRE_TIP=215.6
ROOT_RADIUS=18.7
SHAFT_ENDS={'A':-12.,'B':-3.}

def _build_parts():
    parts,src=normalized()
    changed={}
    for bed in 'AB':
        for level in ('LOWER','UPPER'):
            tag=f'{bed}_{level}'
            x,z=axis(tag)
            n=f'DAMPER_SHAFT_{tag}_0_O'
            cut=(box(x-40,SHAFT_ENDS[bed],z-40,x+40,50,z+40) if bed=='A'
                 else box(x-40,-50,z-40,x+40,SHAFT_ENDS[bed],z+40))
            parts[n]=parts[n].cut(cut).clean()
            changed[n]='Shorten only the bare central shaft end by 4 mm'
            for pos in ('DEEP','SLOPED'):
                n=f'DAMPER_SEAT_{tag}_{pos}_O'
                b=bbox(parts[n])
                parts[n]=parts[n].cut(cy(x,z,b[1]-1,b[4]+1,ROOT_RADIUS)).clean()
                changed[n]='Root steel relief radius 18.7 mm'
            if level=='UPPER':
                n=f'DAMPER_BLADE_{tag}_0_O'
                s=parts[n];b=bbox(s)
                for ya,yb,tip in ((b[1]-1,b[1]+50,TIP),(b[1]+50,b[4]-50,CENTRE_TIP),(b[4]-50,b[4]+1,TIP)):
                    cutter=box(tip,ya,-10,260,yb,10).rotate((0,0,0),(0,1,0),90-THETA).translate((x,0,z))
                    s=s.cut(cutter)
                parts[n]=s.clean()
                changed[n]='End strips 50 mm at radial 213.6; middle strip at 215.6 mm'
                for pos,ang in [('SLOPED',0),('DEEP',THETA)]:
                    sn=f'DAMPER_SEAL_{tag}_{pos}_O';seal=parts[sn]
                    for ya,yb,tip in ((b[1]-1,b[1]+50,TIP),(b[1]+50,b[4]-50,CENTRE_TIP),(b[4]-50,b[4]+1,TIP)):
                        cutter=box(tip-.4,ya,-15,260,yb,15).rotate((0,0,0),(0,1,0),90-THETA).translate((x,0,z))
                        seal=seal.cut(rotate(cutter,tag,ang))
                    parts[sn]=seal.clean();changed[sn]='Matched tip seal trimmed 0.4 mm inside new blade perimeter'
            for n,s in parts.items():
                if tag in n and n in changed:
                    assert s.isValid() and len(s.Solids())==1,n
    from hardware import hardware
    from seals import seals
    from pin_detail import pin_detail
    parts,changed=hardware(parts,changed)
    parts,changed=seals(parts,changed)
    return pin_detail(parts,changed)

def build_parts():
    """Reuse only a complete cache tied to all geometry source hashes."""
    folder=ROOT/'.work/frozen';index=folder/'index.json'
    signature={n:sha(Path(__file__).parent/n) for n in ('changes.py','common.py','hardware.py','seals.py','pin_detail.py')}
    signature['cadquery']=cq.__version__
    if index.exists() and (ROOT/'evidence/seal_geometry.json').exists():
        data=json.loads(index.read_text(encoding='utf-8'))
        if data['signature']==signature:
            return {n:cq.Shape.importBrep(str(folder/f)) for n,f in data['parts'].items()},data['changed']
    p,c=_build_parts();folder.mkdir(parents=True,exist_ok=True);files={}
    for i,(n,s) in enumerate(p.items()):
        assert s.isValid() and s.Solids(),n
        fn=f'{i}.brep';s.exportBrep(str(folder/fn));files[n]=fn
    dump(index,{'signature':signature,'parts':files,'changed':c})
    return p,c

if __name__=='__main__':
    p,c=build_parts()
    folder=ROOT/'.work/candidate'
    folder.mkdir(exist_ok=True)
    index={}
    for i,(n,s) in enumerate(p.items()):
        fn=f'{i}.brep';s.exportBrep(str(folder/fn));index[n]=fn
    dump(folder/'index.json',index)
    dump(ROOT/'evidence/changes.json',c)
    print('Candidate',len(c),flush=True)
