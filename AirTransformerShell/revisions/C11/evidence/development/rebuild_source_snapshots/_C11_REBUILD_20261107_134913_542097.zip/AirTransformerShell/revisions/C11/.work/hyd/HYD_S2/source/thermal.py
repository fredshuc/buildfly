"""python thermal.py HX_H01 S1_MACHINE_STEP OUT. Make water-side thermal crown request, not a fabrication opening."""
from pathlib import Path
import csv,sys,json,math
from cad_io import cq,bb,leaves,overlaps
hx,mach,out=map(Path,sys.argv[1:]);sys.path.append(str(hx/'source'))
from build import end
source_ends=dict(leaves(hx/'H01_EIGHT_INSTALLED_ENDS.step'))
wire=end('W2','wire');placements=json.load((hx/'PLACEMENTS.json').open())
host=[(p,s,bb(s)) for p,s in leaves(mach) if '/HOST/' in p];result={};a=cq.Assembly(name='W2_CLEARANCE_REQUEST');j=cq.Assembly(name='W2_INSULATION_ADDITIONAL_CROWN')
for bed in 'AB':
 t=placements[bed+'_UPPER']['translation'];loc=cq.Location(cq.Vector(*t),cq.Vector(1,0,-1),180)
 def cap(r):
  shape=cq.Workplane(cq.Plane(origin=(52.65,726.85,1080),normal=(0,0,1))).circle(r).sweep(wire,isFrenet=False).val().moved(loc)
  return shape.intersect(cq.Solid.makeBox(180,300,100,cq.Vector(-687,t[1]-850,1141.5))) # clip wet-bay portion before inner gland x=-507
 ins=cap(42.5);budget=cap(44.5)
 assert ins.isValid() and budget.isValid() and abs(bb(budget)[5]-1166.85)<.001
 notch_info=None
 if bed=='A':
  _,post,pb=next(it for it in host if it[0].split('/')[-2]=='F_POST_-600_-825_O')
  original_v=budget.intersect(post).Volume()
  def protect(slack):
   return cq.Solid.makeBox(*[pb[i+3]-pb[i]+2*slack for i in range(3)],cq.Vector(*[pb[i]-slack for i in range(3)]))
  rawins=ins
  ins=ins.cut(protect(2));budget=budget.cut(protect(0.05))
  w2=next(shape for n,shape in source_ends.items() if 'A_U_W2__W2_D35_END_PIPE' in n)
  notch_faces=[]
  for f in ins.Faces():
   if f.geomType()=='PLANE' and any(abs(f.Center().toTuple()[i]-p)<.001 for i in (0,1) for p in (pb[i]-2,pb[i+3]+2)):
    notch_faces.append(f)
  notch_info={'original_uncropped_budget_intersection_post_mm3':round(original_v,3),'post_to_new_material_min_mm':round(ins.distance(post),3),'removed_material_mm3':round(rawins.Volume()-ins.Volume(),3),'new_corner_face_to_W2_min_mm':round(min(f.distance(w2) for f in notch_faces),3) if notch_faces else None}
  assert ins.distance(post)>1.999 and budget.intersect(post).Volume()<.001
 a.add(budget,name=bed+'_W2_25mm_PLUS_2mm_SPACE');j.add(ins,name=bed+'_W2_25mm_CROWN_ONLY')
 hits=[]
 for p,s,b in host:
  if overlaps(bb(budget),b):
   vol=budget.intersect(s).Volume()
   if vol>.001:hits.append([p.split('/')[-2],round(vol,3)])
 result[bed]={'additional_material_bounds_mm':bb(ins),'clearance_bounds_mm':bb(budget),'intersected_host':hits,'corner_treatment':notch_info}
a.save(str(out/'W2_HOST_SPACE_REQUEST.step'));j.save(str(out/'W2_ADDITIONAL_INSULATION.step'))
(out/'thermal_interface.json').write_text(json.dumps(result,indent=2));print(result,flush=True)
