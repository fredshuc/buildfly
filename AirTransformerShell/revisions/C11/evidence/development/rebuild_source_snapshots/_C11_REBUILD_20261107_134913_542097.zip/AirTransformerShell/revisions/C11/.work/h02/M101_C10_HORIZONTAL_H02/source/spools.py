"""H02 first-spool pressure-joint prototype detail; ISO/OEM approval not implied."""
from common import *
def ring(x,r,ax,rad,y,z):
    return cq.Workplane('XY').moveTo(x,r).ellipse(ax,rad).revolve(360,(0,0,0),(1,0,0)).val().translate((0,y,z))
def main():
    old=read(H01/'H01_EIGHT_FIRST_SPOOLS.step');new={};services={};dimensions=[]
    ports=list(csv.DictReader((H01/'EIGHT_PORTS_AND_SPOOLS.csv').open()))
    for row in ports:
        tag=row['tag'];face,y,z=json.loads(row['HX_face']);rack=-865.;rs=rack+10;hs=face-24;mid=rs+(hs-rs)*.58
        p={n.split('__')[1]:s for n,s in old.items() if n.startswith(tag+'__')}
        del p['LOCK']
        # Matching D33.7/ID27.3 weld neck at the existing rack face. Shop weld
        # before installing any elastomer; no pipe-length change at X=-865.
        p['FIXED_RACK_TAIL']=tube((rack,y,z),(1,0,0),16.85,13.65,10).fuse(tube((rs-3,y,z),(1,0,0),29.5,13.65,3)).clean()
        # 12 mm R1-1/4 male machining stock. Thread is drawing-specified;
        # gauge/engagement qualification with Viega is still required.
        male=cq.Solid.makeCone(20.955,20.580,12,V(face,y,z),V(1,0,0)).cut(cyl((face,y,z),(1,0,0),13.65,12))
        p['FIXED_HX_TAIL']=p['FIXED_HX_TAIL'].fuse(male).clean()
        # Two radial seals, metric 29 x 2.5 EPDM, compressed geometry.
        for j,x in enumerate((mid-10,mid-5)):
            groove=tube((x,y,z),(1,0,0),16.86,14.95,3.4)
            p['SLIDE']=p['SLIDE'].cut(groove)
            p[f'RADIAL_EPDM_29x2p5_{j}']=ring(x+1.7,15.975,1.52439,1.025,y,z)
        # Axial face seals in the moving halves; groove OD37 x width3.4 x depth1.9.
        for label,x in [('RACK',rs),('HX',hs-1.9)]:
            g=tube((x,y,z),(1,0,0),18.5,15.1,1.9)
            key='BODY' if label=='RACK' else 'SLIDE'
            p[key]=p[key].cut(g).clean()
            p[f'FACE_EPDM_32x2p5_{label}']=ring(x+.95,16.8,.95,1.64474,y,z)
        # Split collars gain positive bolted retention, two M4 fasteners each.
        for side,x in [('HX',hs),('RACK',rs)]:
            for half in (0,1):
                n=f'{side}_RETAINER_{half}';s=p[n]
                for sign in (-1,1):
                    zz=z+sign*38
                    ear=box(x-5,y+(-9 if half==0 else 0),zz-7,10,9,14)
                    s=s.fuse(ear).cut(cyl((x,y-10,zz),(0,1,0),2.25,20))
                p[n]=s.clean()
            for sign in (-1,1):
                zz=z+sign*38
                p[f'{side}_BOLT_{sign}']=cyl((x,y-13,zz),(0,1,0),3.5,4).fuse(cyl((x,y-9,zz),(0,1,0),2,24)).clean()
                p[f'{side}_NUT_{sign}']=tube((x,y+9,zz),(0,1,0),4,2,3.2)
                services[f'{tag}__{side}_SCREW_TOOL_{sign}']=cyl((x,y-65,zz),(0,1,0),10,52)
            for half in (0,1):
                n=f'{side}_RETAINER_{half}';b=bounds(p[n]);d=-65 if half==0 else 65
                services[tag+'__RELEASE_'+n]=box(b[0],b[1]+min(0,d),b[2],b[3]-b[0],b[4]-b[1]+65,b[5]-b[2])
        for n,s in p.items():assert s.isValid(),(tag,n)
        new.update({tag+'__'+n:s for n,s in p.items()})
        # Actual Knipex 86 03 250 dimensions: 8 mm jaws, 14 mm joint, 18 mm grip.
        # Counterhold pair handles are clocked to opposite vertical directions.
        sign=-1 if tag.endswith('W1') else 1
        for name,x,af in [('SW46',face-18,46),('SW50',face+5.76,50)]:
            services[f'{tag}__{name}_JAW']=tube((x-4,y,z),(1,0,0),45,af/math.sqrt(3),8)
            services[f'{tag}__{name}_JOINT']=box(x-7,y+(35 if sign>0 else -95),z-28,14,60,56)
            services[f'{tag}__{name}_GRIP_SWEEP']=box(x-9,y+(90 if sign>0 else -255),z-88,18,165,176)
        # Retraction and nonrotating withdrawal envelopes include all moving seals.
        for n,s in p.items():
            if n in ('BODY','SLIDE') or n.startswith(('RADIAL_EPDM','FACE_EPDM')):
                dx=-6 if n=='SLIDE' or n.startswith('RADIAL_EPDM') or n.endswith('_HX') else 0
                b=bounds(s);start=b[0]+dx+3
                if dx:services[tag+'__RETRACT_'+n]=box(b[0]-6,b[1],b[2],b[3]-b[0]+6,b[4]-b[1],b[5]-b[2])
                services[tag+'__SHIFT_'+n]=box(b[0]+dx,b[1],b[2],b[3]-b[0]+3,b[4]-b[1],b[5]-b[2])
                services[tag+'__LIFT_'+n]=box(start,b[1],b[2],b[3]-b[0],b[4]-b[1],b[5]-b[2]+110)
                d=(-1350 if tag.startswith('A') else 1350)-y
                services[tag+'__SIDE_EXIT_'+n]=box(start,b[1]+min(0,d),b[2]+110,b[3]-b[0],b[4]-b[1]+abs(d),b[5]-b[2])
        dimensions.append({'tag':tag,'face':json.loads(row['HX_face']),'rack_face':[-865,y,z],
                           'length_mm':77.5,'male_stock_length_mm':12,'radial_ring':'29 x 2.5 EPDM 70, groove D29.9 x3.4',
                           'face_ring':'32 x 2.5 EPDM 70, OD37 x width3.4 x depth1.9',
                           'retention':'two M4 A2-70 per collar; two collars per spool',
                           'SW46_SW50_jaw_axial_gap_mm':15.76,'conservative_18mm_axial_gap_mm':5.76,
                           'pressure_status':'design calculation only; hydro proof, sealing, pullout and thermal cycle outstanding'})
    csvwrite(OUT/'FIRST_SPOOL_DETAIL.csv',dimensions)
    result=[save(new,'H02_EIGHT_FIRST_SPOOLS'),save(services,'H02_FIRST_SPOOL_SERVICE')]
    dump(OUT/'evidence/SPOOL_BUILD.json',{'exports':result})
if __name__=='__main__':main()
