from common import *
core=read(OUT/'H02_SINGLE_CORE.step')
pairs=[('W1_DRAIN_ADAPTER_G14','W1_DRAIN_LINE'),('W2_DRAIN_ADAPTER_G14','W2_DRAIN_LINE'),('H02_COND_BLADE_00','H02_COND_HEADER_LINK'),('H02_COND_BLADE_32','H02_COND_UBEND_LINK'),('H02_COND_BLADE_33','H02_COND_UBEND_LINK'),('H02_COND_UBEND_GUTTER','TOP_CROSS_41.775')]
rows=[]
for a,b in pairs:
    v=core[a].intersect(core[b]).Volume();rows.append({'a':a,'b':b,'overlap_mm3':v})
result={'core_sha256':hashlib.sha256((OUT/'H02_SINGLE_CORE.step').read_bytes()).hexdigest(),'pairs':rows,'all_le_0p001_mm3':all(r['overlap_mm3']<=.001 for r in rows)}
dump(OUT/'evidence/LOCAL_REPAIR_INTERSECTIONS.json',result)
print(json.dumps(result),flush=True)
assert result['all_le_0p001_mm3']
