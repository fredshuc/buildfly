"""Dimensioned CAD-derived candidate details and 1:1 DXF profiles."""
from changes import build_parts
from common import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle,Arc
from hardware import pin_centre

def edges(ax,s,axes=(0,2),offset=(0,0),color='#185873',lw=1):
 for e in s.Edges():
  count=2 if e.geomType()=='LINE' else max(24,int(e.Length()/1.5))
  points=[e.positionAt(i/(count-1)).toTuple() for i in range(count)]
  ax.plot([p[axes[0]]+offset[0] for p in points],[p[axes[1]]+offset[1] for p in points],color=color,lw=lw)

def finish(fig,ax,name,title,notes):
 ax.set_title(title,fontsize=12,weight='bold',loc='left');ax.set_aspect('equal',adjustable='box');ax.grid(alpha=.2)
 fig.text(.08,.025,notes+'\nD05 / C11 | mm | DESIGN CANDIDATE - interface/test holds apply',fontsize=8,va='bottom')
 fig.subplots_adjust(left=.1,right=.97,bottom=.20,top=.90)
 for ext in ('png','svg'):fig.savefig(ROOT/'drawings'/f'{name}.{ext}',dpi=180)
 plt.close(fig)

def dxf(s,path,axes=(0,1)):
 # R2010-style entities with explicitly declared millimetres. Curves are
 # segmented at <=0.01 mm sagitta; all manufacturing sizes remain in drawings.
 lines=['0','SECTION','2','HEADER','9','$ACADVER','1','AC1024','9','$INSUNITS','70','4','0','ENDSEC','0','SECTION','2','ENTITIES']
 for e in s.Edges():
  count=2 if e.geomType()=='LINE' else max(64,int(e.Length()/.25))
  pts=[e.positionAt(i/(count-1)).toTuple() for i in range(count)]
  for a,b in zip(pts,pts[1:]):
   lines+=['0','LINE','8','CUT_PROFILE','10',str(a[axes[0]]),'20',str(a[axes[1]]),'30','0','11',str(b[axes[0]]),'21',str(b[axes[1]]),'31','0']
 lines+=['0','ENDSEC','0','EOF'];path.write_text('\n'.join(lines)+'\n',encoding='ascii')

def run():
 p,c=build_parts()
 # Shaft centre gap plus unchanged inner bearing locations.
 fig,ax=plt.subplots(figsize=(10,6))
 for bed,color in [('A','#23617b'),('B','#bb6426')]:
  s=p[f'DAMPER_SHAFT_{bed}_LOWER_0_O'];b=bbox(s)
  ax.add_patch(Rectangle((max(-45,b[1]),-15),min(45,b[4])-max(-45,b[1]),30,facecolor=color,alpha=.45))
  ib=p[f'D03_INNER_BEARING_INTERFACE_{bed}_LOWER'];q=bbox(ib)
  ax.add_patch(Rectangle((q[1],-27.5),q[4]-q[1],55,fill=False,edgecolor=color,lw=2))
  ax.text((q[1]+q[4])/2,32,bed+' inner support',ha='center',fontsize=9)
 ax.annotate('',(-12,0),(-3,0),arrowprops={'arrowstyle':'<->','color':'crimson'});ax.text(-7.5,5,'9.00',ha='center',color='crimson')
 ax.axvline(-12,color='gray',ls='--');ax.axvline(-3,color='gray',ls='--');ax.set_xlim(-45,40);ax.set_ylim(-35,40)
 ax.set_xlabel('Global Y');ax.set_ylabel('Radius from X610 / Z342')
 finish(fig,ax,'D05-01_SHAFT_ENDS','D05-01  Central free ends / fixed-floating lower shafts',
  'A end Y=-12; B end Y=-3. Remove 4 mm each. Length +/-0.15; bearing span/leaf/pins unchanged.\n6006 fixed centres Y=+/-869; shoulder D40; A30 groove D28.6 x1.60. Axial play 0.10-0.20 each.\n17-4PH H1150 shaft; journals per bearing supplier; floating DU journal Ra0.3-0.5. Cold push-in gap >=8.0.')
 # Root detail, including actual narrowed seal lands.
 fig,ax=plt.subplots(figsize=(10,6))
 tag='A_LOWER'
 for n,color in [(f'DAMPER_ROOT_LIP_{tag}_O','#c4742b'),(f'DAMPER_ROOT_SLEEVE_{tag}_0_O','#28647c'),
                  (f'DAMPER_SEAT_{tag}_DEEP_O','#555'),(f'DAMPER_SEAT_{tag}_SLOPED_O','#555')]:
  edges(ax,p[n],offset=(-610,-342),color=color)
 ax.set_xlim(-28,28);ax.set_ylim(-27,28);ax.set_xlabel('X -610');ax.set_ylabel('Z -342')
 ax.annotate('Steel relief R18.70\n(+0.10 / -0)',(5.5,math.sqrt(18.7**2-5.5**2)),(-25,22),fontsize=9,arrowprops={'arrowstyle':'->'})
 ax.text(-24,-23,'Sleeve R16.50\nNominal steel clearance 2.20',fontsize=10)
 finish(fig,ax,'D05-02_ROOT','D05-02  Root steel relief / replaceable rubbing profile',
  'Retain shaft centre, sleeve length and both crosspin centres. Deburr R0.3; no weld burr in sweep.\nVMQ R401/40 S: two 7-degree contact lands, R16.25 free / R16.5 sleeve; backing R20.5; relieved bore R17.\nRoot lip hot preload, friction and wear remain OPEN. Root-end bands: D29 free, two 2 mm bands; see seal register.')
 # Developed upper blade profile from real CAD face, not a redrawn rectangle.
 s=p['DAMPER_BLADE_A_UPPER_0_O'].translate((500,0,-1385)).rotate((0,0,0),(0,1,0),-(90-THETA))
 face=max(s.Faces(),key=lambda f:f.Area());dxf(face,ROOT/'drawings/D05-03_UPPER_BLADE_1to1.dxf')
 fig,ax=plt.subplots(figsize=(11,6));edges(ax,face,axes=(1,0),offset=(750,0))
 ax.plot([0,50,50,600,600,650],[216,216,220,220,216,216],ls='--',color='#aaa',label='C10 tip')
 ax.text(12,226,'50',fontsize=9);ax.text(300,226,'550',fontsize=9);ax.text(615,226,'50',fontsize=9)
 ax.annotate('R213.60',(25,213.6),(75,185),arrowprops={'arrowstyle':'->'},fontsize=10)
 ax.annotate('R215.60',(300,215.6),(310,170),arrowprops={'arrowstyle':'->'},fontsize=10)
 ax.set_xlabel('Blade span, Y +750');ax.set_ylabel('Radius from shaft');ax.legend(loc='lower right')
 finish(fig,ax,'D05-03_UPPER_BLADE','D05-03  Upper tip contour + matched sealing band',
  'Sheet1.00 +/-0.05, profile +/-0.15, flatness0.20. Ease cut corners R0.5 within inward tolerance.\nSame profile both beds, installed at existing transforms. Aperture unchanged. Min nominal overlap3.5925.\n3.00 mm HT870 contact band starts at aperture edge. Free6.20 +/-0.15; installed CAD4.00; normal loaded acceptance3.80-5.10.')
 # Four-valve common stop profile and exact pin centres.
 fig,ax=plt.subplots(figsize=(10,7));tag='A_UPPER';x,z=axis(tag)
 arm=p[f'D05_STOP_ARM_{tag}'];edges(ax,arm,offset=(-x,-z));edges(ax,rotate(arm,tag,THETA),offset=(-x,-z),color='#9bbac8')
 for i in (0,1):edges(ax,p[f'D05_STOP_PIN_{tag}_{i}'],offset=(-x,-z),color='#b46322',lw=2)
 ax.add_patch(Circle((0,0),39,fill=False,ls='--',color='gray'));ax.set_xlim(-46,45);ax.set_ylim(-45,45)
 ax.set_xlabel('Local X');ax.set_ylabel('Local Z');ax.text(18,-31,'P pin (17.5,-30)',fontsize=9)
 px,pz=pin_centre(tag,1);ax.text(-43,20,f'R pin ({px-x:.5f},{pz-z:.5f})',fontsize=9)
 face=max([f for f in arm.Faces() if abs(f.normalAt().y)>.99],key=lambda f:f.Area());dxf(face,ROOT/'drawings/D05-04_STOP_ARM_1to1.dxf',axes=(0,2))
 finish(fig,ax,'D05-04_STOPS','D05-04  Four hard stops / load path at drive end',
  'S355 arm t3, tongue26 wide, R2 root blends, tip Z=-35; D24 bore / flat X+9; measured backlash<=0.10 deg.\nD10 keyed pins,0.5 contact flat; effective contact>=12 mm2. Jig endpoints0/77.701929 +/-0.04 deg.\nUpper: arm |Y|850.5-853.5; pin850.25-858; backing854-858 + shim853-854; weld effective a1.2 / leg>=2.7.\nLower pin |Y|862-883.5; spacer _1_1 OD10.50 +/-0.05, bore6.60, L28, preload4..6kN. Strength75 Nm / drive60 Nm; tests pending.')
 # Pocket joint real X layers and small upper/lower available lands.
 fig,ax=plt.subplots(figsize=(10,6))
 for xx,w,color,label in [(-512,2,'#777','Shell front'),(-510,3.5,'#dc8b38','5 mm free gasket'),(-506.5,2,'#285f77','Pin seat'),(-504.5,3,'#ecc67f','static pad'),(-501.5,1.5,'#888','rear wall')]:
  ax.add_patch(Rectangle((xx,0),w,20,facecolor=color,alpha=.7));ax.text(xx+w/2,23,label,rotation=60,fontsize=9)
 ax.annotate('',(-510,10),(-506.5,10),arrowprops={'arrowstyle':'<->'});ax.text(-508.25,13,'3.50 +/-0.15',ha='center',fontsize=9)
 ax.set_xlim(-521,-496);ax.set_ylim(-8,35);ax.set_xlabel('Global X');ax.set_ylabel('Schematic joint section, Z1155')
 finish(fig,ax,'D05-05_PIN_POCKET','D05-05  Pin demountable interface for Shell integration',
  'Pin plane X=-506.50, local flatness0.10. Shell proposed faceX=-510.00. No perimeter weld to Pin.\nGasket HT870 candidate: free5.00 +/-0.15, installed3.50 +/-0.15, compression24.7-35.0%; 3 mm band INSIDE pocket boundary.\nM4 studs: X-521.5..-506.5, Z1155; A Y-774.5/-736, B60.5/128. Shell owns ears D4.5, nuts, hard spacers and removable duct joints.\nPin extraction after registered removals: -X70, +Z500, -X200. Reference interface is not merged into installed Shell.')
 # Load-pad section about one D04 stud, geometric layer positions.
 fig,ax=plt.subplots(figsize=(10,6))
 for xx,ww,hh,col,lab in [(-502.5,1,10,'#356d89','D10 x1 pad'),(-504.5,2,16,'#bb7134','outer keeper'),(-501.5,1.5,22,'#999','rear sheet'),(-500,2,18,'#6c7f81','inner keeper')]:
  ax.add_patch(Rectangle((xx,-hh/2),ww,hh,facecolor=col,alpha=.65));ax.text(xx+ww/2,13,lab,rotation=60,fontsize=9)
 ax.add_patch(Rectangle((-511.5,-2),10,4,facecolor='#333'));ax.add_patch(Rectangle((-508.5,-3.5),4,7,fill=False,lw=2))
 ax.set_xlim(-516,-494);ax.set_ylim(-13,26);ax.set_xlabel('Global X');ax.set_ylabel('Local offset from stud axis')
 finish(fig,ax,'D05-06_BOOT_KEEPER','D05-06  D04 boot retention / M4 preload closure',
  'DOWSIL7091 web1.00 +/-0.15; pipe lip axial3.00 +/-0.30; A side return8.00. Cure and adhesion procedure in README.\nM4: measured prevailing0.03-0.05 + clamping increment0.30 Nm; total0.33-0.35. Replace nut on service.\nPad perimeter weld a0.4; stud-to-pad a0.6. Keeper heel relief D11.6 x1.0; inner seams2 x20, a0.6.\nDesign +/-100 N, proof +/-200 N. No copper contact by steel; nominal pipe gap3.0, allocated worst1.6. Tests NOT RUN.')
 print('Six manufacturing detail sheets and two DXFs written',flush=True)

if __name__=='__main__':run()
