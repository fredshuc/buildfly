from common import *

def pin_detail(parts,changed):
    for bed,y in [('A',-791.575),('B',73.425)]:
        n=f'D04_{bed}_OUTER_KEEPER'
        for side,dy in [('LOW',-8),('HIGH',8)]:
            yy,zz=y+dy,1086.85
            def xcyl(x0,x1,r):return cq.Solid.makeCylinder(r,x1-x0,(x0,yy,zz),(1,0,0))
            # Close the M4 preload within a steel pad and keeper, rather than
            # bending the unsupported 1.5 mm rear sheet around a bare stud.
            pad=xcyl(-502.5,-501.5,5).cut(xcyl(-502.6,-501.4,2))
            parts[f'D05_{bed}_M4_LOAD_PAD_{side}']=pad
            parts[n]=parts[n].cut(xcyl(-502.5,-501.4,5.8)).clean()
        changed[n]='D11.6 heel counterbores, depth 1, over D10x1 welded M4 load pads'
        for side,yy in [('LOW',-774.5 if bed=='A' else 60.5),('HIGH',-736 if bed=='A' else 128)]:
            parts[f'D05_PIN_STUD_{bed}_{side}']=cq.Solid.makeCylinder(2,15,(-521.5,yy,1155),(1,0,0))
    return parts,changed
