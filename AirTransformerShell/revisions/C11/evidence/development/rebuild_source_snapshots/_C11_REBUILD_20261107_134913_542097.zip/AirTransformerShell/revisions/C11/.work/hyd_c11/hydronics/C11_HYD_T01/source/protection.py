"""Topology-only trapped-liquid check. Proposed 4 protected bed zones.
Does not certify actual relief sizing, PS, or installed hardware.
"""
from pathlib import Path
import itertools,json,csv
P=Path(__file__).resolve().parents[1]
def wr(n,r):
 with open(P/n,'w',newline='') as f:w=csv.DictWriter(f,fieldnames=r[0]);w.writeheader();w.writerows(r)
st=[]
for b in 'AB':
 for mode,cs,hr,hs,cr,fs,sign in [('COLD',1,0,0,1,1,'+'),('HOT',0,1,1,0,1,'-'),('CHANGEOVER_ISOLATED',0,0,0,0,0,'zero verified'),('MAINTENANCE',0,0,0,0,0,'zero pressure and flow'),('FAULT',0,0,0,0,0,'Q direction/timeout/pressure fault')]:
  st.append(dict(bed=b,state=mode,XV_CS=cs,XV_HR=hr,XV_HS=hs,XV_CR=cr,FS=fs,signed_Q=sign,source_permission='unload + pressure permission before opening or moving source',lower_protection='EV-'+b+'L + TRV-'+b+'L permanently connected',upper_protection='EV-'+b+'U + TRV-'+b+'U permanently connected',status='functional requirement; protection devices not yet installed CAD'))
wr('C11_STATE_MATRIX.csv',st)
# Each isolated half has its own non-isolatable relief/expansion branch.
count=0;unprotected=[];source_bridges=[]
for bits in itertools.product([0,1],repeat=10):
 count+=1
 # 8 selectors and 2 FS: graph records accidental source commoning.
 adj={n:set() for n in ['CS','CR','HS','HR','AL','AU','BL','BU']}
 edges=[('CS','AL'),('HR','AL'),('HS','AU'),('CR','AU'),('CS','BL'),('HR','BL'),('HS','BU'),('CR','BU'),('AL','AU'),('BL','BU')]
 for on,(a,b) in zip(bits,edges):
  if on:adj[a].add(b);adj[b].add(a)
 def reach(n):
  seen={n};todo=[n]
  while todo:
   for x in adj[todo.pop()]-seen:seen.add(x);todo.append(x)
  return seen
 for n in ['AL','AU','BL','BU']:
  if not reach(n)&set(['AL','AU','BL','BU']):unprotected.append([bits,n])
 if reach('CS')&{'HS','HR'} or reach('CR')&{'HS','HR'}:source_bridges.append(bits)
json.dump({'selector_FS_states':count,'proposed_half_bed_unprotected_count':len(unprotected),'uncontrolled_cross_source_states':len(source_bridges),'scope':'graph containment only, each half has its own ALWAYS connected EV/TRV; source/header protection and valve cavities excluded and separately OPEN','not_safety_certification':True},open(P/'evidence/protection_graph.json','w'),indent=2)
r=[]
for b in 'AB':
 for half in ['L','U']:
  r.append(dict(zone=b+half,pressure_boundary='HX plus attached pipes up to FS and two closed selectors',protection='dedicated EV and thermal relief direct tee without isolating valve',discharge='individual air-gap branch to safe collection; never sealed common cold/hot return',filling='low-point metered fill with high-point vent open; HX bulkhead IF-03 pending',drain='low-point positive gravity route and separate vent; no reliance on seat leakage',PS_bar='UNCONFIRMED; minimum actual component allowable at 80C',EV_sizing='Vzone*(rho5/rho80-1)/acceptance_fraction; precharge/cold fill/relief pressure required',status='OPEN: parts/set pressure/physical route/vent bulkheads'))
wr('PRESSURE_ZONE_REGISTER.csv',r)
rows=[]
for b in 'AB':
 for part,thread in [('FS','1 NPT female on valve'),('Q','G1 male flat face; E40217 adapter')]:
  for end in [1,2]:rows.append(dict(id=f'{b}_{part}_STACK_{end}',item='Valworx 560208H+561104E' if part=='FS' else 'ifm SM8020+E40217',interface=thread,installed_budget_mm=50,OD_budget_mm=52,actual_installed_length_mm='OPEN',rated_pressure='FS: P/T curve needed; Q:16bar catalog; complete stack PS unknown',temperature='system5..80C; actual seal/adapter range required',retention='actual engaged threads/union shoulder/anti-pullout not established',tool='82mm original counterhold budget; actual wrench flats and swing OPEN',release_mm='OPEN: no actual adapter/union selected beyond E40217',status='NOT CLOSED by a 50mm cylinder'))
for b in 'AB':
 for pos in ['L_W1','L_W2','U_W1','U_W2']:rows.append(dict(id=b+'_'+pos,item='H01 detachable first spool',interface='Rp1-1/4 HX female',installed_budget_mm=77.5,OD_budget_mm='H01 model',actual_installed_length_mm='nominal77.5; pressure joint detail OPEN',rated_pressure='OPEN',temperature='5..80C design demand',retention='thread engagement/lock-ring proof and pressure sealing OPEN',tool='H01 CAD wrench/retainer envelope retained',release_mm='H01 model only; actual stack stroke OPEN',status='HOLD for pressure/retention qualification'))
wr('C11_HYD_CONNECTION_STACKS.csv',rows)
