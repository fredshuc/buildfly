"""Concrete Shell-owned interface proposal; NOT added to installed models."""
from common import *
from changes import build_parts
from service_probe import check,scene_index
from export import save_small

def run():
 p,c=build_parts();idx=scene_index(p);parts={};report={}
 for bed,y0,y1 in [('A',-766.5,-744.),('B',68.5,120.)]:
  z0,z1=1143.5,1170.
  plate=box(-512,y0,z0,-510,y1,z1)
  for yy in ((-774.5,-736) if bed=='A' else (60.5,128)):
   ear=box(-512,yy-5,1149,-510,yy+5,1161)
   # Join ears through planar webs to the front closure.
   ear=ear.fuse(box(-512,min(yy,y0),1149,-510,max(yy,y1),1161))
   plate=plate.fuse(ear).cut(cq.Solid.makeCylinder(2.25,4,(-513,yy,1155),(1,0,0)))
  plate=plate.clean()
  seal=box(-510,y0,z0,-506.5,y1,z1).cut(box(-511,y0+3,z0+3,-505,y1-3,z1-3))
  parts[f'REF_SHELL_{bed}_DEMOUNTABLE_POCKET_FRONT']=plate
  parts[f'REF_SHELL_{bed}_POCKET_GASKET']=seal
  absent={r['name'] for r in idx if r['name'].startswith(f'C10_{bed}_W2_POCKET_')}
  # Envelope uses the already-returned installed Pin back plane. Pin studs
  # pass through D4.5 reference flange holes, not an invented welded joint.
  hit=check(cq.Compound.makeCompound([plate,seal]),absent,idx,p)
  seat=p[f'DAMPER_SEAT_{bed}_UPPER_DEEP_O']
  face=next(f for f in seal.Faces() if abs(bbox(f)[0]+506.5)<1e-5 and abs(bbox(f)[3]+506.5)<1e-5)
  steel=next(f for f in seat.Faces() if abs(bbox(f)[0]+506.5)<1e-5 and abs(bbox(f)[3]+506.5)<1e-5)
  report[bed]={'pin_plane_X':-506.5,'shell_plane_X':-510,'installed_gap':3.5,'free_thickness':5,
               'band_width':3,'nominal_face_area':face.Area(),'supported_face_area':face.intersect(steel).Area(),
               'existing_shell_parts_to_rework':sorted(absent),'interferences':hit,
               'status':'INTERFACE PROPOSAL: Shell must own front closure, weld joints, compression stops, nuts and duct demountability'}
  print(bed,report[bed],flush=True)
 dump(ROOT/'evidence/pocket_interface.json',report)
 save_small(ROOT/'cad/C11_SHELL_POCKET_INTERFACE_REFERENCE.step',parts)

if __name__=='__main__':run()
