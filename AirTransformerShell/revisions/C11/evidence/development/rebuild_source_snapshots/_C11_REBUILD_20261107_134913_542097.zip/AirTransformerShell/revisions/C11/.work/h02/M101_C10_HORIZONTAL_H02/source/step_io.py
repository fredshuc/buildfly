"""Read named, located XCAF leaves without losing assembly placements."""
import cadquery as cq
import math
from functools import lru_cache
from OCP.STEPCAFControl import STEPCAFControl_Reader
from OCP.TDocStd import TDocStd_Document
from OCP.XCAFDoc import XCAFDoc_DocumentTool
from OCP.TDF import TDF_LabelSequence, TDF_Label
from OCP.TDataStd import TDataStd_Name
from OCP.TCollection import TCollection_ExtendedString
from OCP.TopLoc import TopLoc_Location
from OCP.IFSelect import IFSelect_RetDone


def leaves(path):
    doc = TDocStd_Document(TCollection_ExtendedString("read"))
    reader = STEPCAFControl_Reader()
    reader.SetNameMode(True)
    if reader.ReadFile(str(path)) != IFSelect_RetDone or not reader.Transfer(doc):
        raise ValueError(f"Cannot read {path}")
    tree = XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())

    def name(label):
        attr = TDataStd_Name()
        return attr.Get().ToExtString() if label.FindAttribute(TDataStd_Name.GetID_s(), attr) else ""

    def walk(label, loc, path):
        if tree.IsReference_s(label):
            ref = TDF_Label()
            tree.GetReferredShape_s(label, ref)
            yield from walk(ref, loc * tree.GetLocation_s(label), path + [name(label)])
        elif tree.IsAssembly_s(label):
            seq = TDF_LabelSequence()
            tree.GetComponents_s(label, seq)
            for i in range(1, seq.Length() + 1):
                yield from walk(seq.Value(i), loc, path + [name(label)])
        else:
            yield "/".join(path + [name(label)]), cq.Shape.cast(tree.GetShape_s(label).Moved(loc))

    roots = TDF_LabelSequence()
    tree.GetFreeShapes(roots)
    for i in range(1, roots.Length() + 1):
        yield from walk(roots.Value(i), TopLoc_Location(), [])


@lru_cache(maxsize=10000)
def bounds(shape):
    from OCP.Bnd import Bnd_Box
    from OCP.BRepBndLib import BRepBndLib
    b = Bnd_Box()
    BRepBndLib.Add_s(shape.wrapped,b,False)
    return list(b.Get())


def overlap(a, b, tol=1e-5):
    return all(min(a[i+3], b[i+3]) - max(a[i], b[i]) > tol for i in range(3))


def clashes(left, right, internal=False):
    right_rows = [(n, s, bounds(s)) for n, s in right.items()]
    found = []
    for i, (name, shape) in enumerate(left.items()):
        a = bounds(shape)
        for j, (other, body, b) in enumerate(right_rows):
            if internal and j <= i:
                continue
            if overlap(a, b):
                volume = shape.intersect(body).Volume()
                if volume > 0.001:
                    found.append([name, other, round(volume, 6)])
    return found


def nearest(shape, rows, boxes=None):
    """Exact shape distance, pruned by a conservative AABB lower bound."""
    a = bounds(shape)
    ranked = []
    for name, body in rows.items():
        b = boxes[name] if boxes is not None else bounds(body)
        lower = math.sqrt(sum(max(a[i]-b[i+3], b[i]-a[i+3], 0)**2 for i in range(3)))
        ranked.append((lower, name, body))
    best = (float("inf"), "")
    for lower, name, body in sorted(ranked, key=lambda r: r[:2]):
        if lower > best[0]+1e-6:
            break
        best = min(best, (shape.distance(body), name))
    return best


def shared_planar_area(left, right):
    """Solid common omits zero-volume contacts; intersect coplanar faces."""
    area = 0.
    for a in left.Faces():
        if a.geomType() != "PLANE":
            continue
        for b in right.Faces():
            if b.geomType() != "PLANE":
                continue
            if a.normalAt().dot(b.normalAt()) < -.999999 and a.distance(b) < 1e-6:
                area += a.intersect(b).Area()
    return area
