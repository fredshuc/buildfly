"""Cross-check final evidence and freeze an auditable candidate summary."""
from pathlib import Path
import csv,hashlib,json,datetime

ROOT=Path(__file__).resolve().parents[1]
def read(name):return json.loads((ROOT/name).read_text(encoding='utf-8'))
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def table(name):return list(csv.DictReader((ROOT/name).open(encoding='utf-8-sig')))

def run():
 frozen=read('.work/frozen/index.json')
 for name,value in frozen['signature'].items():
  if name.endswith('.py'):assert digest(ROOT/'source'/name)==value,name
 exp=read('evidence/export.json');static=read('evidence/static_check.json')
 for state in ('S1','S2'):
  assert digest(ROOT/'cad'/('C11_D05_INSTALLED_'+state+'.step'))==exp[state]['output_sha256']
  assert not exp[state]['bad'] and not static[state]['unexpected_penetrations']
  assert len(static[state]['exact_soft_pairs'])==12
 motion=read('evidence/full_motion.json');assert len(motion)==4
 assert all(not row['unexpected_contacts'] and len(row['first_undesigned'])==2 for row in motion.values())
 assert all(c['uncovered_area']<.001 for row in motion.values() for c in row['coverage'])
 svc=read('evidence/service.json')
 assert all(not row['penetrations'] for row in svc['components'].values())
 assert all(not row['hits'] for rows in svc['pin_route'].values() for row in rows)
 for name in ('motion_export','service_export'):
  rec=read('evidence/'+name+'.json');assert digest(ROOT/'cad'/rec['file'])==rec['sha256']
 clears=table('C11_DAMPERS_CLEARANCE_STACK.csv');stops=table('C11_DAMPERS_STOP_LIMITS.csv')
 assert len(stops)==8 and all(float(r['remaining_angle_deg'])>0 for r in stops)
 assert all(float(r['worst_remaining_mm'])>0 for r in clears)
 asynchronous=read('evidence/asynchronous.json');assert all(r['bbox_separation_mm']>0 for r in asynchronous)
 assert len(list((ROOT/'drawings').glob('*.png')))==6
 assert len(list((ROOT/'drawings').glob('*.dxf')))==12
 eng=read('evidence/engineering.json');assert not eng['manufacture_release'] and eng['open_interfaces']
 result={'revision':'C11-D05','generated_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'manufacture_release':False,'CAD_checks':'PASS within the stated model and explicit mates',
  'installed_occurrences':{s:sum(r['counts'].values()) for s,r in exp.items()},
  'static_unexpected_penetrations_over_0p001_mm3':0,'registered_soft_pairs_per_state':12,
  'full_motion_valves':4,'stop_directions':8,'minimum_stop_angle_reserve_deg':min(float(r['remaining_angle_deg']) for r in stops),
  'clearance_budget_mm':{r['id']:{'nominal':float(r['nominal_mm']),'worst_remaining':float(r['worst_remaining_mm'])} for r in clears},
  'asynchronous_min_bbox_gap_mm':min(r['bbox_separation_mm'] for r in asynchronous),
  'service_STEP_occurrences':read('evidence/service_export.json')['occurrences'],
  'drawings':{'PNG':6,'SVG':6,'DXF':12},
  'geometry_signature':frozen['signature'],
  'source_sha256':{p.name:digest(p) for p in sorted((ROOT/'source').glob('*.py'))},
  'open_interfaces':eng['open_interfaces'],
  'physical_tests_FE_CFD':'NOT RUN'}
 (ROOT/'evidence/FINAL_CHECKS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 print('Final candidate evidence, CAD hashes and source signatures: PASS',flush=True)

if __name__=='__main__':run()
