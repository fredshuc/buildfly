"""Run final checks on one immutable delivered geometry set."""
from pathlib import Path
import runpy,sys
base=Path(__file__).resolve().parent
for script in ('check.py','check_spools.py','mating.py','flow_check.py','support_audit.py','discharge.py','vessel_bounds_check.py'):
    if script=='check.py' and '--skip-main' in sys.argv:continue
    print('FINAL CHECK START',script,flush=True)
    runpy.run_path(str(base/script),run_name='__main__')
    print('FINAL CHECK COMPLETE',script,flush=True)
