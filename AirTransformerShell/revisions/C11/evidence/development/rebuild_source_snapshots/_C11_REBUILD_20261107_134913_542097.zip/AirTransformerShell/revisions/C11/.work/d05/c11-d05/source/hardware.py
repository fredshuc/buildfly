"""D05 positive lower-shaft location and four steel torque stops.

Nominal CAD. Purchased bearing/circlip solids are occupied interfaces, not
supplier manufacturing models. Source parts remain the hash-pinned C10 parts.
"""
from common import *
TONGUE_HALF=13.
HUB_R=18.
PIN_TANGENT=17.5

def pin_centre(tag,i):
    x,z=axis(tag);ang,tan=((0.,PIN_TANGENT),(THETA,-PIN_TANGENT))[i]
    c,s=math.cos(math.radians(ang)),math.sin(math.radians(ang))
    return x+c*tan-s*30,z-s*tan-c*30

def hardware(parts,changed):
    # B upper was 15 mm shorter than A in C10. Make the dry drive extension
    # symmetric for the new stop while preserving both bearing datums and
    # all wet rotor/root locations. Still inside the lower drive envelope.
    for prefix in ('D03_COUPLING_','D03_ACT_OUTPUT_','D03_ACTUATOR_INTERFACE_',
                   'M203_ACT_SPACERS_','M203_ACT_M6_'):
        a=next(n for n in parts if n.startswith(prefix) and 'A_UPPER' in n)
        b=a.replace('A_UPPER','B_UPPER')
        parts[b]=parts[a].mirror('XZ')
        changed[b]='B upper dry drive extended +15 Y for four-valve stop package'
    n='DAMPER_SHAFT_B_UPPER_0_O';x,z=axis('B_UPPER')
    stub=cy(x,z,849,859,12).cut(box(x+9,848,z-13,x+14,860,z+13))
    parts[n]=parts[n].fuse(cy(x,z,834,849,15),stub).clean()
    changed[n]+='; B dry output extended 15 mm, wet and bearing locations unchanged'
    for bed in 'AB':
        sign=-1 if bed=='A' else 1
        def ys(a,b): return sorted((sign*a,sign*b))
        for level in ('LOWER','UPPER'):
            tag=f'{bed}_{level}';x,z=axis(tag)
            def cyl(a,b,r): return cy(x,z,*ys(a,b),r)
            def block(a,b,x0,x1,z0,z1):
                lo,hi=ys(a,b);return box(x+x0,lo,z+z0,x+x1,hi,z+z1)
            def d_bore(a,b):return cyl(a,b,12).cut(block(a-1,b+1,9,14,-13,13))
            if level=='LOWER':
                # Preserve the old bearing centre and its span. Fixed 6006 at
                # |Y|869; floating 3015DU inner bush at old inner centre.
                shaft=f'DAMPER_SHAFT_{tag}_0_O'
                parts[shaft]=parts[shaft].fuse(cyl(857.5,862.5,20)).cut(
                    cyl(875.6,877.2,16).cut(cyl(875.5,877.3,14.3))).clean()
                changed[shaft]+='; integral D40 shoulder and DIN471 A30 groove'
                n=f'D03_OUTER_BEARING_INTERFACE_{tag}'
                parts[n]=cyl(862.5,875.5,27.5).cut(cyl(862,876,15))
                changed[n]='6006 30x55x13 at unchanged bearing centre'
                for end,a,b in [('IN',862,862.5),('OUT',875.5,876)]:
                    parts[f'D05_OUTER_RACE_SHIM_{tag}_{end}']=cyl(a,b,27.5).cut(cyl(a-1,b+1,24))
                # Simplified split ring maximum occupied OD40.5. The slot is
                # explicit; final ring purchase is manufacturer A30.
                ring=cyl(875.65,877.15,20.25).cut(cyl(875.5,877.3,14.3),
                    block(875.5,877.3,-4,4,0,22))
                parts[f'D05_SHAFT_RETAINING_RING_{tag}']=ring
                n=f'D03_INNER_BEARING_INTERFACE_{tag}'
                b=bbox(parts[n]);yc=(b[1]+b[4])/2
                parts[n]=cy(x,z,b[1],b[4],27.5).cut(cy(x,z,b[1]-1,b[4]+1,17))
                parts[f'D05_FLOATING_3015DU_{tag}']=cy(x,z,yc-7.5,yc+7.5,17).cut(cy(x,z,yc-8,yc+8,15))
                changed[n]='Fixed cartridge OD55; DU30x34x15 liner permits axial shaft sliding'
                arm_a,arm_b=879.5,882.5
                carrier=f'D03_BEARING_CARRIER_{tag}'
                # Fill obsolete D6 pin holes before drilling D10 stop bores.
                for i in (0,1):
                    old=f'D03_STOP_PIN_{tag}_{i}'
                    # Only the part of each old pin inside the carrier is restored.
                    old_angle,old_tan=((0,6),(THETA,-6))[i]
                    c,s=math.cos(math.radians(old_angle)),math.sin(math.radians(old_angle))
                    px=x+c*old_tan-s*30;pz=z-s*old_tan-c*30
                    parts[carrier]=parts[carrier].fuse(cy(px,pz,*ys(870,876),3)).clean()
                    parts.pop(old,None)
                parts.pop(f'D03_STOP_ARM_{tag}',None)
                pin_a,pin_b=862,883.5
                # R stop pin passes beside the upper-inboard M6 spacer.
                # Keep its length and bolt axis; reduce only this spacer OD.
                spacer=f'D03_CARRIER_SPACER_{tag}_1_1'
                b=bbox(parts[spacer]);sx=(b[0]+b[3])/2;sz=(b[2]+b[5])/2
                parts[spacer]=parts[spacer].intersect(cy(sx,sz,b[1]-.1,b[4]+.1,5.25)).clean()
                changed[spacer]='OD10.50 +/-0.05, boreD6.60, L28 unchanged; S355; M6 preload 4..6kN; pin clearance nominal>1.24mm'
            else:
                arm_a,arm_b=850.5,853.5
                carrier=f'D05_STOP_PLATE_{tag}'
                plate=block(854,858,-52,52,-40,40).cut(cyl(853,859,21))
                weld_shim=block(853,854,-52,52,-40,40).cut(cyl(852,855,39))
                for dx in (-40,40):
                    for dz in (-20,20):
                        plate=plate.cut(cy(x+dx,z+dz,*ys(853,859),3.3))
                        weld_shim=weld_shim.cut(cy(x+dx,z+dz,*ys(852,855),3.3))
                parts[f'D05_STOP_WELD_SHIM_{tag}']=weld_shim
                parts[carrier]=plate
                bracket=f'DAMPER_ACT_BRACKET_{tag}_O'
                parts[bracket]=parts[bracket].cut(cyl(849,854,39)).clean()
                changed[bracket]='Dry-side stop arm clearance D78; original four M6 mounting centres retained'
                coupling=f'D03_COUPLING_{tag}'
                parts[coupling]=parts[coupling].cut(cyl(848,854.5,21)).clean()
                changed[coupling]='Local inboard shortening 5.5 mm, remaining shaft flat engagement 4.5 mm'
                for n in list(parts):
                    if tag in n and n.startswith('M203_ACT_SPACERS'):
                        parts[n]=parts[n].cut(block(852.9,858,-100,100,-100,100)).clean()
                        changed[n]='Spacer length reduced 5 mm for 4 mm stop plate plus 1 mm standoff'
                pin_a,pin_b=858,850.25
            arm=cyl(arm_a,arm_b,HUB_R).fuse(block(arm_a,arm_b,-TONGUE_HALF,TONGUE_HALF,-35,-12)).cut(d_bore(arm_a-.1,arm_b+.1)).clean()
            roots=[e for e in arm.Edges() if e.geomType()=='LINE' and abs(e.Length()-3)<1e-5
                   and abs(abs(e.Center().x-x)-TONGUE_HALF)<.01 and -14<e.Center().z-z<-11]
            assert len(roots)==2,(tag,len(roots))
            arm=arm.fillet(2,roots).clean()
            parts[f'D05_STOP_ARM_{tag}']=arm
            for i,(ang,tan) in enumerate(((0.,PIN_TANGENT),(THETA,-PIN_TANGENT))):
                c,s=math.cos(math.radians(ang)),math.sin(math.radians(ang))
                px=x+c*tan-s*30;pz=z-s*tan-c*30
                lo,hi=ys(pin_a,pin_b)
                # D profile through the complete keyed shank: no round-pin
                # line contact, and no reliance on friction for clocking.
                pin=cy(x+tan,z-30,lo,hi,5)
                cutter=(box(x-100,lo-1,z-100,x+TONGUE_HALF,hi+1,z+100) if i==0 else
                        box(x-TONGUE_HALF,lo-1,z-100,x+100,hi+1,z+100))
                pin=rotate(pin.cut(cutter).clean(),tag,ang)
                parts[carrier]=parts[carrier].cut(pin).clean()
                parts[f'D05_STOP_PIN_{tag}_{i}']=pin
                if level=='UPPER':
                    bracket=f'DAMPER_ACT_BRACKET_{tag}_O'
                    parts[bracket]=parts[bracket].cut(cy(px,pz,*ys(848,858),5.2)).clean()
                    shim=f'D05_STOP_WELD_SHIM_{tag}'
                    parts[shim]=parts[shim].cut(cy(px,pz,*ys(852,855),5.2)).clean()
            changed[carrier]='D10 keyed D-profile pins with 0.5 mm flat, through wire-EDM carrier holes; jig flat contact at P/R'
    for n,s in parts.items():
        assert s.isValid() and s.Solids(),n
    return parts,changed
