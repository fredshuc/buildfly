from common import *
core=read(OUT/'H02_SINGLE_CORE.step')
idx=json.loads((WORK/'S1/index.json').read_text())
rows=[]
for k,p in PLACEMENTS.items():
    g=next(r for r in idx if r['name']=='C09_FACE_GASKET_'+k)
    s=cq.Shape.importBrep(str(WORK/'S1'/g['file']));b=bounds(s);plane=p['translation'][2]-220
    area=s.Volume()/2
    faces=[f for f in s.Faces() if f.geomType()=='PLANE' and f.normalAt().z>.99 and abs(f.Center().z-plane)<1e-5]
    contacted=0;by_part=[];remaining=list(faces)
    for n,c in core.items():
        if n.startswith(('FIN_','C0','C1','C2','C3')):continue
        c=c.moved(loc(p['translation']));bc=bounds(c)
        if abs(bc[2]-plane)>.001:continue
        value=0
        for f in c.Faces():
            if f.geomType()!='PLANE' or f.normalAt().z>-.99 or abs(f.Center().z-plane)>.001:continue
            for gf in faces:value+=f.intersect(gf).Area()
            remaining=[r.cut(f) for r in remaining]
        if value>1e-4:by_part.append({'part':n,'area_mm2':value});contacted+=value
    summed=contacted;contacted=area-sum(r.Area() for r in remaining)
    rows.append({'core_sha256':hashlib.sha256((OUT/'H02_SINGLE_CORE.step').read_bytes()).hexdigest(),'summed_contact_with_duplicate_frame_corners_mm2':summed,'contact_measure':'union of coplanar frame faces, no double-counting at corners','core':k,'HX_land_plane_Z_mm':plane,'C10_nominal_gasket_area_mm2':area,'actual_frame_contact_area_mm2':contacted,
                 'frame_contact_fraction':contacted/area,'contact_parts':by_part,
                 'HT800_example_25pct_load_N':[area*.041,area*.097],
                 'proposed_compressed_gasket_height_mm':1.35,'proposed_Shell_seat_Z_mm':plane-1.35,
                 'existing_nominal_seat_Z_mm':plane-2,'required_seat_raise_mm':.65,
                 'status':'nominal CAD contact and interface request, not measured flatness or force capacity'})
dump(OUT/'evidence/MATING_LAND.json',rows)
print('Mating lands',[(r['core'],r['actual_frame_contact_area_mm2'],r['frame_contact_fraction']) for r in rows],flush=True)
