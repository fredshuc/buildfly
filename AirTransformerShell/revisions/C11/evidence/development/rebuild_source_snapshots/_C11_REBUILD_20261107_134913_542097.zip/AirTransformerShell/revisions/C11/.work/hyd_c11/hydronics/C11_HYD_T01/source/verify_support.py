from pathlib import Path
import sys,json,time
from cad_io import *
from OCP.BRepBndLib import BRepBndLib
from OCP.Bnd import Bnd_Box
def bb(s):
 b=Bnd_Box();BRepBndLib.Add_s(s.wrapped,b,False);return list(b.Get())
P=Path(__file__).resolve().parents[1];root=P.parents[1];work=root.parent/'c11_input'
new=named(P/'cad/C11_HYD_RACK_SUPPORT.step');nbs={n:bb(s) for n,s in new.items()}
for state in (sys.argv[1:] or ['S1','S2']):
 report={'state':state,'threshold_mm3':.001,'input':'C10 unchanged full installed assembly','new_count':len(new),'hits':[],'candidate_pairs':0,'host_count':0}
 for p,s in leaves(root/f'AirTransformerShell/revisions/C10/cad/C10_INSTALLED_{state}.step'):
  report['host_count']+=1;b=bb(s)
  for n,a in nbs.items():
   if overlaps(a,b):
    report['candidate_pairs']+=1;vol=new[n].intersect(s).Volume()
    if vol>.001:report['hits'].append([n,p,vol])
 json.dump(report,open(P/f'evidence/installed_{state}.json','w'),indent=2);print(state,report,flush=True)
# Collision with the existing service volumes: intentional removal must be stated.
service=named(work/'s2/HYD_S2/S2_SERVICE.step')
r={'fixed_support_vs_legacy_service':clashes(new,service),'note':'All listed obstruction cases need an explicit pre-removal step; no automatic exclusion'}
json.dump(r,open(P/'evidence/service_obstructions.json','w'),indent=2);print('service',r,flush=True)
