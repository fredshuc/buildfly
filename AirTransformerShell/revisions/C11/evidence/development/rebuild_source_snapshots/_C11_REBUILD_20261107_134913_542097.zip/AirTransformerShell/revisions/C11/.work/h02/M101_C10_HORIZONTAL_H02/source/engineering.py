"""Traceable calculations and proposed tests. No synthetic measurement values."""
import json,csv,math
from pathlib import Path
OUT=Path(__file__).resolve().parents[1];ROOT=OUT/'repro_inputs' if (OUT/'repro_inputs').exists() else OUT.parents[1]
def dump(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False),encoding='utf8')
def csvwrite(p,rows):
    with p.open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
def main():
    routes=json.loads((OUT/'ROUTES.json').read_text())
    # Catalogue-supported input versus project assumptions are separate fields.
    sources=[
      {'id':'G1','grade':'V','source':'RT5 independently measured C10 S1','url':'https://github.com/fredshuc/buildfly/blob/16b44e96c4640a4bccb565ae371fee445999634f/AirTransformerShell/revisions/C10/RT5_REVIEW/results/vent_drain_S1.json','use':'locations and source configuration, not hydraulic qualification'},
      {'id':'G2','grade':'V','source':'H01 immutable delivered model and 39x6 C04 geometry','url':'https://github.com/fredshuc/buildfly/blob/16b44e96c4640a4bccb565ae371fee445999634f/HX/M101_C08_HORIZONTAL_H01/README_CN.md','use':'port datums, topology, nominal inventory'},
      {'id':'M1','grade':'M','source':'Caleffi 538201 manufacturer product page and STEP','url':'https://www.caleffi.com/en-int/drain-cock-with-hose-connection-and-cap-538-caleffi-538201','use':'G1/4 A ISO228-1 male; -5..110 C; 10 bar component rating, not HX assembly rating'},
      {'id':'M2','grade':'M','source':'Knipex 86 03 250 manufacturer dimensional sheet','url':'https://www.knipex.com/sites/default/files/Product%20data%20sheet%20EN%2086%2003%20250.pdf','use':'8 mm jaws, 14 mm joint, 18 mm overall grip thickness; 52 mm opening; torque not specified'},
      {'id':'M3','grade':'M','source':'Parker O-ring handbook PTD5705','url':'https://www.parker.com/content/dam/Parker-com/Literature/Praedifa/Catalogs/Catalog_O-Ring-Handbook_PTD5705-EN.pdf','use':'seal-gland principles; H02 gland dimensions and compound compatibility remain project proposals'},
      {'id':'M4','grade':'M','source':'Rogers BISCO material selection guide','url':'https://rogerscorp.com/-/media/project/rogerscorp/documents/elastomeric-material-solutions/bisco/english/brochures/18-016-bisco-material-selection-guide.pdf','use':'HT800 example 41..97 kPa at25% compression; not selected gasket or 40% curve'},
      {'id':'M5','grade':'M','source':'ASHRAE 2024 SI Chapter27 air-heating coils','url':'https://handbook.ashrae.org/Handbooks/S24/SI/S24_Ch27/S24_Ch27_si.aspx','use':'horizontal drainage depends on circuit geometry and installation; not certification of M101'},
      {'id':'M6','grade':'M','source':'Alfa Laval finned coil air heat exchanger manual 100001047','url':'https://www.alfalaval.com/globalassets/documents/products/heat-transfer/finned-coil-air-heat-exchangers/manuals/100001047-dch-radiators.pdf','use':'vent-high/drain-low maintenance principle; no borrowing pressure or freeze rating'},
      {'id':'M7','grade':'M','source':'Outokumpu Core range datasheet, Table7','url':'https://www.outokumpu.com/-/media/files/products/core/outokumpu-core-range-datasheet.pdf','use':'304L/4307: E200GPa and density7.9kg/dm3 at20C; project bending screen deliberately uses E190GPa as assumption, not elevated-temperature certification'},
      {'id':'E1','grade':'E','source':'RT5 one-dimensional distribution model','url':'https://github.com/fredshuc/buildfly/blob/16b44e96c4640a4bccb565ae371fee445999634f/AirTransformerShell/revisions/C10/RT5_REVIEW/C10_RT5_REVIEW.md','use':'120 Pa/two-core scenario only; NOT measured HX pressure drop'}]
    dump(OUT/'SOURCE_GRADES.json',{'grades':{'V':'model/source verified','M':'manufacturer published','C':'calculation','E':'assumption/sensitivity','T':'physical test; none yet'},'sources':sources})
    area=1*.612;vref=4870/3600/area;air=[]
    for v in (.5,1,1.10521,1.5,2, vref,2.5,3):
        for base in (60,120,250):
            air.append({'v_face_m_s':round(v,5),'Q_m3h':round(v*area*3600,2),'two_core_reference_Pa':base,
                        'n_low':1.7,'n_high':2.2,'Pa_n1p7':round(base*(v/vref)**1.7,2),'Pa_n2p2':round(base*(v/vref)**2.2,2),
                        'grade':'E','measured_Pa':'','scope':'two clean/coated-core scenarios for sensitivity; excludes H02 collector and plenum; not selection data'})
    csvwrite(OUT/'AIR_RESISTANCE_SCENARIOS_NOT_MEASURED.csv',air)
    # End pipes D35/ID28, deliberately conservative 450 mm unsupported lever.
    I=math.pi*(35**4-28**4)/64;Z=I/17.5
    nozzle={'status':'PROVISIONAL_INTERFACE_LIMITS; pressure-joint proof still required',
      'force_axes':'global X normal to HX face, Y/Z transverse','load_combination':'abs(Fx)/30 + hypot(Fy,Fz)/20 + hypot(My,Mz)/2 + abs(Mx)/1 <= 1',
      'Fx_N':30,'Fr_N':20,'Mb_Nm':2,'Mx_Nm':1,'includes':'external pipe weight, installation offset, thermal restraint, vibration residual; combinations not independent maxima',
      'excludes':'internal pressure resultants balanced inside a qualified pressure boundary; any unbalanced bellows/coupler thrust is an external rack load',
      'screen':{'grade':'C/E','I_mm4':I,'Z_mm3':Z,'lever_mm':450,'E_MPa_assumed':110000,
                'stress_MPa_at_20N_and_2Nm':(20*450+2000)/Z,
                'deflection_mm_at_20N':20*450**3/(3*110000*I)},
      'support_requirement':'independent rack supports each fixed rack tail within100mm; zero imposed fit-up draw-in, <=0.5mm free offset before assembly; counterhold torque at joint, never through coil',
      'test_release':'apply 1.5 times each selected combined service load separately, measure <0.1mm permanent face shift, then leak/proof and hot/cold cycles; manufacturer brazed-joint acceptance required'}
    dump(OUT/'NOZZLE_LOAD_LIMITS.json',nozzle)
    # Nominal pressure seal stack. The project 10bar/80C case is a design screen.
    joint={'grade':'C/E','design_screen_bar':10,'design_screen_temperature_C':80,
           'assembly_PS_bar':None,'why_PS_null':'weakest HX tube/header/braze and connection process not supplier-rated',
           'piston_effective_D_mm':37,'pressure_thrust_N':math.pi*37**2/4,
           'collar_bolts':2,'bolt_type':'M4 A2-70','bolt_tensile_area_mm2_reference':8.78,
           'bolt_equal_share_stress_MPa':math.pi*37**2/4/2/8.78,
           'radial_seal':{'size':'29 x2.5','groove_root_D':29.9,'bore_D':34,'groove_width':3.4,'radial_squeeze_pct':18,'stretch_pct':(29.9/29-1)*100,
                          'nominal_gland_fill_pct':math.pi*2.5**2/4/(3.4*2.05)*100},
           'face_seal':{'size':'32 x2.5','depth':1.9,'squeeze_pct':24,'max_axial_joint_opening_mm':.14,'squeeze_at_max_gap_pct':18.4},
           'not_checked':'split-ring prying, screw preload/torque, fatigue, brazed/threaded mating process, seal extrusion and compound compatibility',
           'tests':'hydrostatic procedure at weakest signed PS; no pneumatic proof; pullout under pressure; repeated 6mm retraction after depressurising; >=1000 5/80C prototype cycles with leakage and wear logging'}
    dump(OUT/'FIRST_SPOOL_CALC.json',joint)
    # Route-only small-bore inventory; valve cavities are deliberately separate.
    small=[]
    for r in routes['small_bore']:
        L=sum(math.dist(a,b) for a,b in zip(r['points_A_LOWER'],r['points_A_LOWER'][1:]))
        small.append({'id':r['port']+'_'+r['function'],'polyline_length_mm':L,'ID4_L_upper_for_bends':L*math.pi*2**2/1e6})
    extra=sum(r['ID4_L_upper_for_bends'] for r in small)+2*8*math.pi*2**2/1e6
    dump(OUT/'WATER_TOPOLOGY.json',{'grade':'C','parallel_circuits':39,'passes_per_circuit':6,'headers':2,
      'row_centre_Z_A_LOWER_mm':[677.35+22*r for r in range(6)],
      'header_centres_mm':[677.35,787.35],'header_invert_mm':[663.35,773.35],
      'original_end_cap':'all eight axial bosses removed, pierced disks replaced; 3mm thickness pressure qualification required',
      'replacement_paths':['each header blind end -> continuous ID28 header -> H01 end pipe -> own ID4 low drain -> labelled valve -> independent discharge hose',
                           'each six-pass circuit -> W1 and W2 headers -> both open drains; both crown vents open',
                           'far and near crown pickup -> continuously rising ID4 bleed line -> independent manual valve'],
      'nominal_topological_result':'all39 circuits connected to both headers and available drains; no isolation check valves in new branches',
      'gravity_limit':'horizontal tube invert has zero slope; deformation, wetting and parallel air bypass prevent a complete-empty guarantee. Far crown pickup is not a bottom drain.',
      'new_small_bore_route_inventory_per_core_L_upper':extra,'routes':small,
      'HYD_S2_inherited_known_per_bed_L':{'cold':23.955,'hot':24.023},
      'new_nominal_per_bed_route_increment_L_upper':2*extra,
      'do_not_add_twice':'H01 original ID4 boss lengths already counted; new inventory is route-only increment, original pierced cap cavities disappear; new spool stepped cavities and all sixteen valve cavities need measured accounting',
      'exchange':'bleed/drain branches are stagnant in normal operation, so report them separately from fully swept water. Never use V/Q as valve changeover timing.',
      'residual_acceptance_proposed':'weigh dry/filled/drained core to1g; target residual <=0.5% of measured flooded volume after specified drain procedure; no freeze-safe claim even if target passes'})
    D=.016; n=.013; slope=.01;full=(1/n)*(D/4)**(2/3)*math.sqrt(slope)*math.pi*D**2/4*3.6e6
    dump(OUT/'CONDENSATE_CALC.json',{'grade':'C/E','blade_count':34,'blade_pitch_Y_mm':18,'blade_projected_width_Y_mm':20,
      'projected_overlap_mm':2,'blade_X_length_mm':1004,'blade_rise_Y_mm':8.5,'blade_X_fall_pct':1,'rail_X_A_LOWER_mm':[-390,-150,90,330,582],'maximum_supported_span_mm':252,
      'blade_bending_screen':{'grade':'C/E','specified_material':'304L stainless, supplier properties and joining process to be confirmed','E_MPa_assumed':190000,'inclined_sheet_I_mm4_lower_bound':12*(8.5**2+.6**2)/12,'differential_pressure_screen_Pa':500,'one_mm_water_film_assumption':True,'uniform_line_load_N_per_mm':.0005*20+12*7.93e-6*9.81+20*1e-6*9.81,'simple_supported_deflection_mm':5*(.0005*20+12*7.93e-6*9.81+20*1e-6*9.81)*252**4/(384*190000*(8.5**2+.6**2)),'caveat':'linear beam screen only; welds, torsion, vibration and wet airflow require prototype test'},
      'gutter_Y_fall_pct':.5,'outlet_OD_ID_mm':[18,16],'outlet_X_fall_pct':1,
      'drain_Manning_n_assumption':n,'full_pipe_L_h':full,'half_full_L_h':full/2,
      'proposed_wet_test_max_L_h_per_core':50,'blade_angle_deg':math.degrees(math.atan(8.5/20)),
      'ideal_2D_throat_gap_mm':18*math.sin(math.atan(8.5/20))-.6*math.cos(math.atan(8.5/20)),
      'ideal_2D_throat_area_fraction':(18*math.sin(math.atan(8.5/20))-.6*math.cos(math.atan(8.5/20)))/18,
      'throat_caveat':'geometric two-dimensional section, before rails, lips and gutters; constriction can substantially add pressure drop. No loss coefficient or capture efficiency established','capacity_caveat':'smooth straight tube estimate; entrance, hose, fittings, trap and pressure differential excluded; measured capacity must meet50L/h',
      'capture':'overlap blocks vertical line-of-sight but does not prove droplet separation at airflow; no measured carryover or pressure curve',
      'trap_formula_mm':'abs(worst fan differential_Pa)/(rho_water*g)*1000 +50 project margin; size each positive/negative-pressure trap for actual architecture',
      'trap_examples_mm':{str(p):round(p/(998*9.81)*1000+50,1) for p in (250,500,1000)},
      'proposed_test_acceptance':'0/50/100% P and R air, water10/25/50Lh, +/-0.2deg installation tilt; >=99% collected mass after correcting measured storage; no droplets onto actuators/insulation/electrics; reverse-air starting with wet core',
      'status':'wet-function verification plan, not confirmed product capability'})
    # Existing 2mm seal has only a 0.3mm permitted compression window.
    dump(OUT/'DATUM_AND_SEAL_REQUIREMENTS.json',{
      'placements':json.loads((ROOT/'HX/M101_C08_HORIZONTAL_H01/PLACEMENTS.json').read_text()),
      'local_reference':'same unhanded product; world=(tx-z,ty-y,tz-x)',
      'mating_face_local_X_mm':220,'nominal_installed_bottom_seal_plane_Z_mm':{'A_LOWER':620,'A_UPPER':955,'B_LOWER':620,'B_UPPER':955},
      'primary_support':'frame lands only, no fins/tubes/nozzles; Shell rails and soft seals do not replace positive location/restraint',
      'proposed_datum_scheme':'three frame supports define Z; one fixed X/Y locator and one slotted Y locator allow X thermal growth; separate positive lift restraint',
      'seal_existing_thickness_mm':2,'compression_nominal_mm':.65,'compression_range_mm':[.5,.8],
      'tolerance_budget_mm':{'HX_land_peak_to_valley':.10,'Shell_mate_peak_to_valley':.10,'stop_and_assembly_parallelism':.10,'total':.30},
      'guard':'these are maximum ranges, not +/- tolerances; reject weld distortion. The entire0.3mm window is consumed: revise gasket/stop design if any budget is exceeded.',
      'clamp_force_release_N':None,'clamp_force_reason':'no selected actual gasket compression curve or frame stiffness proof. CAD planar surfaces cannot establish force capacity.',
      'prototype_load_fixture_limit_N':1000,'fixture_protocol':'100N increments with opposed continuous backing at frame land; stop at0.10mm land bow,0.1mm permanent set, or test limit. Do not transfer test limit to service allowance.',
      'gasket_force_example':'HT80041..97kPa at25% only; multiply by actual gasket contact area, never by entire coil face; not selected material or 40% curve',
      'motion':'copy all82 D03 movement/service references, check H02 delta against both states; nominal1.2119mm upper gap requires supplier tolerance/thermal stack, no tightening of screws may consume it',
      'thermal_growth_example_mm':{'steel_1066mm_75K_alpha12e_6':1066*75*12e-6,'copper_1036mm_75K_alpha17e_6':1036*75*17e-6},
      'load_qualification':'frame, rails, pins, clamps and seal work as a combined load path; owner dry load test required before signing permissible clamp force'})
    print('Engineering ledgers complete',flush=True)
if __name__=='__main__':main()
