from common import *
from changes import build_parts

def translate_sweep(s,vector):
    pieces=[s,s.translate(vector)]
    for face in s.Faces():
        if face.geomType()=='PLANE' and abs(face.normalAt().dot(cq.Vector(*vector)))>1e-7:
            pieces.append(cq.Solid.extrudeLinear(face.outerWire(),face.innerWires(),vector))
    return cq.Compound.makeCompound(pieces)

def scene_index(parts=None):
    rows=json.loads((ROOT/'.work/S1/index.json').read_text(encoding='utf-8'))['parts']
    if parts is None:return rows
    return [r for r in rows if r['group']!='DAMPERS']+[
        {'name':n,'group':'DAMPERS','bbox':bbox(s),'path':'DAMPERS/'+n} for n,s in parts.items()]

def check(s,removed,index,parts):
    hits=[];b=bbox(s)
    for r in index:
        if r['name'] in removed or not overlap(b,r['bbox']):continue
        t=parts.get(r['name']) if r['group']=='DAMPERS' else None
        if t is None:t=cq.Shape.importBrep(str(ROOT/'.work/S1'/r['file']))
        v=s.intersect(t).Volume()
        if v>.001:hits.append({'part':r['path'],'volume':v})
    return hits

if __name__=='__main__':
 p,c=build_parts();index=scene_index();result={}
 for bed in 'AB':
  names=[f'DAMPER_SEAT_{bed}_UPPER_DEEP_O',f'DAMPER_STATIC_GASKET_{bed}_UPPER_O']
  absent=set(names+[n for n in p if n.startswith(f'D04_{bed}_')])
  for vector in ((-20,0,0),(-100,0,0),(0,800,0),(0,-800,0)):
   s=translate_sweep(cq.Compound.makeCompound([p[n] for n in names]),vector)
   hit=check(s,absent,index,p);result[bed+str(vector)]=hit
   print(bed,vector,hit,flush=True)
 dump(ROOT/'evidence/pin_service_probe.json',result)
