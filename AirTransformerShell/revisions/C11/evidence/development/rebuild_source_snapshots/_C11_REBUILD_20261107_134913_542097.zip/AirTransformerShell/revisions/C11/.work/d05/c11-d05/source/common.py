from runtime import *
import hashlib
import json
import math
from xcaf_leaves import leaves,bbox

C10=WORKSPACE/'C10_INTEGRATION_GIT/AirTransformerShell/revisions/C10'
THETA=77.701928604
HASHES={'S1':'55f43f07d34ba2ec186b634673f06bc3efdf6dfdc911c11433e07fd720a67f09',
        'S2':'5e547cd158b5c6d3692a940d672a6aa8a1ae074655237abf4ff09e1fbfe0ecff'}
def dump(path,obj):
    Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def axis(tag):
    return (610.,342.) if 'LOWER' in tag else (-500.,1385.)
def moving(n):
    return n.startswith(('DAMPER_BLADE_','DAMPER_ROOT_SLEEVE_','DAMPER_SHAFT_','DAMPER_ROOT_PIN_',
        'D03_COUPLING_','D03_ACT_OUTPUT_','D03_STOP_ARM_','D05_STOP_ARM_','D05_SHAFT_'))
def rotate(s,tag,angle):
    x,z=axis(tag)
    return s.rotate((x,0,z),(x,1,z),angle) if angle else s
def box(x0,y0,z0,x1,y1,z1):
    return cq.Solid.makeBox(x1-x0,y1-y0,z1-z0,(x0,y0,z0))
def cy(x,z,y0,y1,r):
    return cq.Solid.makeCylinder(r,y1-y0,(x,y0,z),(0,1,0))
def overlap(a,b,tol=1e-5):
    return all(min(a[i+3],b[i+3])-max(a[i],b[i])>tol for i in range(3))
def gap(a,b):
    return math.sqrt(sum(max(0,a[i]-b[i+3],b[i]-a[i+3])**2 for i in range(3)))
def source(state='S1',groups=None):
    p=C10/'cad'/f'C10_INSTALLED_{state}.step'
    assert sha(p)==HASHES[state]
    folder=ROOT/'.work'/state
    index=folder/'index.json'
    if not index.exists():
        folder.mkdir(exist_ok=True)
        rows=[]
        for i,(path,s) in enumerate(leaves(p)):
            file=f'{i}.brep'
            s.exportBrep(str(folder/file))
            group=next(g for g in ('SHELL','DAMPERS','HEAT_EXCHANGERS','WATER_RACK','FIRST_SPOOLS') if g in path.split('/'))
            rows.append({'name':path.split('/')[-1],'group':group,'path':path,'file':file,'bbox':bbox(s)})
        dump(index,{'sha256':sha(p),'parts':rows})
    data=json.loads(index.read_text(encoding='utf-8'))
    assert data['sha256']==sha(p)
    return [(r,cq.Shape.importBrep(str(folder/r['file']))) for r in data['parts']
            if groups is None or r['group'] in groups]
def normalized():
    src=source(groups={'DAMPERS'})
    dampers={r['name']:s for r,s in src if r['group']=='DAMPERS'}
    for n,s in list(dampers.items()):
        tag=next((f'{b}_{l}' for b in 'AB' for l in ('LOWER','UPPER') if f'{b}_{l}' in n),None)
        if tag and tag.startswith('B') and moving(n):
            dampers[n]=rotate(s,tag,-THETA)
    return dampers,src

if __name__=='__main__':
    d,src=normalized()
    for n,s in d.items():
        if 'A_' in n and any(k in n for k in ('SHAFT','BEARING','ROOT_','SEAT','SEAL','BRACKET')):
            print(n,[round(x,4) for x in bbox(s)],round(s.Volume(),2),flush=True)
