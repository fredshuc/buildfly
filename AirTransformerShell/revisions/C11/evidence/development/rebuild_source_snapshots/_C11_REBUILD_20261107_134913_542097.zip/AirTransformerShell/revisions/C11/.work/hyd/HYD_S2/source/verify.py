"""python verify.py S1_DIR S2_DIR D03_SWEEPS_STEP STATE"""
from pathlib import Path
import csv,json,sys,math,itertools,warnings
from cad_io import cq,named,leaves,bb,overlaps
from OCP.BRepBndLib import BRepBndLib
from OCP.Bnd import Bnd_Box
warnings.filterwarnings('ignore',category=FutureWarning)
old,out,d03=map(Path,sys.argv[1:4]);state=sys.argv[4]
def bounds(s):b=Bnd_Box();BRepBndLib.Add_s(s.wrapped,b,False);return b.Get()
def box(b):return cq.Solid.makeBox(*[b[i+3]-b[i] for i in range(3)],cq.Vector(*b[:3]))
def check(left,right,dist=False):
 rb={n:bounds(s) for n,s in right.items()};hits=[];best=(float('inf'),'','');cand=[]
 for n,s in left.items():
  a=bounds(s)
  for k,b in rb.items():
   if overlaps(a,b):
    vol=s.intersect(right[k]).Volume()
    if vol>.001:hits.append([n,k,round(vol,5)])
   if dist:cand.append((math.sqrt(sum(max(a[i]-b[i+3],b[i]-a[i+3],0)**2 for i in range(3))),n,k))
 if dist:
  for lo,n,k in sorted(cand):
   if lo>best[0]+.00001:break
   best=min(best,(left[n].distance(right[k]),n,k))
 return {'hits':hits,'min_gap':list(best) if dist else None}
r=named(out/'S2_RACK.step');allsvc=named(out/'S2_SERVICE.step')
ret=named(old/'H01_HYD_RACK.step');new={k:s for k,s in r.items() if k not in ret or any(w in k for w in ['FS','Q_'])}
ret={k:s for k,s in r.items() if k not in new}
parts=dict(leaves(old/('H01_INSTALLED_'+state+'.step')));host={k:v for k,v in parts.items() if '/HOST/' in k};hx={k:v for k,v in parts.items() if '/H01_FOUR_CORES/' in k};sp={k:v for k,v in parts.items() if '/FIRST_SPOOLS/' in k}
assert len(host)==724 and len(hx)==2204 and len(sp)==72
motion=dict(leaves(d03));olds=named(old/'H01_HYD_SERVICE.step')
tools={k:v for k,v in allsvc.items() if k not in olds}
hs={k:v for k,v in allsvc.items() if '__' in k}
rep={'state':state,'counts':{'host':len(host),'HX':len(hx),'spools':len(sp),'D03_envelopes':len(motion),'new':len(new),'rack':len(r),'new_service':len(tools)},'checks':{}}
for name,l,rr,dist in [('new_host',new,host,True),('new_HX',new,hx,True),('new_spools',new,sp,False),('D03_sweeps_new',new,motion,True),('new_H01_tools',new,hs,True),('new_retained_water',new,ret,True),('new_tools_host',tools,host,True),('new_tools_HX',tools,hx,False),('new_tools_D03',tools,motion,False)]:
 rep['checks'][name]=check(l,rr,dist)
sweeps={};rep['overhaul']={}
for b in 'AB':
 vec=-1 if b=='A' else 1;bed={}
 removed_before=set()
 for device in (('Q','FS') if b=='A' else ('FS','Q')):
  tag=device+'_'+b;moving=[r[tag],r[b+'_'+device+'_STACK_1'],r[b+'_'+device+'_STACK_2']]
  boundslist=[bb(s) for s in moving]
  src=[min(i[d] for i in boundslist) if d<3 else max(i[d] for i in boundslist) for d in range(6)]
  # Pass BOTH outboard skin and existing water-skid footprint before hoisting.
  dy=(-1220-src[4]) if b=='A' else (1000-src[1]);sw=src[:]
  sw[1]=min(src[1],src[1]+dy);sw[4]=max(src[4],src[4]+dy);probe=box(sw)
  skip={tag,b+'_'+device+'_STACK_1',b+'_'+device+'_STACK_2',b+'_LOW_W2_FS',b+'_FS_Q',b+'_Q_UP_W1'}
  stay={k:v for k,v in r.items() if k not in (skip|removed_before)}
  key=tag+'_WITH_STACKS_OUTBOARD';sweeps[key]=probe;bed[tag]=dict(outboard_dY_mm=round(dy,3),moving_bounds=src,sweep_bounds=sw,exclusions=sorted((skip|removed_before)-{tag,b+'_'+device+'_STACK_1',b+'_'+device+'_STACK_2'}))
  for name,g in [('rack',stay),('host',host),('spools',sp),('hx',hx),('D03',motion)]:
   rep['checks'][key+'_'+name]=check({key:probe},g,name=='rack')
  removed_before.update([tag,b+'_'+device+'_STACK_1',b+'_'+device+'_STACK_2'])
 rep['overhaul'][b]=bed
if state=='S1':
 a=cq.Assembly(name='BRIDGE_OUTBOARD_SERVICE');
 for k,s in sweeps.items():a.add(s,name=k)
 a.save(str(out/'S2_OUTBOARD_SERVICE.step'))
(out/('validation_'+state+'.json')).write_text(json.dumps(rep,indent=2))
print({k:v for k,v in rep['checks'].items() if v['hits']},flush=True)
