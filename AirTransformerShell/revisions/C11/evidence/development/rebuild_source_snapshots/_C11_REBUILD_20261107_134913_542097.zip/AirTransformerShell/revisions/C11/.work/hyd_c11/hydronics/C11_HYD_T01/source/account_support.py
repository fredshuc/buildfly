"""Auditable mass allowances and conservative frame screening; not piping FEA."""
import json,csv,math
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parents[1];root=P.parents[1];scratch=root.parent
parts=json.load(open(P/'evidence/support_parts.json'));rack=json.load(open(scratch/'c11_work/rack.json'))
def wr(path,rows):
 with open(path,'w',newline='') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
rows=[]
for n,d in parts.items():
 dry=d['volume_mm3']*({'steel':7850,'PIR':80}[d['material']])*1e-9
 rows.append(dict(item=n,dry_kg=dry,water_L=0,wet_kg=dry,x_mm=d['cg_mm'][0],y_mm=d['cg_mm'][1],z_mm=d['cg_mm'][2],basis='CAD volume x assumed density; no coating/adhesive allowance',kind='rack'))
for n,d in rack.items():
 if 'XV' in n:dry,water,basis=4.,.30,'design mass allowance; vendor model/mass/cavity OPEN'
 elif n.startswith('FS_'):dry,water,basis=3.5,.20,'3.5kg allowance including BSR kit; actual weighed mass/cavity OPEN'
 elif n.startswith('Q_'):dry,water,basis=2.,.10,'2kg allowance; catalogue/actual cavity to confirm'
 elif n.startswith('TA_'):dry,water,basis=8.,.70,'8kg allowance; actual TA size/model/mass/cavity OPEN'
 elif 'STACK' in n:dry,water,basis=.6,.024544,'each 50mm stack design allowance; not actual fitting mass'
 else:
  dry=d['vol']*8e-6
  od,di=(42.4,36.4) if n.startswith('HEADER') else (33.7,27.3)
  water=d['vol']*di**2/(od**2-di**2)/1e6
  basis='CAD metal volume, rho8000; nominal lumen inferred from uniform wall (junction approximation)'
 rows.append(dict(item=n,dry_kg=dry,water_L=water,wet_kg=dry+water*.99997,x_mm=d['cg'][0],y_mm=d['cg'][1],z_mm=d['cg'][2],basis=basis,kind='water island excluding HX/first spools'))
# Five kg harness/insulation/temporary saddle allowance, distinct from modeled items.
rows.append(dict(item='UNMODELED_AUX_ALLOWANCE',dry_kg=5.,water_L=0,wet_kg=5.,x_mm=-1220,y_mm=-250,z_mm=750,basis='design allowance; does not certify accessory envelope',kind='allowance'))
wr(P/'C11_HYD_MASS_NOZZLE_LOADS.csv',rows)
m=sum(r['wet_kg'] for r in rows);cg=sum((r['wet_kg']*np.array([r['x_mm'],r['y_mm'],r['z_mm']]) for r in rows))/m
# Six feet reactions: rigid cap, equal vertical foot stiffness. Includes local tension.
feet=[(x,y) for x in [-1660,-780] for y in [-1180,-100,680]];A=np.array([[1]*6,[y for x,y in feet],[-x for x,y in feet]])
cases=[]
for name,gmult,Fx,Fy,Fz in [('FULL_STATIC',1,0,0,0),('SERVICE_X',1,300,0,-500),('SERVICE_Y',1,0,300,-500),('DRAINED_TRANSPORT_2G',2,0,0,0)]:
 mass=m if name!='DRAINED_TRANSPORT_2G' else sum(r['dry_kg'] for r in rows)
 down=mass*9.80665*gmult-Fz;h=1050-122
 Mx=-mass*9.80665*gmult*cg[1]+Fz*(-250)-h*Fy
 My=mass*9.80665*gmult*cg[0]-Fz*(-1220)+h*Fx
 rz=A.T@np.linalg.solve(A@A.T,np.array([down,-Mx,-My]))
 assert max(abs(A@rz-np.array([down,-Mx,-My])))<1e-6
 for i,(x,y) in enumerate(feet):cases.append(dict(case=name,foot=f'IF-01-F{i+1}',Fx_N=Fx/6,Fy_N=Fy/6,Fz_N=-rz[i],Mx_Nm=0,My_Nm=0,Mz_Nm=0,convention='rack-on-Shell; pinned foot idealization; horizontal equally shared assumption',status='screen; actual base stiffness/joint rotation/weld calculation required'))
wr(P/'load_cases.csv',cases)
# Cantilever post and single span beam elastic bounds, explicit E and section.
E=200000.;I40=(40**4-34**4)/12;I60=(40*60**3-34*54**3)/12
Lpost=600;Pside=300;Lrail=1080;Prail=1500
calc=dict(E_MPa=E,I40_mm4=I40,I60_mm4=I60,post_600mm_300N_side_deflection_mm=Pside*Lpost**3/(3*E*I40),post_stress_MPa=Pside*Lpost/(I40/20),rail_1080mm_1500N_mid_deflection_mm=Prail*Lrail**3/(48*E*I60),rail_stress_MPa=Prail*Lrail/(4*(I60/30)),scope='separate elastic member screens, not assembled frame/weld/bolt/foam FEA; force limits assumed')
# Rigid short-spool sensitivity is a warning bound, not a predicted nozzle force.
Ipipe=math.pi*(33.7**4-27.3**4)/64;Ametal=math.pi*(33.7**2-27.3**2)/4
calc['77p5mm_fixed_guided_spool_sensitivity']={'E_MPa':193000,'I_mm4':Ipipe,'lateral_N_per_mm':12*193000*Ipipe/77.5**3,'moment_Nm_per_mm':6*193000*Ipipe/77.5**2/1000,'axial_N_per_mm':193000*Ametal/77.5,'caution':'fully restrained straight segment upper-stiffness illustration; real bends/joints must be in coupled model'}
calc['thermal_free_growth_mm_per_m_5_to_80']=17e-6*75*1000
calc['wet_mass_kg']=m;calc['wet_CG_mm']=cg.tolist();calc['dry_mass_kg']=sum(r['dry_kg'] for r in rows);calc['island_water_L_est']=sum(r['water_L'] for r in rows);calc['HX_water_L_excluded_from_rack']=4*11.159677953925
json.dump(calc,open(P/'evidence/mechanics_screen.json','w'),indent=2)
nozz=[]
for r in csv.DictReader(open(root/'HX/M101_C08_HORIZONTAL_H01/EIGHT_PORTS_AND_SPOOLS.csv')):
 nozz.append(dict(id='IF-02-'+r['tag'],face=r['HX_face'],Fx_N='UNRESOLVED',Fy_N='UNRESOLVED',Fz_N='UNRESOLVED',Mx_Nm='UNRESOLVED',My_Nm='UNRESOLVED',Mz_Nm='UNRESOLVED',allowable='HX allowable data pending',basis='Do not infer zero from independent gravity frame; joint/pipe flexibility, support creep, thermal friction and pressure restraints not yet qualified',status='HOLD'))
wr(P/'C11_HYD_NOZZLE_LOADS.csv',nozz)
print(json.dumps(calc,indent=2))
