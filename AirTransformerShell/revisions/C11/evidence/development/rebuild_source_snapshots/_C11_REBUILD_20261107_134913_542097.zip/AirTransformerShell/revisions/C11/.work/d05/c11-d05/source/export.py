"""Replace only the damper branch of the hash-pinned C10 XCAF assemblies."""
from common import *
from changes import build_parts
from OCP.IFSelect import IFSelect_RetDone
from OCP.STEPCAFControl import STEPCAFControl_Reader,STEPCAFControl_Writer
from OCP.STEPControl import STEPControl_AsIs
from OCP.TCollection import TCollection_ExtendedString as Str
from OCP.TDataStd import TDataStd_Name
from OCP.TDF import TDF_Label,TDF_LabelSequence
from OCP.TDocStd import TDocStd_Document
from OCP.TopLoc import TopLoc_Location
from OCP.XCAFDoc import XCAFDoc_DocumentTool

def name(l):
 a=TDataStd_Name();return a.Get().ToExtString() if l.FindAttribute(TDataStd_Name.GetID_s(),a) else ''

def save_small(path,parts):
 a=cq.Assembly(name=path.stem)
 for n,s in parts.items():a.add(s,name=n)
 a.export(str(path))
 back=list(leaves(path));assert len(back)==len(parts)
 for n,s in back:
  t=parts[n.split('/')[-1]]
  assert s.isValid() and abs(s.Volume()-t.Volume())<max(.001,t.Volume()*1e-8)
 return {'file':path.name,'sha256':sha(path),'occurrences':len(back)}

def run():
 p,c=build_parts();results={}
 print('Parts ready',len(p),flush=True)
 for state in ('S1','S2'):
  src=C10/'cad'/f'C10_INSTALLED_{state}.step';assert sha(src)==HASHES[state]
  doc=TDocStd_Document(Str('C11_D05'));reader=STEPCAFControl_Reader();reader.SetNameMode(True)
  print('Read',state,flush=True)
  assert reader.ReadFile(str(src))==IFSelect_RetDone
  print('Transfer',state,flush=True)
  assert reader.Transfer(doc)
  print('Transferred',state,flush=True)
  tree=XCAFDoc_DocumentTool.ShapeTool_s(doc.Main());roots=TDF_LabelSequence();tree.GetFreeShapes(roots)
  assert roots.Length()==1;root=roots.Value(1);children=TDF_LabelSequence();tree.GetComponents_s(root,children)
  removed=[]
  for i in range(1,children.Length()+1):
   child=children.Value(i)
   if name(child)=='DAMPERS':
    removed.append(name(child));tree.RemoveComponent(child)
  assert len(removed)==1
  print('Removed old dampers',state,flush=True)
  group=tree.NewShape();TDataStd_Name.Set_s(group,Str('DAMPERS_D05'))
  posed={}
  for n,s in p.items():
   tag=next((f'{b}_{l}' for b in 'AB' for l in ('LOWER','UPPER') if f'{b}_{l}' in n),None)
   angle=THETA if tag and tag[0]==('B' if state=='S1' else 'A') else 0
   s=rotate(s,tag,angle) if tag and moving(n) else s;posed[n]=s
   definition=tree.AddShape(s.wrapped,False);TDataStd_Name.Set_s(definition,Str(n))
   ref=tree.AddComponent(group,definition,TopLoc_Location());TDataStd_Name.Set_s(ref,Str(n))
  ref=tree.AddComponent(root,group,TopLoc_Location());TDataStd_Name.Set_s(ref,Str('DAMPERS'))
  tree.UpdateAssemblies();dest=ROOT/'cad'/f'C11_D05_INSTALLED_{state}.step';TDataStd_Name.Set_s(root,Str(dest.stem))
  print('Tree updated',state,flush=True)
  writer=STEPCAFControl_Writer();writer.SetNameMode(True);writer.SetColorMode(True)
  assert writer.Transfer(root,STEPControl_AsIs) and writer.Write(str(dest))==IFSelect_RetDone
  print('Written',state,flush=True)
  count={};bad=[]
  for path,s in leaves(dest):
   g=next(t for t in ('SHELL','DAMPERS','HEAT_EXCHANGERS','WATER_RACK','FIRST_SPOOLS') if t in path.split('/'))
   count[g]=count.get(g,0)+1
   if g=='DAMPERS':
    n=path.split('/')[-1];t=posed[n]
    if not s.isValid() or max(abs(a-b) for a,b in zip(bbox(s),bbox(t)))>.001 or abs(s.Volume()-t.Volume())>max(.001,t.Volume()*1e-8):bad.append(n)
  assert not bad and count=={'SHELL':560,'DAMPERS':len(p),'HEAT_EXCHANGERS':2204,'WATER_RACK':36,'FIRST_SPOOLS':72},(count,bad)
  results[state]={'input_sha256':HASHES[state],'output_sha256':sha(dest),'counts':count,'bad':bad}
  dump(ROOT/'evidence/export.json',results);print('Readback',state,count,flush=True)
 save_small(ROOT/'cad/C11_D05_DAMPERS_NORMALIZED_P.step',p)
 dump(ROOT/'evidence/changes.json',c)

if __name__=='__main__':run()
