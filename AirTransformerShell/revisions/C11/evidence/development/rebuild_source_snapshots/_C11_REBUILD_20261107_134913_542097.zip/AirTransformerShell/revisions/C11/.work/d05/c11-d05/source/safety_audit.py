from common import *
from changes import build_parts

def run():
 p,c=build_parts();result={'stop_working_face_proof':{},'D04_rigid_endzone':[],'polygon_prism_edges':{},'forced_80_fault':[]}
 for bed in 'AB':
  for level in ('LOWER','UPPER'):
   tag=f'{bed}_{level}';x,z=axis(tag)
   # Every point of the keyed P pin has x>=13,z<=-25. In arm coordinates
   # x'>=13 cos(theta)+25 sin(theta)>=13 on this interval. R is symmetric.
   min_x=min(13.,13*math.cos(math.radians(THETA))+25*math.sin(math.radians(THETA)))
   result['stop_working_face_proof'][tag]={'interval_deg':[0,THETA],'P_pin_min_surface_local_X':min_x,
      'R_pin_max_surface_local_X':-min_x,'tongue_flat_X':[-13,13],'pin_radius':5,
      'min_tongue_clearance_mm':min_x-13,'hub_clearance_mm':math.hypot(17.5,30)-18-5,
      'nominal_flat_contact_area_mm2':3*2*math.sqrt(5**2-4.5**2),
      'interpretation':'zero only at intended endpoint flat/flat contact; no interior interference'}
   assert min_x>=13
   for mode,angle,seat in [('R',80,'DEEP'),('P',-(80-THETA),'SLOPED')]:
    blade=rotate(p[f'DAMPER_BLADE_{tag}_0_O'],tag,angle)
    arm=rotate(p[f'D05_STOP_ARM_{tag}'],tag,angle)
    result['forced_80_fault'].append({'valve':tag,'direction':mode,'angle_deg':angle,
       'blade_steel_penetration_mm3':blade.intersect(p[f'DAMPER_SEAT_{tag}_{seat}_O']).Volume(),
       'intended_stop_penetration_if_forced_mm3':sum(arm.intersect(p[f'D05_STOP_PIN_{tag}_{i}']).Volume() for i in (0,1)),
       'meaning':'REJECTED hypothetical forced geometry; mechanical stop must prevent this pose'})
   for n,s in p.items():
    if tag not in n or not moving(n):continue
    b=bbox(s);R=max(math.hypot(xx-x,zz-z) for xx in (b[0],b[3]) for zz in (b[2],b[5]))
    if n.startswith('DAMPER_BLADE') and n.endswith(('_0_O','_1_O','_2_O','_4_O')):
     types=sorted({e.geomType() for e in s.Edges()})
     result['polygon_prism_edges'][n]=types
     assert types==['LINE'],(n,types)
    for nn,t in p.items():
     if not nn.startswith('D04_') or nn.endswith('_WET_BOOT'):continue
     # Same Y reasoning as full motion, then a rigorous full 1.5-degree
     # distance lower bound at each outward endpoint.
     bb=bbox(t)
     if min(b[4],bb[4])-max(b[1],bb[1])<=1e-5:continue
     for endpoint in (0,THETA):
      d=rotate(s,tag,endpoint).distance(t);lower=d-R*math.radians(1.5)
      assert lower>0,(n,nn,endpoint,lower)
      result['D04_rigid_endzone'].append({'moving':n,'rigid_D04':nn,'endpoint':endpoint,'outward_1p5_deg_lower_mm':lower})
 dump(ROOT/'evidence/safety_scope_audit.json',result)
 print('Analytical stop faces, all D04 rigid endzones, polygonal sweep premises: PASS',flush=True)

if __name__=='__main__':run()
