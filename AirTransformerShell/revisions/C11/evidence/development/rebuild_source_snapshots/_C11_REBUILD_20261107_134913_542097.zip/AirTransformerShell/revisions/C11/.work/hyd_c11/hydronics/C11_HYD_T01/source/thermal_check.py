from pathlib import Path
import csv,math,json
P=Path(__file__).resolve().parents[1];root=P.parents[1]
def ts(t,k,h,cylinder=True):
 r=.0175; R=(r+t/1000)*math.log((r+t/1000)/r) if cylinder else t/1000
 return 32-27/(1+h*R/k)
rows=[]
for row in csv.DictReader(open(root/'HX/M101_C08_HORIZONTAL_H01/HOST_CUT_PROPOSAL.csv')):
 if row['layer']!='INNER':continue
 for revision,t,k in [('C10_existing',5,.040),('C11_proposed',25,.040)]:
  rows.append(dict(id='IF-05-'+row['tag'],revision=revision,x_mm=-502,y_mm=row['y_mm'],z_mm=row['z_mm'],pipe_OD_mm=35,hole_mm=45 if t==5 else 91,insulation_mm=t,k_W_mK=k,air_C=32,water_C=5,dewpoint_C=26,h_W_m2K=5,surface_C=round(ts(t,k,5),3),margin_K=round(ts(t,k,5)-26,3),method='1D cylindrical SCREEN ONLY; excludes metal/adhesive bridges',status='FAIL' if t==5 else 'candidate; host joint and 3D bridge review OPEN',movement='axial +/-4; radial +/-1; sleeve annulus 3mm',vapour='continuous foil/elastomer collar; upper split staggered; 50mm adhesive lap; no pipe-metal contact',drip='wet-side lower lip; separate collector and gravity outlet required from Shell/HX'))
for b in 'AB':
 for rev,t,k in [('C10_corner',19.143,.040),('C11_DT_corner',18,.022)]:
  rows.append(dict(id='IF-05-'+b+'_U_W2_CROWN',revision=rev,x_mm='wet bay -687..-507',y_mm='A: -791.575; B:73.425',z_mm=1122.35,pipe_OD_mm=35,hole_mm='unchanged C10 pocket',insulation_mm=t,k_W_mK=k,air_C=32,water_C=5,dewpoint_C=26,h_W_m2K=5,surface_C=round(ts(t,k,5,False),3),margin_K=round(ts(t,k,5,False)-26,3),method='local planar lower-thickness SCREEN; not 3D notch validation',status='OPEN: DT18 compressed supply thickness/properties not certified; margin below +1K',movement='retain A-post 2mm clearance; no column cut',vapour='ArmaGel DT foil candidate; compatible lap adhesive and aging to confirm',drip='wet-side collector needed; no drain into dry bay or insulation cavity'))
with open(P/'C11_HYD_THERMAL_INTERFACES.csv','w',newline='') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
json.dump({'boundary':'L1 provisional 32/26/5; not project rated ambient','reference_sweep':[{ 't_mm':t,'k':k,'h':h,'Ts':ts(t,k,h)} for t in [5,19.143,25,30] for k in [.034,.04] for h in [5,8]],'planar_aerogel18_k022':ts(18,.022,5,False),'decision':'25mm normal crossings require D91 host candidate; corner remains open; no invented thermal PASS'},open(P/'evidence/thermal_check.json','w'),indent=2)
