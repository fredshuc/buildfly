"""Replace broad rubbing contact by two narrow lips; define seat contact bands."""
from common import *
from OCP.BRepAdaptor import BRepAdaptor_Surface

def wedge(x,z,y0,y1,a,b,r=25):
    pts=[cq.Vector(x,y0,z)]+[cq.Vector(x+r*math.cos(math.radians(t)),y0,z+r*math.sin(math.radians(t))) for t in (a,b)]
    return cq.Solid.extrudeLinear(cq.Wire.makePolygon(pts,close=True),[],(0,y1-y0,0))

def seals(parts,changed):
    data={}
    for bed in 'AB':
      for level in ('LOWER','UPPER'):
        tag=f'{bed}_{level}';x,z=axis(tag)
        lip=f'DAMPER_ROOT_LIP_{tag}_O';s=parts[lip];b=bbox(s)
        # Inner arc endpoints rotate 180 degrees between lower and upper.
        shift=0 if level=='LOWER' else 180
        keep=wedge(x,z,b[1]-1,b[4]+1,88-7+shift,88+shift).fuse(
            wedge(x,z,b[1]-1,b[4]+1,169.701928604+shift,176.701928604+shift))
        relief=cy(x,z,b[1]-1,b[4]+1,17.0).cut(keep)
        parts[lip]=s.cut(relief).clean()
        changed[lip]='VMQ two 7 deg contact lands; free bore R16.25, sleeve R16.5; rest bore R17; hot-preload qualification OPEN'
        for end in ('IN','OUT'):
            n=f'DAMPER_ROOT_END_SEAL_{tag}_{end}_O';s=parts[n];b=bbox(s)
            # Locate lands from the actual D29.5 cylindrical bore, not the
            # complete seal bounding box which includes a bearing recess.
            bore=max([f for f in s.Faces() if f.geomType()=='CYLINDER' and
                abs(BRepAdaptor_Surface(f.wrapped).Cylinder().Radius()-14.75)<1e-5],key=lambda f:f.Area())
            by=bbox(bore);bands=((by[1]+1,by[1]+3),(by[4]-3,by[4]-1))
            relief=cy(x,z,b[1]-1,b[4]+1,15.6)
            adds=[]
            for lo,hi in bands:
                relief=relief.cut(box(x-40,lo,z-40,x+40,hi,z+40))
                adds.append(cy(x,z,lo,hi,14.75).cut(cy(x,z,lo-1,hi+1,14.5)))
            parts[n]=s.cut(relief).fuse(*adds).clean()
            changed[n]='VMQ two 2 mm axial sealing lands, free bore D29.00; relieved bore D31.2 elsewhere'
            data[n]={'axial_contact_bands_global_Y_mm':bands,'free_inner_radius_mm':14.5,
                     'shaft_radius_mm':15.,'free_radial_thickness_mm':6.,'installed_radial_thickness_mm':5.5}
        for pos in ('DEEP','SLOPED'):
            sn=f'DAMPER_SEAL_{tag}_{pos}_O';seat=parts[f'DAMPER_SEAT_{tag}_{pos}_O'];old=parts[sn]
            face=next(f for f in seat.Faces() if f.innerWires())
            w=face.innerWires()[0]
            wires=[]
            for offset in (0,3):
                if offset==0:
                    wires.append(w);continue
                options=w.offset2D(offset)
                bigger=max(options,key=lambda wi:cq.Face.makeFromWires(wi).Area())
                if cq.Face.makeFromWires(bigger).Area()<cq.Face.makeFromWires(w).Area():
                    bigger=max(w.offset2D(-offset),key=lambda wi:cq.Face.makeFromWires(wi).Area())
                wires.append(bigger)
            ring=cq.Face.makeFromWires(wires[1],[wires[0]])
            normal=face.normalAt()
            tool=cq.Solid.extrudeLinear(ring.outerWire(),ring.innerWires(),normal*20).fuse(
                 cq.Solid.extrudeLinear(ring.outerWire(),ring.innerWires(),normal*-20))
            new=old.intersect(tool).clean()
            assert new.isValid() and new.Solids(),sn
            parts[sn]=new
            changed[sn]='HT870 3.0 mm outward contact band, inner edge matches aperture; free 6.20 +/-0.15, CAD installed 4'
            # Integrate pressure torque from actual installed gasket plan area.
            area=new.Volume()/4
            r=math.hypot(new.Center().x-x,new.Center().z-z)
            data[sn]={'area_mm2':area,'pressure_moment_mm3':area*r,'torque_at_80kPa_Nm':area*r*.08/1000,
                      'free_mm':6.2,'free_tolerance_mm':.15,'installed_unloaded_mm':4.0}
    dump(ROOT/'evidence/seal_geometry.json',data)
    return parts,changed
