"""Cache only solids in the interface and service region. Dimensions in mm."""
import hashlib,json,zipfile
from pathlib import Path
from step_io import leaves, bounds
OUT=Path(__file__).resolve().parents[1]
ROOT=OUT.parents[1]
INP=ROOT/'HX_C08_INPUTS'
P0=INP/'C08_HYD_SERIES_S0'
CACHE=INP/'geometry_cache'
R1=ROOT/'C09_RT4_RECONCILED/AirTransformerShell/revisions/C09R1_RT4/C09R1_RT4_CAD_REVIEW.zip'
REGION=(-900,-1450,180,-425,1450,1370)
def relevant(b):
    return all(b[i]<REGION[i+3] and REGION[i]<b[i+3] for i in range(3))
def main():
    CACHE.mkdir(exist_ok=True)
    data=[]
    files=[('P0_HOST',P0/'C08_INSTALLED_P0.step'),('P0_TOOLS',P0/'C08_WATER_SERVICE_P0.step')]
    with zipfile.ZipFile(R1) as z:
        for st in ('S1','S2'):
            n='C09R1_INSTALLED_'+st+'.step'
            path=INP/n
            if not path.exists(): z.extract(n,INP)
            files.append((st,path))
    hashes={}
    for group,path in files:
        hashes[group]=hashlib.sha256(path.read_bytes()).hexdigest()
        for tag,s in leaves(path):
            if group in ('S1','S2') and 'HEAT_EXCHANGERS' in tag: continue  # audited from the common product separately
            for j,body in enumerate(s.Solids()):
                b=bounds(body)
                if not relevant(b): continue
                n=tag.split('/')[-2]+'@'+str(j)
                fn=str(len(data))+'.brep'
                body.exportBrep(str(CACHE/fn))
                data.append(dict(group=group,name=n,path=tag,b=b,file=fn))
        print(group,len(data),flush=True)
    (CACHE/'obstacles.json').write_text(json.dumps(data))
    (CACHE/'sources.json').write_text(json.dumps(hashes,indent=2))
if __name__=='__main__': main()
