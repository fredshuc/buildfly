"""Check exported H01 against C08 P0/BRep, retained HX and relieved C09 R1 S1/S2."""
from functools import lru_cache
import csv,json,math
from collections import Counter
from pathlib import Path
import cadquery as cq
from step_io import leaves,bounds
from build import ROOT,OUT,P0,REF,RACK,BASE,C05,FACE,service,build_spool
from cache_hosts import CACHE,REGION
def read(p):
    return {n.split('/')[-2]:s for n,s in leaves(p)}
def aabb_gap(a,b):
    return math.sqrt(sum(max(a[i]-b[i+3],b[i]-a[i+3],0)**2 for i in range(3)))
def overlap(a,b):
    return all(min(a[i+3],b[i+3])-max(a[i],b[i])>1e-5 for i in range(3))
def main():
    obs=json.loads((CACHE/'obstacles.json').read_text())
    core=read(OUT/'H01_SINGLE_CORE.step')
    ends=read(OUT/'H01_EIGHT_INSTALLED_ENDS.step')
    sp=read(OUT/'H01_EIGHT_FIRST_SPOOLS.step')
    svc=read(OUT/'H01_TOOL_AND_REMOVAL.step')
    pl=json.loads((OUT/'PLACEMENTS.json').read_text())
    fixed={}; original_p0={}; original_host={}
    cuts=[]; penetration_rows=[]
    coords=list(csv.DictReader((OUT/'EIGHT_PORTS_AND_SPOOLS.csv').open()))
    for row in coords:
        tag=row['tag']; bed,st,w=tag.split('_')
        inst=pl[bed+('_LOWER' if st=='L' else '_UPPER')]['translation']
        y,z=json.loads(row['HX_face'])[1:]
        boot=svc[bed+'_'+st+'_W1__WET_BAY_COMMON_BOOT']
        section=boot.intersect(cq.Solid.makeBox(1.5,2500,2000,cq.Vector(-650.8,-1250,0)))
        profiles=[bounds(s) for s in section.Solids()]
        assert len(profiles)==2
        bbsec=min(profiles,key=lambda b:abs((b[1]+b[4])/2-y))
        yc,zc=(bbsec[1]+bbsec[4])/2,(bbsec[2]+bbsec[5])/2
        od=2*math.ceil((max(bbsec[4]-bbsec[1],bbsec[5]-bbsec[2])+8)/2)
        for plane,cy,cz,diam in [('INNER',inst[1]-726.85,inst[2]-(162.65 if w=='W1' else 52.65),45),('SKIN',yc,zc,od)]:
            x=-502 if plane=='INNER' else -651
            tool=cq.Solid.makeCylinder(diam/2,4,cq.Vector(x,cy,cz),cq.Vector(1,0,0))
            cuts.append((plane,tool))
            penetration_rows.append(dict(tag=tag,layer=plane,cut_from_x=x,y_mm=cy,z_mm=cz,diameter_mm=diam,status='proposal; shell owner to detail split gland'))
    from build import csvwrite
    csvwrite(OUT/'HOST_CUT_PROPOSAL.csv',penetration_rows)
    @lru_cache(None)
    def body(file):return cq.Shape.importBrep(str(CACHE/file))
    for i,r in enumerate(obs):
        key=r['group']+'/'+r['name']+'/'+str(i)
        s=body(r['file']); b=r['b']
        if r['group']=='P0_TOOLS' and '_UNION_TOOL' in r['name']:
            continue # previous rack faces retired with the 8 cropped straight tails
        if r['group']=='P0_HOST' and 'SHEET_METAL_REFERENCE' not in r['path'] and b[3]>RACK+1e-4 and b[0]<-735+1e-4:
            original_p0[key]=s
            s=s.cut(cq.Solid.makeBox(-735-RACK+1,2500,2000,cq.Vector(RACK,-1250,0)))
        # Pure in-memory reference edits. Keep the as-delivered hit inventory.
        plane='SKIN' if abs(b[0]+650.8)<.01 and abs(b[3]+649.3)<.01 else 'INNER' if abs(b[0]+501.5)<.01 and abs(b[3]+500)<.01 else None
        if plane and 'SPLIT_GLAND' not in r['name']:
            original_host[key]=s
            s=s.cut(*[tool for layer,tool in cuts if layer==plane])
        if r['group']=='P0_HOST' and abs(b[0]+506.5)<.01 and abs(b[3]+504.5)<.01 and abs(b[2]-1133)<.01:
            original_host[key]=s
            for cy in (-791.575,73.425):
                s=s.cut(cq.Solid.makeCylinder(20.5,12,cq.Vector(-510,cy,1122.35),cq.Vector(1,0,0)))
        if s.Solids():fixed[key]=s
    # Preserve all other core solids, checking every relevant instance, including same-core interactions.
    for k,p in pl.items():
        bed,st=k.split('_'); prefix=bed+'_'+st[0]+'_'
        for n,s in core.items():
            b=bounds(s); t=p['translation']
            world=[t[0]-b[5],t[1]-b[4],t[2]-b[3],t[0]-b[2],t[1]-b[1],t[2]-b[0]]
            if not overlap(world,REGION) or any(n in x.split('__')[1:] for x in ends):continue
            fixed['HX/'+prefix+n]=s.moved(cq.Location(cq.Vector(*t),cq.Vector(1,0,-1),180))
    material={**ends,**sp}
    bb={n:bounds(s) for n,s in {**material,**fixed,**svc}.items()}
    hits=[]; service_hits=[]; raw=[]; host_raw=[]; shared_tools=[]
    def check(name,s,others,dest,kind):
        a=bb[name]
        assert all(a[i]>=REGION[i]-.001 and a[i+3]<=REGION[i+3]+.001 for i in range(3)),(name,a)
        for n,o in others.items():
            if n==name or not overlap(a,bb.get(n) or bounds(o)):continue
            if 'WET_BAY_COMMON_BOOT' in name and n in ends and name[:3]==n[:3]:continue # filled outer budget contains both end pipes
            # Tool solids are occupied only during a particular maintenance operation.
            if n.startswith('P0_TOOLS/') and name.split('__')[0]+'_UNION_TOOL' in n:
                shared_tools.append([name,n]);continue
            if n in material and name.split('__')[0]==n.split('__')[0]:
                if kind=='tool' and (not any(v in name for v in ('RETRACT','SHIFT','LIFT','SIDE_EXIT'))):continue
                if kind=='tool' and any(v in n for v in ('__BODY','__SLIDE','__LOCK','RETAINER')):continue
                # intentional 24 mm OEM CAD socket engagement, no threaded detail
                if kind=='physical' and n in ends and name in ends and ('OEM_LAYOUT' in n or 'OEM_LAYOUT' in name):continue
            v=s.intersect(o).Volume()
            if v>.001:dest.append([name,n,round(v,4)])
    for n,s in material.items():
        check(n,s,fixed,hits,'physical')
        check(n,s,{m:t for m,t in material.items() if m<n},hits,'physical')
        for m,t in original_p0.items():
            if overlap(bb[n],bounds(t)):
                v=s.intersect(t).Volume()
                if v>.001:raw.append([n,m,round(v,4)])
    for n,s in svc.items():
        check(n,s,fixed,service_hits,'tool');check(n,s,material,service_hits,'tool')
    for n,s in {**material,**svc}.items():
        for m,t in original_host.items():
            if overlap(bb[n],bounds(t)):
                v=s.intersect(t).Volume()
                if v>.001:host_raw.append([n,m,round(v,4)])
    # Adjacent wraps must fit concurrently. Other tools operate one port at a time.
    ins=[k for k in svc if k.endswith(('WET_BAY_COMMON_BOOT','INSULATION_SPLIT_COVER'))]
    wrap_hits=[]
    for i,a in enumerate(ins):
        for b in ins[i+1:]:
            if a.split('__')[0]!=b.split('__')[0] and overlap(bb[a],bb[b]):
                v=svc[a].intersect(svc[b]).Volume()
                if v>.001:wrap_hits.append([a,b,round(v,4)])
    for n,s in svc.items():
        if n in ins:continue
        for m in ins:
            if n.split('__')[0]!=m.split('__')[0] and overlap(bb[n],bb[m]):
                v=s.intersect(svc[m]).Volume()
                if v>.001:service_hits.append([n,m,round(v,4)])
    def closest(names,objects):
        candidates=sorted((aabb_gap(bb[a],bb[b]),a,b) for a in names for b in objects)
        best=(float('inf'),'','')
        for low,a,b in candidates:
            if low>best[0]+.00001:break
            aset={**material,**svc}; bset={**fixed,**material}
            best=min(best,(aset[a].distance(bset[b]),a,b))
        return [round(best[0],4),best[1],best[2]] if candidates else None
    near={}
    posts=[n for n in fixed if 'POST_-600_-825' in n or 'C09_A_POST' in n]
    for bed in 'AB':
        for w in ('W1','W2'):
            tag=bed+'_U_'+w
            lower=[n for n in {**material,**fixed} if n.startswith(bed+'_L_W2__') and 'D35_END_PIPE' in n]
            near[tag+'_spool_to_lower_W2']=closest([n for n in sp if n.startswith(tag)],lower)
            near[tag+'_lift_to_lower_W2']=closest([n for n in svc if n.startswith(tag) and 'LIFT_' in n],lower)
        for st in 'LU':
            tag=bed+'_'+st+'_W1'
            near[tag+'_product_to_A_front_post']=closest([n for n in material if n.startswith(tag)],posts)
            near[tag+'_service_to_A_front_post']=closest([n for n in svc if n.startswith(tag)],posts)
    d=dict(scope='Local change and service screen at >0.001 mm3, C08 P0 and C09R1 plus four H01 cores',inputs=json.loads((CACHE/'sources.json').read_text()),included_host_solids=Counter(x['group'] for x in obs),material_hits=hits,service_hits=service_hits,concurrent_wrap_hits=wrap_hits,untrimmed_P0_hits=raw,original_host_hits=host_raw,own_P0_shared_service_pairs=len(shared_tools),clearance_mm=near)
    (OUT/'CHECKS.json').write_text(json.dumps(d,indent=2),encoding='utf8')
    print('hits',len(hits),len(service_hits),'raw P0',len(raw),flush=True)
if __name__=='__main__':main()
