"""python account.py H01_WATER_DIR S2_DIR"""
import math,json,csv,sys
from pathlib import Path
src,out=map(Path,sys.argv[1:])
def rows(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def wr(n,r):
 with (out/n).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=r[0]);w.writeheader();w.writerows(r)
pipe={(r['bed'],r['segment']):float(r['pipe_mm']) for r in rows(out/'bridge_routes.csv')}
pairs={'lower_W2_to_FS1':('LOW_W2_FS',77.5,1),'FS2_to_Q1':('FS_Q',0,2),'Q2_to_upper_W1':('Q_UP_W1',77.5,1)}
rout=[];beds=[];A=math.pi*.0273**2/4
for s in rows(src/'branch_account.csv'):
 b,seg=s['bed'],s['segment'];q=float(s['Q_m3h']);temp=int(s['T_C']);old=float(s['new_length_mm']);newL=old;stacks=0
 if seg in pairs:
  key,spool,stacks=pairs[seg];newL=pipe[b,key]+spool
 vol=newL*A;rho,mu={5:(999.97,.001519),80:(971.8,.000355)}[temp]
 def hyd(D,L):
  v=q/3600/(math.pi*D**2/4);Re=rho*v*D/mu;f=.3164/Re**.25 if Re>=2300 else 64/Re;return f*(L/D)*rho*v*v/2000
 rout.append(dict(bed=b,segment=seg,mode=s['mode'],Q_m3h=q,T_C=temp,H01_pipe_mm=old,S2_pipe_mm=round(newL,5),delta_pipe_mm=round(newL-old,5),pipe_L=round(vol,6),pipe_kPa=round(hyd(.0273,newL/1000),6),stack_budget_count=stacks,stack_reference_L=round(math.pi*.025**2/4*50*stacks,6),stack_straight_kPa=round(hyd(.025,.05*stacks),6)))
wr('all_branches.csv',rout)
for mode,temp in [('cold',5),('hot',80)]:
 for q in (.5,1.72,2.,2.58):
  a=[r for r in rout if (r['bed'],r['mode'],r['T_C'],r['Q_m3h'])==('A',mode,temp,q)];assert len(a)==5
  rho={5:999.97,80:971.8}[temp];v=q/3600/A;alpha=rho*v*v/2000
  V=22.31935590785+sum(r['pipe_L'] for r in a);vs=sum(r['stack_reference_L'] for r in a)
  beds.append(dict(mode=mode,T_C=temp,Q_m3h=q,HX_and_pipe_L=round(V,6),with_stack_budget_L=round(V+vs,6),plug_s_est=round((V+vs)/q*3.6,3),pipe_kPa=round(sum(r['pipe_kPa'] for r in a),5),four_stack_straight_kPa_est=round(sum(r['stack_straight_kPa'] for r in a),5),nine_bridge_elbows_K03_to_K12_kPa=[round(9*k*alpha,4) for k in [.3,1.2]],FS_full_open_kPa=round(100*(q/47.9)**2,4)))
wr('bed_duty.csv',beds)
