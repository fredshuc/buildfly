from service_probe import *
from service_route import run as pin_route
from export import save_small
from services_geometry import services

def run():
 p,c=build_parts();index=scene_index(p);report={};envelopes={}
 for bed in 'AB':
  for level in ('LOWER','UPPER'):
   tag=f'{bed}_{level}';subset={n:s for n,s in p.items() if tag in n}
   envs=services(subset,bed,level)
   for n,s in envs.items():
    if n.startswith('ACT_PULL'):
     absent={f'D03_ACTUATOR_INTERFACE_{tag}',f'D03_ACT_OUTPUT_{tag}'}
     absent.update(k for k in p if tag in k and any(t in k for t in ('DRIVE_NUT','DRIVE_WASHER','ACT_M6')))
    elif n.startswith('HOOD_PULL'):
     absent={k for k in p if tag in k and any(t in k for t in ('FEEDBACK_HOOD','LIMIT_SENSOR','GUARD_M4'))}
    elif n.startswith('ACT_SOCKET'):
     absent={k for k in p if tag in k and any(t in k for t in ('DRIVE_NUT','DRIVE_WASHER','DRIVE_STUD','ACT_M6'))}
    elif n.startswith('HOOD_DRIVER'):
     absent={k for k in p if tag in k and 'GUARD_M4' in k}
    else:
     absent={k for k in p if bed in k and any(t in k for t in ('BASE_M8','BASE_NUT','BASE_WASHER'))}
    hit=check(s,absent,index,p);report[n]={'removed_or_tool_target':sorted(absent),'penetrations':hit}
    envelopes[n]=s;print(n,hit,flush=True)
 # D04 release is checked against actual H01 / HYD-S2, after the stated
 # Pin-seat removal. Export all stages including consumable/tool envelopes.
 for bed,y in [('A',-791.575),('B',73.425)]:
  prefix=f'D04_{bed}_';keeper=prefix+'OUTER_KEEPER';nuts={prefix+'LOCKNUT_'+t for t in ('LOW','HIGH')}
  for side,dy in [('LOW',-8),('HIGH',8)]:
   n=f'D05_{bed}_M4_SOCKET_{side}'
   s=cq.Solid.makeCylinder(5.5,35.5,(-540,y+dy,1086.85),(1,0,0))
   absent={keeper,prefix+'LOCKNUT_'+side,prefix+'STUD_'+side}
   report[n]={'removed_or_tool_target':sorted(absent),'penetrations':check(s,absent,index,p)};envelopes[n]=s
  n=f'D05_{bed}_OUTER_KEEPER_NEG_X_12';s=translate_sweep(p[keeper],(-12,0,0));absent={keeper,*nuts}
  report[n]={'removed_or_tool_target':sorted(absent),'penetrations':check(s,absent,index,p)};envelopes[n]=s
  for side,sign in [('LOW',-1),('HIGH',1)]:
   name=f'C09_SPLIT_GLAND_{bed}_UPPER_W2_{side}'
   r=next(r for r in index if r['name']==name);g=cq.Shape.importBrep(str(ROOT/'.work/S1'/r['file']))
   absent={name,keeper,*nuts,prefix+'WET_BOOT',f'DAMPER_SEAT_{bed}_UPPER_DEEP_O',f'DAMPER_STATIC_GASKET_{bed}_UPPER_O'}
   for label,s in [('NEG_X_2',translate_sweep(g,(-2,0,0))),('RADIAL_25',translate_sweep(g.translate((-2,0,0)),(0,sign*25,0)))]:
    n=f'D05_{bed}_{side}_GLAND_{label}';report[n]={'removed_or_tool_target':sorted(absent),'penetrations':check(s,absent,index,p)};envelopes[n]=s
 route,route_envs=pin_route();envelopes.update(route_envs)
 dump(ROOT/'evidence/service.json',{'maintenance_pose':'all shafts P=0, fans and water isolated','components':report,
      'pin_route':route,'pin_route_status':'GEOMETRY_CONDITIONAL: Shell inlet floor/wrap/pocket demountable joints and roof access not yet signed'})
 dump(ROOT/'evidence/service_export.json',save_small(ROOT/'cad/C11_DAMPERS_PIN_SERVICE_ENVELOPE.step',envelopes))
 print('Service exported',len(envelopes),flush=True)

if __name__=='__main__':run()
