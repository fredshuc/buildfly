import os
import platform
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
WORKSPACE=ROOT.parents[1]
for folder in os.environ.get('CADQUERY_LIBDIRS','').split(os.pathsep):
    if folder:
        sys.path.insert(0,folder)
for folder in ('R5_WORK/early_vendor','R5_WORK/runtime_ready'):
    sys.path.append(str(WORKSPACE/folder))
if os.name=='nt':
    def no_wmi(*args):
        raise OSError('Use Python Windows metadata fallback in this CAD process')
    platform._wmi_query=no_wmi
import cadquery as cq

for folder in ('cad','evidence','drawings','.work'):
    (ROOT/folder).mkdir(exist_ok=True,parents=True)
