import json
from pathlib import Path
OUT=Path(__file__).resolve().parents[1]
WORK=OUT/'_work' if (OUT/'repro_inputs').exists() else OUT.parents[1]/'HX_C10_H02_WORK'
parts=json.loads((WORK/'S1/all_bounds.json').read_text());motion=json.loads((WORK/'motion/index.json').read_text())
zones=[[-1350,-1400,0,-950,-1100,340],[-1350,1130,0,-950,1430,340]]
def overlap(a,b):return all(min(a[i+3],b[i+3])-max(a[i],b[i])>1e-5 for i in range(3))
excluded=[p for p in parts if p['b'][0]>700 or p['b'][2]>1350 or p['b'][5]<300]
result={'scope':'AABB check of full S1 source parts excluded by host cache against vessel work zones, plus complete D03 motion/service bounds','excluded_count':len(excluded),'zones':zones,'hits':[p for p in excluded if any(overlap(p['b'],z) for z in zones)],'motion_AABB_hits':[{'name':r['name'],'b':r['b']} for r in motion if any(overlap(r['b'],z) for z in zones)],'motion_minZ':min(r['b'][2] for r in motion),'S2_basis':'same fixed shell/rack; complete D03 movement/service bounds cover moving components'}
(OUT/'evidence/VESSEL_EXCLUDED_REGION_CHECK.json').write_text(json.dumps(result,indent=2),encoding='utf8')
assert not result['hits'] and not result['motion_AABB_hits']
print('Vessel excluded-region bounds clear')
