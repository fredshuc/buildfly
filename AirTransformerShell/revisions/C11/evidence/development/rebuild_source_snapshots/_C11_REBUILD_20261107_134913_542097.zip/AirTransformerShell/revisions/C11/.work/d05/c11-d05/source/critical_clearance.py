from changes import build_parts
from motion import *
from scipy.optimize import minimize_scalar

p,c=build_parts();idx=json.loads((ROOT/'.work/S1/index.json').read_text(encoding='utf-8'))['parts'];out={}
for bed,key in [('A','POST_0_41.775'),('B','POST_0_673.775')]:
 tag=bed+'_UPPER';s=p[f'DAMPER_BLADE_{tag}_0_O']
 r=next(r for r in idx if r['name']==key and f'/{bed}_UPPER/' in r['path'])
 t=cq.Shape.importBrep(str(ROOT/'.work/S1'/r['file']))
 angles=np.linspace(0,THETA,65);ds=[rotate(s,tag,float(a)).distance(t) for a in angles];i=int(np.argmin(ds))
 result=minimize_scalar(lambda a:rotate(s,tag,a).distance(t),bounds=(float(angles[max(0,i-1)]),float(angles[min(64,i+1)])),method='bounded',options={'xatol':1e-8})
 out[tag]={'exact_pose_angle_deg':result.x,'exact_pose':witness(rotate(s,tag,result.x),t),
           'continuous_conservative':witness(blade_sweep(s,tag),t),'target':r['path'],'coverage':aperture_results(p,tag)}
 print(tag,out[tag],flush=True)
dump(ROOT/'evidence/critical_clearance.json',out)
