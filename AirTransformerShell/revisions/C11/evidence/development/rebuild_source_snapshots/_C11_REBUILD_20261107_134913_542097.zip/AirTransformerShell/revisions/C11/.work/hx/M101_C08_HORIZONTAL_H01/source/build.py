"""C08 H01. Build one product from C05, four occurrences and independent first spools."""
import csv, json, hashlib, math
from pathlib import Path
import cadquery as cq
from step_io import leaves,bounds

OUT=Path(__file__).resolve().parents[1]
ROOT=OUT.parents[1]
REF=ROOT/'AirTransformerShell/interfaces/four-core-horizontal-HX'
C05=ROOT/'HX/M101_D952_P254_220_39x6_C05'
P0=ROOT/'HX_C08_INPUTS/C08_HYD_SERIES_S0'
V=cq.Vector
R=50.
# Local +Z points along machine -X. +local X points DOWN.
TURN=1154.
OEM_START=1349.
FACE=OEM_START+82.5
RACK=-865.
BASE=ROOT/'HX_import_20261105/HX/M101_D952_P254_220_39x6_C04'
CANDIDATE_SHA='2304062c568ca324972ec0f15c137ff27963f7f2558b5fcfbe1c87d163cf9d57'
def dump(p,obj): p.write_text(json.dumps(obj,indent=2),encoding='utf8')
def csvwrite(p,rows):
    with p.open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]); w.writeheader(); w.writerows(rows)
def cylinder(p,d,r,h):return cq.Solid.makeCylinder(r,h,V(*p),V(*d))
def tube(p,d,r,ri,h):return cylinder(p,d,r,h).cut(cylinder(p,d,ri,h))
def save(name,parts):
    a=cq.Assembly(name=name)
    for n,s in parts.items():
        a.add(s.located(cq.Location()),name=n,loc=s.location())
    path=OUT/(name+'.step'); a.save(str(path))
    read=cq.importers.importStep(str(path)).val().Solids()
    uniq=set(s.located(cq.Location()) for s in read)
    assert len(read)==len(parts) and all(s.isValid() for s in uniq),name
    return len(read)
def end(port,include_flow=False):
    xx,yy=(162.65,655.275) if port=='W1' else (52.65,505.275)
    a=V(xx,726.85,1080); b=V(xx,726.85,TURN)
    lane=yy-45 if port=='W1' else yy
    u=V(280-xx,lane-726.85,0).normalized(); z=V(0,0,1); D=math.hypot(280-xx,lane-726.85)
    c=b+u*R+z*R; d=c+u*(D-2*R); e=d+u*R+z*R
    pts=[cq.Edge.makeLine(a,b),cq.Edge.makeThreePointArc(b,b+u*(R*(1-2**-.5))+z*(R*2**-.5),c),
         cq.Edge.makeLine(c,d),cq.Edge.makeThreePointArc(d,d+u*(R*2**-.5)+z*(R*(1-2**-.5)),e)]
    if port=='W1':
        # Offset away from A's sister post, then restore the common rack lane.
        theta=math.acos(1-45/(2*R)); uy=V(0,1,0)
        m=e+z*(R*math.sin(theta))+uy*(R*(1-math.cos(theta)))
        f=e+z*(2*R*math.sin(theta))+uy*45
        h=e+z*(R*math.sin(theta/2))+uy*(R*(1-math.cos(theta/2)))
        pts.extend([cq.Edge.makeThreePointArc(e,h,m),cq.Edge.makeThreePointArc(m,f-(h-e),f)])
        e=f
    pts.append(cq.Edge.makeLine(e,V(280,yy,OEM_START+24)))
    wire=cq.Wire.assembleEdges(pts)
    if include_flow:
        full=cq.Wire.assembleEdges(pts+[cq.Edge.makeLine(V(280,yy,OEM_START+24),V(280,yy,FACE))])
        if include_flow=='wire':
            return full
        flow=cq.Workplane(cq.Plane(origin=a,normal=z)).circle(14).sweep(full,isFrenet=False).val()
        for x,y,ax_z,sgn in [(xx,726.85,1100,-1),(280,yy,OEM_START-7,1)]:
            flow=flow.fuse(cylinder((x,y,ax_z),(sgn,0,0),2,29))
        return flow.clean()
    pipe=cq.Workplane(cq.Plane(origin=a,normal=z)).circle(17.5).circle(14).sweep(wire,isFrenet=False).val()
    caps={}; controls={}
    for label,x,y,ax_z,sgn in [('VENT',xx,726.85,1100,-1),('DRAIN',280,yy,OEM_START-7,1)]:
        pt=(x+10*sgn,y,ax_z); axis=(sgn,0,0)
        pipe=pipe.fuse(cylinder(pt,axis,6,19)).cut(cylinder((x,y,ax_z),axis,2,31)).clean()
        caps[port+'_'+label+'_CAP']=cylinder((x+29*sgn,y,ax_z),axis,7,5)
        controls[label]=[x+29*sgn,y,ax_z]
    raw=cq.importers.importStep(str(BASE/'sources/4015211138875.stp')).val()
    union=raw.rotate((0,0,0),(0,1,0),-90).translate((280,yy,OEM_START+43))
    assert pipe.isValid() and math.hypot(e.x-280,e.y-yy)<1e-6
    # Wet-bay insulation begins after the inner gland, not inside its sealing land.
    wet_start=V(xx,726.85,1151)
    cover_path=cq.Wire.assembleEdges([cq.Edge.makeLine(wet_start,b)]+pts[1:-1]+[cq.Edge.makeLine(e,V(280,yy,OEM_START))])
    insulation=cq.Workplane(cq.Plane(origin=wet_start,normal=z)).circle(42.5).sweep(cover_path,isFrenet=False).val()
    return {port+'_D35_END_PIPE':pipe,port+'_VIEGA138875_OEM_LAYOUT_ONLY':union,**caps},controls,wire.Length()-24+82.5,insulation
def hex_tube(x,y,z,af,bore,length):
    face=cq.Wire.makePolygon([V(x,y+af/math.sqrt(3)*math.cos(i*math.pi/3),z+af/math.sqrt(3)*math.sin(i*math.pi/3)) for i in range(6)],close=True)
    return cq.Solid.extrudeLinear(face,[],V(length,0,0)).cut(cylinder((x,y,z),(1,0,0),bore,length))
def build_spool(y,z,face):
    # Left is rack, right is HX. All pressure details are reference profiles.
    rack_seat=RACK+10; hx_seat=face-24; seat_gap=hx_seat-rack_seat
    mid=rack_seat+seat_gap*.58
    body=tube((rack_seat,y,z),(1,0,0),21.5,17.0,mid-rack_seat)
    body=body.fuse(tube((rack_seat,y,z),(1,0,0),17.,13.65,4)).clean()
    nose=tube((mid-12,y,z),(1,0,0),16.85,13.65,hx_seat-(mid-12))
    nose=nose.fuse(hex_tube(mid+8,y,z,38,16.85,hx_seat-mid-8)).clean()
    lock=hex_tube(mid-11,y,z,48,21.5,11)
    assert nose.translate((-6,0,0)).intersect(body.fuse(lock)).Volume()<.001
    rack=hex_tube(RACK,y,z,46,13.65,10)
    tail=hex_tube(hx_seat,y,z,46,13.65,24)
    # Split external retention collars (positive axial retention detail pending).
    collars={}
    for n,x in [('HX',hx_seat),('RACK',rack_seat)]:
        # Annular clamp reservation outside the mating flange envelope.
        band=tube((x-3,y,z),(1,0,0),34,29.5,6)
        for xx in (x-5,x+3):
            band=band.fuse(tube((xx,y,z),(1,0,0),34,27,2))
        for j,dy in enumerate([-34,0]):
            half=band.intersect(cq.Solid.makeBox(10,34,68,V(x-5,y+dy,z-34)))
            collars[n+'_RETAINER_'+str(j)]=half
    # Flange lands up to the collar ID: thread/groove details unselected.
    def flange(x):return tube((x,y,z),(1,0,0),29.5,13.65,3)
    return {'FIXED_HX_TAIL':tail.fuse(flange(hx_seat)).clean(),
            'FIXED_RACK_TAIL':rack.fuse(flange(rack_seat-3)).clean(),
            'BODY':body.fuse(flange(rack_seat)).clean(),
            'SLIDE':nose.fuse(flange(hx_seat-3)).clean(),'LOCK':lock,**collars}
def box(x,y,z,dx,dy,dz):return cq.Solid.makeBox(dx,dy,dz,V(x,y,z))
def service(y,z,face,parts):
    shapes={}
    # Two axial wrench stations. A tool head cylinder and a conservative
    # +/-15 degree handle-sector bounding box (handle clocked upward).
    lock=bounds(parts['LOCK'])
    for name,x,L in [('UNION_SW50',face+5.76,250),('UNION_SW53',face+41.335,300),('TAIL',face-16,250),('LOCK',(lock[0]+lock[3])/2,250)]:
        sign=-1 if z<700 else 1
        shapes[name+'_HEAD']=cylinder((x-10,y,z),(1,0,0),65,20)
        spread=65+L*math.sin(math.radians(15))
        w=cq.Wire.makePolygon([V(x-10,yy,zz) for yy,zz in [(y-65,z),(y+65,z),(y+spread,z+sign*L),(y-spread,z+sign*L)]],close=True)
        shapes[name+'_HANDLE_SWEEP']=cq.Solid.extrudeLinear(w,[],V(20,0,0))
    shapes['INSULATION_SPLIT_COVER']=cylinder((face-2,y,z),(1,0,0),56,84.5)
    # Separate two halves sideways; swept occupancy for actual annular half covers.
    ann=tube((face-2,y,z),(1,0,0),56,31,84.5)
    for side in (-1,1):
        half=ann.intersect(box(face-3,y-57,z+(-56 if side<0 else 0),88,114,56))
        b=bounds(half)
        shapes['COVER_RELEASE_'+str(side)]=box(b[0],b[1],b[2]+min(0,60*side),b[3]-b[0],b[4]-b[1],b[5]-b[2]+60)
    # Continuous conservative nonrotating middle-spool lift. Seat faces are flat.
    # Remove retainers and lock; retract slide 6 toward rack; then shift +X 3.
    for n in ('BODY','SLIDE','LOCK'):
        s=parts[n]; b=bounds(s); dx=-6 if n=='SLIDE' else 0
        if dx: shapes['RETRACT_'+n]=box(b[0]-6,b[1],b[2],b[3]-b[0]+6,b[4]-b[1],b[5]-b[2])
        shapes['SHIFT_'+n]=box(b[0]+dx,b[1],b[2],b[3]-b[0]+3,b[4]-b[1],b[5]-b[2])
        shapes['LIFT_'+n]=box(b[0]+dx+3,b[1],b[2],b[3]-b[0],b[4]-b[1],b[5]-b[2]+110)
        dy=(-1350 if y<0 else 1350)-y
        shapes['SIDE_EXIT_'+n]=box(b[0]+dx+3,b[1]+min(0,dy),b[2]+110,b[3]-b[0],b[4]-b[1]+abs(dy),b[5]-b[2])
    for n,p in parts.items():
        if 'RETAINER' in n:
            b=bounds(p); side=-1 if n.endswith('_0') else 1
            shapes['RELEASE_'+n]=box(b[0],b[1]+min(0,60*side),b[2],b[3]-b[0],b[4]-b[1]+60,b[5]-b[2])
    return shapes
def main():
    p=C05/(C05.name+'.step')
    assert hashlib.sha256(p.read_bytes()).hexdigest()==CANDIDATE_SHA
    core={n.split('/')[-2]:s for n,s in leaves(p)}
    assert len(core)==549
    new={}; vents={}; lengths={}; insulation={}
    for w in ('W1','W2'):
        pipe,controls,L,insulation[w]=end(w); new.update(pipe); vents[w]=controls; lengths[w]=L
        del core['C05_'+w+'_VENT_CLOSURE_ENVELOPE']
    core.update(new)
    place=json.loads((REF/'PLACEMENTS.json').read_text())['instances']
    rows=[]; allends={}; spools={}; tools={}; moved={}
    with (P0/'eight_ports.csv').open(encoding='utf-8-sig') as f: hyd=list(csv.DictReader(f))
    for row in hyd:
        tag=row['tag']; bed,level,w=tag.split('_'); k=bed+('_LOWER' if level=='L' else '_UPPER')
        t=place[k]['translation']; loc=cq.Location(V(*t),V(1,0,-1),180)
        y=float(row['rack_y']); z=float(row['rack_z']); x=t[0]-FACE
        s=build_spool(y,z,x); v=service(y,z,x,s)
        def world(a):return [round(t[0]-a[2],3),round(t[1]-a[1],3),round(t[2]-a[0],3)]
        face=world((280,655.275 if w=='W1' else 505.275,FACE))
        assert math.dist(face,[x,y,z])<1e-6
        u=new[w+'_VIEGA138875_OEM_LAYOUT_ONLY'].moved(loc)
        assert any(f.geomType() in ('PLANE','BSPLINE') and abs(bounds(f)[0]-x)<.001 and abs(bounds(f)[3]-x)<.001 and (f.Center()-V(*face)).Length<.001 and f.normalAt().x<-.999 for f in u.Faces()),tag
        allends.update({tag+'__'+n:part.moved(loc) for n,part in new.items() if n.startswith(w+'_')})
        spools.update({tag+'__'+n:part for n,part in s.items()}); tools.update({tag+'__'+n:part for n,part in v.items()})
        if w=='W1':
            boot=insulation['W1'].fuse(insulation['W2']).moved(loc)
            dy=0 if bed=='A' else 865
            # One two-channel insulation boot, formed around both tubes and
            # locally relieved for 2 mm installation clearance at the A posts.
            for xmin,xmax,ymin,ymax in [(-640,-560,-845,-805),(-640,-618,-805,-745)]:
                boot=boot.cut(box(xmin-2,ymin+dy-2,100,xmax-xmin+4,ymax-ymin+4,1450))
            # Same formed external profile on all four. Upper floor starts
            # at Z1143.5; the 2 mm separation leaves a thin local W2 boot.
            boot=boot.cut(box(-652,-1050+dy,t[2]-33.5,147.5,900,250))
            tools[tag+'__WET_BAY_COMMON_BOOT']=boot
        rows.append(dict(tag=tag,HX_face=face,HX_outward=[-1,0,0],connection='Rp1-1/4 female',spool_HX_outward=[1,0,0],spool_rack_face=[RACK,y,z],spool_rack_outward=[-1,0,0],cold=row['cold_service'],hot=row['hot_service'],cold_adjacent=row['cold_adjacent'],hot_adjacent=row['hot_adjacent'],header='P1 / first row X162.65' if w=='W1' else 'P7 / last row X52.65',spool_length_mm=round(x-RACK,3),trim_existing_P0_straight_mm=-735-RACK,ID_reference_mm=27.3,new_HX_header_to_face_mm=round(lengths[w],4),vent_boss_face=world(vents[w]['VENT']),drain_boss_face=world(vents[w]['DRAIN'])))
    csvwrite(OUT/'EIGHT_PORTS_AND_SPOOLS.csv',rows)
    dump(OUT/'PLACEMENTS.json',place)
    for nm,parts in [('H01_SINGLE_CORE',core),('H01_EIGHT_INSTALLED_ENDS',allends),('H01_EIGHT_FIRST_SPOOLS',spools),('H01_TOOL_AND_REMOVAL',tools)]:
        print('export',nm,save(nm,parts),flush=True)
if __name__=='__main__':main()
