import json,math,csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
OUT=Path(__file__).resolve().parents[1]
r=json.loads((OUT/'ROUTES.json').read_text())
fig,ax=plt.subplots(2,2,figsize=(15,10),constrained_layout=True)
colors={'W1':'#147fbd','W2':'#d86638'}
a=ax[0,0]
a.add_patch(Rectangle((-410,-737.5),1000,610,facecolor='#e5eaef',edgecolor='#4e5964',label='Fin face'))
for route in r['small_bore']:
    p=route['points_A_LOWER'];a.plot([q[0] for q in p],[q[1] for q in p],color=colors[route['port']],lw=2,ls='-' if route['function']=='VENT' else '--',label=route['port']+' '+route['function'])
p=r['condensate_A_LOWER'];a.plot([q[0] for q in p],[q[1] for q in p],color='#237b4b',lw=3,label='Condensate D18')
for x in (-501,-650):a.axvline(x,color='#999',ls=':',lw=1)
a.set(xlabel='Global X (mm)',ylabel='Global Y (mm)',title='A lower: plan / route vertices');a.set_aspect('equal');a.legend(fontsize=8,ncol=2)
a=ax[0,1]
ports=list(csv.DictReader((OUT/'SERVICE_AND_SHELL_PORTS.csv').open()))
for row in ports:
    if not row['id'].startswith('A_'):continue
    # CSV has Python list representation with numeric entries only.
    p=json.loads(row['sealing_shoulder'].replace('(', '[').replace(')', ']'))
    c='#237b4b' if row['kind']=='CONDENSATE' else '#b54a35' if row['kind']=='DRAIN' else '#147fbd'
    a.scatter(p[1],p[2],c=c,s=35)
    dy=-22 if row['id']=='A_UPPER_W2_DRAIN' else 10 if row['id']=='A_LOWER_W2_VENT' else 0
    a.annotate(row['id'].replace('A_',''),(p[1],p[2]),xytext=(8,dy),textcoords='offset points',fontsize=7)
for z in (560,895):
    for y in (-720,-570):a.add_patch(plt.Circle((y,z),34,fill=False,color='#888'))
a.set(xlabel='Global Y (mm)',ylabel='Global Z (mm)',title='Wet-side operations / A bed');a.grid(alpha=.2);a.set_xlim(-790,-200)
a=ax[1,0]
for i in range(4):
    y=i*18;a.plot([y,y+20],[0,8.5],color='#237b4b',lw=3);a.plot([y,y],[0,2.5],color='#237b4b',lw=3)
for y in (8,25,46,64):a.annotate('',xy=(y,7),xytext=(y,17),arrowprops={'arrowstyle':'->','color':'#147fbd'})
a.text(1,-6,'18 pitch / 20 projection / 2 overlap\nWater runs out of page toward the -X gutter (1% fall).',fontsize=10)
a.set(xlabel='Y section (mm)',ylabel='Relative Z (mm)',title='Ventilated condensate blades: wet test required',ylim=(-10,20));a.set_aspect('equal')
a=ax[1,1]
for x,label,w in [(-18,'SW46',8),(5.76,'SW50',8)]:
    a.add_patch(Rectangle((x-w/2,0),w,50,facecolor='#c6d9e8',edgecolor='#245679'));a.text(x,55,label,ha='center',fontsize=11)
a.annotate('',xy=(-9,70),xytext=(-3.24,70),arrowprops={'arrowstyle':'<->'});a.text(-6.12,78,'5.76 mm',ha='center')
a.text(-28,-20,'8 mm jaws; 14 mm joint; 18 mm grip.\nBoth handles run in Y; W1 toward -Y, W2 toward +Y.\n77.5 mm installed spool length is retained.',fontsize=10)
a.set(xlim=(-35,35),ylim=(-35,90),xlabel='X relative to HX port face (mm)',title='Simultaneous counterhold / nominal envelope');a.set_yticks([])
fig.suptitle('HX H02 | C10 interface iteration | engineering schematic, not a test certificate',fontsize=16)
fig.savefig(OUT/'H02_SERVICE_AND_CONDENSATE.png',dpi=160)
fig.savefig(OUT/'H02_SERVICE_AND_CONDENSATE.svg')
print('Figures saved')
