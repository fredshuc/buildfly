"""Package the versioned HX candidate and check the ZIP byte for byte."""
import csv,hashlib,json,zipfile
from pathlib import Path
from build import OUT,ROOT,REF,P0,C05,BASE,CANDIDATE_SHA,cylinder,save
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    qc=json.loads((OUT/'CHECKS.json').read_text())
    audit=json.loads((OUT/'READBACK_AND_DISTANCES.json').read_text())
    assert audit['exported_end_faces_checked']==24
    assert all(not qc[k] for k in ('material_hits','service_hits','concurrent_wrap_hits'))
    ports=list(csv.DictReader((OUT/'EIGHT_PORTS_AND_SPOOLS.csv').open()))
    assert len({r['tag'] for r in ports})==8
    for r in ports:
        assert r['cold']==('inlet' if r['tag'].endswith('W1') else 'outlet')
        assert r['hot']==('outlet' if r['tag'].endswith('W1') else 'inlet')
    with (OUT/'HOST_CUT_PROPOSAL.csv').open() as f:
        cut={r['tag']+'_'+r['layer']:cylinder(tuple(float(r[k]) for k in ('cut_from_x','y_mm','z_mm')),
             (1,0,0),float(r['diameter_mm'])/2,4) for r in csv.DictReader(f)}
    assert save('H01_HOST_OPENING_TOOLS_REFERENCE',cut)==16
    ins={'C05_product_sha256':CANDIDATE_SHA,'P0_archive_git_source':'51e1d91:AirTransformerShell/revisions/C09_WATER_OVERLAY/C08_HYD_SERIES_S0.zip',
         'C08_sources':json.loads((P0/'sources.json').read_text(encoding='utf-8-sig')),
         'active_STEP_inputs':qc['inputs'],
         'other_inputs':{p.name:sha(p) for p in (REF/'PLACEMENTS.json',P0/'HX_REQUEST_CN.md',P0/'eight_ports.csv',BASE/'sources/4015211138875.stp',BASE/(BASE.name+'_NOMINAL_FLOW.step'))}}
    (OUT/'INPUTS.json').write_text(json.dumps(ins,indent=2))
    sign={'revision':'HX-C08-H01','issuer_role':'L2-HX','date':'2026-11-06','scope':'conditional four-core series interface for prototype integration',
          'controlled_table_sha256':sha(OUT/'EIGHT_PORTS_AND_SPOOLS.csv'),'core_definition_sha256':sha(OUT/'H01_SINGLE_CORE.step'),
          'cold':'CS/L.W1/L.W2/FS/Q/U.W1/U.W2/CR','hot':'HS/U.W2/U.W1/Q(reverse)/FS/L.W2/L.W1/HR',
          'conditions':['8 P0 straight runs shortened by 130 mm; downstream owner acceptance','planned inner/outer penetrations and R1 upper seat relief',
                        'qualify joint retention/pressure, wrench engagement, thermal insulation, venting and draining',
                        'four FS/Q proxy intersections remain with L2-E'],'live_water':'HOLD'}
    (OUT/'HX_SIGNOFF.json').write_text(json.dumps(sign,indent=2))
    files=[p for p in OUT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='MANIFEST.json']
    manifest={p.relative_to(OUT).as_posix():sha(p) for p in sorted(files)}
    (OUT/'MANIFEST.json').write_text(json.dumps(manifest,indent=2))
    dest=ROOT/'HX_C08_H01_HYDRONIC_RETURN.zip'
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files+[OUT/'MANIFEST.json']:z.write(p,OUT.name+'/'+p.relative_to(OUT).as_posix())
    with zipfile.ZipFile(dest) as z:
        assert z.testzip() is None
        for n,h in manifest.items(): assert hashlib.sha256(z.read(OUT.name+'/'+n)).hexdigest()==h
    print(dest,dest.stat().st_size,sha(dest))
if __name__=='__main__':main()
