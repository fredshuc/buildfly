"""Rebuild local H02 repairs while preserving unchanged formed comb rails.
Full build.py is the canonical clean builder; this script is an incremental repair.
"""
from common import *
from build import collector,local,pipe_route
print('Reading delivered core and immutable H01',flush=True)
core=read(OUT/'H02_SINGLE_CORE.step');base=read(H01/'H01_SINGLE_CORE.step')
ch=json.loads((OUT/'CHANGE_REGISTER.json').read_text())
cond,_=collector(base,include_rails=False)
core.update({n:local(s) for n,s in cond.items()})
routes=json.loads((OUT/'ROUTES.json').read_text())
for r in routes['small_bore']:
    if r['function']=='DRAIN':
        r['points_A_LOWER']=[[-664 if p[0]==-666 else p[0],p[1],p[2]] for p in r['points_A_LOWER']]
        core[r['port']+'_DRAIN_LINE']=local(pipe_route(r['points_A_LOWER']))
for name,ya,yb,z0 in [('PLATE_TAB_0_1',-122.5,-142,643.85),('PLATE_TAB_1_1',-770,-736,650.8)]:
    a=V(-421,ya,z0);b=V(-421,yb,638);d=(b-a).normalized()
    tool=cyl((a-d*4).toTuple(),d.toTuple(),6.5,(b-a).Length+8)
    core[name]=base[name].cut(local(tool)).clean()
from OCP.ShapeFix import ShapeFix_Shape
repairs=[]
for n in list(cond)+['W1_DRAIN_LINE','W2_DRAIN_LINE','PLATE_TAB_0_1','PLATE_TAB_1_1']:
    if not core[n].isValid():
        before=core[n];f=ShapeFix_Shape(before.wrapped);f.SetPrecision(1e-6);f.SetMaxTolerance(.01);f.Perform()
        core[n]=cq.Shape.cast(f.Shape());repairs.append({'part':n,'valid_after':core[n].isValid(),'volume_change_mm3':core[n].Volume()-before.Volume()})
dump(OUT/'evidence/LOCAL_REPAIR_SHAPEFIX.json',repairs)
assert len(core)==630
for n in list(cond)+['W1_DRAIN_LINE','W2_DRAIN_LINE','PLATE_TAB_0_1','PLATE_TAB_1_1']:assert core[n].isValid(),n
dump(OUT/'ROUTES.json',routes)
delta={n:core[n] for n in ch['replaced']+ch['added']}
new={n:core[n] for n in ch['added']};mc=[]
for n in ch['replaced']:
    reference=core[n]
    if n.endswith('D35_END_PIPE'):
        w=n[:2];x=162.65 if w=='W1' else 52.65
        reference=base[n].cut(cyl((x-24,726.85,1100),(-1,0,0),3,6),cyl((304,655.275 if w=='W1' else 505.275,1342),(1,0,0),3,6)).clean()
    diff=reference.cut(base[n],tol=1e-5);vol=diff.Volume()
    mc.append({'part':n,'added_mm3':vol,'removed_mm3':base[n].cut(reference,tol=1e-5).Volume(),'STEP_comparison_fuzzy_tolerance_mm':1e-5})
    if vol>.001:new[n+'_NEW_MATERIAL']=diff
dump(OUT/'evidence/MATERIAL_CHANGE.json',mc)
all_delta={k+'__'+n:s.moved(loc(p['translation'])) for k,p in PLACEMENTS.items() for n,s in delta.items()}
all_new={k+'__'+n:s.moved(loc(p['translation'])) for k,p in PLACEMENTS.items() for n,s in new.items()}
results=[save(core,'H02_SINGLE_CORE'),save(all_delta,'H02_FOUR_CORE_DELTA'),save(all_new,'H02_NEW_MATERIAL')]
build=json.loads((OUT/'evidence/BUILD.json').read_text());updated={r['file']:r for r in results}
build['exports']=[updated.get(r['file'],r) for r in build['exports']]
build['single_core_parts']=len(core);build['local_repair']='Drain lane -664, auxiliary condensate link X-421, UBEND gutter starts X-428 on unchanged slope plane'
dump(OUT/'evidence/BUILD.json',build)
print('LOCAL REPAIR COMPLETE',flush=True)
