from common import *
from check import screen
def main():
    s=read(OUT/'H02_EIGHT_FIRST_SPOOLS.step');v=read(OUT/'H02_FIRST_SPOOL_SERVICE.step')
    hx=read(OUT/'H02_SINGLE_CORE.step') if (OUT/'H02_SINGLE_CORE.step').exists() else read(H01/'H01_SINGLE_CORE.step')
    cores={k+'__'+n:t.moved(loc(p['translation'])) for k,p in PLACEMENTS.items() for n,t in hx.items() if not n.startswith(('FIN_','C0','C1','C2','C3'))}
    result={'input_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [OUT/'H02_SINGLE_CORE.step',OUT/'H02_EIGHT_FIRST_SPOOLS.step',OUT/'H02_FIRST_SPOOL_SERVICE.step']},'core_scope':'all non-fin and non-circuit parts (spools are far outside fin/circuit bounding box)','states':{}}
    result['internal']=screen(s,s,lambda n,m:m<=n)
    for state in ('S1','S2'):
        host={r['name']:cq.Shape.importBrep(str(WORK/state/r['file'])) for r in json.loads((WORK/state/'index.json').read_text())}
        def thread(n,m):return n.endswith('FIXED_HX_TAIL') and 'VIEGA' in m and n[:3]==m[0]+('_L' if '_LOWER' in m else '_U') and n[4:6]==m.split('__')[-1][:2]
        result['states'][state]={'host_material':screen(s,host),'core_material':screen(s,cores,thread)}
        def exclude(n,m):
            tag=n.split('__')[0]
            if m.startswith(tag+'__'):
                if any(x in n for x in ['LIFT','SHIFT','RETRACT','SIDE_EXIT']):return any(x in m for x in ['BODY','SLIDE','RETAINER','BOLT','NUT','EPDM'])
                return True # own joint mating/contact region, not neighbouring parts
            # Gripping the corresponding OEM wrench land is intentional.
            if 'VIEGA' in m and tag[:3]==m[0]+('_L' if '_LOWER' in m else '_U') and tag[4:6]==m.split('__')[-1][:2]:return True
            return False
        result['states'][state]['service']=screen(v,{**host,**cores,**s},exclude)
        print(state,{k:len(a['hits']) for k,a in result['states'][state].items()},flush=True)
        dump(OUT/'evidence/SPOOL_CHECKS.json',result)
    result['counterhold_gaps_mm']={}
    for tag in sorted({n.split('__')[0] for n in s}):
        a=cq.Compound.makeCompound([t for n,t in v.items() if n.startswith(tag+'__SW46')]);b=cq.Compound.makeCompound([t for n,t in v.items() if n.startswith(tag+'__SW50')])
        result['counterhold_gaps_mm'][tag]=a.distance(b)
    dump(OUT/'evidence/SPOOL_CHECKS.json',result)
if __name__=='__main__':main()
