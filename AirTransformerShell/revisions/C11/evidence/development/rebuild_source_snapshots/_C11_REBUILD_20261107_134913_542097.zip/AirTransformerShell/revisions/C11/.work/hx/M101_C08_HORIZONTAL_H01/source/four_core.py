from pathlib import Path
import cadquery as cq,json,csv,sys
from itertools import combinations
from OCP.STEPCAFControl import STEPCAFControl_Reader,STEPCAFControl_Writer
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString as S
from OCP.XCAFDoc import XCAFDoc_DocumentTool
from OCP.TDF import TDF_LabelSequence
from OCP.TDataStd import TDataStd_Name
from OCP.gp import gp_Trsf
from OCP.TopLoc import TopLoc_Location
from OCP.STEPControl import STEPControl_AsIs
from OCP.IFSelect import IFSelect_RetDone
from build import OUT as here, REF
from step_io import leaves
source=here/'H01_SINGLE_CORE.step'
poses=json.loads((REF/'PLACEMENTS.json').read_text())['instances']
doc=TDocStd_Document(S('fit'));r=STEPCAFControl_Reader();r.SetNameMode(True)
assert r.ReadFile(str(source))==IFSelect_RetDone and r.Transfer(doc)
tool=XCAFDoc_DocumentTool.ShapeTool_s(doc.Main());seq=TDF_LabelSequence();tool.GetFreeShapes(seq)
assert seq.Length()==1
product=seq.Value(1);root=tool.NewShape();TDataStd_Name.Set_s(root,S('FOUR_HORIZONTAL_HX'))
for k,p in poses.items():
    x,y,z=p['translation'];t=gp_Trsf();t.SetValues(0,0,-1,x,0,-1,0,y,-1,0,0,z)
    occ=tool.AddComponent(root,product,TopLoc_Location(t));TDataStd_Name.Set_s(occ,S(k))
tool.UpdateAssemblies();w=STEPCAFControl_Writer();w.SetNameMode(True);assert w.Transfer(root,STEPControl_AsIs)
out=here/'H01_FOUR_HX_INSTALLED.step';assert w.Write(str(out))==IFSelect_RetDone
from collections import Counter
counts=Counter(next(k for k in poses if k in n.split('/')) for n,s in leaves(out))
assert list(counts.values())==[551]*4,counts
print('Shared STEP',counts,out.stat().st_size,flush=True)
