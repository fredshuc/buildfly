from common import *
digest=hashlib.sha256((OUT/'H02_SINGLE_CORE.step').read_bytes()).hexdigest();folder=WORK/'step_cache'/digest
idx=json.loads((folder/'index.json').read_text());core={r['name']:cq.Shape.importBrep(str(folder/r['file'])) for r in idx if r['name'] in ('W1_D35_END_PIPE','W2_D35_END_PIPE')}
base=read(H01/'H01_SINGLE_CORE.step');rows=[]
for w,x in [('W1',162.65),('W2',52.65)]:
    name=w+'_D35_END_PIPE';s=core[name];b=base[name]
    e=b.cut(cyl((x-24,726.85,1100),(-1,0,0),3,6),cyl((304,655.275 if w=='W1' else 505.275,1342),(1,0,0),3,6)).clean()
    row={'part':name,'core':{'vol':s.Volume(),'bounds':bounds(s),'center':s.Center().toTuple(),'faces':len(s.Faces())},'base':{'vol':b.Volume(),'bounds':bounds(b),'center':b.Center().toTuple(),'faces':len(b.Faces())},'expected':{'vol':e.Volume(),'bounds':bounds(e),'center':e.Center().toTuple(),'faces':len(e.Faces())}}
    print(row,flush=True)
    row['expected_minus_base']=e.cut(b).Volume();row['delivered_minus_expected']=s.cut(e,tol=1e-5).Volume();row['expected_minus_delivered']=e.cut(s,tol=1e-5).Volume();row['max_vertex_distance_to_expected_mm']=max(e.distance(v) for v in s.Vertices());row['max_vertex_distance_to_delivered_mm']=max(s.distance(v) for v in e.Vertices())
    rows.append(row);dump(OUT/'evidence/END_PIPE_ROUNDTRIP_AUDIT.json',rows);print(row,flush=True)
