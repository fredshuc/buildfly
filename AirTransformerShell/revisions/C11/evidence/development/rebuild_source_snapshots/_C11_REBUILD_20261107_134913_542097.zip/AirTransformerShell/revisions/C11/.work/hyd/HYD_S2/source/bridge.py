"""Build H01 HYD-S2 four-core reversible series bridge.
python bridge.py S1_WATER_DIR H01_DIR OUTPUT. Coordinates mm."""
import math,sys,csv,json,warnings
from pathlib import Path
from cad_io import cq,named,bb,overlaps
from OCP.BRepBndLib import BRepBndLib
from OCP.Bnd import Bnd_Box
warnings.filterwarnings('ignore',category=FutureWarning)
src,hx,out=map(Path,sys.argv[1:4]);v=cq.Vector
def box(x,y,z,a,b,c):return cq.Solid.makeBox(a,b,c,v(x,y,z))
def cyl(p,q,r):a=v(*p);e=v(*q)-a;return cq.Solid.makeCylinder(r,e.Length,a,e.normalized())
def hollow(p,q,od,id):return cyl(p,q,od/2).cut(cyl(p,q,id/2))
def bbox(s):b=Bnd_Box();BRepBndLib.Add_s(s.wrapped,b,False);return b.Get()
def screen(g,h,same=False):
 bs={k:bbox(s) for k,s in h.items()};hits=[]
 for n,s in g.items():
  a=bbox(s)
  for k,t in h.items():
   if same and k<=n:continue
   if overlaps(a,bs[k]):
    vol=s.intersect(t).Volume()
    if vol>.001:hits.append([n,k,round(vol,5)])
 return hits
def route(pts,R=36):
 pts=[v(*p) for p in pts];start=pts[0];edges=[]
 for a,b,c in zip(pts,pts[1:],pts[2:]):
  u=(b-a).normalized();w=(c-b).normalized();assert abs(u.dot(w))<1e-6
  p=b-u*R;q=b+w*R;center=p+w*R
  assert (p-start).dot(u)>0,('no room',p,start)
  edges+=[cq.Edge.makeLine(start,p),cq.Edge.makeThreePointArc(p,center+(u-w)*(R/math.sqrt(2)),q)];start=q
 assert (pts[-1]-start).dot((pts[-1]-pts[-2]).normalized())>0
 edges.append(cq.Edge.makeLine(start,pts[-1]));wire=cq.Wire.assembleEdges(edges)
 s=cq.Workplane(cq.Plane(origin=pts[0],normal=(pts[1]-pts[0]).normalized())).circle(16.85).circle(13.65).sweep(wire).val()
 assert s.isValid() and len(s.Solids())==1
 return s,wire.Length()
def csvw(name,ls):
 with (out/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=ls[0]);w.writeheader();w.writerows(ls)
def export(g,n):
 a=cq.Assembly(name=n)
 for k,s in g.items():a.add(s,name=k)
 a.save(str(out/(n+'.step')));t=cq.importers.importStep(str(out/(n+'.step'))).val()
 assert t.isValid() and len(t.Solids())==sum(len(s.Solids()) for s in g.values())
rack=named(src/'H01_HYD_RACK.step');svc=named(src/'H01_HYD_SERVICE.step')
drop={b+'_'+k for b in 'AB' for k in ('LOW_W2_FS','FS_Q','Q_UP_W1')}|{k+'_'+b for k in ['FS','Q'] for b in 'AB'}
assert drop<=rack.keys()
oldpairs={n:s for n,s in rack.items() if n in drop};ret={n:s for n,s in rack.items() if n not in drop}
svc={k:s for k,s in svc.items() if not any(k==p+'_'+b+'_REMOVE_TOOL' for p in ('FS','Q') for b in 'AB')}
new={};tools={};nom=[];datum=[];assembly_paths={};oldhits=screen(oldpairs,oldpairs,True)
for b,y0 in [('A',-720),('B',145)]:
 yW=y0+150;yF=yW+155;zF=644.35;yQ=y0;zQ=750.;x=-930;xq=-824
 # Positive cold flow: FS +Y, Q -Y. Clock the FS actuator about its horizontal process axis, above horizontal.
 F1=yF-44.35;F2=yF+44.35;Q1=yQ+55;Q2=yQ-55
 def clk(s):return s.rotate((x,yF,zF),(x,yF+1,zF),0)
 fsbody=hollow((x,F1,zF),(x,F2,zF),55,25)
 neck=cyl((x,yF+.55,zF+20),(x,yF+.55,zF+54),18)
 # Extended housing bounds cover asymmetry about the stem in Valworx sectional/dimension drawing.
 head=box(x-55,yF-58,zF+53.5,110,193,171)
 new['FS_'+b]=clk(fsbody.fuse(neck,head).clean())
 body=box(xq-24,Q2,zQ-24,73,110,48).cut(cyl((xq,Q2-1,zQ),(xq,Q1+1,zQ),12.5))
 def clockQ(o):return o.rotate((xq,yQ,zQ),(xq,yQ+1,zQ),-140)
 new['Q_'+b]=clockQ(body)
 for part,ys,axis,cz in [('FS',[F1,F2],1,zF),('Q',[Q1,Q2],-1,zQ)]:
  for j,y in enumerate(ys):
   xx=x if part=='FS' else xq
   sign=(-1 if j==0 else 1)*axis
   # This is a bounded installed stack; not a vendor thread or pressure part.
   end=y+sign*50
   new[b+'_'+part+'_STACK_'+str(j+1)]=hollow((xx,y,cz),(xx,end,cz),52,25)
   tools[b+'_'+part+'_COUNTERHOLD_'+str(j+1)]=hollow((xx,y+sign*4,cz),(xx,y+sign*46,cz),82,52)
   datum.append(dict(part=part+'_'+b,end=j+1,center=[xx,y,cz],outward_Y=sign,stack_pipe_end=[xx,end,cz],budget_mm=50))
 # Gentle mandrel bends CLR36; actual tangent lengths include fitting and elbow envelopes.
 pad=315;ysouth=y0-pad;ynorth=y0+470
 routes={'LOW_W2_FS':[(-865,yW,560),(x,yW,560),(x,yW,zF),(x,F1-50,zF)],
 'FS_Q':[(x,F2+50,zF),(x,ynorth,zF),(x,ynorth,zQ),(xq,ynorth,zQ),(xq,Q1+50,zQ)],
 'Q_UP_W1':[(xq,Q2-50,zQ),(xq,ysouth,zQ),(x,ysouth,zQ),(x,ysouth,895),(x,y0,895),(-865,y0,895)]}
 for k,pts in routes.items():
  shape,L=route(pts);new[b+'_'+k]=shape;nom.append(dict(bed=b,segment=k,ID_mm=27.3,CLR_mm=36,pipe_mm=round(L,6),pipe_L=round(L*math.pi*13.65**2/1e6,6),elbows=len(pts)-2,points=pts))
 # Sweeps of pressure components only: assumes adjacent unioned spools separated and physically removed first.
 # +X radial lift of Q, FS cover access to the clocked stem. Acceptance report distinguishes access from full machine extraction.
 tools[b+'_Q_CONNECTOR_ACCESS']=clockQ(box(xq+49,y0-25,zQ-24,150,50,48))
 tools[b+'_FS_TOP_ACCESS']=clk(box(x-45,yF-70,zF+224.5,90,110,85))
 assembly_paths[b]=dict(FS_center=[x,yF,zF],Q_center=[xq,yQ,zQ],Q_face_to_tangent_mm=[470-55-36,pad-55-36],Q_clear_after_stack_mm=[470-55-36-50,pad-55-36-50],FS_inlet_face_to_tangent_mm=155-44.35-36,FS_exit_face_to_tangent_mm=470-305-44.35-36)
csvw('bridge_routes.csv',nom);csvw('ports.csv',datum)
sp=named(hx/'H01_EIGHT_FIRST_SPOOLS.step');both={**ret,**new}
groups={'new_new':screen(new,new,True),'new_retained':screen(new,ret),'new_H01_spools':screen(new,sp),'new_existing_tools':screen(new,svc),'new_tools_rack':screen(tools,both),'new_tools_H01_spools':screen(tools,sp),'new_tools_H01_stowed_boots':screen(tools,{k:v for k,v in svc.items() if 'WET_BAY_COMMON_BOOT' in k or ('COVER' in k and 'RELEASE' not in k)})}
report=dict(historical_pairs=oldhits,checks=groups,details=assembly_paths,counts=[len(ret),len(new),len(tools),len(svc)])
(out/'local_check.json').write_text(json.dumps(report,indent=2));print({k:v[:8] for k,v in groups.items()},flush=True)
if any(groups.values()):sys.exit(2)
export(both,'S2_RACK');export({**svc,**tools},'S2_SERVICE');export({**new,**sp},'S2_BRIDGES_AND_SPOOLS')
