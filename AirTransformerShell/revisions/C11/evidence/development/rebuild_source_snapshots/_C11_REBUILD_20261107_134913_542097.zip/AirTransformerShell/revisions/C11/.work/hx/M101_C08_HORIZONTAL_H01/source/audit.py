import csv,json,math,hashlib
from build import OUT,ROOT,P0,cq,V
from cache_hosts import CACHE
from check import read,aabb_gap
from step_io import bounds

def nearest(a, solids):
    a=[(n,s,bounds(s)) for n,s in a.items()]
    pairs=sorted((aabb_gap(b,c),i,j) for i,(n,s,b) in enumerate(a) for j,(m,t,c) in enumerate(solids))
    best=(float('inf'),'','')
    for lo,i,j in pairs:
        if lo>best[0]+1e-6:break
        n,s,_=a[i]; m,t,_=solids[j]
        best=min(best,(s.distance(t),n,m))
    return [round(best[0],5),*best[1:]]
def signed_face(s,x,y,z,sign):
    return any(abs(bounds(f)[0]-x)<.001 and abs(bounds(f)[3]-x)<.001 and (f.Center()-V(x,y,z)).Length<.001 and sign*f.normalAt().x>.99999 for f in s.Faces())
def main():
    form=list(csv.DictReader((OUT/'EIGHT_PORTS_AND_SPOOLS.csv').open()))
    parts=read(OUT/'H01_EIGHT_FIRST_SPOOLS.step'); ends=read(OUT/'H01_EIGHT_INSTALLED_ENDS.step'); tools=read(OUT/'H01_TOOL_AND_REMOVAL.step')
    core=read(OUT/'H01_SINGLE_CORE.step'); pos=json.loads((OUT/'PLACEMENTS.json').read_text())
    ob=json.loads((CACHE/'obstacles.json').read_text())
    post=[(r['name'],cq.Shape.importBrep(str(CACHE/r['file'])),r['b']) for r in ob if r['group']=='P0_HOST' and max(abs(x-y) for x,y in zip(r['b'],[-640,-845,122,-560,-805,1484]))<.001]
    assert len(post)==1
    result={}
    for r in form:
        tag=r['tag'];bed,st,w=tag.split('_');x,y,z=json.loads(r['HX_face']);end_xyz=json.loads(r['spool_rack_face'])
        assert signed_face(ends[tag+'__'+w+'_VIEGA138875_OEM_LAYOUT_ONLY'],x,y,z,-1)
        assert signed_face(parts[tag+'__FIXED_HX_TAIL'],x,y,z,1)
        assert signed_face(parts[tag+'__FIXED_RACK_TAIL'],*end_xyz,-1)
        if bed=='A' and w=='W1':
            result[tag+'_C08_original_post_physical']=nearest({n:s for n,s in (parts|ends).items() if n.startswith(tag)},post)
            result[tag+'_C08_original_post_service']=nearest({n:s for n,s in tools.items() if n.startswith(tag)},post)
        if st=='L':continue
        t=pos[bed+'_LOWER']['translation']; loc=cq.Location(V(*t),V(1,0,-1),180)
        solids=[]
        for n,s in core.items():
            b=bounds(s)
            solids.append((n,s.moved(loc),[t[0]-b[5],t[1]-b[4],t[2]-b[3],t[0]-b[2],t[1]-b[1],t[2]-b[0]]))
        result[tag+'_installed_spool_to_complete_lower']=nearest({n:s for n,s in parts.items() if n.startswith(tag)},solids)
        result[tag+'_middle_withdrawal_to_complete_lower']=nearest({n:s for n,s in tools.items() if n.startswith(tag) and any(k in n for k in ('LIFT_','SHIFT_','RETRACT_','SIDE_EXIT_'))},solids)
    checks=json.loads((OUT/'CHECKS.json').read_text())
    assert not any(checks[n] for n in ('material_hits','service_hits','concurrent_wrap_hits')), 'unresolved candidate overlap'
    assert len(checks['original_host_hits'])>0 and len(checks['untrimmed_P0_hits'])>0
    assert len(core)==551 and len(parts)==72
    json.dump(dict(status='PASS conditional on listed host cuts, upper seat relief and P0 rack trimming',exported_end_faces_checked=24,minimum_distances_mm=result),open(OUT/'READBACK_AND_DISTANCES.json','w'),indent=2)
    print(result)
if __name__=='__main__':main()
