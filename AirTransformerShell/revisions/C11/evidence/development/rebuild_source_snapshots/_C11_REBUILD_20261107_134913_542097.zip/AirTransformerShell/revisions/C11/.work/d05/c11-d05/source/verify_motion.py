"""Full rigid-member motion, adaptive distance bounds, and first contact search.

For a rotation interval, distance is R-Lipschitz in angle. The nearest sampled
pose is at most span/4 away when both endpoints and midpoint are evaluated.
Only explicit functional mates and the two intended stop contacts are excluded.
"""
from common import *
from changes import build_parts
from motion import witness,blade_sweep,hull_sweep,aperture_results
from scipy.optimize import minimize_scalar

def soft_mate(a,b,tag):
 if a==f'DAMPER_ROOT_SLEEVE_{tag}_0_O' and b==f'DAMPER_ROOT_LIP_{tag}_O':return True
 if a==f'DAMPER_SHAFT_{tag}_0_O' and b in [f'DAMPER_ROOT_END_SEAL_{tag}_{e}_O' for e in ('IN','OUT')]:return True
 if a==f'DAMPER_BLADE_{tag}_0_O' and b in [f'DAMPER_SEAL_{tag}_{e}_O' for e in ('DEEP','SLOPED')]:return True
 return False

def mate(a,b,tag):
 if soft_mate(a,b,tag):return 'registered soft sealing interface'
 if a==f'D05_STOP_ARM_{tag}' and b in [f'D05_STOP_PIN_{tag}_{i}' for i in (0,1)]:return 'intended arm-flat / stop-pin contact, independently checked'
 if a==f'DAMPER_SHAFT_{tag}_0_O' and b in [f'D03_INNER_BEARING_INTERFACE_{tag}',f'D03_OUTER_BEARING_INTERFACE_{tag}',
      f'D03_SEAL_BACKING_{tag}',f'D05_FLOATING_3015DU_{tag}']:
  return 'shaft bearing journal fit'
 return None

def run():
 p,c=build_parts();idx=json.loads((ROOT/'.work/S1/index.json').read_text(encoding='utf-8'))['parts']
 stat=[(n,bbox(s),s) for n,s in p.items() if not moving(n)]
 stat += [(r['path'],r['bbox'],r) for r in idx if r['group']!='DAMPERS']
 loaded={};report={};envelopes={};sample_cache={}
 for bed in 'AB':
  for level in ('LOWER','UPPER'):
   tag=f'{bed}_{level}';x,z=axis(tag);rows=[];exclusions=[];hits=[];first={};whole=[]
   for n,s in p.items():
    if tag not in n or not moving(n):continue
    b=bbox(s);R=max(math.hypot(xx-x,zz-z) for xx in (b[0],b[3]) for zz in (b[2],b[5]))
    def at(a):
     key=(n,round(a,10))
     if key not in sample_cache:sample_cache[key]=rotate(s,tag,a)
     return sample_cache[key]
    # Coarse bbox expanded by a rigorous half-step displacement bound.
    poses=[bbox(at(THETA*i/16)) for i in range(17)];pad=R*math.radians(THETA/32)
    bounds=[min(q[i] for q in poses)-(pad if i!=1 else 0) for i in range(3)]+[
            max(q[i+3] for q in poses)+(pad if i!=1 else 0) for i in range(3)]
    whole.append(bounds)
    # Rotation about Y cannot penetrate across disjoint Y interiors. Exact
    # end-face adjacencies (bearing/shaft output and root seal ends) stay
    # adjacencies through the complete stroke and are not radial collisions.
    candidates=[(nn,bb,t) for nn,bb,t in stat if gap(bounds,bb)<.01 and min(b[4],bb[4])-max(b[1],bb[1])>1e-5]
    for nn,bb,t in candidates:
     reason=mate(n,nn,tag)
     if reason:exclusions.append([n,nn,reason]);continue
     if isinstance(t,dict):
      if nn not in loaded:loaded[nn]=cq.Shape.importBrep(str(ROOT/'.work/S1'/t['file']))
      target=loaded[nn]
     else:target=t
     distances={}
     def dist(a):
      a=round(a,10)
      if a not in distances:distances[a]=at(a).distance(target)
      return distances[a]
     def certify(a,b,depth=0):
      m=(a+b)/2;ds=[dist(t) for t in (a,m,b)]
      lower=min(ds)-R*math.radians(b-a)/4
      if lower>1e-5:return lower
      if min(ds)<1e-7:
       # Distance zero also includes intentional face adjacency. A nonmate
       # contact is reported, never silently converted to a whitelist.
       return -1
      if depth>=16:return -2
      l=certify(a,m,depth+1)
      return l if l<0 else min(l,certify(m,b,depth+1))
     bound=certify(0,THETA)
     if bound<0:hits.append({'moving':n,'fixed':nn,'bound_status':bound,'samples':sorted(distances.items())})
     best=min(distances,key=distances.get)
     rows.append({'moving':n,'fixed':nn,'continuous_clearance_lower_bound_mm':bound,
                  'sample_min_mm':distances[best],'sample_angle_deg':best,'poses':len(distances)})
     # First undesigned contact in each outward direction, excluding ONLY
     # the explicit mates above. Scan 0.05 degrees, then bisect first contact.
     rigid=not (nn.startswith(('DAMPER_SEAL_','DAMPER_ROOT_LIP_','DAMPER_ROOT_END_SEAL_',
                                'DAMPER_STATIC_GASKET_')) or nn.endswith('_WET_BOOT'))
     for mode,origin,sign in ([('P',0,-1),('R',THETA,1)] if rigid else []):
      if dist(origin)<1e-7:continue
      stop=min(1.5,first.get(mode,{}).get('travel_deg',1.5)+.05)
      lo=0.;found=None
      for j in range(1,int(math.ceil(stop/.05))+1):
       hi=min(j*.05,stop)
       # Distance Lipschitz bound excludes most far-away pairs cheaply.
       if dist(origin)>R*math.radians(hi)+1e-7:lo=hi;continue
       if dist(origin+sign*hi)<1e-7:
        for _ in range(18):
         mid=(lo+hi)/2
         if dist(origin+sign*mid)<1e-7:hi=mid
         else:lo=mid
        found=hi;break
       lo=hi
      if found is not None and found<first.get(mode,{}).get('travel_deg',999):
       first[mode]={'travel_deg':found,'angle_deg':origin+sign*found,'moving':n,'fixed':nn,
                    'witness':witness(at(origin+sign*found),target),'bisection_deg':.05/2**18}
    print(tag,n,'candidates',len(candidates),'bad',[(h['moving'],h['fixed']) for h in hits],flush=True)
    # Planar blade and stiffeners have exact polygonal prisms; other exported
    # references are conservative cylinders / boxes, marked separately.
    if n.startswith('DAMPER_BLADE') and n.endswith('_0_O'):
     envelopes[n+'_CONTINUOUS']=blade_sweep(s,tag)
    elif n.startswith('DAMPER_BLADE') and n.endswith(('_1_O','_2_O','_4_O')):
     envelopes[n+'_CONTINUOUS']=hull_sweep(s,tag)
    else:
     envelopes[n+'_BOUND']=box(*bounds)
   # Whole-stroke analytical certificate is in safety_audit.py: in arm-local
   # coordinates P pin surface x>=13, R surface x<=-13, outside the +/-13 tongue.
   intended=[]
   for i,angle in ((0,0),(1,THETA)):
    arm=p[f'D05_STOP_ARM_{tag}'];pin=p[f'D05_STOP_PIN_{tag}_{i}']
    intended.append({'pin':i,'angle':angle,'distance':rotate(arm,tag,angle).distance(pin),
      'penetration':rotate(arm,tag,angle).intersect(pin).Volume()})
   report[tag]={'pairs':rows,'excluded_exact_mates':exclusions,'unexpected_contacts':hits,
               'first_undesigned':first,'coverage':aperture_results(p,tag),'intended_stops':intended,
               'rotor_all_phase_bbox':[min(b[i] for b in whole) for i in range(3)]+[max(b[i+3] for b in whole) for i in range(3)]}
   dump(ROOT/'evidence/full_motion.json',report);print('VALVE',tag,'FIRST',first,'BAD',len(hits),flush=True)
 async_pairs=[]
 from itertools import combinations
 for a,b in combinations(report,2):
  async_pairs.append({'a':a,'b':b,'bbox_separation_mm':gap(report[a]['rotor_all_phase_bbox'],report[b]['rotor_all_phase_bbox'])})
 dump(ROOT/'evidence/asynchronous.json',async_pairs)
 from export import save_small
 dump(ROOT/'evidence/motion_export.json',save_small(ROOT/'cad/C11_DAMPERS_CONTINUOUS_AND_ASYNC.step',envelopes))

if __name__=='__main__':run()
