"""D03 service geometry, vendored unchanged to make this package reproducible.
Original envelopes.py SHA256: f1ace2bceb1f44d07d3fdd40b362f004b2439160c9bee35ca03ae4bdb8d72986
Only primitives are aliased to the local common module; services() is unchanged.
"""
from common import *
from itertools import product
bb=bbox
ycyl=cy

def block(x0,x1,y0,y1,z0,z1):return box(x0,y0,z0,x1,y1,z1)
def zcyl(x,y,z0,z1,r):return cq.Solid.makeCylinder(r,z1-z0,(x,y,z0),(0,0,1))

def services(parts,bed,level):
    side=bed+"_"+level;sgn=-1 if bed=="A" else 1; lift=1 if level=="LOWER" else -1
    x,z=axis(level)
    housing=parts["D03_ACTUATOR_INTERFACE_"+side]
    a=bb(housing);far=a[1] if sgn<0 else a[4]
    near=a[4] if sgn<0 else a[1]
    # Withdraw housing and output spindle together. The translating cylinder
    # is conservative beyond the engaged shaft; retain actual tool bores.
    lo,hi=sorted((near,far+sgn*130))
    swept_body=ycyl(x,z,lo,hi,55)
    for dx,dz in product((-40,40),(-20,20)):
        swept_body=swept_body.cut(ycyl(x+dx,z+dz,lo-1,hi+1,3.5))
    # Only the spindle leaves the housing on the inboard side.
    lo,hi=sorted((near,near-sgn*10))
    nose=ycyl(x,z,lo,hi,12).cut(block(x+9,x+14,lo-1,hi+1,z-13,z+13))
    envelopes={"ACT_PULL_"+side:swept_body.fuse(nose).clean()}
    hood=parts["D03_FEEDBACK_HOOD_"+side]
    hb=bb(hood);za,zb=sorted((z+lift*51,z+lift*141))
    # The hood is open on its trailing edge. Its side walls and U-slot
    # occupy a subset of the original hood below the leading cap. Fill the
    # small mounting bores in the swept region to be conservative.
    crown=block(hb[0],hb[3],hb[1],hb[4],za,zb)
    full=hood.fuse(crown)
    for i,dx in enumerate((-22,22)):
        za,zb=sorted((z+lift*49,z+lift*51))
        full=full.fuse(zcyl(x+dx,sgn*835.5,za,zb,2.25))
    probe_boxes=[]
    for n,s in parts.items():
        if "_LIMIT_SENSOR_" not in n:continue
        b=bb(s)
        probe_boxes.append(block(b[0]-.16,b[3]+.16,b[1],b[4],min(b[2],b[2]+lift*90)-.16,max(b[5],b[5]+lift*90)+.16))
    envelopes["HOOD_PULL_"+side]=cq.Compound.makeCompound([full.clean(),*probe_boxes])
    for i,(dx,dz) in enumerate(product((-40,40),(-20,20))):
        # AF10 thin-wall socket OD16 on a straight extension, enters through
        # the reserved OD18 well. Test one tool at a time.
        lo,hi=sorted((near+sgn*5,far+sgn*65))
        envelopes[f"ACT_SOCKET_{side}_{i}"]=ycyl(x+dx,z+dz,lo,hi,8)
    for i,dx in enumerate((-22,22)):
        lo,hi=sorted((z+lift*54,z+lift*109))
        envelopes[f"HOOD_DRIVER_{side}_{i}"]=zcyl(x+dx,sgn*835.5,lo,hi,4)
    if level=="LOWER":
        for i,xx in enumerate((575.,645.)):
            envelopes[f"BASE_SOCKET_{side}_{i}"]=zcyl(xx,sgn*833.5,175,222,9)
    return envelopes
