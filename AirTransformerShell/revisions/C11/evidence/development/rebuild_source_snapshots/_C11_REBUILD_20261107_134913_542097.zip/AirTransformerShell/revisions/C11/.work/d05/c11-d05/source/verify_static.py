from common import *
from changes import build_parts
from itertools import combinations

def allowed(a,b):
 for tag in (f'{x}_{l}' for x in 'AB' for l in ('LOWER','UPPER')):
  if {a,b}=={f'DAMPER_ROOT_LIP_{tag}_O',f'DAMPER_ROOT_SLEEVE_{tag}_0_O'}:return True
  for end in ('IN','OUT'):
   if {a,b}=={f'DAMPER_ROOT_END_SEAL_{tag}_{end}_O',f'DAMPER_SHAFT_{tag}_0_O'}:return True
 return False

def run():
 p,c=build_parts();index=json.loads((ROOT/'.work/S1/index.json').read_text(encoding='utf-8'))['parts']
 external=[r for r in index if r['group']!='DAMPERS'];cache={};result={}
 for state in ('S1','S2'):
  posed={}
  for n,s in p.items():
   tag=next((f'{b}_{l}' for b in 'AB' for l in ('LOWER','UPPER') if f'{b}_{l}' in n),None)
   angle=THETA if tag and tag[0]==('B' if state=='S1' else 'A') else 0
   posed[n]=rotate(s,tag,angle) if tag and moving(n) else s
  boxes={n:bbox(s) for n,s in posed.items()};hits=[];soft=[];tested=0
  for (a,s),(b,t) in combinations(posed.items(),2):
   if not overlap(boxes[a],boxes[b]):continue
   v=s.intersect(t).Volume();tested+=1
   if v>.001:(soft if allowed(a,b) else hits).append([a,b,v])
  for a,s in posed.items():
   for r in external:
    if not overlap(boxes[a],r['bbox']):continue
    if r['path'] not in cache:cache[r['path']]=cq.Shape.importBrep(str(ROOT/'.work/S1'/r['file']))
    v=s.intersect(cache[r['path']]).Volume();tested+=1
    if v>.001:hits.append([a,r['path'],v])
  result[state]={'tested_bbox_candidates':tested,'unexpected_penetrations':hits,'exact_soft_pairs':soft}
  print(state,'hits',hits,'soft',len(soft),flush=True);dump(ROOT/'evidence/static_check.json',result)
 return result

if __name__=='__main__':run()
