# Reproduction

Python 3.12 + CadQuery 2.7.0 / numpy / matplotlib. Input roots are explicit in the source scripts. This is an engineering candidate, not a released fabrication package.

Place the repository root in `c11_repo/`, the original extracted HYD-S2 delta under sibling `c11_input/s2/HYD_S2/`, and the task ZIP in `c11_input/`. The baseline C10 installed STEP files and HX package are unchanged. `c11_work/rack.json` is the named S2_RACK volume/centroid/bounds inventory read by account_support.py; a copy is provided in evidence. Copy it to that path when replaying.

Run in order:

1. `source/build_support.py`
2. `source/verify_support.py S1`, then `source/verify_support.py S2` in a separate process (limits CAD document memory)
3. `source/account_support.py`
4. `source/thermal_check.py`
5. `source/protection.py`
6. `source/finalize.py`

Geometry checks are exact solid intersections after broad-phase AABBs, threshold 0.001 mm³. Source parts are named and transformations retained. The service reference contains keep-out bodies, not pressure parts. Do not add it to a material BOM.

Current limitations are explicit in README_CN.md. The frame/member calculations do not model welded-joint stiffness, nonlinear contact, preload or PIR creep. The nozzle-load table deliberately remains unresolved; no zeros are inferred from static non-intersection.
