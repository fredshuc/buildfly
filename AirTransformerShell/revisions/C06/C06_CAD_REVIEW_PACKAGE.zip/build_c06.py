"""Build the two-bed sheet-metal design and its interface checks (mm).
Inputs are the adjacent C04 editable sources. Run from any directory.
Use --out DIR to direct all outputs outside the source directory.
"""
import argparse
import csv
import json
import math
import sys
from pathlib import Path

import cadquery as cq

HERE = Path(__file__).resolve().parent
C04 = HERE.parent / "C04"
parser = argparse.ArgumentParser()
parser.add_argument("--out", type=Path, default=HERE)
args = parser.parse_args()
OUT = args.out.resolve()
OUT.mkdir(parents=True, exist_ok=True)
# C04 was delivered as an executable, without an importable build function.
# Its prototype and host are complete at this marker, before file writes.
source = (C04 / "build_c04.py").read_text(encoding="utf-8")
marker = "errors=check(installed)"
assert source.count(marker) == 1
sys.path.insert(0, str(C04))
D01=HERE.parents[2]/"dampers"/"c04-d01"
import design
design.CENTRES={"A":-434.4,"B":845.6}
sys.argv = [str(C04 / "build_c04.py")]
base = {"__file__": sys.argv[0]}
exec(compile(source.split(marker)[0], sys.argv[0], "exec"), base)
box, rhs, cyl = (base[n] for n in ("box", "rhs", "cylinder"))
centres, ports = base["CENTRES"], base["PORTS"]
front, rear = base["front"], base["rear"]
rows, categories, ports_log = {}, {}, []
fit = {}
def put(name, solid, category):
    assert name not in rows
    assert len(solid.Solids()) == 1 and solid.isValid(), name
    rows[name] = solid
    categories[name] = category

def zcyl(x,y,z,r,h):
    return cq.Solid.makeCylinder(r,h,cq.Vector(x,y,z))

def ring(x,cy,cz,w,h,iw,ih,t):
    return box(x,cy-w/2,cz-h/2,t,w,h).cut(box(x-1,cy-iw/2,cz-ih/2,t+2,iw,ih))

def orient(sh, x, cy, sign):
    if sign == -1:
        sh = sh.rotate((0,0,0),(0,0,1),180)
    return sh.translate((x,cy,0))

def rect_wire(x,cy,lo,w,h):
    return cq.Wire.makePolygon([cq.Vector(x,y,z) for y,z in
        [(cy-w/2,lo),(cy+w/2,lo),(cy+w/2,lo+h),(cy-w/2,lo+h)]],close=True)

def z_profile(x, yz, thickness):
    w=cq.Wire.makePolygon([cq.Vector(x,y,z) for y,z in yz],close=True)
    return cq.Solid.extrudeLinear(w,[],cq.Vector(thickness,0,0))

def transverse(x, y1, y2, z, dx=40, height=50):
    return rhs(x,y1,z,dx,y2-y1,height,1)

def top_flange(x,cy,lo,h,t):
    plate=ring(x,cy,lo+h/2,706,h+76,630,h,t)
    # Same grid as C04 and the R21 punched flanges.
    nx,ny=math.ceil(668/70),math.ceil((h+38)/70)
    points=[(cy-334+i*668/nx,z) for i in range(nx+1) for z in (lo-19,lo+h+19)]
    points += [(y,lo-19+(h+38)*i/ny) for y in (cy-334,cy+334) for i in range(1,ny)]
    return plate.cut(*[cyl(x-1,y,z,4.5,t+2) for y,z in points]),points

def tube_z(x,y,z,orad,irad,h):
    return zcyl(x,y,z,orad,h).cut(zcyl(x,y,z-1,irad,h+2))

def obb(s):
    b=s.BoundingBox()
    return [b.xmin,b.ymin,b.zmin,b.xmax,b.ymax,b.zmax]

def sloping_tray(x,y,z,dx,dy,fall):
    # Constant-thickness folded blank, positive fall in Y into a drilled low end.
    t=1.5
    pan=z_profile(x,[(y,z+fall),(y+dy,z),(y+dy,z+t),(y,z+fall+t)],dx)
    edge=68 if dx==162 else 22
    ox,oy=x+dx/2,y+dy-edge
    pan=pan.cut(zcyl(ox,oy,z-2,9,fall+6))
    for xo in (x,x+dx-t):
        pan=pan.fuse(z_profile(xo,[(y,z+fall+t),(y+dy,z+t),(y+dy,z+20),(y,z+fall+20)],t))
    for yy,zz in ((y,z+fall),(y+dy-t,z)):
        pan=pan.fuse(box(x,yy,zz+t,dx,t,18))
    # Trim top of nozzle to the underside of the sloping sheet.
    zz=z+fall*edge/dy
    stub=tube_z(ox,oy,z-27,11,9,fall+30)
    stop=z_profile(x-1,[(y-1,z+fall+fall/dy),(y+dy+1,z-fall/dy),(y+dy+1,z+fall+40),(y-1,z+fall+40)],dx+2)
    stub=stub.cut(stop)
    return pan,stub

# Original dividers, core locations, mounting beams and shell datums.
for n,(s,_) in base["layout"].items():
    if any(token in n for token in ("_RESERVE","WATER_GLAND","DRIVE_","FIN_VOLUME","HX_FRAME","SIDE_")):
        continue
    if n in ("BASE_SILL_800","ROOF_RAIL_820") or n.endswith(", 800)"):
        s=s.translate((0,440,0))
    if n.startswith("BASE_Y_CROSS_"):
        s=transverse(float(n.split("_")[-1]),-800,1240,52)
    if n in ("ROOF","FLOOR"):
        s=box(front-2,-852,2550 if n=="ROOF" else 102,rear-front+2,2144,2)
    if n in ("FRONT_SKIN","BACK_SKIN"):
        x=front-2 if n=="FRONT_SKIN" else rear-2
        s=box(x,-852,104,2,2144,2446)
        for cy in centres.values():
            if n=="FRONT_SKIN":
                s=s.cut(box(x-1,cy-360,142,5,720,984))
            else:
                for z,h in ports.values():
                    s=s.cut(box(x-1,cy-315,z,5,630,h))
    if n.endswith("_DISCHARGE_SLEEVE"):
        b=obb(s)
        s=s.cut(box(b[0]-1,b[1]-1,b[2]-1,40,b[4]-b[1]+2,b[5]-b[2]+2))
    if n=="FLOOR":
        cuts=[]
        for cy in centres.values():
            for x in (265-210,485+210):
                cuts.append(zcyl(x,cy+285,101,16,5))
        s=s.cut(*cuts)
    if n=="BACK_SKIN":
        vent=[]
        for cy in centres.values():
            for j in range(6):
                vent.append(box(rear-3,cy-105,1190+21*j,5,210,9))
        for z in (1230,1510,1840,2100):
            vent.append(cyl(rear-3,-733,z,55,5))
        s=s.cut(*vent)
    put(n,s,"host")
for tag,y in (("A",-852.),("B",1290.)):
    path=D01/"native"/("D01_D01_SIDE_"+str(y)+".brep")
    put(tag+"_SIDE_PANEL",cq.Shape.importBrep(str(path)),"host")
for x in (front, rear-52):
    put("BASE_END_"+str(x),transverse(x,-800,1240,52),"structure")
    put("ROOF_END_"+str(x),transverse(x,-800,1240,2510,40,40),"structure")
# Floor is sandwiched between these RHS cross members and the cassette seats.
for face,datum,sign in (("F",265,-1),("R",485,1)):
    for st in (116,327):
        xc=datum+sign*st
        put(face+"_BASE_CROSS_"+str(st),transverse(xc-20,-800,1240,52),"structure")
        put(face+"_MID_FOOT_"+str(st),box(xc-20,-35,0,40,70,52),"structure")

for bed,cy in centres.items():
    outer=-1 if bed=="A" else 1
    ty=cy-367.775
    # Use the L2-HX +55 tab geometry. Leave four complete 110 mm bores.
    strip=box(750,cy-375,2280,2,750,240).fuse(box(750,cy+375,2295,2,55,150))
    for oy in (726.85,576.85):
        strip=strip.cut(cyl(749,ty+oy,2370,55,5))
    put(bed+"_GLAND_RT1",strip.clean(),"water")
    # A common transverse roof member supports removable forks at the two HX
    # lifting-lug plates. The forks have 1 mm lateral clearance on both sides.
    if bed=="A":
        put("HX_TOP_CROSS",transverse(355,-846,1286,2470,40,40),"structure")
    for k,yl in enumerate((ty+23.35,ty+703.35)):
        for j,yp in enumerate((yl-5,yl+9)):
            put(bed+"_TOP_FORK_"+str((k,j)),box(365,yp,2254,20,4,216),"structure")
    # Removable side-panel diagonal connects opposite corner-post regions.
    ystrap=-858 if bed=="A" else 1292
    if bed=="A":
        points=[(front+10,1030),(rear-48,2475),(rear-48,2520),(front+10,1075)]
    else:
        points=[(front+10,2475),(rear-48,1030),(rear-48,1075),(front+10,2520)]
    put(bed+"_SIDE_BRACE",base["poly"](points,ystrap,6),"structure")
    # Braces connect the inside faces of each pair of risers to each other.
    y1,y2=ty+15+20,ty+655-20
    for x,flip in ((275,False),(435,True)):
        lo,hi=(150,1050) if not flip else (1050,150)
        put(bed+"_RISER_BRACE_"+str(x),z_profile(x+5,
            [(y1,lo),(y2,hi),(y2,hi+36),(y1,lo+36)],30),"structure")
    # M16 crush sleeves. Original 17 mm beam bores pass through both walls.
    for y in (ty+15,ty+655):
        for x in (317,437):
            put(bed+"_CRUSH_"+str((x,y)),tube_z(x,y,1103,12,8.5,44),"structure")
    # Pan sits in the clear space above the 1150 mm beam datum and below
    # the active fins. Two folded, removable brackets span the foot beams.
    tray,stub=sloping_tray(294,cy-306,1162,162,612,8)
    for j,xbar in enumerate((338,408)):
        put(bed+"_TRAY_BAR_"+str(j),rhs(xbar,ty+40,1139,18,590,10,1),"structure")
        # Sidewall hangers land on the bars, with their tops cut to pan fall.
        for k,yy in enumerate((cy-283,cy+209)):
            z1=1162+8*(cy+306-yy)/612
            z2=z1-8*12/612
            put(bed+"_PAN_PAD_"+str((j,k)),z_profile(xbar,
                [(yy,1149),(yy+12,1149),(yy+12,z2),(yy,z1)],18),"drain")
    put(bed+"_HX_TRAY",tray,"drain")
    put(bed+"_HX_TRAY_NOZZLE",stub,"drain")
    for face,datum,sgn in (("F",265,-1),("R",485,1)):
        prefix=bed+face+"_"
        def local(n,s,category):
            put(prefix+n,orient(s,datum,cy,sgn),category)
        side=outer*sgn
        for n,(s,_) in base["proto"].items():
            if n.startswith("RESERVE") or n=="SEAT_RETURN": continue
            if n=="BOTTOM":
                s=s.cut(zcyl(210,sgn*285,141,10,5))
                # Four brake-formed slopes discharge to a flush 20 mm bore.
                corners=[(base["inside"],-358),(base["outside"],-358),
                         (base["outside"],358),(base["inside"],358)]
                panels=[]
                for k,(ux,uy) in enumerate(corners):
                    vx,vy=corners[(k+1)%4]
                    wire=cq.Wire.makePolygon([cq.Vector(ux,uy,152),cq.Vector(vx,vy,152),
                        cq.Vector(210,sgn*285,144)],close=True)
                    panels.append(cq.Solid.extrudeLinear(wire,[],cq.Vector(0,0,1.5)))
                liner=panels[0].fuse(*panels[1:]).cut(zcyl(210,sgn*285,140,10,15))
                liner=liner.fuse(tube_z(210,sgn*285,144,11.5,10,0.55))
                local("SUMP_LINER",liner.clean(),"drain")
            if n.startswith("CHEEK_") and (("306"==n[6:] and side==1) or ("-307.5"==n[6:] and side==-1)):
                for i in range(8):
                    s=s.cut(box(10.5,-310,1204+i*125+0.3,4.5,620,124.4))
                for i in range(8):
                    z=1266.5+i*125
                    s=s.cut(cq.Solid.makeCylinder(1.7,8,cq.Vector(20.5,side*307.5-4,z),cq.Vector(0,1,0)))
            if n.startswith("BOX_CHEEK_"):
                # Take-off bores for the two damper chamber pressures, the throat,
                # and tracer sampling. Ports are on the outboard cheek only.
                if (side==1 and n.endswith("358")) or (side==-1 and n.endswith("-359.5")):
                    for u,z in ((340,365),(340,755),(245,1080),(305,945),(240,795),(315,795),(240,875),(315,875)):
                        cut=cq.Solid.makeCylinder(3,8,cq.Vector(u,side*358-4,z),cq.Vector(0,1,0))
                        s=s.cut(cut)
            local(n,s,"plates" if "BALANCE" in n else "air")
        # Carrier winds back along local +u on eight lead screws. The screws
        # are outside the gasket line and attach to cheek-mounted reaction lugs.
        g=ring(0,0,1704,650,1036,618,1004,4.2)
        local("GASKET_6_FREE",g,"gasket")
        movable=base["proto"]["SEAT_RETURN"][0].translate((4.2,0,0))
        for hand in (-1,1):
            for k,z in enumerate((1235,1547,1859,2173)):
                y=hand*337
                a=min(hand*325,hand*350)
                ear=box(4.2,a,z-10,5,25,20).cut(cyl(3,y,z,4.5,8))
                movable=movable.fuse(ear)
                # Tabs also touch the cheek along the 4 mm thickness.
                b=min(hand*307.5,hand*350)
                lug=box(24,b,z-10,4,42.5,20).cut(cyl(23,y,z,3.4,6))
                local("ADJ_LUG_"+str((hand,k)),lug,"seal")
                screw=cyl(2.2,y,z,6,2).fuse(cyl(4.2,y,z,3.35,23.8),cyl(9.2,y,z,6,2),cyl(28,y,z,6,5))
                local("ADJ_SCREW_"+str((hand,k)),screw.clean(),"seal")
        local("SLIDING_SEAL_CARRIER",movable.clean(),"seal")
        # Cover closes all eight band access slots. Individual plates slide
        # outward along Y after removal. Narrow cover stays between the seals.
        ycover=307.5 if side==1 else -310.5
        # EPDM is bonded to the keeper strip. A removable row of screws
        # sits beyond the slot at u20.5. Remove this strip for seal retraction.
        cover=box(9.4,ycover+side,1203,14,3,1002)
        gasket=box(9.4,307.5 if side==1 else -308.5,1203,14,1,1002)
        for i in range(8):
            z=1266.5+i*125
            hole=cq.Solid.makeCylinder(1.7,9,cq.Vector(20.5,side*307.5-5,z),cq.Vector(0,1,0))
            cover=cover.cut(hole)
            gasket=gasket.cut(hole)
        local("PLATE_ACCESS_GASKET",gasket,"access")
        local("PLATE_ACCESS_COVER",cover,"access")
        for st in (116,327):
            local("CASSETTE_BEARER_"+str(st),rhs(st-20,-349,104,40,698,38.5,1),"structure")
        # Two local anti-walk tabs restrain the bolted lower cassette edge
        # in X. Shear fasteners and weld sizing remain detail work.
        local("DRAIN_STUB",tube_z(210,sgn*285,74,12,10,68.5),"drain")
        # The D01 adapter and its studs belong to the damper package.
        # Each floor-mounted portal carries two crossheads. Ledges contact
        # the outer flange underside independently of the selector wall.
        xpost=-408 if face=="F" else 1156
        foot_z=0 if face=="F" else 104
        for k,y in enumerate((cy-380,cy+350)):
            foot=box(xpost-30,y-8,foot_z,60,46,6)
            for dx in (-21,21):
                foot=foot.cut(zcyl(xpost+dx,y+15,foot_z-1,4.5,8))
            put(prefix+"STAND_FOOT_"+str(k),foot,"stand")
            put(prefix+"STAND_LEG_"+str(k),rhs(xpost-15,y,foot_z+6,30,30,627-foot_z-6,2),"stand")
        for tag,(lo,h) in ports.items():
            rail_z=lo-38
            put(prefix+tag+"_SUPPORT_RAIL",transverse(xpost-15,cy-350,cy+350,rail_z-25,30,25),"stand")
            tip=-343 if face=="F" else 1090
            stop=xpost+15 if face=="F" else xpost-15
            for k,y in enumerate((cy-340,cy+320)):
                put(prefix+tag+"_SUPPORT_PAD_"+str(k),box(min(stop,tip),y,rail_z-16,abs(stop-tip),20,16),"stand")
put("REAR_STAND_BASE_CROSS",transverse(1136,-800,1240,52),"structure")
put("REAR_STAND_MID_FOOT",box(1136,170,0,40,70,52),"structure")

def make_assembly(selected,name):
    colors={"structure":(.28,.36,.43),"host":(.72,.75,.78),"stand":(.33,.40,.46),
        "air":(.31,.61,.65),"adapter":(.40,.64,.65),"drain":(.36,.56,.74),
        "gasket":(.15,.15,.16),"seal":(.72,.55,.29),"plates":(.73,.53,.26),
        "access":(.80,.66,.39),"water":(.40,.52,.75),"fastener":(.50,.54,.57)}
    asm=cq.Assembly(name=name)
    for n in selected:
        # XCAF label names must remain unique and are the inspection IDs.
        asm.add(rows[n],name=n,color=cq.Color(*colors[categories[n]]))
    return asm

def bounds_overlap(a,b):
    return all(min(a[k+3],b[k+3])-max(a[k],b[k])>1e-5 for k in range(3))

def audit_pairs():
    from itertools import combinations
    bounds={n:obb(sh) for n,sh in rows.items()}
    errors=[]
    for a,b in combinations(rows,2):
        if bounds_overlap(bounds[a],bounds[b]):
            volume=rows[a].intersect(rows[b]).Volume()
            if volume>0.001: errors.append([a,b,round(volume,4)])
    return errors

def main():
    errors=audit_pairs()
    (OUT/"clashes.json").write_text(json.dumps(errors,indent=2))
    print("clashes",len(errors),errors[:16],flush=True)
    if errors: raise ValueError("Resolve intersections before export")
    path=OUT/"C06_SHEET_METAL.step"
    make_assembly(rows,"C06_SHEET_METAL").save(str(path))
    imported=cq.importers.importStep(str(path)).val()
    count=len(imported.Solids())
    assert count==len(rows) and imported.isValid(),count
    report=dict(shell_solids=count,clashes_above_0p001_mm3=errors,
        envelope_mm=obb(imported),station_pitch_mm=1280,
        gasket_free_installed_mm=[6,4.2],nominal_compression_pct=30,
        bore_diameter_mm=110,insulation_OD_mm=85,
        bed_pitch_mm=1280,channels_each_face=8,
        parts_by_category={cat:sum(c==cat for c in categories.values()) for cat in sorted(set(categories.values()))})
    (OUT/"shell_checks.json").write_text(json.dumps(report,indent=2))
    print("STEP readback",count,flush=True)
if __name__=="__main__":
    main()