"""Fit D01, the M101 cores and a 1280 mm adaptation of the R1 water bay to C06.
Run beside build_c06.py after generating the shell STEP. Supply the M101 STEP
and the extracted hydronics/C04_HYD_R1 and dampers/c04-d01 directories.
"""
import argparse
import csv
import json
import sys
from pathlib import Path
import cadquery as cq
import numpy as np
from OCP.STEPCAFControl import STEPCAFControl_Reader
from OCP.TDocStd import TDocStd_Document
from OCP.XCAFDoc import XCAFDoc_DocumentTool
from OCP.TDF import TDF_LabelSequence,TDF_Label
from OCP.TDataStd import TDataStd_Name
from OCP.TCollection import TCollection_ExtendedString
from OCP.TopLoc import TopLoc_Location
from OCP.IFSelect import IFSelect_RetDone

parser=argparse.ArgumentParser()
parser.add_argument("hx",type=Path)
parser.add_argument("hyd",type=Path)
parser.add_argument("damper",type=Path)
args=parser.parse_args()
out=Path(__file__).resolve().parent
def leaves(path):
    doc=TDocStd_Document(TCollection_ExtendedString("read"))
    reader=STEPCAFControl_Reader()
    reader.SetNameMode(True)
    assert reader.ReadFile(str(path))==IFSelect_RetDone and reader.Transfer(doc)
    tree=XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
    def name(l):
        a=TDataStd_Name()
        return a.Get().ToExtString() if l.FindAttribute(TDataStd_Name.GetID_s(),a) else ""
    def walk(l,loc,path):
        if tree.IsReference_s(l):
            ref=TDF_Label()
            tree.GetReferredShape_s(l,ref)
            yield from walk(ref,loc*tree.GetLocation_s(l),path+[name(l)])
        elif tree.IsAssembly_s(l):
            seq=TDF_LabelSequence();tree.GetComponents_s(l,seq)
            for i in range(1,seq.Length()+1):
                yield from walk(seq.Value(i),loc,path+[name(l)])
        else:
            yield '/'.join(path+[name(l)]),cq.Shape.cast(tree.GetShape_s(l).Moved(loc))
    root=TDF_LabelSequence();tree.GetFreeShapes(root)
    for i in range(1,root.Length()+1):yield from walk(root.Value(i),TopLoc_Location(),[])

def bb(s):
    b=s.BoundingBox()
    return [b.xmin,b.ymin,b.zmin,b.xmax,b.ymax,b.zmax]
def screen(left,right,internal=False):
    rn=list(right); rb=np.array([bb(right[k]) for k in rn]);bad=[]
    for i,(n,s) in enumerate(left.items()):
        a=bb(s)
        mask=np.all(np.minimum(rb[:,3:],a[3:])-np.maximum(rb[:,:3],a[:3])>1e-5,axis=1)
        for j in np.flatnonzero(mask):
            if internal and j<=i:continue
            v=s.intersect(right[rn[j]]).Volume()
            if v>0.001:bad.append([n,rn[j],round(v,4)])
    return bad

# Reuse the owner routing logic. Each replacement is guarded so a new
# hydraulic baseline cannot silently receive the old placement changes.
text=(args.hyd/"build.py").read_text(encoding="utf-8").split("host={};removed=[];cuts=[]")[0]
for before,after in [
    ("'B':764.675","'B':1204.675"),("yB=yA+840","yB=yA+1280"),
    ("32,1600,34","32,2040,34"),("(-800,776)","(-800,1216)"),
    ("(-410,185,535)","(-410,185,535,975)"),("350,1580,18","350,2020,18"),("347,1577,19","347,2017,19")]:
    assert text.count(before)==1,before
    text=text.replace(before,after)
sys.argv=[__file__,str(out/"C06_SHEET_METAL.step"),str(args.hx),str(out)]
hyd=dict(__file__=str(args.hyd/"build.py"))
exec(compile(text,"C04_HYD_R1/geometry","exec"),hyd)
water=hyd["parts"];sweeps=hyd["sweeps"]
def export(group,name):
    a=cq.Assembly(name=name)
    for n,s in group.items():a.add(s,name=n)
    path=out/(name+".step");a.save(str(path))
    expected=sum(len(s.Solids()) for s in group.values())
    got=cq.importers.importStep(str(path)).val()
    assert len(got.Solids())==expected and got.isValid()
    return expected
water_count=export(water,"C06_WATER_FIT");export(sweeps,"C06_WATER_SERVICE")
with (out/"interfaces.csv").open("w",newline="") as f:
    w=csv.writer(f);w.writerow(["id","x_mm","y_mm","z_mm","direction","connection","function"]);w.writerows(hyd["points"])
shell=dict(leaves(out/"C06_SHEET_METAL.step"))
hx=cq.importers.importStep(str(args.hx)).val().Solids()
core={f"{bed}_{i:03}":s.translate((265,y,1150)) for bed,y in (("A",-802.175),("B",477.825)) for i,s in enumerate(hx)}
damp={n:s for n,s in leaves(args.damper/"cad/D01_EIGHT_DAMPERS_INSTALLED.step") if "/HOST/" not in n and not n.rsplit("/",1)[-1].startswith("HOST_")}
dservice=dict(leaves(args.damper/"cad/D01_SERVICE_ENVELOPES.step"))
assert len(damp)>6000 and len(shell)>200 and len(core)==1074
checks={}
report=dict(bed_pitch_mm=1280,water_solids=water_count,shell_leaves=len(shell),damper_leaves=len(damp),hx_solids=len(core),damper_service_leaves=len(dservice),checks=checks)
for name,l,r,internal in [
 ("water_internal",water,water,True),("water_shell",water,shell,False),("water_service_shell",sweeps,shell,False),
 ("water_service_water",sweeps,water,False),("HX_shell",core,shell,False),("water_HX",water,core,False),
 ("D01_shell",damp,shell,False),("D01_water",damp,water,False),("D01_water_service",damp,sweeps,False),
 ("D01_service_shell",dservice,shell,False),("D01_service_water",dservice,water,False)]:
    checks[name]=screen(l,r,internal)
    print(name,len(checks[name]),checks[name][:3],flush=True)
    (out/"integration_checks.json").write_text(json.dumps(report,indent=2))
