"""Measure C09 inlet/outlet sections and seam engagement on the exported hardware."""
from build_c09 import *
import csv

def limitz(shape,x,y):
    ray=cq.Edge.makeLine(cq.Vector(x,y,0),cq.Vector(x,y,1550))
    return sorted(v.Z for v in ray.intersect(shape).Vertices())

def run():
    new={n:s for n,(_,s) in entries(CAD/"C09_SHELL.step").items()}
    base={n:s for n,(_,s) in entries(BASE).items()}
    sections=[]
    for bed,y in (("A",-425),("B",440)):
        for mode,start0,start1,end,roof,floor in [
            ("Pout",521,631,746,"AIR_PROCESS_OUT_CHANNEL","AIR_PROCESS_OUT_FLOOR"),
            ("Rin",532,642,748,"AIR_PORT_DIVIDER","AIR_REGEN_FLOOR")]:
            for i in range(9):
                heights=[]
                for group,start in ((base,start0),(new,start1)):
                    x=start+(end-start)*i/8
                    top=limitz(group[roof+"_"+bed+"_O"],x,y)
                    bot=limitz(group[floor+"_"+bed+"_O"],x,y)
                    assert top and bot,(mode,x,y,top,bot)
                    heights.append([round(x,3),round(min(top)-max(bot),3)])
                sections.append([bed,mode,i/8,*heights[0],*heights[1]])
    with (E/"air_sections.csv").open("w",newline="") as f:
        w=csv.writer(f);w.writerow(["bed","path","fraction","parent_x_mm","parent_clear_mm","C09_x_mm","C09_clear_mm"]);w.writerows(sections)
    seams={}
    for bed in "AB":
        for side in ("LOW","HIGH"):
            cheek=new[f"AIR_REGEN_CHEEK_{bed}_{side}_O"]
            b=bb(cheek);yc=(b[1]+b[4])/2
            yd=b[4]+.1 if side=="LOW" else b[1]-.1
            divider=new[f"AIR_PORT_DIVIDER_{bed}_O"]
            sampled=[]
            for x in range(631,749):
                zs=limitz(cheek,x,yc); dd=limitz(divider,x,yd)
                if zs and dd:sampled.append([x,round(max(zs)-min(dd),4)])
            assert sampled
            seams[f"{bed}_{side}"]={"samples_x_and_edge_engagement_mm":sampled,"minimum_edge_engagement_mm":min(v for x,v in sampled)}
            floor=new[f"AIR_REGEN_FLOOR_{bed}_O"]
            edges=[]
            for x in range(631,749):
                wall_z=limitz(cheek,x,yc)
                floor_z=limitz(floor,x,yd)
                if wall_z and floor_z:edges.append([x,round(max(floor_z)-min(wall_z),4)])
            assert edges
            seams[f"{bed}_{side}"].update(bottom_samples_x_and_edge_engagement_mm=edges,
                minimum_bottom_edge_engagement_mm=min(v for x,v in edges))
    dump("seam_screen.json",{"shell_sha256":digest(CAD/"C09_SHELL.step"),"edges":seams})
    print("airpath",min(r[-1] for r in sections),"minimum edge engagement",min(d["minimum_edge_engagement_mm"] for d in seams.values()))

if __name__=="__main__":run()
