"""Plot sections through the exported C09 hardware at the Bed A air-passage centre."""
from build_c09 import *
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

def make():
    fig,(ax,zoom)=plt.subplots(2,1,figsize=(10,7.8),gridspec_kw={"height_ratios":[2.5,1]})
    section=cq.Face.makePlane(2600,2600,cq.Vector(0,-425,500),cq.Vector(0,1,0))
    for path,s in leaves(CAD/"C09_INSTALLED_S1.step"):
        fields=path.split("/")
        n=fields[-2]
        if "HEAT_EXCHANGERS" in fields:
            continue  # Fin window is indicated separately below.
        if "DAMPERS" in fields:
            if not any(t in n for t in ("BLADE_A_","SEAT_A_","ROOT_LIP_A")):continue
            color="#ab4227"
        elif n.startswith(("AIR_BOTTOM_SPLITTER_A","AIR_TOP_SPLITTER_A","AIR_PORT_DIVIDER_A","AIR_PROCESS_OUT_","AIR_REGEN_FLOOR_A")):
            color="#0b6470"
        else:continue
        b=bb(s)
        if not b[1]<-425<b[4]:continue
        cut=s.intersect(section)
        for edge in cut.Edges():
            pts,_=edge.sample(0.4)
            if any(abs(pt.y+425)>.05 for pt in pts):continue
            for view in (ax,zoom):view.plot([pt.x for pt in pts],[pt.z for pt in pts],color=color,linewidth=1.15)
    for z in (656.35,991.35):
        ax.add_patch(Rectangle((-410,z),1000,152,facecolor="#b4cbd9",edgecolor="#466a7f",lw=1))
        ax.text(90,z+76,"HX fin window",ha="center",va="center",fontsize=10)
    for view in (ax,zoom):
        view.axvline(590,color="#46596d",linestyle="--",lw=.9);view.set_aspect("equal")
        view.grid(alpha=.12);view.set_ylabel("Z (mm)")
    ax.set_xlim(-570,780);ax.set_ylim(0,1450);ax.set_title("Bed A, process state  |  section at Y = -425 mm",loc="left",fontsize=13)
    zoom.set_xlim(520,765);zoom.set_ylim(285,645);zoom.set_aspect("auto")
    zoom.annotate("HX edge 590",(590,621),(531,621),fontsize=9)
    zoom.annotate("Pout seat 614.5",(615,579),(645,513),arrowprops={"arrowstyle":"->","color":"#ab4227"},fontsize=9)
    zoom.set_xlabel("X (mm)");zoom.set_title("Lower outlet detail  |  24.5 mm beyond the fin edge",loc="left",fontsize=11)
    fig.tight_layout();fig.savefig(HERE/"C09_AIR_SECTION.png",dpi=145);plt.close(fig)

if __name__=="__main__":make()
