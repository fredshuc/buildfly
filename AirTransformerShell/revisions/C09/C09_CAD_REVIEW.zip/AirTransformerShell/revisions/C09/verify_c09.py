"""Screen C09 host against D03 states, sweeps, tool volumes and all four installed coils."""
from build_c09 import *
import argparse
from collections import defaultdict
from cad_io import overlaps

TOL=0.001

def contacts(left,right,internal=False):
    out=[];candidates=0
    right=[(k,v,bb(v)) for k,v in right.items()]
    for n,s in left.items():
        bounds=bb(s)
        for k,t,b in right:
            if (internal and n==k) or not overlaps(bounds,b):continue
            candidates+=1
            volume=s.intersect(t).Volume()
            if volume>TOL:
                out.append([n,k,round(volume,5)])
    return {"candidate_pairs":candidates,"overlaps":out}

from functools import lru_cache

@lru_cache(maxsize=1)
def installed_shell():
    path=CAD/"C09_SHELL.step"
    before=digest(path)
    parts={n:s for n,(_,s) in entries(path).items()}
    assert before==digest(path), "shell changed while importing"
    return before,parts

def verify(kind):
    shell_sha,shell=installed_shell()
    path=DAMP/"cad"
    if kind=="hx":
        hx=dict(leaves(HX))
        assert len(hx)==2196
        data=contacts(hx,shell)
    elif kind in ("S1","S2"):
        parts={n:s for n,(k,s) in entries(path/f"D03_INSTALLED_{kind}.step").items() if "SHELL_REFERENCE" not in k.split("/")}
        data=contacts(parts,shell)
    elif kind=="shell":
        ledger=json.loads((E/"shell.json").read_text())
        changed=list(ledger["changed"])+ledger["new_parts"]
        original={n:s for n,(_,s) in entries(BASE).items()}
        raw=contacts({n:shell[n] for n in changed},shell,internal=True)
        rows=[];seen=set()
        for a,b,v in raw["overlaps"]:
            if a==b or tuple(sorted((a,b))) in seen:continue
            seen.add(tuple(sorted((a,b))))
            old=original[a].intersect(original[b]).Volume() if a in original and b in original else 0.0
            if v>old+TOL:rows.append([a,b,v,round(old,5)])
        data={"candidate_pairs":raw["candidate_pairs"],"increased_overlaps":rows}
    else:
        spans={k:s for k,s in leaves(path/"D03_MOTION_AND_SERVICE.step") if any(part in {bed+"_"+level+("_SERVICE" if kind=="service" else "_MOTION") for bed in "AB" for level in ("LOWER","UPPER")} for part in k.split("/"))}
        assert len(spans)==(36 if kind=="service" else 46),(kind,len(spans))
        data=contacts(spans,shell)
    assert shell_sha==digest(CAD/"C09_SHELL.step"), "shell changed during verification"
    data["shell_sha256"]=shell_sha
    data["threshold_mm3"]=TOL
    dump("check_"+kind+".json",data)
    print(kind,data["candidate_pairs"],len(data.get("overlaps",data.get("increased_overlaps",[]))),flush=True)

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("checks",nargs="*",default=["S1","S2","motion","service","hx","shell"])
    for kind in parser.parse_args().checks:verify(kind)
