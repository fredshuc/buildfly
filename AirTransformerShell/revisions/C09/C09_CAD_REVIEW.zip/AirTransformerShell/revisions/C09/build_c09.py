"""Build the horizontal four-core C09 shell and two installed configurations."""
from pathlib import Path
import hashlib
import json
import os
import sys
from collections import Counter

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
for lib in os.environ.get("CADQUERY_LIBDIRS", "").split(os.pathsep):
    if lib:
        sys.path.insert(0, lib)
sys.path.extend(str(ROOT / "R5_WORK" / sub) for sub in ("early_vendor", "runtime_ready"))
sys.path.insert(0, str(ROOT / "dampers/c08-d03/source"))
from cad_io import cq, bb, leaves
from OCP.STEPCAFControl import STEPCAFControl_Reader, STEPCAFControl_Writer
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString as S
from OCP.XCAFDoc import XCAFDoc_DocumentTool
from OCP.TDF import TDF_LabelSequence, TDF_Label
from OCP.TDataStd import TDataStd_Name
from OCP.TopLoc import TopLoc_Location
from OCP.STEPControl import STEPControl_AsIs
from OCP.IFSelect import IFSelect_RetDone

BASE = ROOT / "AirTransformerShell/references/four-core-outdoor/V050_SM_M2_IN1_R1_OUTDOOR_SHEET_METAL_ONLY.stp"
DAMP = ROOT / "dampers/c08-d03"
HX = DAMP / "inputs/FOUR_HX_INSTALLED.step"
E = HERE / "evidence"
CAD = HERE / "cad"

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def dump(name, data):
    (E / name).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def entries(path):
    result = {}
    for full, shape in leaves(path):
        fields = full.split("/")
        key = next((k for k in reversed(fields) if k.endswith("_O")), fields[-2])
        if key in result:
            raise ValueError((path, key))
        result[key] = (full, shape)
    return result

def block(x0,y0,z0,x1,y1,z1):
    return cq.Solid.makeBox(x1-x0,y1-y0,z1-z0,cq.Vector(x0,y0,z0))

def stretch_segment(shape, x0, x1, delta0, delta1):
    seg = shape.intersect(block(x0,-2000,-100,x1,2000,2000))
    if not seg.Solids():
        return None
    if delta0 == delta1:
        return seg.translate((delta0,0,0))
    slope=(delta1-delta0)/(x1-x0)
    matrix=cq.Matrix([[1+slope,0,0,delta0-slope*x0],[0,1,0,0],[0,0,1,0]])
    return seg.transformGeometry(matrix)

def remap(shape, nodes):
    pieces=[stretch_segment(shape,x0,x1,d0,d1) for (x0,d0),(x1,d1) in zip(nodes,nodes[1:])]
    pieces=[s for s in pieces if s is not None]
    return pieces[0].fuse(*pieces[1:]).clean() if len(pieces)>1 else pieces[0].clean()

def move_holes(shape, x0,x1,z0,z1, skin_b=False):
    # Transfer the original aperture outline and restore the old cut in the sheet.
    b=bb(shape)
    patch=block(x0,848.5 if skin_b else b[1],z0,x1,b[4],z1)
    void=patch.cut(shape)
    assert void.Volume() > 100
    return shape.fuse(patch).cut(void.translate((110,0,0))).clean()

def floor_regrade(s):
    # Keep the formed inlet and the drain mouth. Replace the straight run with
    # a 1.5 mm normal-gauge strip between two sharp mitres in its neutral face.
    b=bb(s);ymid=(b[1]+b[4])/2
    def section(x):
        ray=cq.Edge.makeLine(cq.Vector(x,ymid,-10),cq.Vector(x,ymid,500))
        zs=sorted(v.Z for v in ray.intersect(s).Vertices())
        assert len(zs)==2,(x,zs)
        return zs
    old0,old1=531.,719.
    z0,z1=section(old0),section(old1)
    slope=(sum(z1)-sum(z0))/(2*(old1-old0))
    gauge=(z0[1]-z0[0])/(1+slope**2)**.5
    assert abs(gauge-1.5)<.005,gauge
    x0,x1=old0+110,old1
    m=(sum(z1)-sum(z0))/(2*(x1-x0))
    half=gauge*(1+m*m)**.5/2
    outline=[]
    for sign,j in [(-1,0),(1,1)]:
        a=(z0[0]+z0[1])/2+sign*half
        xx0=x0+(z0[j]-a)/(m-slope)
        xx1=x1+(z1[j]-(a+m*(x1-x0)))/(m-slope)
        arc=[(x0-4,z0[j]-4*slope),(xx0,z0[j]+slope*(xx0-x0)),
             (xx1,z1[j]+slope*(xx1-x1)),(x1+4,z1[j]+4*slope)]
        outline.extend(arc if j==0 else reversed(arc))
    profile=cq.Wire.makePolygon([cq.Vector(x,b[1],z) for x,z in outline],close=True)
    bridge=cq.Solid.extrudeLinear(profile,[],cq.Vector(0,b[4]-b[1],0))
    upstream=s.intersect(block(-700,-1500,-100,old0-4,1500,1600)).translate((110,0,0))
    downstream=s.intersect(block(old1+4,-1500,-100,1500,1500,1600))
    return upstream.fuse(bridge,downstream).clean()

# The upper hood crosses the original rear edge of the outer cheek. The local
# rear wall terminates at the new cheek face there. All dimensions are in mm.
HOOD_ZONES=[(554,666,317,490,False),(-505,-444,1237,1410,True)]
def hood_recess(shape):
    for x0,x1,z0,z1,rear_edge in HOOD_ZONES:
        region=block(x0,814,z0,x1,818,z1)
        patch=shape.intersect(region)
        inset=block(x0 if rear_edge else x0+1.5,814,z0+1.5,x1-1.5,818,z1-1.5)
        rim=patch.cut(inset)
        returns=[]
        for face in rim.Faces():
            if abs(face.Center().y-815)<1e-5 and abs(face.normalAt().y)>.999:
                returns.append(cq.Solid.extrudeLinear(face.outerWire(),face.innerWires(),cq.Vector(0,-4.5,0)))
        assert returns
        shape=shape.cut(region).fuse(patch.translate((0,-4.5,0)),*returns).clean()
    return shape

def top_splitter(s):
    # Two shallow folds lift the deck over the taller universal upper cores.
    nodes=[(-750,0),(-250,0),(420,17),(640,17),(744,0),(900,0)]
    pieces=[]
    for (x0,d0),(x1,d1) in zip(nodes,nodes[1:]):
        piece=s.intersect(block(x0,-1400,-5,x1,1400,1700))
        if not piece.Solids():continue
        m=(d1-d0)/(x1-x0)
        if m:
            piece=piece.transformGeometry(cq.Matrix([[1,0,0,0],[0,1,0,0],[m,0,1,d0-m*x0]]))
        else:piece=piece.translate((0,0,d0))
        pieces.append(piece)
    return pieces[0].fuse(*pieces[1:]).clean()

def frame_post(s):
    # Keep the original outer face, two continuous longitudinal webs and both ends.
    for z0,z1 in ((440,715),(775,1050)):
        s=s.cut(block(-645,-824,z0,-555,-795,z1))
        wall=block(-640,-827,z0,-560,-824,z1)
        lo=block(-640,-824,z0,-560,-805,z0+3)
        hi=block(-640,-824,z1-3,-560,-805,z1)
        s=s.fuse(wall,lo,hi).clean()
    return s

def inlet_mask(n,s):
    b=bb(s)
    ym=-432.5 if "_A_" in n else 432.5
    z=620 if "_L_" in n else 955
    panel=block(b[0],b[1],z-3.5,b[3],b[4],z-2)
    panel=panel.cut(block(-410.2,ym-305.275,z-5,590.2,ym+305.275,z+1)).clean()
    if "_L_" in n:
        # The far edge must return to the legacy outlet flange elevation.
        line=cq.Wire.makePolygon([cq.Vector(x,b[1],h) for x,h in [
            (684,z-3.5),(690,z-3.5),(726,z),(b[3],z),
            (b[3],z+1.5),(726,z+1.5),(690,z-2),(684,z-2)]],close=True)
        tail=cq.Solid.extrudeLinear(line,[],cq.Vector(0,b[4]-b[1],0))
        panel=panel.intersect(block(-550,-1500,0,684,1500,1600)).fuse(tail).clean()
    return panel

def face_gasket(ym,z):
    return block(-423,ym-318,z-2,603,ym+318,z).cut(
        block(-410.2,ym-305.275,z-3,590.2,ym+305.275,z+1)).clean()

def tube_crossings():
    result={}
    for k,s in leaves(HX):
        n=k.split("/")[-2]
        if n not in ("W1_D35_END_PIPE","W2_D35_END_PIPE"):continue
        stage=next(t for t in k.split("/") if t in {"A_LOWER","A_UPPER","B_LOWER","B_UPPER"})
        cut=s.intersect(block(-501.5,-1000,42,-500,1000,1484))
        b=bb(cut)
        assert abs(b[4]-b[1]-35)<.02 and abs(b[5]-b[2]-35)<.02,(k,b)
        result[stage+"_"+n[:2]]=[(b[4]+b[1])/2,(b[5]+b[2])/2]
    assert len(result)==8
    return result

def gland(y,z,rad,x,length):
    return cq.Solid.makeCylinder(rad,length,cq.Vector(x,y,z),cq.Vector(1,0,0))

def host_shape(n, orig, refs):
    if n.startswith("HX_MASK_"):
        return inlet_mask(n,orig),"replace half mask with continuous 12 mm-class gasket land"
    if n.startswith("AIR_TOP_SPLITTER_"):
        return top_splitter(orig),"lift local deck 17 mm over the upper universal HX, preserve ends"
    if n=="F_POST_-600_-825_O":
        return frame_post(orig),"box two local reliefs behind A water tails; structural review required"
    if n.startswith("AIR_PORT_DIVIDER_"):
        return remap(orig,[(100,110),(531,110),(719,0),(900,0)]),"match Rin cheek profile and fixed exit"

    if n.startswith("F_DAMPER_RAIL_"):
        return refs[n], "D03 drilled load rail"
    if n.startswith(("M401_DAMPER_BACKER_", "M401_DAMPER_BLANK_")) and "_L_" in n:
        return refs[n], "D03 relocated lower drive cover interface"
    if n.startswith("M611_ROOT_RCV_") or (n.startswith("M203_INNER_FLANGE_") and "_LOWER_" in n):
        return orig.translate((110,0,0)), "move lower shaft interface"
    if n.startswith("SKIN_DRY_SIDE_"):
        return move_holes(orig,415,585,245,445,skin_b=n=='SKIN_DRY_SIDE_B_O'), "move lower drive access, retain cable entry"
    if n=="AIR_SIDE_OUT_B_O":
        return hood_recess(move_holes(orig,445,555,290,394)), "relocated shaft and two formed dry-side feedback pockets"
    if n=="AIR_REAR_B_O":
        return orig.cut(block(-600,810.5,1237,-450,820,1410)).clean(), "close rear corner against formed upper pocket"
    if n.startswith("AIR_REGEN_FLOOR_"):
        return floor_regrade(orig), "constant-gauge mitred Rin floor with retained drain mouth"
    if n.startswith(("AIR_SIDE_IN_","AIR_SIDE_OUT_")):
        return move_holes(orig,445,555,290,394), "move lower shaft penetration"
    if n.startswith("AIR_BOTTOM_SPLITTER_"):
        return remap(orig,[(-700,0),(-490,0),(252,110),(900,110)]), "extend splitter up to translated Rin seating zone"
    if n.startswith(("AIR_PORT_DIVIDER_","AIR_PROCESS_OUT_FLOOR_","AIR_PROCESS_OUT_CHANNEL_")):
        fix=748.5 if "DIVIDER" in n else 746.5
        return remap(orig,[(100,110),(521,110),(fix,0),(900,0)]), "shorten Pout transition to fixed port"
    if n.startswith(("AIR_REGEN_FLOOR_", "AIR_REGEN_CHEEK_")):
        return remap(orig,[(100,110),(531,110),(719,0),(900,0)]), "regrade Rin transition, retain drain end and root clearance"
    return orig, None

def add_group(assembly,name,items,col):
    group=cq.Assembly(name=name)
    for n,s in sorted(items.items()):
        group.add(s,name=n,color=cq.Color(*col))
    assembly.add(group,name=name)

def combine(paths, out):
    doc=TDocStd_Document(S("C09"))
    tool=XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
    components=[]
    for tag,path in paths:
        before=TDF_LabelSequence()
        tool.GetFreeShapes(before)
        r=STEPCAFControl_Reader();r.SetNameMode(True)
        assert r.ReadFile(str(path))==IFSelect_RetDone and r.Transfer(doc)
        after=TDF_LabelSequence();tool.GetFreeShapes(after)
        assert after.Length()==before.Length()+1,(tag,before.Length(),after.Length())
        components.append((tag,after.Value(after.Length())))
    top=tool.NewShape();TDataStd_Name.Set_s(top,S(out.stem))
    for tag,label in components:
        occ=tool.AddComponent(top,label,TopLoc_Location());TDataStd_Name.Set_s(occ,S(tag))
    tool.UpdateAssemblies()
    w=STEPCAFControl_Writer();w.SetNameMode(True);w.SetColorMode(True)
    assert w.Transfer(top,STEPControl_AsIs) and w.Write(str(out))==IFSelect_RetDone

def run():
    E.mkdir(exist_ok=True);CAD.mkdir(exist_ok=True)
    assert digest(BASE)=="d20fbdc7a29cf05dad60b861e0eac5a06509d531450b63370dea08928586f6ae"
    assert digest(HX)=="0360e579144f74aba14026e1d77f619e547365f2ee48cb3fdcd67370db4d271c"
    base=entries(BASE); assert len(base)==521
    damper_checks=json.loads((DAMP/"D03_GIT_READBACK.json").read_text(encoding="utf-8-sig"))["files"]
    for name, check in damper_checks.items():
        assert digest(DAMP/"cad"/name)==check["sha256"]
    shell_path=CAD/"C09_SHELL.step"
    for state in ("S1","S2"):
        d03=entries(DAMP/"cad"/f"D03_INSTALLED_{state}.step")
        refs={n:s for n,(k,s) in d03.items() if "SHELL_REFERENCE" in k.split("/")}
        product={n:s for n,(k,s) in d03.items() if n not in refs}
        assert (len(refs),len(product))==(344,230)
        if state=="S1":
            shell={};changed={};owned=[];retired=[]
            ports=tube_crossings()
            for n,(_,orig) in base.items():
                if n in product:
                    owned.append(n);continue
                if n.startswith("HX_END_"):
                    retired.append(n);continue
                s,reason=host_shape(n,orig,refs)
                if n in ("AIR_BOTTOM_SPLITTER_B_O","AIR_TOP_SPLITTER_B_O"):
                    for x0,x1,z0,z1,rear_edge in HOOD_ZONES:
                        s=s.cut(block(x0,810.5,z0,x1,820,z1)).clean()
                    reason+="; scribe edge to inner face of sealed feedback pocket"
                if n.startswith("AIR_REAR_"):
                    bed=n.split("_")[2]
                    for tag,(y,z) in ports.items():
                        if tag.startswith(bed+"_"):
                            s=s.cut(gland(y,z,22.5,-503,5))
                    reason="H00 rear-wall pass-throughs for measured tubes"+(" and upper pocket closure" if bed=="B" else "")
                if reason:
                    assert s.Solids() and s.isValid(),n
                    changed[n]={"operation":reason,"old_bbox":bb(orig),"new_bbox":bb(s)}
                shell[n]=s
            added={}
            for bed,ym in (("A",-432.5),("B",432.5)):
                for stage,z in (("LOWER",620),("UPPER",955)):
                    added[f"C09_FACE_GASKET_{bed}_{stage}"]=face_gasket(ym,z)
            for tag,(y,z) in ports.items():
                ann=gland(y,z,22.5,-501.5,1.5).cut(gland(y,z,17.5,-503,5))
                for side,y0,y1 in (("LOW",y-24,y),("HIGH",y,y+24)):
                    added["C09_SPLIT_GLAND_"+tag+"_"+side]=ann.intersect(block(-503,y0,z-24,-499,y1,z+24)).clean()
            # Sister RHS spans both relieved areas. The uncut end and middle bands
            # form attachment zones. Closure webs join the two sections locally.
            sleeve=block(-640,-805,400,-618,-745,1090).cut(block(-637,-802,399,-621,-748,1091))
            added["C09_A_POST_SISTER_RHS_22x60x3"]=sleeve
            for tag,z0,z1 in (("LOWER",443,712),("UPPER",778,1047)):
                for side,x0 in (("REAR",-640),("FRONT",-621)):
                    added[f"C09_A_POST_{tag}_{side}_WEB"]=block(x0,-824,z0,x0+3,-805,z1)
            shell.update(added)
            a=cq.Assembly(name="C09_SHELL")
            add_group(a,"STRUCTURE",shell,(.68,.73,.78))
            a.save(str(shell_path))
            check=entries(shell_path)
            assert set(check)==set(shell)
            for n,(_,s) in check.items():
                assert s.isValid() and max(abs(i-j) for i,j in zip(bb(s),bb(shell[n])))<.01,n
            dump("shell.json",{"source_count":len(base),"shell_count":len(shell),"superseded_by_D03":owned,"superseded_by_face_seals":retired,"new_parts":sorted(added),"H00_wall_crossings_YZ":ports,"changed":changed})
        a=cq.Assembly(name="D03_"+state)
        add_group(a,"SELECTORS",product,(.19,.55,.64))
        stage=HERE/(".selectors_"+state+".step")
        a.save(str(stage))
        out=CAD/f"C09_INSTALLED_{state}.step"
        combine([("SHELL",shell_path),("DAMPERS",stage),("HEAT_EXCHANGERS",HX)],out)
        counts=Counter()
        for k,s in leaves(out):
            counts[next(g for g in ("SHELL","DAMPERS","HEAT_EXCHANGERS") if g in k.split("/"))]+=1
        assert counts=={"SHELL":len(shell),"DAMPERS":230,"HEAT_EXCHANGERS":2196},counts
        stage.unlink()
        dump("readback_"+state+".json",{"file":out.name,"sha256":digest(out),"groups":dict(counts),"bytes":out.stat().st_size})
    print("Completed both installed STEP readbacks.", flush=True)

if __name__=="__main__":
    run()
