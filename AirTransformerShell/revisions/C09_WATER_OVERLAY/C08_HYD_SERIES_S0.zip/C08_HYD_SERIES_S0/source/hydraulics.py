"""python hydraulics.py RT01.zip OUTPUT
Per-core friction screen, not a performance curve. Series only."""
from pathlib import Path
import math,json,csv,io,itertools,sys,zipfile
z=zipfile.ZipFile(sys.argv[1]);d=Path(sys.argv[2])
def old(n):return list(csv.DictReader(io.StringIO(z.read('engineering/'+n).decode('utf-8-sig'))))
def wr(n,r):
 with (d/n).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(r[0]));w.writeheader();w.writerows(r)
src=old('functional_baseline/C05_CONNECTION_SCHEDULE.csv')
bridge={'A':('E058','E075','E076','E077','E070'),'B':('E093','E110','E111','E112','E105')}
base={p['id']:p for p in src};area=math.pi*.0273**2/4; vc=10.995722199123406
# Per bed: E0 lower terminal / 3 links of bridge / E4 upper terminal.
# Rack end sections terminate at the selected bed-facing valve ports, not the main header.
runs={'cold':[431,235,201.3,240,587],'hot':[659,235,201.3,240,475]}
segments=['lower_W1_endpoint','lower_W2_to_FS1','FS2_to_Q1','Q2_to_upper_W1','upper_W2_endpoint']
unknown=['ell_L_W1','ell_L_W2','0','ell_U_W1','ell_U_W2']
# Water at 0.1 MPa, round constants; temperature range sensitivity rather than precision.
props={5:(999.97,.001519),80:(971.8,.000355)}
def dpr(Q,di,L,loK,hiK,T):
 rho,mu=props[T];v=Q/3600/(math.pi*di**2/4);Re=rho*v*di/mu
 lam=64/Re;turb=.3164/Re**.25
 if Re<2300:fs=[lam,lam]
 elif Re>4000:fs=[turb,turb]
 else:fs=[min(lam,turb),max(lam,turb)]
 return [round((f*L/di+k)*rho*v*v/2000,4) for f,k in zip(fs,[loK,hiK])]
def add(*rows):return [round(sum(v),4) for v in zip(*rows)]
results=[];pipe=[];carry=[];scope=[]
for b in 'AB':
 for mode,ls in runs.items():
  for i,L in enumerate(ls):
   v=base[bridge[b][i]];ref=json.loads(v['C05_physical']);oldL=ref['developed_mm'];assert ref['ID_mm']==27.3
   scope.append(dict(bed=b,mode=mode,segment=segments[i],legacy_route_id=v['id'],old_from=v['from_port'],old_to=v['to_port'],old_length_mm=oldL,C08_known_mm=L,unreleased_first_segment_mm=unknown[i],length_change_mm=f'{L-oldL:+.2f} + {unknown[i]}',known_C08_L=round(area*L,5),old_L=round(area*oldL,5),carryover_source='bed-side; whole quantity is inventory, not guaranteed plug transfer'))
   for Q in [.5,1.72,2,2.58]:
    for T in props:
     dp=dpr(Q,.0273,L/1000,0,0,T)
     pipe.append(dict(bed=b,segment=segments[i],mode=mode,Q_m3h=Q,T_C=T,known_length_mm=L,known_water_L=round(area*L,4),dp_straight_kPa_lo=dp[0],dp_straight_kPa_hi=dp[1],per_extra_m_kPa=dpr(Q,.0273,1,0,0,T)[1],per_extra_m_L=round(area*1000,5),per_K_kPa=dpr(Q,.0273,0,1,1,T)[0]))
for T in props:
 for Q in [.5,1.72,2.,2.58]:
  # Five 180-degree bends; two header legs, two terminal pipes, entry/exit and build-up at the headers.
  L=(6*.650+2*.020075+5*math.pi*math.hypot(.022,.0127)/2)
  circuit=dpr(Q/39,.00852,L,4,12,T)
  # Two headers with linear takeoffs/collection, integrated v^2 -> L/3 each.
  # Additional equivalent full-speed ID28 length 0.6 m (provisional) and total local K 2..8.
  common=dpr(Q,.028,2*1.036/3+.6,2,8,T);core=add(circuit,common)
  P=(props[T][0]/1000)*Q*4.18*5/3.6
  for mode,ls in runs.items():
   pipe_dp=dpr(Q,.0273,sum(ls)/1000,0,0,T)
   results.append(dict(T_C=T,bed_and_each_core_Q_m3h=Q,mode=mode,core_circuit_dp_kPa=circuit,core_terminal_header_dp_kPa=common,estimated_each_core_kPa=core,estimated_two_series_cores_kPa=[round(2*x,4) for x in core],rack_bed_known_straight_kPa=pipe_dp,example_bed_kW_at_5K=round(P,2),example_each_core_kW_equal_duty=round(P/2,2),assumed_equal_duty_deltaT_each_K=2.5))
 for mode,L in runs.items():
  nominal=2*vc+area*sum(L)
  carry.append(dict(T_C=T,mode=mode,core_only_L=round(2*vc,4),mode_path_plus_known_pipe_L=round(nominal,4),mode_path_example_MJ_at_50K=round(nominal*props[T][0]/1000*4.18*50/1000,4),plug_transit_s_at_2m3h=round(nominal*1.8,2),additions='actual four HX spools, FS/Q and cavities; idle branches partly stagnant'))
wr('branch_old_new.csv',scope);wr('branch_pressure.csv',pipe);wr('core_duty.csv',results);wr('carryover.csv',carry)
olds=old('internal/C05_PUMP_DUTY_16_POINTS.csv');wr('historical_design_pump_screen.csv',[{k:r[k] for k in ('state','water_C','Q_m3_h','actual_candidate_route_m','HX_kPa','total_kPa','available_kPa','margin_after_10kPa_source_and5kPa_reserve','result')} for r in olds])
tags=[b+'_XV_'+c for b in 'AB' for c in ['CS','HR','HS','CR']]
states=[]
def classify(on):
 for b in 'AB':
  codes={n[-2:] for n in on if n.startswith(b)}
  if codes>={'CS','HR'} or codes>={'CR','HS'}:return 'FAULT_DIRECT_END_BRIDGE'
  if codes>={'CS','HS'} or codes>={'CR','HR'}:return 'FAULT_CROSS_SOURCE_THROUGH_SERIES'
 a,b=[{n[-2:] for n in on if n.startswith(x)} for x in 'AB']
 if (a,b) in [({'CS','CR'},{'HS','HR'}),({'HS','HR'},{'CS','CR'})]:return 'STEADY_IF_ALL_OTHER_PROOFS'
 return 'NO_RUN'
for bits in itertools.product((0,1),repeat=8):
 on={k for k,i in zip(tags,bits) if i};states.append({**dict(zip(tags,bits)),'classification':classify(on)})
assert len([s for s in states if s['classification'].startswith('STEADY')])==2
wr('feedback_256.csv',states)
seq=[]
for fw in [0,1]:
 codes=({'CS','CR'},{'HS','HR'}) if fw==0 else ({'HS','HR'},{'CS','CR'});N=codes[::-1]
 def tr(arr,select):return {b+'_XV_'+c for b,cs in zip('AB',arr) for c in cs if select in ('all',c[1])}
 order=[('steady_old',tr(codes,'all')),('unload_prove_no_flow',tr(codes,'all')),('old_supplies_closed',tr(codes,'R')),('old_returns_closed',set()),('new_returns_open',tr(N,'R')),('new_supplies_open',tr(N,'all')),('steady_new',tr(N,'all'))]
 for i,(step,s) in enumerate(order):
  permit=step.startswith('steady')
  if permit:assert classify(s)=='STEADY_IF_ALL_OTHER_PROOFS'
  if i:
   prev=order[i-1][1];moving=prev^s
   for x in itertools.product((0,1),repeat=len(moving)):
    observed=prev^{k for k,t in zip(sorted(moving),x) if t};assert not classify(observed).startswith('FAULT')
  seq.append(dict(swap=fw,step=step,**{t:int(t in s) for t in tags},pump_permit='steady, require proofs' if permit else 'NO'))
wr('sequence.csv',seq)
print('constant inventory incl inactive pipe only / litres',round(2*vc+area*(2*295+290+218+4*74+676.3),5))
