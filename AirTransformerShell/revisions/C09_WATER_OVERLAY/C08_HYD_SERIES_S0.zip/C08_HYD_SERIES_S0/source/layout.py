"""C08 HYD-P0. usage: python layout.py SHELL_STEP OUTPUT [M101_C05_LOCAL_STEP]
The -735 plane is a proposed WATER RACK battery limit, not an approved HX endpoint."""
import sys,math,csv,json
from pathlib import Path
from itertools import combinations
from cad_io import cq,named,bb,overlaps
host=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
V=cq.Vector
parts={};svc={};zones={};ports=[];valves=[];lengths=[];coords=[]
def cyl(p,e,r):
 a,b=V(*p),V(*e);v=b-a;return cq.Solid.makeCylinder(r,v.Length,a,v.normalized())
def box(x,y,z,a,b,c):return cq.Solid.makeBox(a,b,c,V(x,y,z))
def tube(p,e,ro,ri):return cyl(p,e,ro).cut(cyl(p,e,ri))
def tree(segs):
 outer=[cyl(p,e,ro) for p,e,ro,ri in segs]
 inner=[cyl(p,e,ri) for p,e,ro,ri in segs]
 return outer[0].fuse(*outer[1:]).cut(*inner).clean()
def wr(name,rows):
 with (out/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
def export(group,name):
 a=cq.Assembly(name=name)
 for k,s in group.items():a.add(s,name=k)
 a.save(str(out/(name+'.step')))
 sh=cq.importers.importStep(str(out/(name+'.step'))).val()
 assert sh.isValid() and len(sh.Solids())==sum(len(s.Solids()) for s in group.values()),name
Y={}; Z={'CS':622,'HS':789,'CR':677,'HR':850}
ends={'CS':'L','HR':'L','HS':'U','CR':'U'}; machine=Path(__file__).resolve().parent
for b,base in [('A',-720),('B',145)]:
 for j,lev in enumerate(['L','U']):
  for i,w in enumerate(['W1','W2']):
   y=base+150*i;z=560+j*335;tag=b+'_'+lev+'_'+w;hcold=('inlet' if w=='W1' else 'outlet')
   hhot=('outlet' if w=='W1' else 'inlet')
   cold={('L','W1'):b+'_XV_CS -> lower W1',('L','W2'):'lower W2 -> FS:'+b+' -> Q:'+b,('U','W1'):'Q:'+b+' -> upper W1',('U','W2'):'upper W2 -> '+b+'_XV_CR'}[lev,w]
   hot={('L','W1'):'lower W1 -> '+b+'_XV_HR',('L','W2'):'FS:'+b+' -> lower W2',('U','W1'):'upper W1 -> Q:'+b+' -> FS:'+b,('U','W2'):b+'_XV_HS -> upper W2'}[lev,w]
   ports.append(dict(tag=tag,H00_x=-576,H00_y=round(-791.575+(865 if b=='B' else 0)+150*i,3),H00_z=490+j*335,H00_normal='-Z (rejected)',connection='Rp1-1/4 female at HX',cold_service=hcold,cold_adjacent=cold,hot_service=hhot,hot_adjacent=hot,legacy_function=('P1' if i==0 else 'P7')+' proposed mapping; HX to identify actual circuit end',rack_plane_x=-735,rack_y=y,rack_z=z,HX_horizontal_center='OPEN',HX_horizontal_normal='OPEN',detachable_spool='OPEN',status='P0_TARGET_ONLY'))
   svc[tag+'_UNION_TOOL']=cyl((-810,y,z),(-735,y,z),42).cut(cyl((-811,y,z),(-734,y,z),16.85))
 # End trees: ONLY lower W1 and upper W2 join selectors. No parallel tees.
 for lev,y,z,codes in [('L',base,560,('CS','HR')),('U',base+150,895,('HS','CR'))]:
  sign=-1 if lev=='L' else 1
  zs=[z]+[Z[c] for c in codes]
  segments=[((-1030,y,min(zs)),(-1030,y,max(zs)),16.85,13.65),((-1030,y,z),(-735,y,z),16.85,13.65)]
  for code in codes:
   h=Z[code];Y[b,code]=y;segments.append(((-1104,y,h),(-1030,y,h),16.85,13.65))
   body=box(-1220,y-32,h-32,116,64,64).cut(cyl((-1221,y,h),(-1103,y,h),13.65))
   act=box(-1201,y-147 if sign<0 else y+32,h-52,78,115,104)
   tag=b+'_XV_'+code;parts[tag]=body.fuse(act)
   svc[tag+'_PULL']=box(-1201,y-382 if sign<0 else y+147,h-52,78,235,104)
   valves.append(dict(tag=tag,function=code,x=-1162,y=y,z=h,stroke_axis='-Y' if sign<0 else '+Y',pull_mm=235,loss_of_power='closed; independent open/closed limits required',status='P0 candidate no holes'))
  parts[b+'_END_'+lev]=tree(segments)
 # Interstage: relocate two historical reference bodies by rigid translation.
 # Keep a separate by-name spool on all 3 interstage connections.
 def spool(tag,pts):
  seg=[(a,z,16.85,13.65) for a,z in zip(pts,pts[1:])]
  parts[b+'_'+tag]=tree(seg) if len(seg)>1 else tube(pts[0],pts[1],16.85,13.65)
  lengths.append(dict(bed=b,segment=tag,length_mm=sum(math.dist(a,z) for a,z in zip(pts,pts[1:])),ID_mm=27.3,polyline=str(pts)))
 y1=base;y2=base+150;x=-930
 spool('LOW_W2_FS',[(-735,y2,560),(x,y2,560),(x,y2,600)])
 # Move away from the FS head before changing lane at the intermediate elevation.
 spool('FS_Q',[(x,y2,688.7),(x,y2,720),(x,y1,720),(x,y1,740)])
 spool('Q_UP_W1',[(x,y1,850),(x,y1,895),(-735,y1,895)])
 for k,y,z,yold in [('FS',y2,600,-740 if b=='A' else 740),('Q',y1,740,-740 if b=='A' else 740)]:
  xo,zo=(900,820.65) if k=='FS' else (1100,975)
  shape=cq.Shape.importBrep(str(machine/'old_parts'/(k+'_'+b+'.brep'))).translate((x-xo,y-yold,z-zo))
  parts[k+'_'+b]=shape
  vals=bb(shape)
  svc[k+'_'+b+'_REMOVE_TOOL']=box(x-50,y+100,z+50,100,100,100) if k=='FS' else box(x-35,y-115,z+24,70,75,70)
for code,z in Z.items():
 role=code[-1];ya,yb=[Y[b,code] for b in 'AB']; seg=[((-1400,-945,z),(-1400,yb+35,z),21.2,17.95)]
 for y in (ya,yb):seg.append(((-1400,y,z),(-1220,y,z),16.85,13.65))
 parts['HEADER_'+code]=tree(seg)
 if role=='R':
  tag='TA_'+code
  parts[tag]=box(-1448.5,-1145,z-28,97,200,191).cut(cyl((-1400,-1146,z),(-1400,-944,z),17.95))
  svc[tag+'_TOOL']=box(-1448.5,-1145,z+163,97,200,75)
  valves.append(dict(tag=tag,function='meter/modulate common '+code,x=-1400,y=-1045,z=z,stroke_axis='+Z',pull_mm=75,loss_of_power='not used as safety isolation',status='R1 DN32 envelope; vendor/straight runs open'))
# TA units at CR/HR different elevations but their tool envelopes cannot overlap the other valve:
# Offset one lane in X to give independent access; translate its complete header, retain selector endpoints.
# Rebuild both R headers at different X; meter locations tracked so body and tool never stack.
for code,x in [('CR',-1400),('HR',-1570)]:
 if code=='CR':continue
 z=Z[code];ya,yb=[Y[b,code] for b in 'AB']
 parts['HEADER_'+code]=tree([((x,-945,z),(x,yb+35,z),21.2,17.95)]+[((x,y,z),(-1220,y,z),16.85,13.65) for y in (ya,yb)])
 parts['TA_HR']=parts['TA_HR'].translate((x+1400,0,0));svc['TA_HR_TOOL']=svc['TA_HR_TOOL'].translate((x+1400,0,0));valves[-1]['x']=x
# Reserve external skid; no shell-bracket/hole or HX spool represented.
zones['WATER_MODULE_BOUNDARY']=box(-1630,-1165,505,895,1860,600)
wr('eight_ports.csv',ports);wr('valve_positions.csv',valves);wr('bridge_dimensions.csv',lengths)
shell=named(host)
def hit(d,e,same=False):
 outp=[]
 for n,s in d.items():
  a=bb(s)
  for k,t in e.items():
   if same and k<=n:continue
   if overlaps(a,bb(t)):
    v=s.intersect(t).Volume()
    if v>.001:outp.append([n,k,round(v,4)])
 return outp
def closest(d,e):
 # AABB-separation lower bound first; exact BRep distance for possible winner
 candidates=[]
 for n,p in d.items():
  a=bb(p)
  for k,q in e.items():
   b=bb(q);lower=math.sqrt(sum(max(0,a[i]-b[i+3],b[i]-a[i+3])**2 for i in range(3)))
   candidates.append((lower,n,k))
 best=(1e30,'','')
 for l,n,k in sorted(candidates):
  if l>best[0]+1e-6:break
  dist=d[n].distance(e[k]);best=min(best,(dist,n,k))
 return list(best)
report={'units':'mm; clashes mm3 at >0.001','count':{k:len(v) for k,v in [('shell',shell),('water',parts),('service',svc)]},'checks':{},'clearance':{}}
for n,l,r,it in [('water_shell',parts,shell,0),('service_shell',svc,shell,0),('water_internal',parts,parts,1),('service_water',svc,parts,0)]:
 report['checks'][n]=hit(l,r,it);print(n,report['checks'][n],flush=True)
for name,d in [('physical_shell',parts),('service_shell',svc)]:
 report['clearance'][name]=closest(d,shell)
for name,expr in [('drains',lambda n:'DRAIN' in n),('regen_in',lambda n:'REGEN_IN' in n),('lower_drive_reference',lambda n:('LOWER' in n or 'LWR' in n) and ('DRIV' in n or 'ACT' in n or 'RECEIVER' in n))]:
 group={k:v for k,v in shell.items() if expr(k)};report['clearance'][name]=closest({**parts,**svc},group) if group else 'no named group'
if len(sys.argv)>3:
 hx=named(sys.argv[3]); local_zmax=max(bb(s)[5] for s in hx.values());xmin=644-local_zmax
 xwater=max(bb(s)[3] for s in [*parts.values(),*svc.values()]);report['lateral_extraction_slab']={'H00_product_minX':xmin,'rack_maxX':xwater,'X_gap_for_any_pure_Y_translation':xmin-xwater,'condition':'all first spools removed; not an independent validation of the C08 extraction direction or the handling equipment'}
(out/'layout_checks.json').write_text(json.dumps(report,indent=2))
assert not any(report['checks'][k] for k in ('water_shell','service_shell','service_water'))
expected={(b+'_FS_Q','FS_'+b) for b in 'AB'}|{(b+'_Q_UP_W1','Q_'+b) for b in 'AB'}
assert {(a,b) for a,b,v in report['checks']['water_internal']}==expected,report['checks']
export(parts,'C08_WATER_ISLAND_P0');export(svc,'C08_WATER_SERVICE_P0');export(zones,'C08_WATER_ZONE_P0')
asm=cq.Assembly(name='C08_INSTALL_OVERLAY_P0')
asm.add(cq.Compound.makeCompound(list(shell.values())),name='C08_SHEET_METAL_REFERENCE')
for n,s in parts.items():asm.add(s,name=n)
asm.save(str(out/'C08_INSTALLED_P0.step'))
check=cq.importers.importStep(str(out/'C08_INSTALLED_P0.step')).val()
assert len(check.Solids())==sum(len(x.Solids()) for x in [*shell.values(),*parts.values()])
