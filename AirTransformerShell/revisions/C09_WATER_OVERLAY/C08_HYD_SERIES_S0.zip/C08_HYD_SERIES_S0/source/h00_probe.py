import sys,json
from pathlib import Path
from cad_io import *
from OCP.gp import gp_Trsf
hx=named(sys.argv[1]);shell=named(sys.argv[2])
out=[]
for bed,dy in [('A',0),('B',865)]:
 for W,y in [('W1',-791.575+dy),('W2',-641.575+dy)]:
  tr=gp_Trsf();tr.SetValues(0,0,-1,644,0,-1,0,-64.725+dy,-1,0,0,840);loc=cq.Location(tr)
  s=hx['W2_D35_END_PIPE'].moved(loc)
  def gauge(l,z):return cq.Solid.makeCylinder(21,l,cq.Vector(-576,y,z),cq.Vector(0,0,-1))
  lo=0;hi=80
  for i in range(23):
   mid=(lo+hi)/2
   if gauge(mid,825).distance(s)<1e-6:hi=mid
   else:lo=mid
  row={'bed':bed,'port':W,'first_lower_W2_tube_contact_mm':round(hi,4),'first_80mm_overlap_mm3':round(gauge(80,825).intersect(s).Volume(),3),'old_front_post_hits':[]}
  for n,p in shell.items():
   if n.startswith('F_POST_-600_'):
    for lev,z in [('L',490),('U',825)]:
     g=gauge(40,z)
     if overlaps(bb(g),bb(p)):
      vol=g.intersect(p).Volume()
      if vol>0.001:row['old_front_post_hits'].append([lev,n,round(vol,3)])
  out.append(row)
(Path(sys.argv[3])/'H00_PROBE.json').write_text(json.dumps(out,indent=2));print(out)
