from pathlib import Path
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,FancyBboxPatch
import matplotlib.patheffects as pe
P=Path(__file__).parent
fig,ax=plt.subplots(figsize=(13.2,7));fig.set_facecolor('white');ax.set(xlim=(0,15),ylim=(0,8));ax.axis('off')
col={'C':'#156ba2','H':'#c35435'};black='#273e46'
def line(xs,ys,k=black,w=2):ax.plot(xs,ys,c=k,lw=w,solid_capstyle='round')
def txt(x,y,s,fs=9,**kw):ax.text(x,y,s,fontsize=fs,**kw)
def v(x,y,c):
 for s in (-1,1):ax.add_patch(Polygon([[x,y],[x+.17*s,y+.12],[x+.17*s,y-.12]],color=c))
def dot(x,y,c):ax.plot(x,y,'o',ms=4,c=c)
for j,(bed,y) in enumerate([('A',5.15),('B',2.5)]):
 for idx,c in enumerate('CH'):
  yy=y+.40-idx*.8; cl=col[c]; xx=.72+idx*.67; rx=10.0+idx*.7
  line([xx,4.05,4.05],[yy,yy,y],cl);dot(xx,yy,cl);v(2.65,yy,cl)
  txt(2.65,yy+.16,f'{bed}-XV-{c}S',8.5,ha='center',color=cl)
  line([8.15,8.15,rx],[y,yy,yy],cl);v(9.04,yy,cl);dot(rx,yy,cl)
  txt(9.0,yy+.16,f'{bed}-XV-{c}R',8.5,ha='center',color=cl)
 line([4.05,5.35],[y,y]);line([6.95,8.15],[y,y]);dot(4.05,y,black);dot(8.15,y,black)
 ax.add_patch(FancyBboxPatch((5.35,y-.39),1.60,.78,boxstyle='round,pad=0.04,rounding_size=.1',facecolor='#e3eeed',edgecolor=black))
 txt(6.15,y+.04,f'M101 • BED {bed}',10,ha='center',weight='bold');txt(6.15,y-.21,'W1  →  W2',9,ha='center')
 line([4.65,4.65],[y,y+.65]);txt(4.65,y+.76,f'RV/EV-{bed}',8.5,ha='center')
 txt(7.58,y+.14,f'TT-{bed}',8.5,ha='center');dot(7.58,y,black)
for idx,c in enumerate('CH'):
 hi=6.55+idx*.62; x=.72+idx*.67;rx=10+idx*.7;k=col[c]
 line([x,x],[2.5+.4-idx*.8,hi],k);txt(x,hi+.14,c+'S ↓',10,weight='bold',color=k,ha='center')
 line([rx,rx,11.25],[2.5+.4-idx*.8,hi,hi],k)
 ax.add_patch(FancyBboxPatch((11.25,hi-.2),1.48,.4,boxstyle='round,pad=.03',facecolor='white',edgecolor=k))
 txt(12,hi-.07,'TA-Smart '+c+'R',9,ha='center',color=k)
 line([12.75,13.73],[hi,hi],k);txt(13.8,hi-.06,c+'R →',10,weight='bold',color=k)
txt(2.08,7.48,'C04  /  TWO-BED HYDRONICS',17,weight='bold',color=black)
txt(2.08,7.03,'Functional P&ID  •  common water direction in adsorption and regeneration',10,color=black)
txt(2.08,6.57,'Supply temperature probes on CS and HS; local TT before each return fork.',8.6,color=black)
txt(.65,1.12,'XV: fail-closed two-way valve with two independent end-position signals.  •  RV/EV: always-connected thermal relief / expansion branch.',9,color=black)
txt(.65,.74,'Only marked dots and tee ends connect. Source pumps, bypasses and service isolation are outside the module at CS, HS, CR and HR.',9,color=black)
txt(.65,.34,'Recovery intentionally pairs HS → old CR and CS → old HR through separate beds; enable only on a pressure-compatible test installation.',9,color=black)
plt.subplots_adjust(left=.012,right=.99,bottom=.015,top=.99);fig.savefig(P/'water_pid.svg');fig.savefig(P/'water_pid.png',dpi=130);plt.close(fig)
