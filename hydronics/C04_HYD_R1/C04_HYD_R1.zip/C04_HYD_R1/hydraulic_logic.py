"""Enumerate 8 independent limit switches. Command whitelist, paired-switch paths and fault checks.
Offline topology verification, not PLC code. python hydraulic_logic.py [OUT]"""
from pathlib import Path
from itertools import product
from collections import Counter
import csv,json,sys
out=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent
tags=[b+'_XV_'+c for b in 'AB' for c in ('CS','HS','CR','HR')]
def names(x):return {tags[i] for i,k in enumerate(x) if k}
def route(s,b):
 a=[c for c in ('CS','HS') if b+'_XV_'+c in s];r=[c for c in ('CR','HR') if b+'_XV_'+c in s]
 return a,r
def classify(s):
 pairs=[route(s,b) for b in 'AB']
 if any(len(a)>1 or len(r)>1 for a,r in pairs):return 'FAULT_LOCAL_HOT_COLD_BRIDGE'
 if any(not a or not r for a,r in pairs):return 'NO_RUN_PARTIAL_OR_ISOLATED'
 if len({a[0] for a,r in pairs})<2 or len({r[0] for a,r in pairs})<2:return 'NO_RUN_SOURCE_OR_RETURN_DUPLICATED'
 if all(a[0][0]==r[0][0] for a,r in pairs):return 'STEADY_TWO_BEDS'
 return 'RECOVERY_PAIRED_ONLY'
def tags_for(cs):return {b+'_XV_'+c for b,ls in zip('AB',cs) for c in ls}
states={}; 
with (out/'all_256_feedback_states.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(tags+['classification'])
 for x in product((0,1),repeat=8):
  c=classify(names(x));states[x]=c;w.writerow([*x,c])
counts=Counter(states.values())
assert counts['STEADY_TWO_BEDS']==2 and counts['RECOVERY_PAIRED_ONLY']==2
def commands(forward,recover):
 old=(('CS','CR'),('HS','HR')) if forward else (('HS','HR'),('CS','CR'))
 new=old[::-1]
 def side(i,src):return tags_for(tuple([bb[i]] for bb in src))
 os,orr,ns,nr=side(0,old),side(1,old),side(0,new),side(1,new)
 init=os|orr
 seq=[('RUN_OLD',init,'STEADY'),('UNLOAD',init,'OFF'),('CLOSE_OLD_SUPPLIES',orr,'OFF')]
 if recover:seq.extend([('OPEN_NEW_SUPPLIES_OLD_RETURNS',ns|orr,'OFF'),('METER_DISPLACEMENT',ns|orr,'RECOVERY'),('UNLOAD_RECOVERY',ns|orr,'OFF'),('CLOSE_NEW_SUPPLIES',orr,'OFF')])
 seq += [('CLOSE_OLD_RETURNS',set(),'OFF'),('OPEN_NEW_RETURNS',nr,'OFF'),('OPEN_NEW_SUPPLIES',ns|nr,'OFF'),('RUN_NEW',ns|nr,'STEADY')]
 return seq
def subsets(s):
 a=sorted(s)
 for v in product((0,1),repeat=len(a)):yield {k for k,t in zip(a,v) if t}
rows=[];intermediate=0;fault_tests=0
for mode in (False,True):
 for forward in (True,False):
  seq=commands(forward,mode)
  for i,(cmd,s,permit) in enumerate(seq):
   c=classify(s)
   assert permit=='OFF' or (permit=='STEADY' and c=='STEADY_TWO_BEDS') or (permit=='RECOVERY' and c=='RECOVERY_PAIRED_ONLY')
   if i:
    prev=seq[i-1][1];add=s-prev;remove=prev-s
    assert not(add and remove)
    for done in subsets(add|remove):
     possible=prev^done;assert not classify(possible).startswith('FAULT');intermediate+=1
   for tag in tags:
    observed=s^{tag}
    assert observed!=s
    # Pump permission compares all eight proofs to the commanded state, not just the number of open valves.
    if permit!='OFF':assert not (observed==s and classify(observed)==c);fault_tests+=1
   rows.append([('recovery' if mode else 'direct'),('A_cold_to_hot' if forward else 'A_hot_to_cold'),i,cmd,permit,*[int(t in s) for t in tags]])
with (out/'sequences.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['mode','direction','step','command','pump_permit_after_proof',*tags]);w.writerows(rows)
cycle={}
for mode in (False,True):
 seq=commands(True,mode)+commands(False,mode)
 cycle['recovery' if mode else 'direct']={t:sum((t in s)!=(t in p) for (_,s,_),(_,p,_) in zip(seq[1:],seq[:-1]))/2 for t in tags}
(out/'logic_results.json').write_text(json.dumps(dict(counts=counts,possible_partial_motion_states_checked=intermediate,single_inverted_open_bit_cases_at_run=fault_tests,full_open_close_cycles_per_machine_roundtrip=cycle,scope='Eight resolved binary valve positions; unknown, both limit switches asserted, feedback loss or pending motion never permits pump. No proof of physical motion, valve tightness, pressure or hardware safety.'),indent=2))
