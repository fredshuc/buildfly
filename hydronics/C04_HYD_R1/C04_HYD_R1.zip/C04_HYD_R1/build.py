"""C04 hydronics integration model. Run: python build.py C04_INSTALLED.step M101_single_C04.step OUT
CadQuery 2.7. Millimetres. All hydraulic metal is routing or installation envelope, not fabrication geometry."""
from pathlib import Path
import cadquery as cq
import math,itertools,sys,csv,json,hashlib
from collections import defaultdict
V=cq.Vector
hostp,hxp,out=map(Path,sys.argv[1:4]);out.mkdir(exist_ok=True,parents=True)
def savejson(n,x): (out/n).write_text(json.dumps(x,indent=2))
def csvout(n,fields,rows):
 with (out/n).open('w',newline='') as f:
  w=csv.writer(f);w.writerow(fields);w.writerows(rows)
def box(x,y,z,a,b,c):return cq.Solid.makeBox(a,b,c,V(x,y,z))
def cyl(p,q,r):
 v=V(*q)-V(*p);return cq.Solid.makeCylinder(r,v.Length,V(*p),v.normalized())
def bounds(s):
 b=s.BoundingBox();return [b.xmin,b.ymin,b.zmin,b.xmax,b.ymax,b.zmax]
def boxes(a,b):return all(min(a[i+3],b[i+3])-max(a[i],b[i])>1e-5 for i in range(3))
def addpart(n,s):assert s.isValid(),n; parts[n]=s
def tubegrp(n,edges,ro,ri):
 # Intersecting straight bores at elbows/tees: topology and swept material envelope, no vendor fitting radii.
 def solid(r):
  segs=[cyl(a,b,r) for a,b in edges]
  joints={p for e in edges for p in e if sum(p in t for t in edges)>1}
  for p in joints:segs.append(cq.Solid.makeSphere(r,V(*p),angleDegrees1=-90))
  return segs[0].fuse(*segs[1:]).clean() if len(segs)>1 else segs[0]
 outer,inner=solid(ro),solid(ri)
 addpart(n,outer.cut(inner).clean())
 vols[n]=inner.Volume()/1e6
 for a,b in edges:routes.append([n,*a,*b,ro*2,ri*2])
def chain(*p):return list(zip(p,p[1:]))
parts={};sweeps={};vols={};routes=[];points=[];bom=[];ports={}; endcaps={}
level={'CR':2100,'CS':1840,'HR':1510,'HS':1230}; xh=1160; yz={'A':-75.325,'B':764.675}
for bed,y in yz.items():
 for w,y0,codes in [('W1',y,('CS','HS')),('W2',y-150,('CR','HR'))]:
  tag=bed+'_'+w; p=(615,y0,2370);ports[tag]=p
  points.append([tag,*p,'+X','Rp1-1/4 female','SUPPLY' if w=='W1' else 'RETURN'])
  tubegrp(tag+'_DETACHABLE_SPOOL',chain(p,(805,y0,2370)),16.85,13.65)
  # two separable joints; oversized front coupling stays inside original OD85 reserve
  for xx in [632,780]:
   addpart(tag+'_UNION_'+str(xx),cyl((xx,y0,2370),(xx+23,y0,2370),35).cut(cyl((xx,y0,2370),(xx+23,y0,2370),16.85)))
  hi,lo=[level[c] for c in codes]
  edges=chain((805,y0,2370),(875,y0,2370),(875,y0,hi),(875,y0,lo),(952,y0,lo))+[((875,y0,hi),(952,y0,hi))]
  if w=='W1':
   # bed-side service takeoff continuously open to the trapped coil. RV/EV not sized or represented as selected products.
   mid=(875,y0,1600);edges=chain((805,y0,2370),(875,y0,2370),(875,y0,hi),mid,(875,y0,lo),(952,y0,lo))+[((875,y0,hi),(952,y0,hi)),(mid,(875,y0-60,1600))]
   points.append([bed+'_TRV_EV',(875),y0-60,1600,'-Y','open bed-side takeoff; final adapter and relief sizing pending','no isolation between HX and thermal relief'])
  tubegrp(tag+'_BED_TREE',edges,16.85,13.65)
  for c in codes:
   z=level[c];n=bed+'_XV_'+c
   addpart(n,box(952,y0-32,z-32,116,64,64).fuse(box(971,y0-52,z+32,78,104,115)).clean())
   sweeps[n]=box(971,y0-52,z+147,78,104,235)
   bom.append([n,'DN25 two-way on/off, CLOSED on loss of power, independent open/closed proof','engineering envelope only',1010,y0,z])
   points.append([n,1010,y0,z,'+X toward header; supply flow -X, return +X','ends X952/X1068','FLOW ROUTE '+c])
for c,z in level.items():
 isret=c.endswith('R');yA=yz['A']-(150 if isret else 0); yB=yA+840
 e=[((1068,y,z),(xh,y,z)) for y in (yA,yB)]
 a=(xh,yA,z);b=(xh,yB,z); cap=(xh,yB+28,z)
 e+=chain(cap,b,a)
 if isret:
  # DN32 full-flow envelope from merge to TA; straight inlet from bed-A tee
  e+=chain(a,(xh,-435,z))
  tubegrp(c+'_HEADER_UP',e,21.2,17.95)
  addpart('TA_'+c,box(xh-48.5,-635,z-28,97,200,191))
  sweeps['TA_'+c]=box(xh-48.5,-635,z+163,97,200,75)
  bom.append(['TA_'+c,'IMI TA-Smart DN32 G1 1/2; sensor housing in corresponding supply','catalogue L/W/H envelope only',xh,-535,z])
  e=chain((xh,-635,z),(xh,-733,z),(1360,-733,z)); tubegrp(c+'_OUTLET',e,21.2,17.95)
 else:
  e+=chain(a,(xh,-535,z),(xh,-733,z),(1360,-733,z)); tubegrp(c+'_HEADER',e,21.2,17.95)
  addpart('TT_'+c,box(xh-20,-570,z+21.2,40,70,70))
  sweeps['TT_'+c]=box(xh-20,-570,z+91.2,40,70,75)
 points.append([c+'_SITE',1360,-733,z,'+X outward','DN32 design connection','supply into skid' if not isret else 'return out of skid'])
 endcaps[c]=cap
# Rack bears on inner faces of the rear corner posts, independent of the HX headers and air cassette.
for c,z in level.items():
 pieces=[box(x,-800,z-86,32,1600,34) for x in (1085,1144)]
 pieces+= [box(1085,y,z-86,205,24,34) for y in (-800,776)]
 for bed,yy in yz.items():
  v=yy-(150 if c.endswith('R') else 0)
  pieces.append(box(994,v-18,z-52,123,36,12));pieces.append(box(994,v-18,z-40,32,36,8))
 for yy in (-410,185,535):
  saddle=box(1144,yy-16,z-52,32,32,39).cut(cyl((xh,yy-17,z),(xh,yy+17,z),21.21))
  pieces.append(saddle)
 carrier=pieces[0].fuse(*pieces[1:]).clean();addpart('RACK_'+c,carrier)
 cap=endcaps[c];addpart('CAP_'+c,cyl(cap,(cap[0],cap[1]+3,cap[2]),21.2))
# Water island catch tray, separate from the air-side condensate pans. Outlet is an interface only.
tray=box(889,-790,1118,350,1580,18).cut(box(890.5,-788.5,1119.5,347,1577,19)).cut(cyl((1210,-700,1117),(1210,-700,1121),10))
addpart('WATER_DRIP_TRAY',tray)
points.append(['TRAY_DRAIN',1210,-700,1118,'-Z','20 mm hole; drain/slope detail pending','non-pressurised catch tray'])
# Scoped service items. Opening actual host back skin at four ports is part of the candidate.
# Tray and rack are nominal seat geometry. Relief/vent internals and attachment details are not represented.
host={};removed=[];cuts=[]
for s,n,loc,_ in cq.Assembly.importStep(str(hostp)):
 n=n.replace('/','__');s=s.located(loc)
 if n.endswith(('_BODY_REFERENCE','_ACTUATOR_REFERENCE','_RESERVE_OD85')):
  removed.append(n);continue
 if n.endswith('BACK_SKIN'):
  for c,z in level.items():
   h=cyl((1308,-733,z),(1314,-733,z),55);vol=s.intersect(h).Volume()
   assert vol>1000,(c,vol)
   s=s.cut(h);cuts.append([c,1310,-733,z,110,round(vol,3)])
 host[n]=s
# Physical detailed HX for collision and inclusion in installed assembly; shell fin/frame references removed in assembled view only.
hx=cq.importers.importStep(str(hxp)).val(); hxes={}
for bed,ty in [('A',-802.175),('B',37.825)]:
 hxes[bed+'_M101_DETAILED']=hx.translate((265,ty,1150))
def audit(left,right,internal=False):
 bl={k:bounds(s) for k,s in left.items()};br={k:bounds(s) for k,s in right.items()};bad=[]
 for a,b in itertools.combinations(left,2) if internal else itertools.product(left,right):
  if boxes(bl[a],br[b]):
   v=left[a].intersect(right[b]).Volume()
   if v>0.001:bad.append([a,b,round(v,4)])
 return bad
# Regression: the old Y-wide rail crossed the pulling CS head while missing its installed actuator.
probe=box(994,-800,2014,32,1600,34)
assert not audit({'A_XV_CS':parts['A_XV_CS']},{'old_rail':probe}) and audit({'A_XV_CS':sweeps['A_XV_CS']},{'A_XV_CS':parts['A_XV_CS'],'old_rail':probe})
bad={'internal':audit(parts,parts,True),'host':audit(parts,host),'hx':audit(parts,hxes),'service_host':audit(sweeps,host),'service_parts':audit(sweeps,parts),'service_hx':audit(sweeps,hxes)}
print('CLASH',bad,flush=True)
if any(bad.values()):savejson('interim_clashes.json',bad);raise RuntimeError(bad)
def assembly(name,d):
 a=cq.Assembly(name=name)
 for n,s in d.items():
  cold=('_CS' in n or '_CR' in n or n[:2] in ('CS','CR'))
  hot=('_HS' in n or '_HR' in n or n[:2] in ('HS','HR'))
  color=(.15,.46,.84) if cold else ((.9,.35,.17) if hot else (.53,.67,.67))
  a.add(s,name=n,color=cq.Color(*color))
 return a
hyd=assembly('HYD_R1',parts);hyd.save(str(out/'HYD_R1.step'))
svc=assembly('SERVICE_RESERVES',sweeps);svc.save(str(out/'service_keepouts.step'))
ins=cq.Assembly(name='C04_HYD_R1_WATER_BAY'); ins.add(hyd,name='WATER')
for n,s in host.items():
 if any(k in n for k in ['FIN_VOLUME_REF','HX_FRAME_REF','WATER_GLAND','BACK_SKIN','POST_','ROOF_RAIL','SIDE_']):
  ins.add(s,name=n,color=cq.Color(.64,.67,.70,.40))

ins.save(str(out/'C04_HYD_R1_WATER_BAY.step'))
# Readback counts and bbox of exports against source native assembly
exports={}
for f0,a in [('HYD_R1',hyd),('service_keepouts',svc),('C04_HYD_R1_WATER_BAY',ins)]:
 p=out/(f0+'.step');ref=a.toCompound();got=cq.importers.importStep(str(p)).val()
 bbmax=max(abs(i-j) for i,j in zip(bounds(ref),bounds(got)));volrel=abs(got.Volume()-ref.Volume())/ref.Volume()
 exports[f0]={'source_solids':len(ref.Solids()),'readback_solids':len(got.Solids()),'bbox_delta_mm':bbmax,'volume_relative_delta':volrel,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 assert exports[f0]['source_solids']==exports[f0]['readback_solids'] and bbmax<0.001 and volrel<1e-6
bc={k:bounds(s) for k,s in parts.items()}; bs={k:bounds(s) for k,s in sweeps.items()}
savejson('fit.json',dict(source_sha256={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in [hostp,hxp]},interferences_mm3=bad,tolerance_mm3=.001,water_parts=len(parts),removed_reference_groups=removed,host_groups_retained=len(host),per_bed_HX_solids=len(hx.Solids()),catalog_and_proxy_pull_top_mm={k:round(v[5],3) for k,v in bs.items()},roof_underside_mm=2550,min_roof_clearance_after_full_withdrawal_mm=round(min(2550-v[5] for v in bs.values()),3),after_removing_spool_HX_xmax_mm=max(bounds(s)[3] for s in hxes.values()),remaining_hydraulic_xmin_mm=min(v[0] for k,v in bc.items() if not ('UNION_' in k or 'DETACHABLE' in k)),bores_l=vols,exports=exports))
csvout('interfaces.csv',['id','x_mm','y_mm','z_mm','axis_or_direction','interface','function'],points)
csvout('routes.csv',['group','x1','y1','z1','x2','y2','z2','OD_mm','ID_mm'],routes)
csvout('catalog_and_envelopes.csv',['tag','function','basis','x','y','z'],bom)
csvout('rear_skin_changes.csv',['header','x_outer_region_start','y','z','hole_dia_mm','intersection_removed_mm3'],cuts)
assert len(removed)==12 and len(cuts)==4
assert not any(bad.values()),bad
