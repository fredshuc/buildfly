"""Build the one-page English sign-off sheet from the single CSV. python print_signoff.py [OUTPUT_DIR]"""
from pathlib import Path
from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.colors import HexColor,Color,white
from reportlab.lib.utils import simpleSplit
import csv,hashlib,sys
d=Path(__file__).resolve().parent;o=Path(sys.argv[1]) if len(sys.argv)>1 else d
p=d/'PORT_FUNCTION_REGISTER.csv';rows=list(csv.DictReader(p.open()))
digest=hashlib.sha256(p.read_bytes()).hexdigest()
c=Canvas(str(o/'C06_HX_PORT_SIGNOFF.pdf'),pagesize=A4);W,H=A4
c.setTitle('C06 | HX water-port acceptance / RT2 N7')
navy=HexColor('#193243');teal=HexColor('#176b70');gray=HexColor('#506570');light=HexColor('#e7f2f1');line=HexColor('#beced0')
def t(x,y,s,fs=10,b=False,color=navy):
    c.setFillColor(color);c.setFont('Helvetica-Bold' if b else 'Helvetica',fs);c.drawString(x,y,s)
def wrap(s,x,y,w=495,fs=10,step=14):
    for tx in simpleSplit(s,'Helvetica',fs,w):
        t(x,y,tx,fs);y-=step
    return y
def rule(y):
    c.setStrokeColor(line);c.setLineWidth(.6);c.line(38,y,W-38,y)
def field(name,x,y,w,h,help):
    c.acroForm.textfield(name=name,tooltip=help,x=x,y=y,width=w,height=h,
        fontSize=10,fontName='Helvetica',borderWidth=.65,borderColor=line,textColor=navy,fillColor=HexColor('#f6f9fa'),forceBorder=True)
t(38,797,'AIRTRANSFORMER     /     L2-E HYDRONICS  +  M101 HEAT EXCHANGER',9,True,teal)
t(38,757,'Installed water-port acceptance',26,True)
t(39,735,'C06  /  Twin bed, 1280 mm pitch  /  RT2 finding N7',12,False,gray)
c.setFillColor(HexColor('#fff3dd'));c.roundRect(38,678,W-76,39,5,fill=1,stroke=0)
t(50,700,'OPEN   |   HX owner decision required',12,True,HexColor('#76490f'))
t(50,686,'Prototype detailing only. This form does not release wet operation or fabrication.',9,False,navy)
t(38,654,'01    Union faces in installed shell coordinates',13,True,teal)
t(38,638,'All four faces: X615 mm, Z2370 mm, outward normal +X, Rp 1-1/4 female.',10)
cols=[44,98,170,298,432];y=607
c.setFillColor(light);c.rect(38,600,W-76,21,stroke=0,fill=1)
for x,s in zip(cols,['Port','Y (mm)','Cold / selector','Hot / selector','Water vector']):t(x,y,s,9,True)
for i,r in enumerate(rows):
    y-=23
    for x,s in zip(cols,[r['port'],r['y_mm'],r['cold_service']+' / '+r['cold_selector'],r['hot_service']+' / '+r['hot_selector'],r['water_vector_at_union']+('  into HX' if r['port'].endswith('1') else '  out of HX')]):t(x,y,s,10)
    rule(y-8)
t(38,492,'CS / CR = cold supply / return.    HS / HR = hot supply / return.',9,False,gray)
t(38,461,'02    HX owner: confirm the design basis',13,True,teal)
y=438
for i,s in enumerate([
'Allow both cold and hot water to enter W1 and leave W2 on both beds. This reverses the hot flow direction in the historical C04 HX register.',
'Identify the crest and bleed path of each top header in both modes, including the W2 offset, unions and installation tolerances. Attach a marked-up drawing. The four external bleed seats alone do not prove venting inside the HX.',
'Agree the cold-fill purge verification and regeneration-direction performance comparison in the water handoff. If the legacy direction is mandatory, return the design for a piping and control revision.']):
    t(39,y,str(i+1)+'.',10,True,teal);y=wrap(s,57,y,494,10,14)-9
t(38,281,'03    Record the decision and evidence',13,True,teal)
t(38,259,'Decision: enter ACCEPT or RETURN',9,True);field('decision',38,231,209,23,'ACCEPT or RETURN')
t(266,259,'Date (YYYY-MM-DD)',9,True);field('date',266,231,150,23,'Date')
t(38,214,'HX owner name',9,True);field('owner_name',38,186,209,23,'HX owner name')
t(266,214,'Signature / controlled approval reference',9,True);field('approval_reference',266,186,290,23,'Sign by hand, or provide controlled approval reference')
t(38,168,'Drawing ID and revision, vent-path evidence, or reason for return',9,True)
field('evidence',38,139,W-76,24,'Evidence or reason for return; attach marked drawing')
t(38,115,'A typed name alone is not a controlled approval. Archive the signed copy against the CSV digest.',9,False,gray)
rule(89)
t(38,72,'C06-HYD-R2 / base 205f9c2   |   SHA-256 of PORT_FUNCTION_REGISTER.csv',8,True,gray)
t(38,58,digest,8)
c.showPage();c.save()
