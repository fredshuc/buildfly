"""C06 HYD-R2 geometry delta. Python 3.12 / CadQuery 2.7.
Usage: python build_check.py C06_EXTRACTED D01_CAD_DIR M101_SINGLE_STEP OUT_DIR
"""
from pathlib import Path
import sys, math, json, warnings
import cadquery as cq
from OCP.STEPCAFControl import STEPCAFControl_Reader
from OCP.TDocStd import TDocStd_Document
from OCP.XCAFDoc import XCAFDoc_DocumentTool
from OCP.TDF import TDF_LabelSequence,TDF_Label
from OCP.TDataStd import TDataStd_Name
from OCP.TCollection import TCollection_ExtendedString
from OCP.TopLoc import TopLoc_Location
from OCP.IFSelect import IFSelect_RetDone
from collections import Counter
warnings.filterwarnings("ignore",category=FutureWarning)
src,d01,hx,out=map(Path,sys.argv[1:])
out.mkdir(exist_ok=True,parents=True)
v=cq.Vector
def leaves(path):
    doc=TDocStd_Document(TCollection_ExtendedString("read")); r=STEPCAFControl_Reader()
    r.SetNameMode(True); assert r.ReadFile(str(path))==IFSelect_RetDone and r.Transfer(doc)
    tree=XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
    def name(l):
        a=TDataStd_Name();return a.Get().ToExtString() if l.FindAttribute(TDataStd_Name.GetID_s(),a) else ""
    def walk(l,loc,path):
        if tree.IsReference_s(l):
            t=TDF_Label();tree.GetReferredShape_s(l,t);yield from walk(t,loc*tree.GetLocation_s(l),path+[name(l)])
        elif tree.IsAssembly_s(l):
            seq=TDF_LabelSequence();tree.GetComponents_s(l,seq)
            for i in range(1,seq.Length()+1):yield from walk(seq.Value(i),loc,path+[name(l)])
        else:yield '/'.join(path+[name(l)]),cq.Shape.cast(tree.GetShape_s(l).Moved(loc))
    root=TDF_LabelSequence();tree.GetFreeShapes(root)
    for i in range(1,root.Length()+1):yield from walk(root.Value(i),TopLoc_Location(),[])
def cyl(p,axis,r,l):return cq.Solid.makeCylinder(r,l,v(*p),v(*axis))
def zc(x,y,z,r,h):return cyl((x,y,z),(0,0,1),r,h)
def box(x,y,z,L,W,H):return cq.Solid.makeBox(L,W,H,v(x,y,z))
def ext(points,t):
    wire=cq.Wire.makePolygon([v(*p) for p in points],close=True)
    return cq.Solid.extrudeLinear(wire,[],v(0,0,t))
def bb(s):
    b=s.BoundingBox();return [b.xmin,b.ymin,b.zmin,b.xmax,b.ymax,b.zmax]
def overlaps(a,b):return all(min(a[i+3],b[i+3])-max(a[i],b[i])>1e-6 for i in range(3))
def save(parts,name):
    a=cq.Assembly(name=name)
    for tag,s in parts.items():
        assert s.isValid() and len(s.Solids())==1,(tag,len(s.Solids()))
        a.add(s,name=tag)
    path=out/(name+'.step');a.save(str(path))
    back=cq.importers.importStep(str(path)).val()
    assert back.isValid() and len(back.Solids())==len(parts)
water={n.split('/')[-1]:s for n,s in leaves(src/'C06_WATER_FIT.step')}
# Four sloping folded fields finish on a 40 x 40 horizontal outlet weld pad.
cx,cy,z0=1210,-700,1118
xl,xr,yl,yr=889,1239,-790,1230
outer=[(xl,yl,z0+10),(xr,yl,z0+10),(xr,yr,z0+10),(xl,yr,z0+10)]
inner=[(cx-20,cy-20,z0),(cx+20,cy-20,z0),(cx+20,cy+20,z0),(cx-20,cy+20,z0)]
fields=[ext([outer[i],outer[(i+1)%4],inner[(i+1)%4],inner[i]],1.5) for i in range(4)]
rim=box(xl,yl,z0+10,xr-xl,yr-yl,8).cut(box(xl+1.5,yl+1.5,z0+9,xr-xl-3,yr-yl-3,10))
pan=ext(inner,1.5).fuse(*fields,rim).cut(zc(cx,cy,z0-2,10,5)).clean()
# Bent open-bore tail: no air-side drain or relief discharge is connected.
alpha=math.atan(.02);R=25;zc0=1095;xc=cx+R;tend=1.5*math.pi-alpha
point=lambda t:v(xc+R*math.cos(t),cy,zc0+R*math.sin(t))
p0=v(cx,cy,z0);p1=point(math.pi);p2=point(tend);pend=v(1390,cy,p2.z-.02*(1390-p2.x))
wire=cq.Wire.assembleEdges([cq.Edge.makeLine(p0,p1),cq.Edge.makeThreePointArc(p1,point((math.pi+tend)/2),p2),cq.Edge.makeLine(p2,pend)])
tail=cq.Workplane(cq.Plane(origin=p0,normal=(0,0,-1))).circle(13).circle(10).sweep(wire).val()
collar=zc(cx,cy,z0-2,19,2).cut(zc(cx,cy,z0-3,11.5,4))
tail=tail.fuse(collar).clean()
skin_items={n.split('/')[-1]:s for n,s in leaves(src/'C06_SHEET_METAL.step')}
oldskin=skin_items['BACK_SKIN'];sb=bb(oldskin);sx=(sb[0]+sb[3])/2;sz=p2.z-.02*(sx-p2.x)
bore=cyl((sb[0]-2,cy,sz),(1,0,0),23,sb[3]-sb[0]+4)
# High-point pressure tapping geometry is proposed; final manual valve and tool are envelopes only.
parts={'WATER_DRIP_TRAY':pan,'WATER_TRAY_TAIL':tail};env={};notes={};bosses={}
for tag in ('A_W1','A_W2','B_W1','B_W2'):
    key=tag+'_BED_TREE';y={'A_W1':-75.325,'A_W2':-225.325,'B_W1':1204.675,'B_W2':1054.675}[tag]
    x=837;z=2370
    ring=zc(x,y,z,8,42).cut(zc(x,y,z-1,4,44))
    boss=ring.cut(cyl((804,y,z),(1,0,0),16.85,72));bosses[tag]=boss
    # Open the upper tube wall ONLY; below z+12 is original water space.
    cutter=zc(x,y,z+12,4,36)
    tree=water[key];cutvol=tree.intersect(cutter).Volume();assert cutvol>100
    parts[key]=tree.cut(cutter).fuse(boss).clean()
    # Confirm a continuous empty bore from the pipe lumen to the future bleed valve seat.
    assert parts[key].intersect(zc(x,y,z+11,3.99,32)).Volume()<.001
    env[tag+'_MANUAL_BLEED_BODY']=zc(x,y,2412,16,38)
    env[tag+'_BLEED_TOOL']=zc(x,y,2450,25,50)
    notes[tag]=dict(x=x,y=y,union_axis_z=z,seat_z=2412,tool_top_z=2500,opened_wall_mm3=round(cutvol,3))
delta={**parts,**env}; db={k:bb(s) for k,s in delta.items()}
finds={};counts={};limit=.001
def screen(group,items):
    bad=[];count=0
    for n,s in items:
        count+=1;b=bb(s)
        for k,ds in delta.items():
            if overlaps(db[k],b):
                vol=ds.intersect(s).Volume()
                if vol>limit:bad.append([k,n,round(vol,4)])
    counts[group]=count;finds[group]=bad;print(group,count,bad[:4],flush=True)
screen('retained_water',((k,s) for k,s in water.items() if k not in parts))
screen('existing_water_service',leaves(src/'C06_WATER_SERVICE.step'))
screen('shell_before_requested_bore',skin_items.items())
old_hits=finds['shell_before_requested_bore']
assert len(old_hits)==1 and old_hits[0][:2]==['WATER_TRAY_TAIL','BACK_SKIN'],old_hits
screen('shell_with_local_bore',((k,s.cut(bore) if k=='BACK_SKIN' else s) for k,s in skin_items.items()))
screen('D01_service',leaves(d01/'D01_SERVICE_ENVELOPES.step'))
screen('M101_installed',((bed+str(i),s.translate((265,y,1150))) for bed,y in [('A',-802.175),('B',477.825)] for i,s in enumerate(cq.importers.importStep(str(hx)).val().Solids())))
screen('D01_installed',((n,s) for n,s in leaves(d01/'D01_EIGHT_DAMPERS_INSTALLED.step') if '/HOST/' not in n and not n.split('/')[-1].startswith('HOST_')))
inside=[]
for i,(k,s) in enumerate(delta.items()):
    for t,ss in list(delta.items())[i+1:]:
        if overlaps(db[k],db[t]):
            vol=s.intersect(ss).Volume()
            if vol>limit:inside.append([k,t,round(vol,4)])
assert not inside,inside
assert all(not a for k,a in finds.items() if k!='shell_before_requested_bore'),finds
assert counts['D01_installed']==7212 and counts['M101_installed']==1074 and counts['shell_with_local_bore']==327
# Total floor-to-tail bore continuity (center through 1.5 mm pan, collar, and first length).
assert pan.fuse(tail).intersect(zc(cx,cy,z0-12,9.99,16)).Volume()<limit
save(parts,'C06_HYD_R2_REPLACEMENTS_AND_TAIL');save(env,'C06_HYD_R2_BLEED_ENVELOPES');save({'WATER_TAIL_REAR_SKIN_BORE':bore},'C06_HYD_R2_SHELL_BORE_TOOL')
report=dict(units='mm; intersection volumes mm3; solid clash threshold 0.001 mm3',checks=finds,counts=counts,internal_hits=inside,
water_original_items=len(water),new_physical_parts=len(parts),replaced_names=[k for k in parts if k in water],additional_name='WATER_TRAY_TAIL',envelope_count=len(env),
rear_skin_bore=dict(x_mid=sx,y=cy,z=round(sz,4),diameter=46,skin_x=[sb[0],sb[3]]),
tail_outlet=[pend.x,pend.y,round(pend.z,4)],tail_ID_OD_mm=[20,26],tray_bed_mm=[xl,xr,yl,yr],tray_max_rim_z=1136,
long_face_grade_percent=round(100*10/(yr-(cy+20)),4),shallowest_fold_grade_percent=round(100*10/math.hypot(yr-(cy+20),(cx-20)-xl),4),tail_grade_percent=2,bleeds=notes)
(out/'geometry_checks.json').write_text(json.dumps(report,indent=2)+'\n')
