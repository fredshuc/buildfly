"""Check canonical rows against the delivered C06 interfaces, HX RT1 family geometry,
and closed-valve states. Generate hydraulic screen and a read-only printable signing view.
python check_interface.py C06_EXTRACTED HX_RT1_EXTRACTED HYD_R1_EXTRACTED [OUT]
"""
from pathlib import Path
import csv,math,sys,json,hashlib,subprocess,tempfile,html
here=Path(__file__).resolve().parent
c,h,r=map(Path,sys.argv[1:4]);out=Path(sys.argv[4]) if len(sys.argv)>4 else here
out.mkdir(exist_ok=True,parents=True)
reg=here/'PORT_FUNCTION_REGISTER.csv'
def rows(p):
    with p.open() as f:return list(csv.DictReader(f))
ports=rows(reg);source={x['id']:x for x in rows(c/'interfaces.csv')};hx={x['port']:x for x in rows(h/'INSTALLED_PORTS.csv')};tags=set()
assert [p['port'] for p in ports]==[b+'.W'+str(i) for b in 'AB' for i in (1,2)]
for p in ports:
    bed,role=p['port'].split('.');s=source[bed+'_'+role];old=hx[p['port']]
    assert [float(s[k]) for k in ('x_mm','y_mm','z_mm')]==[float(p[k]) for k in ('x_mm','y_mm','z_mm')]
    assert (float(old['face_x']),float(old['y'])+(440 if bed=='B' else 0),float(old['z']))==tuple(float(p[k]) for k in ('x_mm','y_mm','z_mm'))
    assert old['outward_normal']==s['direction']==p['face_normal']=='+X' and s['connection']==p['connection']
    sup=role=='W1';assert (s['function'],p['water_vector_at_union'])==(('SUPPLY','-X') if sup else ('RETURN','+X'))
    for mode,prefix in [('cold','C'),('hot','H')]:
        code=p[mode+'_service'];tag=p[mode+'_selector']
        assert code==prefix+('S' if sup else 'R') and tag==bed+'_XV_'+code and float(source[tag]['y_mm'])==float(p['y_mm'])
        assert ((code==old[mode+'_service'])==(mode=='cold'))
        tags.add(tag)
assert len(tags)==8
with tempfile.TemporaryDirectory() as tm:
    subprocess.run([sys.executable,str(r/'hydraulic_logic.py'),tm],check=True)
    for fname in ('sequences.csv','all_256_feedback_states.csv','logic_results.json'):
        assert (Path(tm)/fname).read_bytes()==(r/fname).read_bytes()
    states=rows(Path(tm)/'all_256_feedback_states.csv');seq=rows(Path(tm)/'sequences.csv')
    steady=[s for s in states if s['classification']=='STEADY_TWO_BEDS']
    assert len(states)==256 and len(steady)==2
    for s in steady:
        active={k for k in tags if s[k]=='1'}
        hotcold=[]
        for b in 'AB':
            modes=[mode for mode in ('hot','cold') if all(p[mode+'_selector'] in active for p in ports if p['port'].startswith(b))]
            assert len(modes)==1;hotcold+=modes
        assert set(hotcold)=={'hot','cold'}
    for s in seq:
        if s['mode']=='direct' and s['pump_permit_after_proof']!='OFF':
            assert s['pump_permit_after_proof']=='STEADY' and any(all(x[k]==s[k] for k in tags) for x in steady)
d=.0359;area=math.pi*d**2/4
q=[1.72,2,2.58];range_kpa={str(Q):[round(f*.88/d*1000*(Q/3600/area)**2/2000,4) for f in (.02,.035)] for Q in q}
v=11+1.67;dv=v*(999.97/971.8-1);cross=11*4.18*50/1000
saddles=[-410,185,535,975];supply_cap=1204.675+28;return_cap=supply_cap-150
report=dict(register_SHA256=hashlib.sha256(reg.read_bytes()).hexdigest(),verified_ports=4,verified_selectors=8,source_baseline='205f9c2f3cf4df45d1bed5dff193eb12fb8f4b6e',modes='4 cold functions retained, 4 hot functions supersede historical HX labels; owner signature pending',
logic_rerun=json.loads((r/'logic_results.json').read_text()),pipe_inner_diameter_mm=d*1000,added_m_per_header=.44,added_L_per_header=round(.44*area*1000,4),added_L_four_headers=round(4*.44*area*1000,4),incremental_B_path_loss_range_kPa=range_kpa,
header_saddle_Y_mm=saddles,adjacent_saddle_intervals_mm=[b-a for a,b in zip(saddles,saddles[1:])],supply_return_outboard_cap_from_saddle_mm=[round(x-975,3) for x in (supply_cap,return_cap)],added_length_growth_75K_mm=round(.44*17e-6*75*1000,3),
screen_water_L_per_isolated_bed=v,screen_acceptance_L_5_to_80C=round(dv,4),coil_only_carryover_L=11,enthalpy_MJ_50K_per_bed_transition=round(cross,3),nominal_sensible_heat_portion_kW_each_source_at_10_to_12min=[round(cross*1000/x,3) for x in (720,600)],
coil_only_2m3h_transit_s=round(11/(2000/3600),2),screen_upper_inventory_MJ_if_all_12p67L_displaced_50K=round(v*4.18*50/1000,3))
(out/'interface_checks.json').write_text(json.dumps(report,indent=2)+'\n')
# Signed snapshots refer to the digest. Never change the canonical rows in this rendering.
table=''.join('<tr>'+''.join('<td>'+html.escape(str(a))+'</td>' for a in [p['port'],p['x_mm']+' / '+p['y_mm']+' / '+p['z_mm'],p['cold_service']+' · '+p['cold_selector'],p['hot_service']+' · '+p['hot_selector'],p['water_vector_at_union']])+'</tr>' for p in ports)
page="""<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>C06 水口接口签认 | N7</title><style>
*{box-sizing:border-box}body{max-width:950px;margin:36px auto;padding:0 22px;font:16px/1.55 system-ui,sans-serif;color:#182d39}h1,h2{line-height:1.23}h1{margin:8px 0 14px;font-size:30px}h2{font-size:19px;margin:22px 0 5px}p{margin:6px 0 10px}.ey{font-size:13px;font-weight:700;letter-spacing:.1em;color:#245f68}.status{border-left:5px solid #a56221;background:#fff5e8;padding:10px 12px;margin:12px 0}table{width:100%;border-collapse:collapse;font-size:14px;margin:14px 0}th,td{text-align:left;border-bottom:1px solid #c5d1d4;padding:8px 6px}th{background:#e9f3f2}small{font-size:12px;color:#425866}footer{margin-top:18px;border-top:1px solid #9fb1b7;padding-top:8px;overflow-wrap:anywhere}li{margin-bottom:5px}@media print{body{margin:0;padding:0;max-width:none}table{break-inside:avoid}h1{font-size:24px}h2{font-size:16px}p,li{font-size:13px}}@page{size:A4;margin:15mm}</style>
<div class="ey">AIRTRANSFORMER · C06 · L2-E HYDRONICS / M101 HX · RT2 N7</div>
<h1>装机水口签认单 / Installed water-port acceptance</h1>
<div class="status"><b>待 HX 负责人签认 / OPEN — HX owner signature pending.</b><br>用于原型深化；本页没有授权通水、下料或生产。</div>
<p>以下为 PORT_FUNCTION_REGISTER.csv 的只读打印视图。尺寸为机壳坐标，单位 mm。四个活接端面的外法线均为 +X；最后一列是水在活接处的实际流动方向。CS/CR：冷供/冷回；HS/HR：热供/热回。</p>
<table><thead><tr><th>芯体口</th><th>X / Y / Z (mm)</th><th>冷工况与阀号</th><th>热工况与阀号</th><th>水流</th></tr></thead><tbody>TABLE</tbody></table>
<h2>请 HX 负责人确认 / HX decision</h2>
<ol><li>Cold and hot may both enter W1 and leave W2 on both installed cores. Accept the reversed regeneration direction relative to the C04 HX register, or list the required correction below.</li>
<li>Confirm each installed upper header and W2 offset can release air to its own proposed bleed point in both modes. Identify the drawing, crest heights, gradients/installation tolerance and any internal high pocket requiring a separate bleed. The bottom drains and W1 relief branch do not prove venting.</li>
<li>Agree the purge verification and hot-direction performance comparison described in the accompanying handoff. If the legacy direction is mandatory, reject this register; revised piping and PLC logic are required.</li></ol>
<p>□ 接受以上接口 / Accept as detailed　　□ 退回修改 / Return with reason</p>
<p>HX 负责人（姓名/签字）__________________　日期 ____________</p>
<p>受控图号、排气路径证据及限制：_____________________________________</p>
<p>_______________________________________________________________</p>
<small>L2-E 技术意见：按此接法深化。实物排气、热侧对比、每床压力保护及切换验证另行记录。签认本页只批准接口，不替代湿测放行。</small>
<footer><small>C06-HYD-R2 · Git source 205f9c2 · SHA-256 of canonical CSV: DIGEST</small></footer></html>"""
(out/'C06_PORT_SIGNOFF.html').write_text(page.replace('TABLE</tbody>',table+'</tbody>').replace('DIGEST',report['register_SHA256']))
