# Register applicability: C04 and C06

**C04 (840 mm bed pitch):** the RT1 ZIP in this directory is the historical C04 reference. Its included INSTALLED_PORTS.csv, valve tags and hot-return assignment apply to that arrangement only. Keep the issued ZIP intact.

**C06 (1280 mm, eight selectors):** use the single [C06 installed water-port register](../../../hydronics/C06_RT2_HYD_R2/PORT_FUNCTION_REGISTER.csv) and its [HX sign-off sheet](../../../hydronics/C06_RT2_HYD_R2/C06_PORT_SIGNOFF.html). The conflicting hot-mode function and old bed-B coordinates inside the C04 ZIP do not apply to C06. This is the L2-E interface proposal for HX review, not an HX signature or a change to M101 internals. Live water is held; see the [release gates](../../../hydronics/C06_RT2_HYD_R2/README.md).
