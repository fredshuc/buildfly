"""Extract the historical 94-member water group in its original S1 machine frame."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/"AirTransformerShell/revisions/C09"))
from build_c09 import cq, leaves, bb
from OCP.BRep import BRep_Builder
from OCP.BRepTools import BRepTools
from OCP.TopoDS import TopoDS_Shape
from OCP.gp import gp_Trsf

def key(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run():
    subset=HERE/"LEGACY_WATER_SOURCE.json.gz"
    if len(sys.argv)>1:
        src=Path(sys.argv[1])
        with gzip.open(src,"rt",encoding="utf-8") as f:model=json.load(f)
        occ=[o for o in model["occurrences"] if o["group"]=="WATER"]
        assert len(occ)==94
        defs={o["definition"] for o in occ}
        data={"group":"WATER","parent_file":src.name,"parent_sha256":key(src),"occurrences":occ,
              "definitions":[d for d in model["definitions"] if d["definition"] in defs]}
        subset.write_bytes(gzip.compress(json.dumps(data,separators=(",",":")).encode(),mtime=0))
    with gzip.open(subset,"rt",encoding="utf-8") as f: data=json.load(f)
    asm=cq.Assembly(name="HISTORICAL_DB_MAIN_S1_WATER_REFERENCE")
    defs={}
    for d in data["definitions"]:
        shape=TopoDS_Shape()
        BRepTools.Read_s(shape,io.BytesIO(d["brep"].encode()),BRep_Builder())
        defs[d["definition"]]=cq.Shape.cast(shape)
    original={}
    for o in data["occurrences"]:
        r,t=o["R"],o["t"]
        tr=gp_Trsf();tr.SetValues(*r[0],t[0],*r[1],t[1],*r[2],t[2])
        s=defs[o["definition"]].moved(cq.Location(tr))
        original[o["occurrence"]]=bb(s);asm.add(s,name=o["occurrence"])
    out=HERE/"LEGACY_DB_MAIN_S1_WATER_REFERENCE.step"
    asm.save(str(out))
    readback={k.split("/")[-2]:bb(s) for k,s in leaves(out)}
    assert len(readback)==94 and set(readback)==set(original)
    err=max(abs(a-b) for k in readback for a,b in zip(readback[k],original[k]))
    assert err<.01,err
    (HERE/"LEGACY_REFERENCE_CHECK.json").write_text(json.dumps({
        "parent_sha256":data["parent_sha256"],"step_sha256":key(out),"occurrences":94,"source_group":"WATER",
        "roundtrip_max_bbox_delta_mm":err,"scope":"Historical four-core route only. Exclude from installed states and valve-position release."},indent=2))
if __name__=="__main__":run()
