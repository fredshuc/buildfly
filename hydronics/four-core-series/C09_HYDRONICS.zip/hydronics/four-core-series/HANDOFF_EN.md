# Four-core series changeover for the C09 shell

This is the shell integrator's record of the L2-E S0 return and a register for red-team review. The S0/P0 owner STEP files were reported under the names C08_HYD_SERIES_INSTALLED_P0.step and C08_HYD_SERIES_SERVICE_P0.step. The integrator did not obtain those binaries. Their actuator locations, service volumes and first-spool geometry are open. No valve coordinate, hole or water pipe in this record is a production datum.

## Circuit

Each bed contains two coils in series. Lower W2 connects to upper W1. In cold operation CS feeds lower W1 and upper W2 discharges to CR. In hot operation HS feeds upper W2 and lower W1 discharges to HR. The two beds take opposite operating states. Four two-way selection functions per bed give eight in the machine. Both coils carry the full bed flow, nominally 2.0 m³/h each at the nominal circuit operating point. The reported coil water content for a bed is 21.99 L, about 23 L with the active connecting pipework. Treat those as S0 estimates until measured. See PORTS_BY_MODE.csv for all eight ports.

## Shell coordination

Use the four-core H00 coordinates as the reference for the imported STEP only. The eight rear-wall pipe crossing centres in the C09 shell register lie on the X=-500 wall near the core. The eight terminal end faces lie at X=-576 and point toward -Z. A wall-crossing centre and an end-face centre are different datums. The older HX_PORTS.csv includes a flow-role column from before the four-core series correction. Use its coordinates and thread identity only. PORTS_BY_MODE.csv controls mode-dependent routing in this handoff.

The nominal 42 mm straight connection projection below the top-stage terminals meets the lower-stage return tube after 20.15 mm for W1 and 26.697 mm for W2. Shell changes alone cannot resolve this coil-to-spool conflict. Obtain the released unhanded end geometry, first removable spool and wrench envelope and check all eight connections, drains, air vents, bed switching, pipe insulation and actuator extraction before freezing a valve bracket or drilling an external pass-through. Shell pockets and subdivided elastomer glands may change when those owner envelopes arrive. Pre-qualify the 8-valve isolation logic with both fans unloaded during changeover.

## Original water hardware reference

LEGACY_DB_MAIN_S1_WATER_REFERENCE.step is a separate overlay of the 94 original WATER occurrences in the verified four-core DB_MAIN S1 machine (same axes). This preserves the original coordinates for route comparison. The C06 two-core HX function note assigned W1 to supply in both modes. L2-E retained hot flow in the reverse direction through both series coils for the four-core machine. Obtain joint HX/hydronics approval of that difference before wet operation. The historical overlay contains neither the new valve-position release nor proof of pipe/extraction clearance in C09. Rebuild with export_legacy.py from its bundled native subset.
