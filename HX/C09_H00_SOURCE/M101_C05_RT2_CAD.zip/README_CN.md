# M101 C05｜C06 RT2 换热器回包

日期：2026-11-05。发行角色：L2-HX，Codex 接续设计记录。单位 mm。

状态：HX 几何及接口候选，可供壳体与水路负责人整合复审。本包不放行切板、承压件制造、双床制造或热水运行。

## 交付入口

- [完整单芯 STEP（gzip）](M101_D952_P254_220_39x6_C05.step.gz)：解压后为 `M101_D952_P254_220_39x6_C05.step`。两床均使用该件，禁止镜像或旋转。本地交付同时保留未压缩 STEP。
- `C05_REPLACE_AND_ADD_LOCAL.step`：独立增量，**替换 C04 的四个同名零件，再增加十二件**。不得直接把它和完整 C05 重叠装配。
- `C05_VENT_SERVICE_LOCAL.step`：两个排气口的顶部工具预约，非实物。
- `C05_SHELL_MATING_REFERENCES_LOCAL.step`：八根密封拉杆与两个顶部销的配合参考，非 HX BOM。
- `C05_TIE_ROD_CORRIDORS_LOCAL.step`：拉杆每侧增加 2 mm 径向余量后的走廊，非实物。
- [当前装机端口功能表](C06_INSTALLED_PORT_FUNCTIONS.csv)、[L2-HX 条件签认](HX_FUNCTION_SIGNOFF.json)、[检查结果](C05_CHECKS.json)、[问题处置表](RT2_DISPOSITION.csv)。
- [English RT2 response](RT2_RESPONSE_EN.md) / [几何说明图](C05_RT2_HX_REVIEW.png)。
- [壳体配合要求](SHELL_INTERFACE_CN.md)、[水路流向及排气裁定](WATER_DIRECTION_AND_VENTING_CN.md)、[重建源代码](source/build_c05.py)。

## 实体修改

1. 接水盘沿用 C06 的 162×612 覆盖范围及沿 +Y 的 8 mm 落差，改为由 HX 携带。四个托耳连接盘侧壁与两根 HX 底横梁，底横梁增加四个固定孔预约。采用顶侧盲孔固定，不能在底脚下设置需拆装的散装螺母。M4 件为紧固包络；螺纹、盲孔深度、防松和托耳连接工艺仍需详图。
2. 原下伸到整机 Z1135 的硬嘴取消。芯上短接嘴底面为局部 Z9、整机 Z1159，比承托梁顶 Z1150 高 9 mm。排水软管及其软管侧接头必须先断开并移走，再连芯带盘抽出。采购接头若在抽芯时仍留在芯上，必须放入重新扫掠的实物模型。

盘底低/高端为局部 Z24/Z32，围边最高 Z42，距翅片底 Z54 保留12；短嘴轴线上约有15.89 mm长度。该值为几何预算，软管卡箍、止退结构和实际接头仍需选型确认。
3. W1、W2 两根顶端管各增加一个朝 +Z 的独立排气支口候选，位置为局部 X235、各自水口 Y、顶端 Z1252。排气孔参考 Ø4、支口外形 Ø12；盖帽为采购包络，最高 Z1257。未选择实际额定阀、螺纹或承压连接工艺。保温需设置可拆排气操作盖。
4. 533 个 C04 原零件直接保留。修改的四件是两根底横梁与两根 D35 端管。六程盘管、两根 39 支路集管、翅片、底脚、密封落座面、上导向耳及两只原厂活接形状保留。

## C06 安装变换

使用局部单芯坐标；两床旋转矩阵均为单位阵：

| 床 | 平移 X,Y,Z | W1 整机坐标 | W2 整机坐标 |
|---|---|---|---|
| A | 265, −802.175, 1150 | 615, −75.325, 2370 | 615, −225.325, 2370 |
| B | 265, 477.825, 1150 | 615, 1204.675, 2370 | 615, 1054.675, 2370 |

四个活接仍为 +X、Rp1¼ 内螺纹，同床水口中距 150。壳体 X750 穿板面与活接端面相距 135；该值不是短节下料长度。旧 C04 的 840 mm 两芯预览及 B 床坐标不能用于 C06。

## 验证边界

`C05_CHECKS.json` 记录实际 STEP 读回、增改件与其余芯体的交集、两床装机碰撞、排气工具预约、托耳接触及向外抽芯检查。阈值为 0.001 mm³。抽芯按 A 向 −Y、B 向 +Y，各 900 mm；固定障碍为原 C06 壳体删除指定服务件后的实体。报告区分连续包围盒证明与 5 mm 采样，不能把采样结果描述为连续扫掠证明。

该检查不替代整机拆装试验；旧 C06 侧板仍要求按其驱动机构顺序拆卸。排水软管、外接风管、电缆、吊具及实际采购排气阀和接头均需最终整合验证。未运行 FEA、CFD、模态或物理试验，未证明密封 ≤0.2% 旁通、压力额定值、排气性能或再生等效性能。

## 重建

Python 3.12 / CadQuery 2.8.0。在仓库根目录运行，先从 C06 工程包展开对应壳体 STEP：

```powershell
python HX/M101_D952_P254_220_39x6_C05/source/build_c05.py HX/M101_D952_P254_220_39x6_C04/M101_D952_P254_220_39x6_C04.step AirTransformerShell/revisions/C06/C06_SHEET_METAL.step
python HX/M101_D952_P254_220_39x6_C05/source/verify_vent_flow.py HX/M101_D952_P254_220_39x6_C04/M101_D952_P254_220_39x6_C04_NOMINAL_FLOW.step HX/M101_D952_P254_220_39x6_C05/VENT_FLOW_TOPOLOGY_CHECK.json
python HX/M101_D952_P254_220_39x6_C05/source/review_figure.py
python HX/M101_D952_P254_220_39x6_C05/source/finalize.py AirTransformerShell/revisions/C06/interfaces.csv
```

原 C04 单芯 SHA256 固定为 `efca1457db1e90731da5adccc963e49f197238e8cbdda91a1ae95d7c8a9646e5`。壳体输入 SHA256 与输出文件校验值见检查及清单。本地交付含完整 STEP；远端保存的文件范围以交付记录为准。

完整单芯在 Git 中只保存 gzip 压缩件，不重复保存未压缩副本。可用 Python 解压：

```python
import gzip
from pathlib import Path
p = Path('M101_D952_P254_220_39x6_C05.step.gz')
p.with_suffix('').write_bytes(gzip.decompress(p.read_bytes()))
```

依据：[C06 RT2 红队报告](https://github.com/fredshuc/buildfly/blob/205f9c2f3cf4df45d1bed5dff193eb12fb8f4b6e/AirTransformerShell/revisions/C06/RT2_REVIEW/C06_RT2_REVIEW.md)、原 C04 源代码、RT1 端口对齐回包与 HYD-R1 水路说明。仅修改 `HX/`。
