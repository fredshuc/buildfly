"""Topology check for the two proposed vent branches, not a purge simulation."""
import argparse
import hashlib
import json
from pathlib import Path
import cadquery as cq

parser = argparse.ArgumentParser()
parser.add_argument("c04_nominal_flow", type=Path)
parser.add_argument("out", type=Path)
args = parser.parse_args()
flow = cq.importers.importStep(str(args.c04_nominal_flow)).val()
assert flow.isValid() and len(flow.Solids()) == 1
branches = [cq.Solid.makeCylinder(2, 32, cq.Vector(235, y, 1220)) for y in (726.85, 576.85)]
overlaps = [flow.intersect(branch).Volume() for branch in branches]
assert min(overlaps) > 1
vented = flow.fuse(*branches).clean()
assert vented.isValid() and len(vented.Solids()) == 1
report = {
    "source_sha256": hashlib.sha256(args.c04_nominal_flow.read_bytes()).hexdigest(),
    "source_components": 1, "vented_components": 1,
    "branch_to_main_flow_overlap_mm3": overlaps,
    "nominal_closed_main_flow_volume_L": flow.Volume()/1e6,
    "nominal_vented_flow_volume_L": vented.Volume()/1e6,
    "scope": "Ideal C04 nominal domain plus two ID4 branches. Does not qualify actual fittings, braze insertion, air transport, purge, pressure or thermal performance."
}
args.out.write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps(report))
