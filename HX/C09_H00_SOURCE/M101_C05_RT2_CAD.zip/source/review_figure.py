"""Generate a dimensioned engineering overview from the C05 parameters/checks."""
import json
from pathlib import Path
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, Polygon

out = Path(__file__).resolve().parent.parent
report = json.loads((out/"C05_CHECKS.json").read_text(encoding="utf-8"))
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False})
fig, axes = plt.subplots(1, 3, figsize=(16, 7.5), layout="constrained")
blue, dark, orange = "#317da8", "#293f51", "#c77734"
fig.suptitle("M101 C05 | dimensioned interface schematic | geometry candidate, mm", fontsize=17, weight="bold")
a, b, c = axes
# Y-Z bottom section at local X110; dimensions exactly match the model.
for y in (0, 640):
    a.add_patch(Rectangle((y, 0), 80, 8, fc=dark, alpha=.8))
for y in (41.775, 673.775):
    a.add_patch(Rectangle((y, 8), 20, 18, fc="#9eaeb8", ec=dark))
points = [(61.775,32),(673.775,24),(673.775,25.5),(61.775,33.5)]
a.add_patch(Polygon(points, color=blue))
for y, z in ((61.775,33.5),(672.275,25.5)):
    a.add_patch(Rectangle((y,z),1.5,8,fc=blue))
a.add_patch(Rectangle((594.775,9),22,15.89,ec=blue,fc="#b9d7e7"))
a.add_patch(Rectangle((594.775,-15),22,24,ec="#b54f48",fc="none",ls="--"))
a.axhline(0, color=dark, lw=1.5)
a.text(360,72,"shell beam top: Z0 local / Z1150 installed",ha="center",fontsize=8)
a.add_patch(Rectangle((62.775,54),610,12,fc="#d2dce2",ec="none"))
a.text(365,59,"fin pack starts Z54",ha="center",fontsize=9)
a.annotate("short retained spigot: Z9",xy=(605.775,9),xytext=(200,-20),arrowprops={"arrowstyle":"->"},color=blue)
a.annotate("old rigid nozzle: Z-15",xy=(605.775,-15),xytext=(200,-40),arrowprops={"arrowstyle":"->"},color="#b54f48")
a.annotate("tray + core move together",xy=(80,43),xytext=(650,43),arrowprops={"arrowstyle":"<->"},ha="right",color=blue)
a.text(360,80,"Four tray tabs bolt to HX bottom crossbars.\nRemove hose-side connector before withdrawal.",ha="center",fontsize=10)
a.set(xlim=(-20,760),ylim=(-48,100),xlabel="Local Y",ylabel="Local Z",title="1  Core-carried tray / section X110")
a.set_aspect(5)
# Plan of terminal interfaces and bleed branches; no invented external pipe route.
for name, y in (("W1",726.85),("W2",576.85)):
    b.plot([212.65 if name=="W1" else 102.65,291.5],[y,y],color=orange,lw=13,solid_capstyle="butt",alpha=.55)
    b.add_patch(Rectangle((267.5,y-28.68),82.5,57.36,fc="#d8ba7c",ec="#8d6b34",alpha=.7))
    b.add_patch(Circle((235,y),7,fc=blue,ec=dark))
    b.add_patch(Circle((235,y),15,fc="none",ec=blue,ls="--"))
    b.text(357,y,name+"  +X\nRp 1 1/4",va="center",fontsize=9)
    b.annotate(name+".VENT",xy=(235,y),xytext=(160,y+42),arrowprops={"arrowstyle":"->"},fontsize=9)
b.annotate("",xy=(440,576.85),xytext=(440,726.85),arrowprops={"arrowstyle":"<->"})
b.text(448,651.85,"150",ha="left",va="center")
b.text(253,500,"Vent boss face Z1252\nClosure envelope top Z1257\nTop tool budget Z1297",ha="center",fontsize=10)
b.set(xlim=(70,480),ylim=(480,810),xlabel="Local X",ylabel="Local Y",title="2  Two independent high-point vents")
b.set_aspect("equal")
# Front / rear land and removable cross-frame rod axes.
c.add_patch(Rectangle((41.775,34),652,1040,fc="#a3b4bf",ec=dark))
c.add_patch(Rectangle((61.775,54),612,1000,fc="white",ec=dark))
c.add_patch(Rectangle((42.775,36),650,1036,fc="none",ec=blue,lw=2))
c.add_patch(Rectangle((58.775,52),618,1004,fc="none",ec=blue,lw=1,ls="--"))
for yy in (12.775,759.775):
    for zz in (85,397,709,1023):
        c.add_patch(Circle((yy,zz),6,fc=orange,ec=dark))
min_rod = min(r["rod_to_HX_gap_mm"] for r in report["seal_tie_rod_mating_references"])
min_corr = min(r["corridor_to_HX_gap_mm"] for r in report["seal_tie_rod_mating_references"])
c.text(367,700,"unchanged 612 x 1000 window\n20 mm frame lands\nblue: gasket footprint",ha="center",va="center",fontsize=10)
c.text(367,410,f"Orange: 8 tie-rod axes\nOD8 rod clearance >= {min_rod:.2f}\nOD12 corridor clearance >= {min_corr:.2f}",ha="center",va="center",fontsize=9)
c.text(367,-63,"Mating references only; shell redesign and\nload / bypass validation remain open.",ha="center",fontsize=9)
c.set(xlim=(-60,835),ylim=(-110,1160),xlabel="Local Y",ylabel="Local Z",title="3  Seal lands and tie-rod corridors")
c.set_aspect("equal")
fig.savefig(out/"C05_RT2_HX_REVIEW.png",dpi=160)
