"""HX-only RT2 response. CadQuery 2.8; all dimensions mm.

Uses the preserved C04 STEP, never executes or rewrites the shell sources.
The delta STEP REPLACES four named C04 parts and adds twelve parts.
"""
import argparse
import csv
import hashlib
import json
from itertools import combinations
from pathlib import Path
import cadquery as cq
from step_io import leaves, bounds, clashes, overlap, nearest, shared_planar_area

HERE = Path(__file__).resolve().parent
OUT = HERE.parent
ID = OUT.name
CORE_SHA = "efca1457db1e90731da5adccc963e49f197238e8cbdda91a1ae95d7c8a9646e5"
PLACEMENTS = {"A": (265., -802.175, 1150.), "B": (265., 477.825, 1150.)}
PORT_Y = {"W1": 726.85, "W2": 576.85}
TOL = .001


def box(x, y, z, dx, dy, dz):
    return cq.Solid.makeBox(dx, dy, dz, cq.Vector(x, y, z))


def zcyl(x, y, z, r, h):
    return cq.Solid.makeCylinder(r, h, cq.Vector(x, y, z))


def profile(x, yz, dx):
    wire = cq.Wire.makePolygon([cq.Vector(x, y, z) for y, z in yz], close=True)
    return cq.Solid.extrudeLinear(wire, [], cq.Vector(dx, 0, 0))


def export(rows, path):
    asm = cq.Assembly(name=path.stem)
    for name, shape in rows.items():
        color = (.28, .57, .72) if name.startswith("C05_") else (.65, .68, .71)
        # Preserve the C04 shared fin / circuit prototypes. Baking each
        # occurrence location into a distinct part duplicates the STEP BRep.
        asm.add(shape.located(cq.Location()), name=name, loc=shape.location(), color=cq.Color(*color))
    asm.save(str(path))
    read = cq.importers.importStep(str(path)).val()
    solids = read.Solids()
    # A flat compound has no additional solid topology to validate. Check
    # each unique BRep once; its rigidly located copies share that validity.
    unique = set(s.located(cq.Location()) for s in solids)
    assert len(solids) == len(rows) and all(s.isValid() for s in unique), path
    print("STEP readback", path.name, len(solids), "solids;", len(unique), "unique bodies valid", flush=True)
    return {"solids": len(solids), "unique_bodies_validated": len(unique), "bounds_mm": bounds(read),
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def make_tray():
    # Same 162 x 612 collection footprint as C06; 8 mm fall in +Y.
    x, y, z, dx, dy, fall, t = 29., 61.775, 24., 162., 612., 8., 1.5
    low_y = y + dy
    floor = profile(x, [(y, z+fall), (low_y, z), (low_y, z+t), (y, z+fall+t)], dx)
    drain_x, drain_y = 110., low_y-68
    floor = floor.cut(zcyl(drain_x, drain_y, 8, 9, 35))
    for xx in (x, x+dx-t):
        floor = floor.fuse(profile(xx, [(y, z+fall+t), (low_y, z+t),
                        (low_y, z+10), (y, z+fall+10)], t))
    for yy, zz in ((y, z+fall), (low_y-t, z)):
        floor = floor.fuse(box(x, yy, zz+t, dx, t, 8))
    # Short spigot retained with HX: lower face Z9, nine mm above beam top.
    stub = zcyl(drain_x, drain_y, 9, 11, 30).cut(zcyl(drain_x, drain_y, 8, 9, 32))
    above = profile(x-1, [(y-1, z+fall+fall/dy), (low_y+1, z-fall/dy),
                          (low_y+1, z+fall+40), (y-1, z+fall+40)], dx+2)
    stub = stub.cut(above)
    return floor.clean(), stub.clean()


def require_zero(label, rows):
    if rows:
        raise ValueError(f"{label}: {rows[:15]}")
    return []


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("core", type=Path)
    parser.add_argument("shell", type=Path)
    parser.add_argument("--out", type=Path, default=OUT)
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    assert hashlib.sha256(args.core.read_bytes()).hexdigest() == CORE_SHA, "C04 baseline identity"
    # XCAF leaf labels can be shared prototype names (e.g. FIN_000).
    # The parent reference label is the unique occurrence ID.
    core = {n.split("/")[-2]: s for n, s in leaves(args.core)}
    assert len(core) == 537
    original = dict(core)
    changes, additions, holes = {}, {}, []
    # Four captive-to-core mounting points. This is frame drilling only.
    # Thread forms are not modelled; the 4.5 mm bores are fastener clearance
    # reservations. Blind tapped inserts / screws require production detailing.
    for side, bar_y, bracket_y, bracket_dy in (
        ("NEAR", 41.775, 48., 61.775-48.),
        ("FAR", 673.775, 673.775, 13.225)):
        bar_name = f"BOTTOM_CROSS_{bar_y}"
        bar = core[bar_name]
        for i, xx in enumerate((80., 140.)):
            yy = bar_y+10
            bore = zcyl(xx, yy, 7, 2.25, 24)
            bar = bar.cut(bore)
            tab = box(xx-8, bracket_y, 26, 16, bracket_dy, 3).cut(bore)
            if side == "NEAR":
                # Formed upstand meets the raised pan wall without lifting
                # the frame-mounted screw head into the fin pack.
                tab = tab.fuse(box(xx-8, 60.275, 29, 16, 1.5, 7)).clean()
            additions[f"C05_TRAY_TAB_{side}_{i}"] = tab
            # Simplified captive screw envelope, no thread or torque claim.
            screw = zcyl(xx, yy, 14, 2, 15).fuse(zcyl(xx, yy, 29, 3.5, 3))
            additions[f"C05_TRAY_M4_ENVELOPE_{side}_{i}"] = screw.clean()
            holes.append({"bar": bar_name, "xyz_mm": [xx, yy, 26],
                          "clearance_reservation_diameter_mm": 4.5,
                          "final_thread_and_retention": "OPEN: detail blind M4 attachment; no loose nuts below shoe"})
        core[bar_name] = changes[bar_name] = bar.clean()
    tray, stub = make_tray()
    additions["C05_CORE_CARRIED_TRAY"] = tray
    additions["C05_SHORT_DRAIN_SPIGOT"] = stub
    vents = []
    services = {}
    for port, yy in PORT_Y.items():
        name = f"{port}_D35_END_PIPE"
        # Positive-Z vent branch at each terminal high-level run. Only the
        # terminal tube changes: 39 circuits, headers and fin pack are preserved.
        boss = zcyl(235, yy, 1230, 6, 22)
        modified = core[name].fuse(boss).cut(zcyl(235, yy, 1220, 2, 34)).clean()
        assert modified.isValid() and len(modified.Solids()) == 1
        core[name] = changes[name] = modified
        cap = zcyl(235, yy, 1252, 7, 5)
        additions[f"C05_{port}_VENT_CLOSURE_ENVELOPE"] = cap
        # A removable insulation boot and tool approach, not a hardware part.
        services[f"{port}_VENT_TOOL_TOP_APPROACH"] = zcyl(235, yy, 1238, 15, 59)
        vents.append({"id": port+".VENT", "boss_face_xyz_mm": [235, yy, 1252],
                      "outward_normal": "+Z", "nominal_bore_mm": 4,
                      "boss_OD_mm": 12, "closure_envelope_top_z_mm": 1257,
                      "tool_budget_top_z_mm": 1297,
                      "status": "candidate vent boss and closure envelope; pressure-rated valve/thread not selected"})
    core.update(additions)
    assert len(core) == 549
    delta = dict(changes, **additions)
    print("HX C05 geometry created", len(core), "parts; checking additions", flush=True)
    # Do not repeat the inherited simplified fin/circuit contact inventory.
    # Check every changed/new solid against every other product solid.
    checked = set()
    errors = []
    bboxes = {n: bounds(s) for n, s in core.items()}
    for a, sa in delta.items():
        for b, sb in core.items():
            key = tuple(sorted((a, b)))
            if a == b or key in checked:
                continue
            checked.add(key)
            if overlap(bboxes[a], bboxes[b]):
                volume = sa.intersect(sb).Volume()
                if volume > TOL:
                    errors.append([a, b, round(volume, 6)])
    (out/"debug_clashes.json").write_text(json.dumps(errors, indent=2))
    require_zero("new/changed product clashes", errors)
    print("New/changed product collision check passed", flush=True)
    # Tray tabs must have genuine shared faces, rather than nearby floating parts.
    contacts = []
    for n, tab in additions.items():
        if not n.startswith("C05_TRAY_TAB"):
            continue
        bar_name = "BOTTOM_CROSS_41.775" if "NEAR" in n else "BOTTOM_CROSS_673.775"
        tab_tray = shared_planar_area(tab, tray)
        tab_bar = shared_planar_area(tab, core[bar_name])
        assert tab_tray > 10 and tab_bar > 100, (n, tab_tray, tab_bar)
        contacts.append({"tab": n, "tray_shared_face_mm2": tab_tray,
                         "frame_shared_face_mm2": tab_bar})
    print("Tray mounting face contacts passed", flush=True)
    unchanged = [n for n in original if n not in changes]
    assert len(unchanged) == 533
    # C04 is the input for those objects, so their exact shapes are retained.
    assert all(core[n] is original[n] for n in unchanged)
    report = {"revision": ID, "date": "2026-11-05", "status": "HX_GEOMETRY_CANDIDATE_NOT_MANUFACTURING_RELEASE",
              "source_core_sha256": CORE_SHA,
              "source_shell_sha256": hashlib.sha256(args.shell.read_bytes()).hexdigest(),
              "changed_C04_parts": list(changes), "added_parts": list(additions),
              "unchanged_C04_parts": len(unchanged), "circuits": 39, "passes": 6,
              "new_changed_product_intersections_above_0p001_mm3": errors,
              "tray_tab_contacts": contacts, "mount_holes": holes, "vents": vents,
              "prototype_water_direction": {"cold": "W1 -> W2", "hot": "W1 -> W2",
                  "HX_disposition": "geometry compatible for HYD-R1 prototype; regeneration equivalence and vent performance NOT qualified"},
              "placements": PLACEMENTS}
    # The old shell-owned tray set is superseded by the core-carried assembly.
    shell = {n.split("/")[-2]: s for n, s in leaves(args.shell)}
    assert len(shell) == 327
    print("C06 shell loaded", flush=True)
    removed = {n: s for n, s in shell.items() if any(token in n for token in
               ("_HX_TRAY", "_PAN_PAD_", "_TRAY_BAR_"))}
    assert len(removed) == 16, list(removed)
    fixed = {n: s for n, s in shell.items() if n not in removed}
    placed = {bed+"_"+n: s.translate(t) for bed, t in PLACEMENTS.items() for n, s in core.items()}
    report["shell_owner_remove_parts"] = list(removed)
    report["installed_HX_shell_clashes"] = require_zero("HX/shell", clashes(placed, fixed))
    report["vent_tool_shell_clashes"] = require_zero("vent tools/shell", clashes(
        {bed+"_"+n: s.translate(t) for bed, t in PLACEMENTS.items() for n, s in services.items()}, fixed))
    print("Installed HX and vent-tool shell checks passed", flush=True)
    report["drain"] = {"connection_face_local_xyz_mm": [110, 605.775, 9],
                       "bore_mm": 18, "OD_mm": 22, "installed_connection_face_z_mm": 1159,
                       "beam_top_z_mm": 1150, "nominal_clearance_mm": 9,
                       "spigot_length_at_axis_mm": 24+8*68/612-9,
                       "pan_floor_low_high_local_z_mm": [24, 32],
                       "pan_upper_edge_local_z_max_mm": 42,
                       "fin_bottom_local_z_mm": 54,
                       "nominal_pan_to_fin_vertical_gap_mm": 12,
                       "service": "disconnect complete hose-side coupling before HX translation",
                       "fixed_drain_system_status": "OPEN: shell routes flexible drain to floor penetration and external trap"}
    # HX-side mating references only: shell owner designs their supports.
    # Rod solid is M8 OD, the wider corridor includes 2 mm radial allowance.
    references, corridors, rod_gaps, pin_gaps = {}, {}, [], []
    for side, yy in (("HAIRPIN", 12.775), ("HEADER", 759.775)):
        for zz in (85., 397., 709., 1023.):
            name = f"TIE_ROD_{side}_Z{zz}"
            rod = cq.Solid.makeCylinder(4, 270, cq.Vector(-25, yy, zz), cq.Vector(1, 0, 0))
            corridor = cq.Solid.makeCylinder(6, 270, cq.Vector(-25, yy, zz), cq.Vector(1, 0, 0))
            references[name] = rod
            corridors[name+"_ALLOWANCE"] = corridor
            # Euclidean distances are evaluated against the entire detailed HX.
            closest = nearest(rod, core, bboxes)
            assert closest[0] > 9, (name, closest)
            rod_gaps.append({"reference": name, "nearest_HX_part": closest[1],
                             "rod_to_HX_gap_mm": closest[0],
                             "corridor_to_HX_gap_mm": nearest(corridor, core, bboxes)[0]})
    for i, yy in enumerate((27.35, 707.35)):
        name = f"REMOVABLE_TOP_PIN_{i}"
        pin = cq.Solid.makeCylinder(6, 20, cq.Vector(110, yy-10, 1116), cq.Vector(0, 1, 0))
        references[name] = pin
        require_zero(name, clashes({name: pin}, core))
        pin_gaps.append({"reference": name, "axis_local_xyz_mm": [110, yy, 1116],
                         "axis_direction": "+Y", "diameter_mm": 12,
                         "slot_width_mm": 13.2, "slot_length_Z_mm": 21.2,
                         "X_clearance_each_side_mm": .6, "Z_travel_total_mm": 9.2,
                         "status": "geometric mating reference; shell fork drilling and joint/load/modal qualification OPEN"})
    report["seal_tie_rod_mating_references"] = rod_gaps
    report["top_restraint_mating_references"] = pin_gaps
    # Prove translation continuously wherever a moving part's entire swept
    # AABB avoids all fixed AABBs. For unresolved pairs use documented 5 mm
    # configurations; this part of the result is explicitly a sampled check.
    sweeps = {}
    for bed, t in PLACEMENTS.items():
        sign = -1 if bed == "A" else 1
        extra_remove = [n for n in fixed if n == bed+"_SIDE_PANEL" or n == bed+"_SIDE_BRACE"
                        or n.startswith(bed+"_TOP_FORK_")]
        host = {n: s for n, s in fixed.items() if n not in extra_remove}
        hb = {n: bounds(s) for n, s in host.items()}
        moving = {n: s.translate(t) for n, s in core.items()}
        candidates = []
        for n, s in moving.items():
            b = bounds(s)
            swept = b.copy()
            swept[1 if sign < 0 else 4] += sign*900
            for hn, bs in hb.items():
                if overlap(swept, bs):
                    candidates.append((n, hn))
        print(bed, "withdrawal candidate pairs", len(candidates), flush=True)
        sweep_bad = []
        for mm in range(0, 901, 5):
            for n, hn in candidates:
                s = moving[n].translate((0, sign*mm, 0))
                if overlap(bounds(s), hb[hn]):
                    volume = s.intersect(host[hn]).Volume()
                    if volume > TOL:
                        sweep_bad.append([mm, n, hn, round(volume, 6)])
            if sweep_bad:
                break
        require_zero(bed+" withdrawal", sweep_bad)
        sweeps[bed] = {"direction": "-Y" if sign < 0 else "+Y", "travel_mm": 900,
                       "configuration_step_mm": 5, "positions": 181,
                       "moving_solids": len(moving), "fixed_shell_solids": len(host),
                       "service_remove": extra_remove, "candidate_pairs": len(candidates),
                       "clashes_above_0p001_mm3": sweep_bad,
                       "continuous_AABB_proof": len(candidates) == 0,
                       "scope": "HX+tray+short spigot+vent closures; hose detached, carriers released, spools removed; shell obstacles only"}
    report["outboard_withdrawal"] = sweeps
    # Keep the completed geometry evidence even if a later export is interrupted.
    (out/"C05_GEOMETRY_CHECKS.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    report["exports"] = {
        "single": export(core, out/(ID+".step")),
        "delta": export(delta, out/"C05_REPLACE_AND_ADD_LOCAL.step"),
        "service": export(services, out/"C05_VENT_SERVICE_LOCAL.step"),
        "mating_references": export(references, out/"C05_SHELL_MATING_REFERENCES_LOCAL.step"),
        "tie_rod_corridors": export(corridors, out/"C05_TIE_ROD_CORRIDORS_LOCAL.step")}
    # Readable, single authority function table for the C06 installed datums.
    rows = []
    for bed, t in PLACEMENTS.items():
        for port, yy in PORT_Y.items():
            supply = port == "W1"
            rows.append({"port": bed+"."+port, "x_mm": 350+t[0], "y_mm": round(yy+t[1], 3),
                         "z_mm": 1220+t[2], "normal": "+X", "connection": "Rp1-1/4 female",
                         "cold_service": "CS" if supply else "CR", "hot_service": "HS" if supply else "HR",
                         "flow_relative_to_HX": "IN" if supply else "OUT",
                         "hydronics_selectors": bed+"_XV_"+("CS|"+bed+"_XV_HS" if supply else "CR|"+bed+"_XV_HR"),
                         "scope": "C06/HYD-R1 prototype; thermal and vent qualification hold"})
    with (out/"C06_INSTALLED_PORT_FUNCTIONS.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0])
        writer.writeheader()
        writer.writerows(rows)
    (out/"C05_CHECKS.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print("PASS", json.dumps({"parts": len(core), "changed": list(changes), "sweeps": sweeps}), flush=True)


if __name__ == "__main__":
    main()
