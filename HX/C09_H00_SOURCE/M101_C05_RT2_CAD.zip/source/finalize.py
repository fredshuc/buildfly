"""Validate the handoff tables, compress the complete STEP and hash deliverables."""
import argparse
import csv
import gzip
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("c06_interfaces", type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parent.parent
checks = json.loads((root/"C05_CHECKS.json").read_text(encoding="utf-8"))
assert checks["exports"]["single"]["solids"] == 549
assert checks["exports"]["delta"]["solids"] == 16
assert checks["unchanged_C04_parts"] == 533
assert not checks["new_changed_product_intersections_above_0p001_mm3"]
assert not checks["installed_HX_shell_clashes"]
assert not checks["vent_tool_shell_clashes"]
assert all(not row["clashes_above_0p001_mm3"] for row in checks["outboard_withdrawal"].values())
with (root/"C06_INSTALLED_PORT_FUNCTIONS.csv").open(encoding="utf-8", newline="") as f:
    ports = list(csv.DictReader(f))
with args.c06_interfaces.open(encoding="utf-8", newline="") as f:
    hydro = {row["id"]: row for row in csv.DictReader(f)}
assert len(ports) == 4
for row in ports:
    target = hydro[row["port"].replace(".", "_")]
    assert all(abs(float(row[key])-float(target[key])) < .001 for key in ("x_mm", "y_mm", "z_mm"))
    is_in = row["port"].endswith("W1")
    assert target["function"] == ("SUPPLY" if is_in else "RETURN")
    assert row["cold_service"] == ("CS" if is_in else "CR")
    assert row["hot_service"] == ("HS" if is_in else "HR")
for path in (root/"source").glob("*.py"):
    compile(path.read_text(encoding="utf-8"), str(path), "exec")
flow = json.loads((root/"VENT_FLOW_TOPOLOGY_CHECK.json").read_text(encoding="utf-8"))
assert flow["vented_components"] == 1
single = root/(root.name+".step")
packed = single.with_suffix(".step.gz")
data = single.read_bytes()
assert hashlib.sha256(data).hexdigest() == checks["exports"]["single"]["sha256"]
packed.write_bytes(gzip.compress(data, compresslevel=9, mtime=0))
assert gzip.decompress(packed.read_bytes()) == data
baseline = {
    "repository": "https://github.com/fredshuc/buildfly",
    "review_commit": "205f9c2f3cf4df45d1bed5dff193eb12fb8f4b6e",
    "red_team_baseline_commit": "d2c9a68",
    "C04_single_STEP_sha256": checks["source_core_sha256"],
    "C04_single_STEP_git_blob_verified_against_remote": "fb78e42bb24bb6d947a9c8bcf801710e0e0ccb86",
    "C06_shell_STEP_sha256": checks["source_shell_sha256"],
    "C06_interface_table_sha256": hashlib.sha256(args.c06_interfaces.read_bytes()).hexdigest(),
    "scope": "HX only; shell, hydronics and damper files unmodified"
}
(root/"SOURCE_BASELINES.json").write_text(json.dumps(baseline, indent=2), encoding="utf-8")
audit = {"C06_installed_ports_compared": len(ports), "coordinate_and_function_mismatches": [],
         "python_sources_compile": "PASS", "gzip_round_trip": "PASS",
         "product_solids": 549, "delta_solids": 16,
         "live_water_status": "HOLD: hydronics reconciliation, actual vent hardware and tests pending; HX prototype function record issued",
         "unchanged_HX_core_circuits": "39 parallel x 6 passes; C04 shapes retained",
         "full_uncompressed_STEP_sha256": hashlib.sha256(data).hexdigest()}
(root/"HANDOFF_AUDIT.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
signoff = {"issuer_role": "L2-HX", "issuer": "Codex successor acting in the user-assigned L2-HX role",
           "date": "2026-11-05", "disposition": "CONDITIONAL_PROTOTYPE_INTERFACE_SIGNOFF",
           "controlled_function_table": "C06_INSTALLED_PORT_FUNCTIONS.csv",
           "table_sha256": hashlib.sha256((root/"C06_INSTALLED_PORT_FUNCTIONS.csv").read_bytes()).hexdigest(),
           "cold_and_hot_prototype_direction": "W1 -> W2",
           "vent_interfaces": ["W1.VENT", "W2.VENT"],
           "conditions": ["Hydronics reconciles installation and control registers",
                          "Select and qualify actual pressure-rated vent hardware and joints",
                          "Demonstrate filling/purging in both comparison directions",
                          "Compare regeneration performance before product adoption"],
           "does_not_release": ["pressure manufacture", "two-bed manufacture", "live-water operation"]}
(root/"HX_FUNCTION_SIGNOFF.json").write_text(json.dumps(signoff, indent=2), encoding="utf-8")
files = {}
for path in sorted(root.rglob("*")):
    if not path.is_file() or path.name in ("MANIFEST_SHA256.json", "build.log", "debug_clashes.json") or path == single:
        continue
    if "__pycache__" in path.parts:
        continue
    content = path.read_bytes()
    files[path.relative_to(root).as_posix()] = {"bytes": len(content), "sha256": hashlib.sha256(content).hexdigest()}
manifest = {"stored_files": files,
            "generated_uncompressed_STEP": {"path": single.name, "bytes": len(data),
                                            "sha256": hashlib.sha256(data).hexdigest(), "stored_as": packed.name}}
(root/"MANIFEST_SHA256.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
print(json.dumps({"status": "PASS", "stored_files": len(files), "compressed_STEP_bytes": packed.stat().st_size}))
