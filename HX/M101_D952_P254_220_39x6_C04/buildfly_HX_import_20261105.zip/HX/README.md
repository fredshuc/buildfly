# HX — AirTransformer 换热器

本目录保存 HX 的 CAD、接口文件、图册、源代码及几何检查记录。后续 HX 工作继续提交到此目录，并按版本保留历史。

## 当前版本

**[M101 C04：同高、沿 Y 分开的 +X 双水口](M101_D952_P254_220_39x6_C04/README_CN.txt)**，日期 2026-11-05。

- [六页说明图册 PDF](M101_D952_P254_220_39x6_C04/M101_D952_P254_220_39x6_C04_Interface_Revision_CN.pdf)
- [完整单芯 STEP](M101_D952_P254_220_39x6_C04/M101_D952_P254_220_39x6_C04.step)
- [同件同向双芯 STEP](M101_D952_P254_220_39x6_C04/M101_D952_P254_220_39x6_C04_TWO_CORES.step)
- [顶部标注俯视图](M101_D952_P254_220_39x6_C04/07_top_plan_dimensioned.png)
- [接口坐标 CSV](M101_D952_P254_220_39x6_C04/INTERFACES.csv) / [坐标及安装变换 JSON](M101_D952_P254_220_39x6_C04/INTERFACES_AND_PLACEMENTS.json)
- [源代码](M101_D952_P254_220_39x6_C04/source/) / [检查记录](M101_D952_P254_220_39x6_C04/DESIGN_AND_CHECKS.json)

39 路并联、每路六程；两口沿 Y 中距 150 mm，中心 Z=1220 mm，均朝 +X。
本版为 HX 接口候选。壳体工作见仓库中的 `AirTransformerShell/`；本次导入不改变其文件。

## 文件管理

- 每次主要修订建立独立版本目录，并更新本页的当前版本入口。
- CAD、说明、接口表和检查结果应属于同一版本；保留可重建源文件。
- `MANIFEST_SHA256.json` 记录原交付文件的校验值。本次导入与 C04 原包一致。
- 后续在 Git 中保存版本，不重复提交同一套文件的 ZIP。GitHub 可下载整个仓库 ZIP。

