"""Raster views from the actual CAD tessellation; dimensioned plan from same parameters."""
from pathlib import Path
import sys
import json,gzip,math
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from numba import njit
O=Path(__file__).resolve().parent.parent
with gzip.open(O/'CAD_MESH.json.gz','rt') as f:data=json.load(f)
meshes={k:(np.array(m['v'],dtype=np.float64),np.array(m['t'],dtype=np.int32))for k,m in data['meshes'].items()}
@njit
def paint(v,tri,buf,zbuf,col):
 H,W=zbuf.shape
 for t in tri:
  a,b,c=v[t[0]],v[t[1]],v[t[2]]
  den=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1])
  if abs(den)<1e-7:continue
  xmin=max(0,int(math.floor(min(a[0],b[0],c[0]))));xmax=min(W-1,int(math.ceil(max(a[0],b[0],c[0]))))
  ymin=max(0,int(math.floor(min(a[1],b[1],c[1]))));ymax=min(H-1,int(math.ceil(max(a[1],b[1],c[1]))))
  ux=b[0]-a[0];uy=b[1]-a[1];uz=b[2]-a[2];vx=c[0]-a[0];vy=c[1]-a[1];vz=c[2]-a[2]
  nx=uy*vz-uz*vy;ny=uz*vx-ux*vz;nz=ux*vy-uy*vx;norm=math.sqrt(nx*nx+ny*ny+nz*nz)
  light=abs((-.35*nx-.45*ny+.82*nz)/norm) if norm>0 else 1
  shade=.52+.48*light
  for yy in range(ymin,ymax+1):
   for xx in range(xmin,xmax+1):
    w0=((b[1]-c[1])*(xx+.5-c[0])+(c[0]-b[0])*(yy+.5-c[1]))/den
    w1=((c[1]-a[1])*(xx+.5-c[0])+(a[0]-c[0])*(yy+.5-c[1]))/den;w2=1-w0-w1
    if w0>=-1e-8 and w1>=-1e-8 and w2>=-1e-8:
     z=w0*a[2]+w1*b[2]+w2*c[2]
     if z>zbuf[yy,xx]:
      zbuf[yy,xx]=z
      for k in range(3):buf[yy,xx,k]=min(255,int(col[k]*255*shade))


def render(name,eye,focal,size=(1500,1500),select=None,pair=False,up=(0,0,1)):
 W,H=size;f=np.array(eye,dtype=float)-np.array(focal,dtype=float);f/=np.linalg.norm(f)
 r=np.cross(up,f);r/=np.linalg.norm(r);u=np.cross(f,r);R=np.array([r,-u,f]).T
 selected=[i for i in data['items'] if select is None or select(i)]
 corners=[]
 for dy in ([0,840]if pair else[0]):
  for i in selected:
   v=meshes[i['mesh']][0]+np.array(i['pos'])+[0,dy,0];mn=v.min(0);mx=v.max(0)
   corners.extend([[x,y,z]for x in[mn[0],mx[0]]for y in[mn[1],mx[1]]for z in[mn[2],mx[2]]])
 corner=np.array(corners)@R;lo=corner[:,:2].min(0);hi=corner[:,:2].max(0)
 scale=min((W-90)/(hi[0]-lo[0]),(H-90)/(hi[1]-lo[1]));center=(lo+hi)/2
 buf=np.full((H,W,3),248,np.uint8);zbuf=np.full((H,W),-1e10)
 for dy in ([0,840]if pair else[0]):
  for i in selected:
   v,t=meshes[i['mesh']];p=(v+np.array(i['pos'])+[0,dy,0])@R
   p[:,:2]=(p[:,:2]-center)*scale+[W/2,H/2];p[:,2]*=scale
   paint(p,t,buf,zbuf,np.array(data['colors'][i['kind']]))
 Image.fromarray(buf).save(O/(name+'.png'));print(name,flush=True)

if '--plan-only' not in sys.argv:
 render('01_overall',(2100,2400,1800),(170,380,620))
 render('02_top_detail',(1900,2200,1900),(175,650,1150),size=(1600,1100),select=lambda i:i['group']in ['riser','port','guide'])
 render('03_waterpath',(2100,2400,1800),(170,380,620),select=lambda i:i['kind']!='fin'and i['kind']!='frame')
 render('04_two_identical',(2500,2800,1600),(175,800,620),size=(1800,1300),pair=True)
 render('05_top_CAD',(175,380,5000),(175,380,0),size=(1100,1700),up=(0,1,0))
 render('06_three_circuits',(2100,2400,1800),(107,380,100),size=(1600,750),select=lambda i:i['name'].startswith(('C01_','C02_','C03_')))
 
# Orthographic plan: X horizontal, Y vertical; all dimensions are in local HX coordinates.
W,H=1800,1200;im=Image.new('RGB',(W,H),'white');d=ImageDraw.Draw(im)
fontpath=str(Path(__file__).parent/'fonts/wqy-zenhei.ttc')
fonts={n:ImageFont.truetype(fontpath,n)for n in[22,26,30,34,42]}
S=3.1;OX=210;OY=1020
def pt(x,y):return (OX+S*x,OY-S*(y-490))
def rect(x0,y0,x1,y1,fill,outline=None,width=1):d.rectangle([pt(x0,y1),pt(x1,y0)],fill=fill,outline=outline,width=width)
def txt(x,y,s,n=26,c='#17384a'):d.text((x,y),s,font=fonts[n],fill=c)
def path(points,color,width):
 pixels=[pt(x,y)for x,y in points];ww=round(width*S);d.line(pixels,fill=color,width=ww)
 if width>2:
  rr=ww/2
  for px,py in pixels:d.ellipse((px-rr,py-rr,px+rr,py+rr),fill=color)
def dim(x1,y1,x2,y2,s,vertical=False):
 a=pt(x1,y1);b=pt(x2,y2);d.line([a,b],fill='#526b78',width=2)
 for x,y in[a,b]:d.line([(x-8,y-8),(x+8,y+8)],fill='#526b78',width=2)
 if vertical:txt(a[0]+15,(a[1]+b[1])/2-15,s,26)
 else:txt((a[0]+b[0])/2-20,a[1]-40,s,26)
txt(60,35,'C04 顶部接管俯视图  |  两口 +X，同高 Z = 1220',42)
txt(60,95,'铜色：管路；金色：活接Ø62外廓预算；浅蓝：保温；虚线：工具预约',26,'#526b78')
rect(0,490,220,747.85,'#f2f5f6','#b8c9ce',2)
rect(31.65,490,183.65,672.85,'#e1e8eb')
txt(235,1050,'+X → 接平台水路',30)
txt(35,560,'+Y ↑',30)
txt(250,950,'下方为管翅芯及载架投影',22,'#687d88')
# Swept-plan outlines are calculated from the circular centerlines.
pts1=[(162.65,726.85),(212.65,726.85),(291.5,726.85)]
pts2=[(52.65,726.85),(52.65,626.85)]
pts2 +=[(102.65-50*math.cos(t),626.85-50*math.sin(t))for t in np.linspace(0,math.pi/2,40)]
pts2 +=[(291.5,576.85)]
for pp in[pts1,pts2]:
 path(pp,'#cdebf2',85);path(pp,'#cb8e57',35);path(pp,'#824c2c',1)
for yy,nm in[(726.85,'W1'),(576.85,'W2')]:
 rect(267,yy-56,350,yy+56,'#cdebf2','#78b0c1',2)
 rect(267.5,yy-31,350,yy+31,'#d3ac58','#87692d',2)
 # dashed tool budget rectangle including +X 60-mm withdrawal
 a=pt(267,yy+55);b=pt(410,yy-55)
 for xx in np.arange(a[0],b[0],20):
  d.line([(xx,a[1]),(min(xx+10,b[0]),a[1])],fill='#895c8a',width=2)
  d.line([(xx,b[1]),(min(xx+10,b[0]),b[1])],fill='#895c8a',width=2)
 for zz in np.arange(a[1],b[1],20):d.line([(b[0],zz),(b[0],min(zz+10,b[1]))],fill='#895c8a',width=2)
 txt(*pt(354,yy+8),nm+'  +X',30)
 for xx in[162.65 if nm=='W1' else 52.65]:
  px,py=pt(xx,726.85);d.ellipse((px-12,py-12,px+12,py+12),fill='#17384a')
dim(440,576.85,440,726.85,'150',True)
dim(220,510,350,510,'130 外伸')
dim(350,510,410,510,'60 预约')
txt(930,1008,'保温管外径 85 → 净距 65',26)
txt(930,1044,'活接罩外径 112 → 净距 38',26)
txt(930,1080,'工具外径预约 110 → 净距 40',26)
txt(80,1130,'单位 mm；工具包络待具体扳手 / 压接钳复核。压接完成后再安装保温罩。',26,'#526b78')
im.save(O/'07_top_plan_dimensioned.png')
print('07_top_plan_dimensioned',flush=True)
