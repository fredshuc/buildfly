from pathlib import Path
import json,math,fitz
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import HexColor,white
O=Path(__file__).resolve().parent.parent
D=json.loads((O/'DESIGN_AND_CHECKS.json').read_text())
ID=D['id'];P=O/(ID+'_Interface_Revision_CN.pdf')
pdfmetrics.registerFont(TTFont('CN',str(Path(__file__).parent/'fonts/wqy-zenhei.ttc'),subfontIndex=0))
N=HexColor('#17384a');T=HexColor('#147d88');G=HexColor('#5c717b');L=HexColor('#edf3f5');C=HexColor('#b27741')
st=ParagraphStyle('base',fontName='CN',fontSize=9.2,leading=13.8,textColor=N,wordWrap='CJK')
c=canvas.Canvas(str(P),pagesize=(595.28,841.89));c.setTitle('M101 HX C04｜同高 +X 双水口接口修订');c.setAuthor('AirTransformer')
def text(x,y,s,size=10,col=N):c.setFillColor(col);c.setFont('CN',size);c.drawString(x,y,s)
def para(s,y,x=42,w=511,size=9.2):
 p=Paragraph(s,ParagraphStyle('p',parent=st,fontSize=size,leading=size*1.48));_,h=p.wrap(w,800);p.drawOn(c,x,y-h);return y-h-9
def table(rows,y,widths=(118,393),size=9):
 sty=ParagraphStyle('cell',parent=st,fontSize=size,leading=size*1.42)
 t=Table([[Paragraph(str(v),sty)for v in row]for row in rows],colWidths=widths)
 t.setStyle(TableStyle([('ROWBACKGROUNDS',(0,0),(-1,-1),[L,white]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
 _,h=t.wrap(511,800);t.drawOn(c,42,y-h);assert y-h>60,(y,h);return y-h-11
def head(n,title,sub):
 text(42,801,'AIRTRANSFORMER  /  M101  /  HX C04',10,T)
 text(42,765,title,22);para(sub,742)
 c.setStrokeColor(HexColor('#cbd8de'));c.line(42,44,553,44)
 text(42,29,'C04 | 2026-11-05 | 单位 mm | 接口候选 / 非制造定尺图',8,G);text(525,29,f'{n}/6',8,G)
def img(n,x,y,w,h):c.drawImage(str(O/(n+'.png')),x,y,width=w,height=h,preserveAspectRatio=True,anchor='c',mask='auto')

head(1,'同高、横向分口、统一 +X','在 C03 的 39路并联 × 每路六程芯体上，只调整端部接管与端接。')
img('01_overall',42,322,286,379)
para('<b>候选接口</b><br/>两口均朝 +X<br/>中心高 Z = 1220<br/>沿 Y 中距 150<br/><br/><b>芯体保持</b><br/>39 × 6；234根直管<br/>25.4 × 22 错列<br/>错位 12.7；片距 2.00<br/>306片平翅片<br/><br/><b>两芯供货</b><br/>同一零件 × 2<br/>两芯同向，R = I<br/>W1 / W2功能一致',685,x=347,w=206,size=11)
text(42,310,'三维视图来自 C04 CAD；金色零件为所选活接的厂家外形。',9,G)
y=table([('端部处理','两根集管保留在 Y=726.85。同侧集管位置与内部六程水路不变。W1直接转向+X；W2在芯顶向-Y偏移150后转向+X。'),('外廓 / 外伸',f'材料外廓约 X350 × Y755.53 × Z1248.68；活接端面相对原X=220载架外伸130。计入25保温及活接可拆罩，保守包络为X350 × Y782.85 × Z1276。'),('状态','已完成单芯、同向双芯、保温/工具预约及名义水域STEP。壳体穿板口、阀组短节与执行器空间在下一轮按本接口重布。')],289)
para('接口属于候选设计。实装压入深度、螺纹旋合、工具型号和结构支承尚需回填；不按示意管端直接下料。',y,size=9)
c.showPage()

head(2,'顶部俯视与接口坐标','局部坐标：X为气流厚度方向，Y沿迎风面横向，Z向上。端口坐标取Rp入口参考端面中心。')
img('07_top_plan_dimensioned',35,368,525,350)
y=table([('口号','X','Y','Z','外法向','水路功能'),('W1','350.00','726.85','1220.00','(+1,0,0)','CS / HR'),('W2','350.00','576.85','1220.00','(+1,0,0)','CR / HS')],353,(49,70,82,82,109,119),9)
y=table([('接管与弯头','端管OD35；ID28仅名义内孔参考，成品壁厚按接头/管材配套。弯曲中心半径R50。两管口同X、同Z，仅Y不同。W2偏移发生在芯顶，不改变39条支路接入位置。'),('保温与净距','Ø35 + 两侧25保温 = Ø85；两口水平直段净距65。转弯根部最小包络间距为25，不把65外推到整段接管。'),('工具与外伸','活接以Ø62外廓预算，加25可拆保温罩为Ø112，横向净距38。Ø110工具预约间距40；沿+X另留60拔离预算，预约端X410。')],y)
para('工具预约不是实物操作认证。请按最终压接钳、扳手长度、转角及拆卸动作校核；压接后安装保温罩，维护时先拆罩。',y,size=9)
c.showPage()

head(3,'端接实物外形与保温边界','活接采用Viega Sanpress 2262、料号138875（35 × Rp1¼）作为本轮几何参考；替换件须满足接口和包络。')
img('02_top_detail',42,405,511,294)
y=table([('厂家尺寸依据','官网表：L83，Z36，扳手尺寸50 / 53。已导入原厂STEP。该STEP轴向长度82.5，Rp端参考面绑定X350，压接口入口约X267.5；0.5差异保留，不缩放源件。'),('厂家CAD的边界','厂家STEP用于外形与装配位置。其内部存在简化封闭面，不用于验证活接真实流道、螺纹或密封。水路检查在该段使用明确标识的ID28连续参考水域。'),('直管插入与下料','图中向厂家压接口插入24仅为显示装配关系；不是厂家合格插入深度。按正式装配图回填压入、压接和密封尺寸后，确定直管下料长度。'),('保温起点','本候选仅在Z≥1170的上部弯管/水平管布置25保温。Z1080～1170为床内裸露接管段；两根集管不设单独保温。若要求全段包覆，必须另改导向座或上接管。'),('固定件避让','保温起点高于上导向座顶Z1134共36；新接管及保温预约与本芯载架的实体交集为0。不得将外接管载荷传递给翅片或细管。')],390,size=8.8)
para('公开依据：Viega英国官网“Sanpress Adapter union – Model 2262”；下载原厂4015211138875.stp。源件及SHA256随包提供。',y,size=8.5)
c.showPage()

head(4,'水路连通与功能保持','每路六程的进出端仍接原同侧双集管。39条并联支路没有交换、删减或串接。')
img('03_waterpath',42,403,251,297)
para('<b>名义水域检查</b><br/>39条支路逐条构造<br/>每条6直段 + 5回弯<br/>逐条验证与两集管相交<br/>全网络布尔合并为1个连通实体<br/>导出后再次读回仍为1实体<br/><br/><b>计数保持</b><br/>234段穿片直管<br/>117根长U管<br/>78只独立回弯<br/>两根集管，各39个支管口',684,x=313,w=240,size=10)
img('06_three_circuits',42,258,511,139)
y=table([('冷却方向','CS → 下三通A → AB → W1 → 39条六程支路 → W2 → 上三通AB → A → CR。'),('加热方向','HS → 上三通B → AB → W2 → 39条六程支路（反向）→ W1 → 下三通AB → B → HR。'),('两床一致','A床和B床均采用W1接CS/HR、W2接CR/HS。四只三通阀架构保留；取消B床因180°旋转而造成的W1/W2互换。'),('检查口径','水域为名义连通验证，包含集管、39×6支路、端管及理想活接通道；底部关闭的排液支路不计入主通路。未验证压降、流量均布、耐压、排气残液或真实接合缝。')],245,size=8.7)
c.showPage()

head(5,'两芯同向与壳体接口输入','双芯STEP采用相同零件、相同朝向，预览间距ΔY=840。壳体安装变换作为下一轮设计输入。')
img('04_two_identical',42,470,511,235)
y=table([('安装变换','A：R=I，t=(265, -802.175, 150)。<br/>B：R=I，t=(265, 37.825, 150)。B芯保留C02所在舱位，但取消180°旋转。'),('接口','全局X','全局Y','全局Z')],456,(130,127,127,127),8.8) if False else 456
y=table([('A芯变换','R=I；t=(265, -802.175, 150)。'),('B芯变换','R=I；t=(265, 37.825, 150)。B芯保留C02所在舱位，取消180°旋转。')],y)
y=table([('全局端口','X','Y','Z / 方向'),('A.W1','615.000','-75.325','1370.000 / +X'),('A.W2','615.000','-225.325','1370.000 / +X'),('B.W1','615.000','764.675','1370.000 / +X'),('B.W2','615.000','614.675','1370.000 / +X')],y,(118,100,117,176),9)
y=para('<b>穿板口输入：</b>若继续使用X750湿区隔板，四个穿板轴线的Y/Z取上表；X615～750轴向距离为135。该值不是成品短节长度，须扣除接头、插入和密封装成。孔径与领圈由壳体方案确定。',y)
para('<b>B芯结构同步项：</b>底脚孔、上导向、抽芯路径及空气密封边须按R=I重新检查。两芯同向会改变B芯原安装点位置，不能只把水口标签改回。',y)
c.showPage()

head(6,'回传检查与下一轮接口工作','本轮先建立HX接口；壳体和外部短接管据此更新。以下尺寸区分CAD实测、空间预算和待回填项目。')
y=table([('STEP校验',f'单芯导出读回{D["STEP_readback"]["single_solids"]}实体；双芯{D["STEP_readback"]["pair_solids"]}实体。所有不同形状原型有效。名义流体域读回1个有效连通实体。'),('精确间隙',f'两根上部保温管的全路线最小3D间距{D["clearance_checks"][0]["minimum_3D_gap_mm"]:.1f}；两活接保温罩38.0；两个工具预约40.0。新材料/保温包络与本芯框架无正体积交集。'),('风箱顶板','按C02安装Z150：管轴全局Z1370；活接保温罩最低点Z1314。原后风箱顶板顶Z1300，竖向预算14。此为从C02源尺寸计算，尚未完成整壳重布后的实体总装检查。'),('壳体高度约束','C02上阀原点Z1230；执行器起点偏置47.5004、包络高95、向上拔出235，拆卸包络顶约Z1607.5。新HX保温顶Z1426，因此执行器仍控制上方空间。'),('不直接减120','C02外壳顶Z1752。若阀位和拆卸方式都不变，至Z1607.5仅剩144.5几何差额，还需扣除顶板/梁和操作余量。该数值不是允许降高量；壳体新顶高待总装检查。'),('后续建模输入','沿四条+X轴线更新隔板孔、密封领圈、可拆短节和支架；按相同W1/W2功能重布B床外接管；复核阀执行器拆装、抽芯30上提及-X移出路径。'),('制造回填项','确认R50弯制及最薄壁、OD34集管至OD35接管接合、正式活接及密封温压适用性、实际插入/旋合长度、压接钳与扳手扫掠、全段保温需求。')],703,size=8.9)
text(42,y-2,'交付文件',12,T);y-=22
y=para('主STEP：完整单芯；TWO_CORES：同向双芯；SERVICE：保温/工具预约（非实物）；NOMINAL_FLOW：名义连通水域（非制造实体）。另含接口CSV/JSON、切点坐标、顶部俯视PNG、源CAD与计算检查JSON。',y,size=9)
para('本轮没有修改C02壳体文件，也未完成四阀至公共总管的物理配管。上述冷热功能链是保留的系统架构；本次三维连通检查范围为HX本体。',y,size=9)
c.save();doc=fitz.open(P);assert len(doc)==6
for i,p in enumerate(doc):p.get_pixmap(matrix=fitz.Matrix(1.4,1.4)).save(O/'evidence'/f'pdf_page_{i+1}.png')
print('PDF_OK',len(doc),str(P),flush=True)
