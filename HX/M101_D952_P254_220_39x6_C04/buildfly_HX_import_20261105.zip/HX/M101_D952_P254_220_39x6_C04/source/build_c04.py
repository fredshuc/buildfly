"""C04: C03 core unchanged, two +X interfaces at 150 mm Y pitch.
Run with Python + CadQuery. Nominal design, mm; read interface notes before fabrication.
"""
from core_base import *
import time
T=time.time()
PORT_X=350.;PORT_Z=1220.;Y1=726.85;Y2=576.85;BEND_R=50.
UNION_START_X=267.5;PIPE_END_X=291.5 # 24 mm visual engagement, not a released cut length
COLORS.update({'service':(.55,.78,.87),'water':(.18,.58,.84)})

def solid_sweep(ed,start,tangent,d):
 return cq.Workplane(cq.Plane(origin=start,normal=tangent)).circle(d/2).sweep(cq.Wire.assembleEdges(ed),isFrenet=False).val()

def route(name,x,yend):
 a=(x,Y1,1080);b=(x,Y1,1170)
 if name=='W1':
  c=(x+50,Y1,1220);m=(x+50-50/math.sqrt(2),Y1,1170+50/math.sqrt(2))
  bends=[arc(b,m,c),line(c,(PIPE_END_X,yend,PORT_Z))]
  coords=[a,b,c,(PIPE_END_X,yend,PORT_Z)]
 else:
  c=(x,Y1-50,1220);m=(x,Y1-50+50/math.sqrt(2),1170+50/math.sqrt(2))
  d=(x,yend+50,1220);e=(x+50,yend,1220)
  m2=(x+50-50/math.sqrt(2),yend+50-50/math.sqrt(2),1220)
  bends=[arc(b,m,c),line(c,d),arc(d,m2,e),line(e,(PIPE_END_X,yend,PORT_Z))]
  coords=[a,b,c,d,e,(PIPE_END_X,yend,PORT_Z)]
 return [line(a,b)]+bends,bends,coords

union_src_path=OUT/'sources/4015211138875.stp'
union_raw=cq.importers.importStep(str(union_src_path)).val()
union_box=bbox(union_raw)
assert max(abs(a-b) for a,b in zip(union_box,[-43,-28.6822814,-28.6822812,39.5,28.6822799,28.6822812]))<.001
routes={};clearance=[];services=[];flow_top=[]
for name,x,y in [('W1',XS[0],Y1),('W2',XS[-1],Y2)]:
 edges,bends,points=route(name,x,y);routes[name]={'x':x,'y':y,'edges':edges,'bends':bends,'points':points}
 add(name+'_D35_END_PIPE',sweep(edges,points[0],(0,0,1),35,28),'riser','riser')
 # Preserve OEM source: filled interior surfaces are not changed or called flow geometry.
 uni=union_raw.translate((310.5,y,PORT_Z))
 add(name+'_VIEGA138875_OEM_LAYOUT_ONLY',uni,'port','port')
 insulated=solid_sweep(bends,points[1],(0,0,1),85)
 cover=cq.Solid.makeCylinder(56,83,cq.Vector(267,y,PORT_Z),cq.Vector(1,0,0))
 tool=cq.Solid.makeCylinder(55,143,cq.Vector(267,y,PORT_Z),cq.Vector(1,0,0))
 services.extend([(name+'_D85_PIPE_INSULATION',insulated),(name+'_D112_REMOVABLE_UNION_COVER',cover),(name+'_D110_TOOL_BUDGET',tool)])
 routes[name]['insulated']=insulated;routes[name]['cover']=cover;routes[name]['tool']=tool
 # Nominal continuous flow path includes a reference bore through the OEM fitting envelope.
 full=edges+[line(points[-1],(350,y,1220))]
 flow_top.append(solid_sweep(full,points[0],(0,0,1),28))

print('New end pipes and OEM fittings created',flush=True)
# Check exact new material / frame intersections; tool reservations are not material.
frame=[p for p in parts if p[2]=='frame']
new=[p for p in parts if p[3] in ['riser','port']]
collisions=[]
for an,a,_,_ in new:
 for bn,b,_,_ in frame:
  if overlap(bbox(a),bbox(b)):
   v=a.intersect(b).Volume()
   if v>1e-4:collisions.append([an,bn,v])
assert not collisions,collisions
for nm,s in services:
 for bn,b,_,_ in frame:
  if overlap(bbox(s),bbox(b)):
   v=s.intersect(b).Volume()
   if v>1e-4:collisions.append([nm,bn,v])
assert not collisions,collisions
for category in ['insulated','cover','tool']:
 a,b=routes['W1'][category],routes['W2'][category]
 gap=a.distance(b);vol=a.intersect(b).Volume()
 assert vol<1e-4
 clearance.append({'pair':category,'minimum_3D_gap_mm':gap,'intersection_mm3':vol})
# Cross-check all W1 reservations against W2 hardware/insulation, not only matching categories.
allg=[]
for an,a in [('pipe',routes['W1']['insulated']),('cover',routes['W1']['cover']),('tool',routes['W1']['tool'])]:
 for bn,b in [('pipe',routes['W2']['insulated']),('cover',routes['W2']['cover']),('tool',routes['W2']['tool'])]:
  gap=a.distance(b);assert gap>0
  allg.append({'W1':an,'W2':bn,'gap_mm':gap})

# A single connected fluid solid per six-pass circuit, followed by complete network fuse.
def circuit_flow(z):
 ed=[]
 for r,x in enumerate(XS):
  zz=z+ROW_DZ[r]
  if r%2==0:
   a=(x,714.85 if r==0 else 694.775,zz);b=(x,44.775,zz)
  else:
   a=(x,44.775,zz);b=(x,714.85 if r==5 else 694.775,zz)
  ed.append(line(a,b))
  if r<5:
   x2=XS[r+1];z2=z+ROW_DZ[r+1]
   c=(x2,b[1],z2)
   mid=((x+x2)/2,b[1]+(-R if r%2==0 else R),(zz+z2)/2)
   ed.append(arc(b,mid,c))
 return solid_sweep(ed,(XS[0],714.85,z),(0,-1,0),DI)

headers=[cq.Solid.makeCylinder(14,1036,cq.Vector(x,Y1,44)) for x in [XS[0],XS[-1]]]
flow_parts=headers+flow_top
graph=[]
for i,z in enumerate(ZS):
 s=circuit_flow(z);assert s.isValid() and len(s.Solids())==1
 meets=[s.intersect(h).Volume() for h in headers]
 assert min(meets)>1.,(i,meets)
 graph.append({'circuit':i+1,'straight_passes':6,'u_bends':5,'header_W1_overlap_mm3':meets[0],'header_W2_overlap_mm3':meets[1]})
 flow_parts.append(s)
print('Fuse 39 six-pass circuits and two headers / ports into one nominal flow domain',flush=True)
fluid=flow_parts[0].fuse(*flow_parts[1:]).clean()
assert fluid.isValid() and len(fluid.Solids())==1,('flow_disconnected',len(fluid.Solids()))
# Pressure copper continuity of unchanged circuit prototype, independent of fluid check.
merged=members[0][1].fuse(*[s for _,s in members[1:]])
assert len(merged.Solids())==1

print('Export single, same-orientation pair, service and nominal flow STEP',flush=True)
assy.save(str(OUT/(ID+'.step')))
pair=cq.Assembly(name=ID+'_IDENTICAL_SAME_ORIENTATION_PAIR')
pair.add(assy,name='BED_A_R_IDENTITY',loc=cq.Location(cq.Vector(0,0,0)))
pair.add(assy,name='BED_B_R_IDENTITY',loc=cq.Location(cq.Vector(0,840,0)))
pair.save(str(OUT/(ID+'_TWO_CORES.step')))
service=cq.Assembly(name=ID+'_SPACE_RESERVATIONS_NOT_HARDWARE')
for nm,sh in services:service.add(sh,name=nm,color=cq.Color(.3,.65,.85,.25))
service.save(str(OUT/(ID+'_SERVICE.step')))
cq.exporters.export(fluid,str(OUT/(ID+'_NOMINAL_FLOW.step')))

ports=[{'id':n,'x_mm':350.,'y_mm':y,'z_mm':1220.,'nx':1,'ny':0,'nz':0,'interface':'Rp1-1/4 female, OEM CAD face reference','network_function':'CS/HR' if n=='W1' else 'CR/HS','coordinate_status':'candidate'} for n,y in [('W1',Y1),('W2',Y2)]]
with (OUT/'INTERFACES.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=ports[0].keys());w.writeheader();w.writerows(ports)
placement={'definition':'Shell integration input; preserve A origin; same orientation B in existing C02 B bay, pending shell rebuild','A':{'R':[[1,0,0],[0,1,0],[0,0,1]],'t_mm':[265,-802.175,150]},'B':{'R':[[1,0,0],[0,1,0],[0,0,1]],'t_mm':[265,37.825,150]},'pair_preview_delta_Y_mm':840.,'global_ports':[]}
for bed in ['A','B']:
 t=placement[bed]['t_mm']
 for p in ports:placement['global_ports'].append({'id':bed+'.'+p['id'],'xyz_mm':[p['x_mm']+t[0],p['y_mm']+t[1],p['z_mm']+t[2]],'direction':[1,0,0],'function':p['network_function'],'shell_opening_status':'not_released'})
(OUT/'INTERFACES_AND_PLACEMENTS.json').write_text(json.dumps({'local_ports':ports,'placement':placement},indent=2))
with (OUT/'ROUTE_TANGENT_POINTS.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['route','point_index','x_mm','y_mm','z_mm','meaning'])
 for nm,r in routes.items():
  for i,p in enumerate(r['points']):w.writerow([nm,i,*p,'tangent or end point; circular bends R50, not sharp polyline'])

print('Read back single STEP',flush=True)
readback=cq.importers.importStep(str(OUT/(ID+'.step'))).val()
assert len(readback.Solids())==len(parts)
bb=bbox(readback)
assert max(abs(a-b)for a,b in zip(bb,[0,0,0,350,Y1+28.6822799,1220+28.6822812]))<.001,bb
assert all(s.isValid()for s in protos.values())
print('Read back same-orientation pair STEP',flush=True)
pairread=cq.importers.importStep(str(OUT/(ID+'_TWO_CORES.step'))).val()
assert len(pairread.Solids())==2*len(parts)
flowread=cq.importers.importStep(str(OUT/(ID+'_NOMINAL_FLOW.step'))).val()
assert len(flowread.Solids())==1 and flowread.isValid()
report={'id':ID,'date':'2026-11-05','status':'INTERFACE_CANDIDATE_NOT_MANUFACTURING_RELEASE','core_basis':'C03 core copied without dimensional change','circuits':39,'passes_per_circuit':6,'straight_legs':234,'fins':306,'fin_pitch_mm':2.,'die_pitch_Z_X_mm':[25.4,22.],'stagger_Z_mm':12.7,'headers_X_Y_mm':[[162.65,726.85],[52.65,726.85]],'port_X_Z_mm':[350,1220],'port_Y_mm':[Y1,Y2],'port_direction':[1,0,0],'port_Y_spacing_mm':150,'new_pipe_OD_ID_mm':[35,28],'bend_R_mm':50,'insulation_start_Z_mm':1170,'pipe_insulation_thickness_mm':25,'union_cover_OD_mm':112,'tool_budget_OD_mm':110,'tool_budget_end_X_mm':410,'tool_budget_status':'project reservation, not verified OEM wrench/press-jaw swept volume','union_source':{'article':'Viega 138875 / 2262','raw_step_sha256':hashlib.sha256(union_src_path.read_bytes()).hexdigest(),'raw_bbox_mm':union_box,'catalog_L_mm':83,'CAD_axial_length_mm':82.5,'model_usage':'unaltered OEM placement geometry; internal filled faces do not represent water passage','visual_pipe_engagement_mm':24,'engagement_status':'layout placeholder, not manufacturer-qualified insertion or cut length'},'material_bbox_mm':bb,'conservative_insulated_bbox_mm':[0,0,0,350,782.85,1276],'material_protrusion_beyond_frame_X220_mm':130,'service_protrusion_beyond_frame_X220_mm':190,'frame_collisions_mm3':collisions,'clearance_checks':clearance,'cross_clearances':allg,'common_port_pipe_insulation_gap_mm':65,'conservative_insulated_union_gap_mm':38,'two_tool_budgets_gap_mm':40,'minimum_insulation_start_above_guide_top_mm':36,'nominal_flow_domain':{'connected_solids':len(flowread.Solids()),'valid':flowread.isValid(),'volume_L_reference':fluid.Volume()/1e6,'scope':'39x6 core, headers, end pipes and ideal ID28 continuation to two Rp faces; excludes drain branches; OEM union internals and branch insertion wall details simplified, not a CFD/pressure model','circuits':graph},'STEP_readback':{'single_solids':len(readback.Solids()),'pair_solids':len(pairread.Solids()),'pair_bbox_mm':bbox(pairread),'all_unique_build_shapes_valid':True},'elapsed_s':time.time()-T}
(OUT/'DESIGN_AND_CHECKS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('Tessellate actual CAD for views',flush=True)
meshes={}
for key,sh in protos.items():
 vs,ts=sh.tessellate(.5,.3);meshes[key]={'v':[(v.x,v.y,v.z)for v in vs],'t':ts}
raw=json.dumps({'meshes':meshes,'items':instances,'colors':COLORS}).encode()
p=OUT/'CAD_MESH.json.gz';tmp=p.with_suffix('.tmp');tmp.write_bytes(gzip.compress(raw));tmp.replace(p)
assert json.loads(gzip.decompress(p.read_bytes()))['items']==json.loads(raw)['items']
print(json.dumps({'status':'PASS','parts':len(parts),'bbox':bb,'fluid_components':len(fluid.Solids()),'clearances':clearance,'elapsed_s':time.time()-T}),flush=True)
