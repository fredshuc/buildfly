"""M101 D9.52 / 25.4 x 22 staggered / 39 x 6. mm. RFQ concept.
Run from any directory. Requires CadQuery 2.7 and ezdxf.
Pressure joints and fin collars remain simplified; see DESIGN_AND_CHECKS.json.
"""
from pathlib import Path
import math,json,csv,gzip,hashlib
import cadquery as cq
import ezdxf
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib

OUT=Path(__file__).resolve().parent.parent
ID='M101_D952_P254_220_39x6_C04'
COLORS={'fin':(.72,.77,.80),'copper':(.72,.37,.17),'riser':(.86,.48,.22),'frame':(.18,.30,.39),'port':(.87,.70,.30)}
N=39;NR=6;NF=306;PZ=25.4;PX=22.;STAG=12.7
OD=9.64;DI=8.52;FD=152.;FH=1000.
X0=31.65;Z0=54.;CX=107.65
XS=[162.65-PX*r for r in range(NR)]
ZS=[65.05+PZ*i for i in range(N)]
ROW_DZ=[0 if r%2==0 else STAG for r in range(NR)]
R=math.hypot(PX,STAG)/2

def bbox(sh):
 b=Bnd_Box();BRepBndLib.AddOptimal_s(sh.wrapped,b,False,False);return list(b.Get())
def overlap(a,b,tol=1e-6):return all(min(a[j+3],b[j+3])-max(a[j],b[j])>tol for j in range(3))
def box(x,y,z,dx,dy,dz):return cq.Solid.makeBox(dx,dy,dz,cq.Vector(x,y,z))
def tube(a,b,od,di):
 d=cq.Vector(*b)-cq.Vector(*a)
 return cq.Solid.makeCylinder(od/2,d.Length,cq.Vector(*a),d.normalized()).cut(cq.Solid.makeCylinder(di/2,d.Length,cq.Vector(*a),d.normalized()))
def line(a,b):return cq.Edge.makeLine(cq.Vector(*a),cq.Vector(*b))
def arc(a,b,c):return cq.Edge.makeThreePointArc(cq.Vector(*a),cq.Vector(*b),cq.Vector(*c))
def sweep(ed,start,tangent,od=OD,di=DI):
 return cq.Workplane(cq.Plane(origin=start,normal=tangent)).circle(od/2).circle(di/2).sweep(cq.Wire.assembleEdges(ed),isFrenet=False).val()

assy=cq.Assembly(name=ID+'_SINGLE_PRODUCT');parts=[];protos={};instances=[]
def add(name,shape,kind,group=None,loc=(0,0,0),key=None):
 key=key or name
 if key not in protos:
  assert shape.isValid(),name
  protos[key]=shape
 assy.add(protos[key],name=name,loc=cq.Location(cq.Vector(*loc)),color=cq.Color(*COLORS[kind]))
 placed=protos[key].translate(loc)
 parts.append((name,placed,kind,group or kind))
 instances.append({'name':name,'mesh':key,'pos':loc,'kind':kind,'group':group or kind})

def perforated(y,z0,height,thick,rad,x0=X0,depth=FD,xs=XS,zs=ZS):
 outer=cq.Wire.makePolygon([cq.Vector(x,y,z) for x,z in [(x0,z0),(x0+depth,z0),(x0+depth,z0+height),(x0,z0+height),(x0,z0)]])
 holes=[cq.Wire.makeCircle(rad,cq.Vector(x,y,z+ROW_DZ[r]),cq.Vector(0,1,0)) for r,x in enumerate(xs) for z in zs]
 return cq.Solid.extrudeLinear(outer,holes,cq.Vector(0,thick,0))

print('Fin prototype: 234 holes',flush=True)
fin=perforated(0,Z0,FH,.15,OD/2)
for i in range(NF):add('FIN_%03d'%i,fin,'fin',loc=(0,62.775+2*i-.075,0),key='fin')

def circuit_members(xs,far_y,near_y,head_y):
 result=[]
 for k in range(3):
  r=2*k;x=xs[r];xn=xs[r+1];z=ROW_DZ[r];zn=ROW_DZ[r+1]
  a=(x,head_y if k==0 else near_y,z);b=(x,far_y,z)
  c=(xn,far_y,zn);d=(xn,head_y if k==2 else near_y,zn)
  mid=((x+xn)/2,far_y-R,(z+zn)/2)
  result.append(('LONG_U_%d'%(k+1),sweep([line(a,b),arc(b,mid,c),line(c,d)],a,(0,-1,0))))
 for k in range(2):
  r=2*k+1;a=(xs[r],near_y,ROW_DZ[r]);b=(xs[r+1],near_y,ROW_DZ[r+1])
  mid=((xs[r]+xs[r+1])/2,near_y+R,(ROW_DZ[r]+ROW_DZ[r+1])/2)
  result.append(('RETURN_%d'%(k+1),sweep([arc(a,mid,b)],a,(0,1,0))))
 return result

members=circuit_members(XS,44.775,694.775,714.85)
print('39 circuits / 117 long U / 78 return bends',flush=True)
for i,z in enumerate(ZS):
 for nm,sh in members:add('C%02d_%s'%(i+1,nm),sh,'copper','circuit',(0,0,z),nm)

for name,x,dz in [('W1',XS[0],0),('W2',XS[-1],STAG)]:
 h=tube((x,726.85,44),(x,726.85,1080),34,28)
 cuts=[cq.Solid.makeCylinder(OD/2,30,cq.Vector(x,726.85,z+dz),cq.Vector(0,-1,0)) for z in ZS]
 h=h.cut(*cuts);add(name+'_HEADER_39_BRANCHES',h,'copper','header')
 add(name+'_BOTTOM_CAP',tube((x,726.85,41),(x,726.85,44),34,6),'copper','header')
 add(name+'_DRAIN_BOSS',tube((x,726.85,31),(x,726.85,41),12,6),'port','drain')
 add(name+'_DRAIN_CLOSURE_PROXY',cq.Solid.makeCylinder(6,5,cq.Vector(x,726.85,26)),'port','drain')

# Reuse interface positions, rebuild core supports to this fin outline.
for k,y in enumerate([0,640]):
 sh=box(20,y,0,180,80,8)
 for x in [52,172]:
  cy=y+15
  if k==0 and x==52:cut=cq.Solid.makeCylinder(8.5,8,cq.Vector(x,cy,0))
  else:cut=cq.Workplane('XY').center(x,cy).slot2D(19 if k==0 else 23,17,angle=0 if k==0 else 90).extrude(8).val()
  sh=sh.cut(cut)
 add('SHOE_%d'%k,sh,'frame')
for x in [0,212]:
 for y in [41.775,673.775]:add('POST_%s_%s'%(x,y),box(x,y,8,8,20,1076),'frame')
 for z in [34,1054]:add('AIR_EDGE_%s_%s'%(x,z),box(x,41.775,z,8,652,20),'frame')
for y in [41.775,673.775]:
 add('BOTTOM_CROSS_%s'%y,box(8,y,8,204,20,18),'frame')
 add('TOP_CROSS_%s'%y,box(8,y,1074,204,20,10),'frame')
for k,y in enumerate([27.35,707.35]):
 lug=box(90,y-4,1098,40,8,36)
 cut=cq.Workplane(cq.Plane(origin=(110,y-4,1116),xDir=(1,0,0),normal=(0,1,0))).slot2D(21.2,13.2,90).extrude(8).val()
 add('UPPER_GUIDE_%d'%k,lug.cut(cut),'frame','guide')
 gy=min(y-4,41.775 if k==0 else 673.775);gymax=max(y+4,61.775 if k==0 else 693.775)
 add('GUIDE_BRIDGE_%d'%k,box(90,gy,1084,40,gymax-gy,14),'frame')
for k,y in enumerate([57.775,677.775]):
 add('TUBE_SHEET_%d'%k,perforated(y,42,1024,3,5.1),'frame','tube_sheet')
 for j,(x,w) in enumerate([(8,X0-8),(X0+FD,212-X0-FD)]):add('PLATE_TAB_%d_%d'%(k,j),box(x,y,42,w,3,1024),'frame')

