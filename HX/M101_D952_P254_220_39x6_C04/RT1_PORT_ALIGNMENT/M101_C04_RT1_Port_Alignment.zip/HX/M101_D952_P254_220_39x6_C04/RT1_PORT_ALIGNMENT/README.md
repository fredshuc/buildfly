# M101 C04 water ports in shell C04

Use the single-core 39-circuit, six-pass M101 C04 as the part for **both** beds. Install it twice using the translations below. The same physical nozzle serves the same function on each bed. This record applies to shell C04 at the reviewed 840 mm bed pitch. If the shell changes bed pitch or height, recompute the machine coordinates from the local HX datums.

## Assembly datums

All coordinates are in mm. X runs through the core, Y across the beds and Z upwards. Both transformations have identity rotation. The local W1 and W2 faces are (350, 726.850, 1220) and (350, 576.850, 1220). Translate by (265, −802.175, 1150) for A and (265, 37.825, 1150) for B. The archived HX import ZIP, interface PDF and pair preview predate this shell placement. Use the [updated placement register](../INTERFACES_AND_PLACEMENTS.json) for shell C04.

| Port | Installed union face (X, Y, Z) | Gland near face (X, Y, Z) | Required valve port | Cold / hot service |
|---|---|---|---|---|
| A.W1 | 615, −75.325, 2370 | 750, −75.325, 2370 | A_VL.AB | Cold supply / hot return |
| A.W2 | 615, −225.325, 2370 | 750, −225.325, 2370 | A_VU.AB | Cold return / hot supply |
| B.W1 | 615, 764.675, 2370 | 750, 764.675, 2370 | B_VL.AB | Cold supply / hot return |
| B.W2 | 615, 614.675, 2370 | 750, 614.675, 2370 | B_VU.AB | Cold return / hot supply |

All four union faces are Rp 1¼ female and point towards +X. Gland material extends from X750 to X752. The 135 mm from union face to the near sheet face is a layout dimension. Spool cut length depends on the mating fittings and insertion depths. Cold water enters W1 and leaves W2. Hot water enters W2 and leaves W1.

![Shell port datums and revised W1 plate edge](port_fit.svg)

## Gland fit and proposed shell mating parts

The nominal axes coincide in the two source STEPs. In the shell STEP each original W2 opening has a full circular edge. Both W1 cut-outs break through the positive-Y edge of the strip. Only 213.661° of the Ø110 cylindrical cut remains. The Ø110 circle projects 39.075 mm beyond the original edge. A centreline or solid-interference check alone misses this detail.

The [mating reference STEP](C04_GLAND_MATING_REFERENCE.step) contains the **two proposed replacement gland strips in shell coordinates**. Replace A_WATER_GLAND and B_WATER_GLAND when trialling them. The single-core product uses its existing nozzle geometry. The integral tab on each 2 mm strip extends the +Y edge by 55 mm between Z2295 and Z2445. Both revised W1 openings have a 360° profile and 15.925 mm of material between the hole and the outboard edge. W2 retains its original profile. A nominal Ø85 insulated pipe has 12.5 mm radial clearance in each opening. There is 35 mm between the two plates at their closest point.

The added material was checked against the other 187 solids of the reviewed shell STEP for each plate. The STEP re-import yielded two valid solids and four full bores. For the final gland, select the split seal or grommet and check its flange, fasteners and removal path against the available land. The shell owner should confirm whether side-entry removal requires a split closure before adopting the outline. The HX perimeter air seal is a separate interface.

## Water-side handoff

The required valve tags above identify the connections. The RT1-measured B_VL and B_VU AB faces are both at Y75.325. Relative to their correct HX faces, the Y errors are −689.350 and −539.350 mm. Route or reposition the valve pair to these assigned ports. Carry the upper-actuator removal envelope into the layout check. In C04 it projects 57.5 mm above the roof underside on **both** beds. Rerun clearance checks with the selected unions, spools, supports and removal envelopes before issuing any fabrication drawing.

## Evidence

- [Installed port table](INSTALLED_PORTS.csv) and [CAD check results](CHECKS.json).
- [RT1 review and source measurements](https://github.com/fredshuc/buildfly/tree/72f89eb410fd8ec1baa979cd3af8faeefc46636e/AirTransformerShell/revisions/C04/RT1_REVIEW).
- [Reviewed shell CAD archive](https://github.com/fredshuc/buildfly/blob/72f89eb410fd8ec1baa979cd3af8faeefc46636e/AirTransformerShell/revisions/C04/C04_CAD.zip) and [single-core STEP](../M101_D952_P254_220_39x6_C04.step).

To reproduce with Python 3.12 and CadQuery, extract C04_INSTALLED.step from C04_CAD.zip and run:

```sh
python verify_ports.py ../M101_D952_P254_220_39x6_C04.step /path/to/C04_INSTALLED.step ./check-output
```
