"""Check the detailed C04 HX and shell STEPs; export the HX-side fit proposal.

Run: python verify_ports.py CORE.step C04_INSTALLED.step OUTPUT_DIRECTORY
Inputs are the single-core STEP and the installed STEP from shell C04_CAD.zip.
All lengths are in mm. Uses CadQuery 2.x / Open CASCADE.
"""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

import cadquery as cq
from OCP.BRepAdaptor import BRepAdaptor_Surface

SHELL_HASH = "39ca12fd602d70d71eec9495613f02b1ff1b0d7f704f3caee8f5d4593741b98f"
CORE_HASH = "efca1457db1e90731da5adccc963e49f197238e8cbdda91a1ae95d7c8a9646e5"
PLACEMENTS = {"A": (265, -802.175, 1150), "B": (265, 37.825, 1150)}
PORTS = {"W1": (726.85, "VL", "CS", "HR"), "W2": (576.85, "VU", "CR", "HS")}
TOL = 0.001
FACE_X, FACE_Z = 350, 1220
R_HOLE, R_PIPE = 55, 42.5
EAR_EXTENSION, EAR_HALF_HEIGHT = 55, 75

def require(condition, message):
    if not condition:
        raise ValueError(message)

def close(a, b):
    return abs(a - b) <= TOL

def axial_cylinders(solid, radius):
    for face in solid.Faces():
        if face.geomType() != "CYLINDER":
            continue
        cylinder = BRepAdaptor_Surface(face.wrapped).Cylinder()
        direction = cylinder.Axis().Direction()
        if close(cylinder.Radius(), radius) and close(abs(direction.X()), 1):
            origin = cylinder.Location()
            yield origin.Y(), origin.Z(), face.Area()

def end_faces(hx):
    ports = {}
    for label, (y, *_) in PORTS.items():
        union_faces = []
        for solid in hx:
            b = solid.BoundingBox()
            if not (close(b.xmax, FACE_X) and b.ymin < y < b.ymax and b.zmin < FACE_Z < b.zmax):
                continue
            for face in solid.Faces():
                f = face.BoundingBox()
                if close(f.xmin, FACE_X) and close(f.xmax, FACE_X):
                    union_faces.append(face)
        require(len(union_faces) == 1, f"{label}: expected one OEM connection face")
        face = union_faces[0]
        normal = face.normalAt().toTuple()
        require(math.dist(normal, (1, 0, 0)) < 1e-5, f"{label}: face normal")
        # The OEM face is a trimmed spline. Take the axis from the actual OD35 straight.
        axes = [(cy, cz) for solid in hx if solid.BoundingBox().zmax > FACE_Z
                for cy, cz, _ in axial_cylinders(solid, 17.5)
                if math.hypot(cy-y, cz-FACE_Z) < TOL]
        require(bool(axes), f"{label}: terminal tube axis missing")
        centre = face.Center()
        require(math.hypot(centre.y-y, centre.z-FACE_Z) < TOL, f"{label}: OEM face/pipe offset")
        ports[label] = (centre.x, *axes[0])
    return ports

def hole_measurement(plate, y, z):
    matches = [(a, b, area) for a, b, area in axial_cylinders(plate, R_HOLE)
               if math.hypot(a-y, b-z) < TOL]
    require(bool(matches), f"missing gland cut at Y{y}, Z{z}")
    # Summing handles a CAD seam that splits the trimmed cylinder into several faces.
    area = sum(row[2] for row in matches)
    return matches[0][:2], area/(R_HOLE*plate.BoundingBox().xlen)

def bbox_overlap(a,b):
    return (min(a.xmax,b.xmax) > max(a.xmin,b.xmin)+1e-6 and
            min(a.ymax,b.ymax) > max(a.ymin,b.ymin)+1e-6 and
            min(a.zmax,b.zmax) > max(a.zmin,b.zmin)+1e-6)

def run(core_path, shell_path, out):
    require(hashlib.sha256(shell_path.read_bytes()).hexdigest() == SHELL_HASH, "shell STEP revision")
    core_sha = hashlib.sha256(core_path.read_bytes()).hexdigest()
    require(core_sha == CORE_HASH, "HX STEP revision")
    out.mkdir(exist_ok=True, parents=True)
    host = cq.importers.importStep(str(shell_path)).val().Solids()
    hx = cq.importers.importStep(str(core_path)).val().Solids()
    require((len(host), len(hx)) == (188, 537), "input solid counts")
    local = end_faces(hx)
    host_boxes = [s.BoundingBox() for s in host]
    derived = cq.Assembly(name="HX_C04_PORT_FIT_SHELL_DATUM")
    ports, checks, candidates = [], {}, []
    for bed, (dx,dy,dz) in PLACEMENTS.items():
        # Select the original plate by its actual section and by containment of W2.
        target_y = PORTS["W2"][0]+dy
        ids = [i for i,b in enumerate(host_boxes) if close(b.xmin,750) and close(b.xlen,2)
               and close(b.ylen,750) and close(b.zlen,240) and b.ymin<target_y<b.ymax]
        require(len(ids) == 1, f"{bed}: installed gland")
        idx = ids[0]
        plate, bounds = host[idx], host_boxes[idx]
        z = FACE_Z+dz
        # Integral local extension leaves the rails and the remainder of the original outline clear.
        ear = cq.Solid.makeBox(bounds.xlen, EAR_EXTENSION, 2*EAR_HALF_HEIGHT,
                               cq.Vector(bounds.xmin, bounds.ymax, z-EAR_HALF_HEIGHT))
        w1_y = local["W1"][1]+dy
        hole = cq.Solid.makeCylinder(R_HOLE, bounds.xlen+2,
                       cq.Vector(bounds.xmin-1, w1_y,z), cq.Vector(1,0,0))
        candidate = plate.fuse(ear).cut(hole).clean()
        require(candidate.isValid() and len(candidate.Solids()) == 1, f"{bed}: plate validity")
        added = candidate.cut(plate)
        require(added.Volume()>0 and plate.cut(candidate).Volume()<TOL, f"{bed}: change is additive")
        interactions = [added.intersect(s).Volume() for i,s in enumerate(host)
                        if i!=idx and bbox_overlap(added.BoundingBox(),host_boxes[i])]
        max_overlap = max(interactions,default=0)
        require(max_overlap<TOL, f"{bed}: added material interferes with an installed C04 solid")
        require(close(candidate.BoundingBox().ymax-w1_y-R_HOLE, 15.925), f"{bed}: edge ligament")
        # install a separate solid per bed in the returned STEP; no proxy pipes in the parts list
        derived.add(candidate, name=bed+"_WATER_GLAND_MATING_REFERENCE",
                    color=cq.Color(0.4,0.65,0.75))
        candidates.append(candidate)
        checks[bed] = dict(original_positive_Y_edge_mm=round(bounds.ymax,3),
                    candidate_positive_Y_edge_mm=round(candidate.BoundingBox().ymax,3),
                    old_W1_breakout_mm=round(w1_y+R_HOLE-bounds.ymax,3),
                    new_W1_min_ligament_mm=round(candidate.BoundingBox().ymax-w1_y-R_HOLE,3),
                    added_material_max_clash_mm3=round(max_overlap,6))
        for label, (_, valve, cold, hot) in PORTS.items():
            x,y,z_local = local[label]
            x,y,z = x+dx,y+dy,z_local+dz
            (hole_y,hole_z), original_angle = hole_measurement(plate,y,z)
            _, new_angle = hole_measurement(candidate,y,z)
            require(close(new_angle,2*math.pi), f"{bed}.{label}: open proposed hole")
            require((label=="W1") == (original_angle<2*math.pi-TOL), f"{bed}.{label}: original profile")
            error = math.hypot(hole_y-y,hole_z-z)
            require(error<TOL and close(bounds.xmin-x,135), f"{bed}.{label}: port alignment")
            reserve = [s for s,b in zip(host,host_boxes) if close(b.xmin,x) and close(b.xlen,160)
                       and close(b.ylen,2*R_PIPE) and close((b.ymax+b.ymin)/2,y)
                       and close((b.zmax+b.zmin)/2,z)]
            require(len(reserve)==1 and bool(list(axial_cylinders(reserve[0],R_PIPE))),
                    f"{bed}.{label}: OD85 reserve")
            require(close(reserve[0].distance(candidate), R_HOLE-R_PIPE), f"{bed}.{label}: clearance")
            ports.append(dict(port=bed+"."+label,face_x=round(x,3),y=round(y,3),z=round(z,3),
                         outward_normal="+X",gland_x_near=round(bounds.xmin,3),
                         gland_x_far=round(bounds.xmax,3),bore_dia=110,insulated_dia=85,
                         transverse_axis_error_mm=round(error,6),radial_clearance_mm=12.5,
                         old_bore_arc_deg=round(math.degrees(original_angle),3),
                         proposed_bore_arc_deg=round(math.degrees(new_angle),3),
                         connect_to=bed+"_"+valve+".AB",cold_service=cold,hot_service=hot))
    require(candidates[0].distance(candidates[1])>0,"plate-to-plate clearance")
    for bed in PLACEMENTS:
        pair = [p for p in ports if p["port"].startswith(bed+".")]
        require(close(pair[0]["y"]-pair[1]["y"],150) and close(pair[0]["z"],pair[1]["z"]),
                f"{bed}: port pitch and elevation")
    name = "C04_GLAND_MATING_REFERENCE.step"
    derived.save(str(out/name))
    back = cq.importers.importStep(str(out/name)).val().Solids()
    require(len(back)==2 and all(s.isValid() for s in back), "export readback")
    for p in ports:
        plate = next(s for s in back if s.BoundingBox().ymin < p["y"] < s.BoundingBox().ymax)
        _, angle = hole_measurement(plate,p["y"],p["z"])
        require(close(angle,2*math.pi), f'{p["port"]}: exported profile')
    with (out/"INSTALLED_PORTS.csv").open("w",newline="") as f:
        writer = csv.DictWriter(f,fieldnames=list(ports[0]))
        writer.writeheader()
        writer.writerows(ports)
    results = dict(baseline_commit="72f89eb410fd8ec1baa979cd3af8faeefc46636e",
                   core_sha256=core_sha,shell_sha256=SHELL_HASH,
                   input_solids={"hx":len(hx),"shell":len(host)},plate_checks=checks,
                   installed_ports=ports,plate_to_plate_mm=round(candidates[0].distance(candidates[1]),3),
                   step_readback_solids=len(back),status="CAD interface check; shell adoption pending")
    (out/"CHECKS.json").write_text(json.dumps(results,indent=2)+"\n")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("core","shell","output"):
        parser.add_argument(name,type=Path)
    args = parser.parse_args()
    run(args.core,args.shell,args.output)
