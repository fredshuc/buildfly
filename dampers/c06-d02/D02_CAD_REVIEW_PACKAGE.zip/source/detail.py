"""Prepare engineering screens and the RT2 load-path drawing from checked STEP."""
import json
import os
from pathlib import Path
from model_io import ROOT, bounds, named_step, json_write, np
from baseline import Scene, digest
from supports import BOTTOM, PICKUP_X


def beam_screen(parts, shell, report):
    # Per 1000 N at the seats. Positive reactions only; no equal four-way split.
    E, F = 200000., 1000.
    bar_I = (20-4)*32**3/12  # conservatively remove a 4 mm stripe along the entire bar
    side_I = (24*32**3-18*26**3)/12
    L, seat_centre_from_end = 724., 62.
    # Any resultant may move over the 60 mm crown. Its inward edge gives
    # the largest simple-beam compliance within either bearing footprint.
    a = seat_centre_from_end+30.
    rows = {}
    for face,span in (("F",248.4),("R",329.)):
        rows[face]=dict(span_mm=span,
          crossbar_seat_deflection_mm_per_kN=round(F*a*a*(L-a)**2/(3*E*bar_I*L),4),
          crossbar_stress_MPa_per_kN=round(F*a*(L-a)*16/(L*bar_I),2),
          side_arm_max_deflection_mm_per_kN=round(F*span**3/(48*E*side_I),4),
          side_arm_max_stress_MPa_per_kN=round(F*span*16/(4*side_I),2))
    kg_per_vol=7.85e-6
    gross=sum(s.Volume() for s in parts.values())*kg_per_vol
    retired=sum(shell.shape(n).Volume() for n in report["c06_suppressed"])*kg_per_vol
    result=dict(E_assumed_N_per_mm2=E,load_scale_N=F,crossbar_conservative_I_mm4=bar_I,
        side_arm_I_mm4=side_I,bar_span_mm=L,seat_centre_from_bar_end_mm=seat_centre_from_end,
        most_inboard_bearing_load_from_bar_end_mm=a,by_face=rows,
        steel_equivalent_support_addition_kg=round(gross,2),steel_equivalent_retired_kg=round(retired,2),
        steel_equivalent_net_change_kg=round(gross-retired,2),
        scope="Simply supported separate beams; per kN per beam, positive loads, no welded joint, stand, local flange, seal or skid compliance. No FE or measured deflection.")
    json_write(ROOT/"evidence/D02_MEMBER_SCREEN.json",result)
    return result


def drawing(parts, shell, report):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    from matplotlib.patches import Rectangle
    candidates = [Path(os.environ.get("WINDIR","C:/Windows"))/"Fonts/msyh.ttc",
                  Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc")]
    for p in candidates:
        if p.exists():
            font_manager.fontManager.addfont(str(p))
            plt.rcParams["font.family"]=font_manager.FontProperties(fname=str(p)).get_name()
            break
    plt.rcParams.update({"font.size":9,"axes.unicode_minus":False,"svg.fonttype":"path"})
    ink="#163341"; sub="#45616c"; metal="#c6862b"; new="#147b70"; grey="#8998a2"; silver="#dce3e6"
    fig=plt.figure(figsize=(15.4,9.1),facecolor="white")
    fig.text(.044,.936,"风阀支承与底架连接",fontsize=25,color=ink,weight="bold")
    fig.text(.045,.899,"D02  /  C06 RT2 · N8      床 A 的侧投影；床 B 使用相同承托尺寸。图中尺寸为 mm。",fontsize=11,color=sub)
    g=fig.add_gridspec(2,3,left=.055,right=.975,bottom=.085,top=.80,
                        width_ratios=(1.04,1.18,1.1),height_ratios=(1.1,1),hspace=.53,wspace=.22)
    axf=fig.add_subplot(g[:,0]); axr=fig.add_subplot(g[:,1])
    detail=fig.add_subplot(g[0,2]); notes=fig.add_subplot(g[1,2])

    def rect(ax,x0,x1,z0,z1,color,alpha=1,lw=.65):
        ax.add_patch(Rectangle((x0,z0),x1-x0,z1-z0,facecolor=color,edgecolor=color,lw=lw,alpha=alpha))

    def projection(ax,face):
        v="A"+face
        for n in shell.names:
            take=(n.startswith(v+"_STAND_") or
                  (face=="F" and n.startswith(("BASE_END_-","FOOT_(-129."))) or
                  (face=="R" and (n in ("R_BASE_CROSS_327","R_MID_FOOT_327","REAR_STAND_BASE_CROSS","REAR_STAND_MID_FOOT","BASE_END_1260.0")
                                   or n.startswith(("POST_(1260.0","FOOT_(1260.0")))))
            if take:
                b=bounds(shell.shape(n));rect(ax,b[0],b[3],max(0,b[2]),min(920,b[5]),grey,.65)
        if face=="R":rect(ax,760,1310,102,104,grey)
        for tag,z in BOTTOM.items():
            xs=sorted(PICKUP_X[face].values())
            top=z+(421 if tag=="P" else 256)
            rect(ax,xs[0],xs[1],z,top,"#eaeff0",.8)
            for x in xs:rect(ax,x-1.5,x+1.5,z,top,metal,1,1.0)
            for x in (xs[0]+9,xs[1]-9):
                ax.annotate("",(x,z+5),(x,z+66),arrowprops=dict(arrowstyle="-|>",lw=1.5,color=metal))
            ax.text(sum(xs)/2,(z+top)/2,tag,ha="center",va="center",weight="bold",color=ink,fontsize=13)
        for n,s in parts.items():
            if (not n.startswith(v) and not(face=="R" and n=="REAR_SKID_CROSS_TIE")) or "_HI_" in n or "_M4_" in n:
                continue
            b=bounds(s);rect(ax,b[0],b[3],b[2],b[5],new,.93)
        ax.axhline(0,color=ink,lw=.85)
        ax.set(xlim=(-455,-55) if face=="F" else (755,1320),ylim=(-18,925),xlabel="X  /  mm")
        ax.set_ylabel("Z  /  mm" if face=="F" else "")
        ax.grid(axis="y",alpha=.13);ax.set_axisbelow(True)
        ax.spines[["top","right"]].set_visible(False)
        ax.tick_params(labelsize=8,colors=sub)
        ax.set_title("前侧  /  两道地面门架接入底架" if face=="F" else "后侧  /  支脚正对底架横梁",loc="left",fontsize=12.5,color=ink,pad=14)
        if face=="F":
            ax.annotate("底架拉梁",(-275,78),(-326,33),color=new,fontsize=9,
                        arrowprops=dict(arrowstyle="-",color=new,lw=.85))
        else:
            ax.annotate("后门架连接角柱",(1235,164),(1060,43),color=new,fontsize=9,
                        arrowprops=dict(arrowstyle="-",color=new,lw=.85))
    projection(axf,"F");projection(axr,"R")
    # Enlarged cross section through one crown, with the ridge and clearance to scale.
    detail.set_title("金属端法兰下缘  /  局部放大",loc="left",fontsize=12.5,color=ink,pad=14)
    rect(detail,-1.5,1.5,0,8,metal);rect(detail,1.5,3.5,0,8,"#647482")
    rect(detail,-1,1,-2,0,new);rect(detail,-9,9,-8,-2,new,.82);rect(detail,-10,10,-10,-8,"#0d5c54")
    detail.annotate("3 mm 金属",(0,5),(-11,7),fontsize=9,color=ink,arrowprops=dict(arrowstyle="-",color=ink,lw=.7))
    detail.annotate("密封垫",(2.5,4),(5,7),fontsize=9,color=ink,arrowprops=dict(arrowstyle="-",color=ink,lw=.7))
    detail.annotate("2 mm 承托凸台",(-.6,-.6),(-11,.8),fontsize=9,color=new,arrowprops=dict(arrowstyle="-",color=new,lw=.7))
    detail.text(0,-5.5,"可更换承托块",ha="center",color="white",fontsize=9)
    detail.set_xlim(-12,12);detail.set_ylim(-11,10);detail.set_aspect("equal",adjustable="box");detail.axis("off")
    notes.axis("off")
    notes.text(0,1.13,"装配核对",fontsize=13,weight="bold",color=ink,va="top")
    blocks=[("每阀四点","内、外法兰各两点，中心距 177 mm。\n每点 2 × 60 mm，贴合面积 120 mm²。"),
            ("装夹顺序","先承重、测四点反力，再紧密封焊钉。\n复测薄板法兰的位移和反力变化。"),
            ("壳体接口","抑制 C06 的 16 个旧支垫。\n承托脚、横梁和拉梁按 STEP 共原点叠装。")]
    for i,(title,msg) in enumerate(blocks):
        y=.91-i*.355
        notes.text(0,y,title,fontsize=10.5,weight="bold",color=new,va="top")
        notes.text(0,y-.105,msg,fontsize=9.3,color=ink,va="top",linespacing=1.6)
    fig.text(.045,.85,"■  D02 新支承",color=new,fontsize=10)
    fig.text(.18,.85,"■  D01 金属法兰",color=metal,fontsize=10)
    fig.text(.33,.85,"■  C06 参考结构",color=grey,fontsize=10)
    fig.text(.045,.028,"原型详设候选  ·  现场反力与法兰挠度待测  ·  精确几何与焊接接口见 STEP 和接触表",fontsize=9,color=sub)
    for ext in ("png","svg"):
        fig.savefig(ROOT/f"drawings/D02_N8_LOAD_PATH.{ext}",dpi=150,facecolor="white")
    plt.close(fig)


if __name__=="__main__":
    report=json.loads((ROOT/"evidence/D02_GEOMETRY_RESULT.json").read_text())
    path=ROOT/"cad/D02_DAMPER_SUPPORTS.step"
    assert report["step_sha256"][path.name]==digest(path.read_bytes())
    parts={p[-1]:s for p,d,s in named_step(path)}
    shell=Scene("shell")
    result=beam_screen(parts,shell,report)
    drawing(parts,shell,report)
    print("Support steel-equivalent net change (kg):",result["steel_equivalent_net_change_kg"])
