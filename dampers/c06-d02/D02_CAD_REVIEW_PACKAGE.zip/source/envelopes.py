"""Reuse D01 shaft law, native BReps and tool shapes without executing its writers."""
import json
import zipfile
from model_io import D01, cq, np
import build as d01
from native import box, read_brep, transform


def moving_bounds():
    with zipfile.ZipFile(D01/"inputs/C04_R21_BASELINES.zip") as archive:
        definitions = {p["pn"]: p for p in json.loads(archive.read("R21/native/R20_PARTS.json"))}
        configs = {t: json.loads(archive.read(f"R21/native/R20_{t}_OCCURRENCES.json")) for t in "PR"}
    rows = []
    for tag, parts in configs.items():
        for o in parts:
            if not (o.get("moving") or o["pn"] in ("BUY504","BUY_R13_BK2","BUY_R13_7206","BUY520","BUY521")):
                continue
            # Moving native records are checked against the installed neutral
            # occurrence names by the caller. Never include facility fixtures.
            s = transform(read_brep(definitions[o["pn"]]["brep"]),np.array([o["u"],o["v"],o["n"]]).T,o["o"])
            b = d01.bb(s)
            pieces = [b]
            if o["pn"] == "B200_R13":
                cuts = [b[1], -723., -93., b[4]]
                pieces = []
                for lo, hi in zip(cuts, cuts[1:]):
                    seg = s.intersect(box([b[0]-1,lo,b[2]-1,b[3]+1,hi,b[5]+1]))
                    if seg.Volume() > .001:
                        pieces.append(d01.bb(seg))
            for pb in pieces:
                sweep = d01.swept_test_bounds(dict(o=o,bounds=pb))
                for bed in "AB":
                    for face in "FR":
                        placement = d01.product_placement(tag,bed,face,d01.CFG["candidate_bed_pitch"])
                        rows.append((bed+face+tag+"/"+o["occurrence"],d01.place_bound(sweep,placement,bed)))
    return rows


def sockets():
    for bed in "AB":
        for face in "FR":
            for tag in "PR":
                p = d01.product_placement(tag,bed,face,d01.CFG["candidate_bed_pitch"])
                _,tools,_ = d01.make_hardware(p,face,d01.CFG["ports"][tag][1],tag,bed+face+tag)
                for t in tools:
                    yield t["name"],t["shape"],t["bounds"]
