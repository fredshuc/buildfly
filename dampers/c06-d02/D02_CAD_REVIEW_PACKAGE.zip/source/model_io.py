"""Read named, globally located CAD occurrences at the common machine origin, mm."""
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parents[1]
D01 = ROOT.parent / "c04-d01"
C06 = REPO / "AirTransformerShell/revisions/C06"
sys.path.insert(0, str(D01 / "source"))
import bootstrap
import cadquery as cq
import numpy as np
from OCP.IFSelect import IFSelect_RetDone
from OCP.STEPCAFControl import STEPCAFControl_Reader
from OCP.TCollection import TCollection_ExtendedString
from OCP.TDataStd import TDataStd_Name
from OCP.TDF import TDF_Label, TDF_LabelSequence
from OCP.TDocStd import TDocStd_Document
from OCP.TopLoc import TopLoc_Location
from OCP.XCAFDoc import XCAFDoc_DocumentTool


def named_step(path):
    reader = STEPCAFControl_Reader()
    reader.SetNameMode(True)
    doc = TDocStd_Document(TCollection_ExtendedString("read"))
    if reader.ReadFile(str(path)) != IFSelect_RetDone or not reader.Transfer(doc):
        raise ValueError(f"STEP read failed: {path}")
    tree = XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())

    def name(label):
        attr = TDataStd_Name()
        return attr.Get().ToExtString() if label.FindAttribute(TDataStd_Name.GetID_s(), attr) else ""

    def visit(label, loc, prefix):
        target = label
        if tree.IsReference_s(label):
            target = TDF_Label()
            assert tree.GetReferredShape_s(label, target)
            loc = loc * tree.GetLocation_s(label)
        # CadQuery may give an instance only a numeric name. Keep meaningful
        # occurrence IDs (D01), otherwise use the named definition (C06).
        instance, definition = name(label), name(target)
        key = instance if instance and not instance.isdecimal() else definition
        if tree.IsAssembly_s(target):
            seq = TDF_LabelSequence()
            tree.GetComponents_s(target, seq)
            for i in range(1, seq.Length()+1):
                yield from visit(seq.Value(i), loc, prefix + (key,))
        else:
            yield prefix + (key,), definition, cq.Shape.cast(tree.GetShape_s(target).Moved(loc))

    roots = TDF_LabelSequence()
    tree.GetFreeShapes(roots)
    for i in range(1, roots.Length()+1):
        yield from visit(roots.Value(i), TopLoc_Location(), ())


def bounds(shape):
    b = shape.BoundingBox()
    return [b.xmin, b.ymin, b.zmin, b.xmax, b.ymax, b.zmax]


def block(x0, x1, y0, y1, z0, z1):
    return cq.Solid.makeBox(x1-x0, y1-y0, z1-z0, cq.Vector(x0, y0, z0))


def json_write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def csv_write(path, rows):
    with path.open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
