"""Verified neutral-format inputs. A disposable BRep cache avoids repeated STEP parsing."""
import hashlib
import json
import zipfile
from pathlib import Path

from model_io import C06, D01, REPO, ROOT, bounds, cq, named_step, np
from OCP.BRepGProp import BRepGProp
from OCP.GProp import GProp_GProps
from OCP.TopLoc import TopLoc_Location
from OCP.gp import gp_Trsf

FILES = {
    "damper": D01/"cad/D01_EIGHT_DAMPERS_INSTALLED.step",
    "service": D01/"cad/D01_SERVICE_ENVELOPES.step",
    "shell": C06/"C06_SHEET_METAL.step",
    "water": C06/"C06_WATER_FIT.step",
    "water_service": C06/"C06_WATER_SERVICE.step",
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def verify_baselines():
    source = json.loads((ROOT/"source/baselines.json").read_text(encoding="utf-8"))
    records = {}
    for info in source["archives"]:
        path = REPO/info["path"]
        data = path.read_bytes()
        assert hashlib.sha1(f"blob {len(data)}\0".encode()+data).hexdigest() == info["git_blob_sha1"], path
        with zipfile.ZipFile(path) as archive:
            if path.parent == D01:
                used = ["native/D01_PLACEMENTS.json", "native/D01_ACTUATOR_RESERVES.json",
                        "inputs/C04_R21_BASELINES.zip", "design.json", "source/build.py", "source/native.py",
                        "source/bootstrap.py","source/step_export.py"]
            else:
                used = ["shell_checks.json", "motion_shell.json"]
            used += [p.relative_to(path.parent).as_posix() for p in FILES.values() if path.parent in p.parents]
            for member in used:
                actual = path.parent/member
                sha = digest(archive.read(member))
                assert sha == digest(actual.read_bytes()), actual
                records[actual.relative_to(REPO).as_posix()] = sha
    return records


def transform_rows(shape):
    t = shape.wrapped.Location().Transformation()
    return [[t.Value(i,j) for j in (1,2,3,4)] for i in (1,2,3)]


def cache(source, path):
    folder = ROOT/".work"/source
    folder.mkdir(parents=True, exist_ok=True)
    marker = folder/"index.json"
    key = digest(path.read_bytes()) + ":" + digest(Path(__file__).read_bytes()) + ":" + digest((ROOT/"source/model_io.py").read_bytes())
    if marker.exists():
        old = json.loads(marker.read_text())
        if old["key"] == key and all(digest((folder/d["file"]).read_bytes()) == d["sha256"] for d in old["defs"].values()):
            return old
    print("Reading", path.name, flush=True)
    defs, rows = {}, []
    for names, definition, shape in named_step(path):
        if source == "damper" and ("HOST" in names or definition.startswith("HOST_")):
            continue
        if definition not in defs:
            local = cq.Shape.cast(shape.wrapped.Located(TopLoc_Location()))
            brep = folder/f"{len(defs):04}.brep"
            local.exportBrep(str(brep))
            info = dict(file=brep.name, bounds=bounds(local), sha256=digest(brep.read_bytes()))
            if source == "damper":
                props = GProp_GProps()
                BRepGProp.VolumeProperties_s(local.wrapped,props)
                c = props.CentreOfMass()
                info.update(volume=props.Mass(), centre=[c.X(),c.Y(),c.Z()])
            defs[definition] = info
        rows.append(["/".join(names[1:]), definition, transform_rows(shape)])
    assert len(rows) == len(set(n for n,_,_ in rows)), source
    result = dict(key=key, defs=defs, rows=rows)
    marker.write_text(json.dumps(result),encoding="utf-8")
    print(source,len(rows),"instances,",len(defs),"definitions",flush=True)
    return result


class Scene:
    def __init__(self, source):
        self.folder = ROOT/".work"/source
        data = cache(source, FILES[source])
        self.defs, self.rows, self.locals = data["defs"], {}, {}
        self.boxes = []
        for name, definition, rows in data["rows"]:
            m = np.array(rows)
            b = np.array(self.defs[definition]["bounds"])
            centre = m[:,:3]@((b[3:]+b[:3])/2)+m[:,3]
            half = abs(m[:,:3])@((b[3:]-b[:3])/2)
            self.rows[name] = (definition, m)
            self.boxes.append(np.r_[centre-half,centre+half])
        self.names = list(self.rows)
        self.boxes = np.array(self.boxes)

    def shape(self, name):
        key,m = self.rows[name]
        if key not in self.locals:
            self.locals[key] = cq.Shape.importBrep(str(self.folder/self.defs[key]["file"]))
        tf = gp_Trsf()
        tf.SetValues(*m.ravel())
        return self.locals[key].moved(cq.Location(tf))

    def candidates(self, b, tol):
        return [self.names[i] for i in np.flatnonzero(np.all(
            np.minimum(self.boxes[:,3:],b[3:])-np.maximum(self.boxes[:,:3],b[:3]) > tol, axis=1))]


if __name__ == "__main__":
    verify_baselines()
    for source, path in FILES.items():
        cache(source, path)
