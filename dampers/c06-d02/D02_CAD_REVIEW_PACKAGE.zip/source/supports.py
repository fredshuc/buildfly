"""D02 damper-side support change at the C06 machine origin (millimetres)."""
from model_io import block, cq

BED_Y = {"A": -434.4, "B": 845.6}
BOTTOM = {"P": 152., "R": 627.}
# Metal midplanes of the D01 P101/R101 end frames (gaskets are outside).
PICKUP_X = {"F": {"INNER": -167.6, "OUTER": -344.6},
            "R": {"INNER": 917.6, "OUTER": 1094.6}}
POST_X = {"F": -139.6, "R": 804.}
PORTAL_X = {"F": -408., "R": 1156.}
SIDE_Y = 374.
SEAT_Y = 300.


def tube_x(x1, x2, y, width, z, height, t=3.):
    outer = block(x1, x2, y-width/2, y+width/2, z, z+height)
    return outer.cut(block(x1-1, x2+1, y-width/2+t, y+width/2-t, z+t, z+height-t))


def cylinder(x, y, z, radius, height):
    return cq.Solid.makeCylinder(radius, height, cq.Vector(x,y,z))


def shoe(x, y, z, crown_height=2., crown_dx=0.):
    # The two end screws retain the shoe when the valve is removed.
    # The 2 mm wide raised land bears only on the 3 mm thick metal edge.
    base = block(x-9, x+9, y-45, y+45, z-8, z-2)
    if not (1.6 <= crown_height <= 2.4 and abs(crown_dx) <= 1.5):
        raise ValueError("Measured fit exceeds cartridge machining allowance")
    crown = block(x+crown_dx-1, x+crown_dx+1, y-30, y+30, z-2, z-2+crown_height)
    screws = []
    for dy in (-38.,38.):
        yy = y+dy
        base = base.cut(cylinder(x, yy, z-9, 2.25, 8),
                        cylinder(x, yy, z-6.2, 3.7, 5))
        shank = cylinder(x, yy, z-18.2, 2, 12)
        head = cylinder(x, yy, z-6.2, 3.5, 4)
        # Nominal M4x12, thread represented by major-diameter envelope.
        hexagon = cq.Workplane("XY", origin=(x,yy,z-4.2)).polygon(6, 3.464101615).extrude(2.1).val()
        screws.append(shank.fuse(head).cut(hexagon).clean())
    return base.fuse(crown).clean(), screws


def build():
    parts, seats, omitted = {}, [], []
    # Dry-side skid pickup below both rear discharge sleeves. The tube meets
    # the two structural corner posts without drilling the 2 mm floor sheet.
    parts["REAR_SKID_CROSS_TIE"] = block(1260,1290,-800,1240,153,178).cut(
        block(1263,1287,-801,1241,156,175))
    for bed, cy in BED_Y.items():
        for face, post in POST_X.items():
            pair = bed+face
            outside = PORTAL_X[face]
            for side, sign in (("LO",-1),("HI",1)):
                y = cy + sign*SIDE_Y
                if face == "F":
                    # Front stand feet at X=-408 are already grounded. These
                    # two structural links per portal also carry its inner fins.
                    parts[f"{pair}_{side}_BASE_TIE"] = tube_x(-393., -129.1, cy+sign*370., 40, 52, 50)
                    parts[f"{pair}_{side}_POST"] = block(post-5, post+5, y-10, y+10, 102, BOTTOM["R"]-8)
                else:
                    # The new foot is directly over R_BASE_CROSS_327 and/or
                    # the adjoining sill. The floor between them is 2 mm.
                    parts[f"{pair}_{side}_FOOT"] = block(792.5, 824.5, y-20, y+20, 104, 110)
                    parts[f"{pair}_{side}_POST"] = block(post-8, post+8, y-10, y+10, 110, BOTTOM["R"]-8)
                    parts[f"{pair}_{side}_REAR_TIE"] = tube_x(1171,1260,cy+sign*365.,30,153,25)
                for tag, z in BOTTOM.items():
                    ends = (outside+15, post-5) if face == "F" else (post+8, outside-15)
                    parts[f"{pair}{tag}_{side}_SIDE_ARM"] = tube_x(*ends, y, 24, z-40, 32)
            for tag, z in BOTTOM.items():
                valve = pair+tag
                omitted.extend(f"{pair}_{tag}_SUPPORT_PAD_{k}" for k in (0,1))
                for end, x in PICKUP_X[face].items():
                    group = f"{valve}_{end}"
                    # Solid bar gives tapped engagement independent of RHS wall thickness.
                    bar = block(x-10, x+10, cy-SIDE_Y+12, cy+SIDE_Y-12, z-40, z-8)
                    for side, sign in (("LO",-1),("HI",1)):
                        y = cy+sign*SEAT_Y
                        key = f"{group}_{side}_SHOE"
                        parts[key], screws = shoe(x, y, z)
                        for i, dy in enumerate((-38.,38.)):
                            # Threaded pairs use matching nominal thread envelopes.
                            bar = bar.cut(cylinder(x,y+dy,z-21,2,14))
                            parts[f"{group}_{side}_M4_{i+1}"] = screws[i]
                        idx = "002" if (face == "F") == (end == "INNER") else "001"
                        seats.append(dict(valve=valve, end=end, side=side, x=x, y=y, z=z,
                                          shoe=key, bar=group+"_BEAM", frame=valve+"/"+tag+"101_"+idx))
                    parts[group+"_BEAM"] = bar
    return parts, seats, omitted
