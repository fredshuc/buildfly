"""Build the additive STEP and verify its fresh readback at the C06 machine origin."""
from itertools import combinations
import json
from model_io import ROOT, D01, block, bounds, cq, csv_write, json_write, named_step, np
from baseline import Scene, digest, verify_baselines
from supports import BED_Y, BOTTOM, PICKUP_X, PORTAL_X, POST_X, SEAT_Y, SIDE_Y, build
from envelopes import moving_bounds, sockets

VOLUME_LIMIT = .001
OVERLAP = 1e-5
EVID = ROOT/"evidence"


def planar_area(a, b, axis, at):
    """Intersection of coplanar *faces*, mm². A touching-solid volume is zero."""
    def faces(shape):
        found = []
        for f in shape.Faces():
            if f.geomType() != "PLANE":
                continue
            bb = bounds(f)
            if max(abs(bb[axis]-at),abs(bb[axis+3]-at)) < 1e-5:
                found.append(f)
        return found
    left,right = faces(a),faces(b)
    return sum(f.intersect(g).Area() for f in left for g in right)


def overlap(a,b):
    return all(min(a[k+3],b[k+3])-max(a[k],b[k])>OVERLAP for k in range(3))


def volume_hit(a,b):
    return sum(s.Volume() for s in a.intersect(b).Solids())


def write_step(path, groups):
    assembly = cq.Assembly(name=path.stem)
    for name, (group, color) in groups.items():
        sub = cq.Assembly(name=name)
        for part,solid in group.items():
            sub.add(solid, name=part, color=cq.Color(*color))
        assembly.add(sub)
    assembly.export(str(path))


def nodes(parts, seats, shell, damp):
    contacts, bearings, old_contacts = [], [], []
    def edge(aid,bid,a,b,axis,at,kind,minimum=1.):
        area=planar_area(a,b,axis,at)
        contacts.append(dict(member=aid,receiver=bid,interface=kind,area_mm2=round(area,4)))
        assert area >= minimum-1e-5, (aid,bid,area,minimum)
        return area

    for row in seats:
        end, side, vid, z = (row[k] for k in ("end","side","valve","z"))
        face, pair = vid[1],vid[:2]
        key, beam = row["shoe"],row["bar"]
        frame=damp.shape(row["frame"])
        area=edge(row["frame"],key,frame,parts[key],2,z,"GRAVITY_BEARING",120)
        assert abs(area-120.)<1e-4, row
        edge(key,beam,parts[key],parts[beam],2,z-8,"SHOE_BASE_BEARING",1400)
        gaskets=[damp.shape(n) for n in damp.names if n.startswith(vid+"/") and
                 ("106_" in n or n.endswith("R106_SECOND_FACE"))]
        gasket_clear=min(parts[key].distance(s) for s in gaskets)
        assert gasket_clear >= .4999,(key,gasket_clear)
        bearings.append(dict(**row,metal_contact_mm2=round(area,3),nearest_valve_gasket_mm=round(gasket_clear,4)))
        arm=f"{vid}_{side}_SIDE_ARM"
        sign=-1 if side=="LO" else 1
        edge(beam,arm,parts[beam],parts[arm],1,BED_Y[vid[0]]+sign*(SIDE_Y-12),"BEAM_TO_ARM_WELD",600)
        if end=="OUTER":
            k=0 if sign<0 else 1
            original=f"{pair}_{vid[2]}_SUPPORT_PAD_{k}"
            original_area=planar_area(shell.shape(original),frame,2,z)
            counterpart=vid+"/"+vid[2]+"101_"+("002" if row["frame"].endswith("001") else "001")
            inner_area=planar_area(shell.shape(original),damp.shape(counterpart),2,z)
            assert original_area>0 and inner_area<1e-6,(vid,original_area,inner_area)
            old_contacts.append(dict(pad=original,original_outer_metal_mm2=round(original_area,4),
                                     original_inner_metal_mm2=round(inner_area,4)))

    def shell_shape(prefix):
        return next((n,shell.shape(n)) for n in shell.names if n.startswith(prefix))
    front_name,front=shell_shape("BASE_END_-")
    base_names=[n for n in shell.names if n.startswith("BASE_SILL_")]
    rear_corners=[n for n in shell.names if n.startswith("POST_(1260.0")]
    assert len(rear_corners)==2
    for name in rear_corners:
        corner=shell.shape(name)
        y=bounds(corner)
        at=y[4] if y[1]<0 else y[1]
        edge("REAR_SKID_CROSS_TIE",name,parts["REAR_SKID_CROSS_TIE"],corner,1,at,"REAR_TIE_TO_C06_CORNER_WELD",285)
    for bed,cy in BED_Y.items():
        for face in "FR":
            pair=bed+face
            for k,side in enumerate(("LO","HI")):
                leg=pair+"_STAND_LEG_"+str(k)
                foot=pair+"_STAND_FOOT_"+str(k)
                post=pair+"_"+side+"_POST"
                original_leg=shell.shape(leg)
                original_foot=shell.shape(foot)
                for tag in BOTTOM:
                    arm=f"{pair}{tag}_{side}_SIDE_ARM"
                    edge(arm,leg,parts[arm],original_leg,0,PORTAL_X[face]+(15 if face=="F" else -15),"ARM_TO_C06_LEG_WELD",160)
                    edge(arm,post,parts[arm],parts[post],0,POST_X[face]+(-5 if face=="F" else 8),"ARM_TO_POST_WELD",100)
                edge(leg,foot,original_leg,original_foot,2,6 if face=="F" else 110,"C06_LEG_TO_FOOT",200)
                if face=="F":
                    tie=pair+"_"+side+"_BASE_TIE"
                    edge(post,tie,parts[post],parts[tie],2,102,"POST_TO_SKID_TIE",195)
                    edge(tie,leg,parts[tie],original_leg,0,-393,"POSITIVE_SKID_WELD_AT_PORTAL",170)
                    # At the end of one cross tube the joint straddles the adjacent sill.
                    total=0.
                    for name,receiver in [(front_name,front)]+[(n,shell.shape(n)) for n in base_names]:
                        a=planar_area(parts[tie],receiver,0,-129.1)
                        if a>1e-5:
                            total+=a
                            contacts.append(dict(member=tie,receiver=name,interface="POSITIVE_SKID_WELD_AT_BASE",area_mm2=round(a,4)))
                    assert total>200,(tie,total)
                    assert abs(bounds(original_foot)[2])<1e-5
                else:
                    pad=pair+"_"+side+"_FOOT"
                    link=pair+"_"+side+"_REAR_TIE"
                    edge(link,leg,parts[link],original_leg,0,1171,"REAR_PORTAL_SKID_WELD",285)
                    edge(link,"REAR_SKID_CROSS_TIE",parts[link],parts["REAR_SKID_CROSS_TIE"],0,1260,"REAR_LINK_TO_CROSS_TIE",120)
                    edge(post,pad,parts[post],parts[pad],2,110,"POST_TO_FOOT",315)
                    deck=shell.shape("FLOOR")
                    for foot_name,plate,member,column in (
                        (pad,parts[pad],"R_BASE_CROSS_327",parts[post]),
                        (foot,original_foot,"REAR_STAND_BASE_CROSS",original_leg)):
                        edge(foot_name,"FLOOR",plate,deck,2,104,"REAR_COMPRESSION_TO_BACKED_FLOOR",850)
                        # Project only the column cross-section down through the
                        # foot and 2 mm deck to measure the directly backed area.
                        projection=column.translate((0,0,-8))
                        projected_area=sum(f.Area() for f in projection.Faces() if f.geomType()=="PLANE" and
                                           all(abs(bounds(f)[i]-102)<1e-5 for i in (2,5)))
                        backed=0.
                        for name in [member]+base_names:
                            area=planar_area(projection,shell.shape(name),2,102)
                            if area>1e-5:
                                backed+=area
                                contacts.append(dict(member=foot_name,receiver=name,interface="COLUMN_FOOTPRINT_THROUGH_2MM_FLOOR",
                                                     area_mm2=round(area,4)))
                        assert projected_area>150 and abs(backed-projected_area)<1e-3,(foot_name,backed,projected_area)
    return bearings,contacts,old_contacts


def load_screen(damp, seats):
    """Gravity screening only. No inferred equal load at four indeterminate seats."""
    reserves={r["id"]:r["bounds"] for r in json.loads((D01/"native/D01_ACTUATOR_RESERVES.json").read_text())}
    result=[]
    for vid in reserves:
        mass=0.; moment=np.zeros(3)
        for n,(key,m) in damp.rows.items():
            if not n.startswith(vid+"/"):
                continue
            proto=damp.defs[key]
            weight=proto["volume"]*7.85e-6
            mass+=weight
            moment+=weight*(m[:,:3]@np.array(proto["centre"])+m[:,3])
        cg=moment/mass
        r=[s for s in seats if s["valve"]==vid]
        x0,x1=min(s["x"] for s in r),max(s["x"] for s in r)
        cy=BED_Y[vid[0]]
        inner=PICKUP_X[vid[1]]["INNER"]
        inner_fraction=(cg[0]-x0)/(x1-x0) if inner==x1 else (x1-cg[0])/(x1-x0)
        drive_fraction=(SEAT_Y+(cy-cg[1] if vid[0]=="A" else cg[1]-cy))/(2*SEAT_Y)
        assert 0<inner_fraction<1 and 0<drive_fraction<1
        ax=reserves[vid]
        # Unknown actuator CG may be anywhere in the 250 mm reserve. Report
        # the most restrictive mass preserving 15 mm CG inset on BOTH axes.
        limits=[]
        for k,lo,hi in ((0,x0+15,x1-15),(1,cy-SEAT_Y+15,cy+SEAT_Y-15)):
            assert lo<cg[k]<hi
            if ax[k]<lo:limits.append(mass*(cg[k]-lo)/(lo-ax[k]))
            if ax[k+3]>hi:limits.append(mass*(hi-cg[k])/(ax[k+3]-hi))
        result.append(dict(valve=vid,steel_equivalent_kg=round(mass,3),proxy_cg_xyz_mm=[round(v,3) for v in cg],
                           inner_pair_reaction_fraction=round(inner_fraction,4),drive_side_pair_reaction_fraction=round(drive_fraction,4),
                           worst_reserve_actuator_kg_at_15mm_inset_proxy_only=round(min(limits),2)))
    return result


def verify():
    for directory in ("cad","evidence","drawings"):
        (ROOT/directory).mkdir(exist_ok=True)
    identity=verify_baselines()
    scenes={s:Scene(s) for s in ("shell","damper","service","water","water_service")}
    shell,damp=scenes["shell"],scenes["damper"]
    assert (len(shell.names),len(damp.names),len(scenes["service"].names),len(scenes["water"].names))==(327,7212,24,43)
    service_names=scenes["service"].names
    actuator_count=sum(n.endswith("_ACTUATOR_SELECTION_RESERVE") for n in service_names)
    cover_count=sum(n.endswith("_ONE_COVER_SERVICE") for n in service_names)
    assert actuator_count==cover_count==8
    design,seats,omitted=build()
    assert len(seats)==32 and len(omitted)==16 and all(n in shell.rows for n in omitted)
    path=ROOT/"cad/D02_DAMPER_SUPPORTS.step"
    write_step(path,{"D02_SUPPORTS":(design,(.13,.55,.50))})
    parts={p[-1]:s for p,d,s in named_step(path)}
    assert set(parts)==set(design)
    for n,s in parts.items():
        assert s.isValid() and len(s.Solids())==1 and abs(s.Volume()-design[n].Volume())<1e-4,n
        assert np.allclose(bounds(s),bounds(design[n]),atol=1e-6,rtol=0),n
    bbs={n:bounds(s) for n,s in parts.items()}
    print("Delta STEP:",len(parts),"valid, named solids",flush=True)
    counts={}; collisions={}
    def screen(label,pairs):
        hits=[]; count=0
        for a,b,sa,sb in pairs:
            count+=1; volume=volume_hit(sa,sb)
            if volume>VOLUME_LIMIT: hits.append([a,b,round(volume,5)])
        counts[label]=count
        collisions[label]=hits
        print(label,"candidates",count,"hits",len(hits),hits[:3],flush=True)

    screen("D02_self",((a,b,parts[a],parts[b]) for a,b in combinations(parts,2) if overlap(bbs[a],bbs[b])))
    for key,scene in scenes.items():
        screen("D02_vs_"+key,((n,b,s,scene.shape(b)) for n,s in parts.items()
               for b in scene.candidates(bbs[n],OVERLAP) if not(key=="shell" and b in omitted)
               and not(key=="service" and "FULL_ROTATION_BOUND" in b)))
    moving=moving_bounds()
    assert len(moving)==600 and all(n in damp.rows for n,_ in moving),len(moving)
    screen("D02_vs_continuous_360",((n,v,s,block(*[q[i] for i in (0,3,1,4,2,5)]))
           for v,q in moving for n,s in parts.items() if overlap(bbs[n],q)))
    tools=list(sockets())
    assert len(tools)==240
    screen("D02_vs_D01_socket_access",((n,v,s,t) for v,t,q in tools for n,s in parts.items() if overlap(bbs[n],q)))
    screen("retained_C06_vs_D01_socket_access",((v,n,t,shell.shape(n)) for v,t,q in tools
           for n in shell.candidates(q,OVERLAP) if n not in omitted))
    json_write(EVID/"D02_CLASH_CHECKS.json",dict(candidates=counts,hits=collisions,mm3_limit=VOLUME_LIMIT))
    assert not any(collisions.values()),collisions
    bearings,contacts,older=nodes(parts,seats,shell,damp)
    csv_write(EVID/"D02_BEARING_POINTS.csv",bearings)
    csv_write(EVID/"D02_LOAD_PATH_CONTACTS.csv",contacts)
    csv_write(EVID/"D02_C06_PADS_TO_SUPPRESS.csv",older)
    loads=load_screen(damp,seats)
    json_write(EVID/"D02_GRAVITY_SCREEN.json",dict(density_kg_per_m3=7850,cg_edge_inset_mm=15,
               scope="uniform steel-equivalent D01 product only; static pair reactions for vertical gravity, individual seat loads require measurement",
               rows=loads))
    # Small stand-alone review view. Only the support interfaces of the
    # original models are copied; the entire product was used for the checks.
    refnames=[n for n in shell.names if "_STAND_" in n or "_SUPPORT_RAIL" in n or n.startswith(("BASE_SILL_","BASE_END_-","R_BASE_CROSS_327","REAR_STAND_","R_MID_FOOT_327","FOOT_","POST_(1260.0"))]
    refs={n:shell.shape(n) for n in refnames}
    frames={n.replace("/","__"):damp.shape(n) for n in sorted(set(r["frame"] for r in bearings))}
    sealing={}
    for vid in sorted(set(r["valve"] for r in bearings)):
        gasket_names=[n for n in damp.names if n.startswith(vid+"/"+vid[2]+"106_") or n==vid+"/D01_R106_SECOND_FACE"]
        assert len(gasket_names)==2,vid
        for n in [*gasket_names,"INTERFACES/"+vid+"_D01_ADAPTER_33"]:
            sealing[n.replace("/","__")]=damp.shape(n)
    wall={n:shell.shape(n) for n in shell.names if n.endswith("_DUAL_VALVE_FLANGE") or n=="FLOOR"}
    assert len(wall)==5
    fit=ROOT/"cad/D02_LOAD_PATH_REVIEW.step"
    write_step(fit,{"D02_SUPPORTS":(parts,(.13,.55,.5)),"C06_STRUCTURE_REFERENCE":(refs,(.38,.44,.5)),
                    "D01_METAL_FRAMES_REFERENCE":(frames,(.83,.54,.16)),
                    "D01_GASKETS_AND_ADAPTERS_REFERENCE":(sealing,(.43,.49,.56,.55)),
                    "C06_FLOOR_AND_WALL_REFERENCE":(wall,(.67,.74,.76,.24))})
    observed={p[-1]:s for p,d,s in named_step(fit)}
    expected={**parts,**refs,**frames,**sealing,**wall}
    assert set(observed)==set(expected)
    for n,s in observed.items():
        assert s.isValid() and len(s.Solids())==1 and abs(s.Volume()-expected[n].Volume())<1e-3,n
        assert np.allclose(bounds(s),bounds(expected[n]),atol=1e-6,rtol=0),n
    low_y=min(b[1] for b in bbs.values())
    high_y=max(b[4] for b in bbs.values())
    clear_to_skin={"A":round(low_y-bounds(shell.shape("A_SIDE_PANEL"))[4],3),
                   "B":round(bounds(shell.shape("B_SIDE_PANEL"))[1]-high_y,3)}
    assert min(clear_to_skin.values())>10
    report=dict(status="PASS_N8_NOMINAL_GEOMETRY",parts=len(parts),review_solids=len(observed),
                c06_total=327,c06_suppressed=omitted,c06_retained=311,d01_occurrences=7212,
                d01_moving_enclosures=len(moving),d01_actuator_volumes=actuator_count,d01_one_cover_pulls=cover_count,d01_stud_tools=len(tools),
                water_static=len(scenes["water"].rows),water_service=len(scenes["water_service"].rows),
                seats=len(bearings),metal_area_per_seat_mm2=120.,lowest_shoe_gasket_gap_mm=min(r["nearest_valve_gasket_mm"] for r in bearings),
                front_skid_links=4,rear_skid_links=4,rear_cross_tie=1,side_panel_inward_clearance_mm=clear_to_skin,
                load_path_records=len(contacts),highest_added_part_mm=max(b[5] for b in bbs.values()),
                checked_input_sha256=identity,step_sha256={p.name:digest(p.read_bytes()) for p in (path,fit)})
    json_write(EVID/"D02_GEOMETRY_RESULT.json",report)
    print(report["status"],"contacts",len(contacts),"review",len(observed),"solids",flush=True)


if __name__=="__main__":
    verify()
