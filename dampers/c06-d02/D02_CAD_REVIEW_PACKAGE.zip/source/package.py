"""Package only the reviewable D02 change and verify every archive entry."""
import csv
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def field_record():
    fields = ["valve","state","valve_and_actuator_serials","gauge_and_calibration_ID","temperature_C",
              "weighed_mass_kg","measured_CG_X_mm","measured_CG_Y_mm","nut_torque_Nm","hoist_force_N",
              "inner_lowY_N","inner_highY_N","outer_lowY_N","outer_highY_N","sum_seat_reactions_N",
              "applied_gravity_minus_hoist_N","force_uncertainty_N"]
    for axis in ("Z","X"):
        fields.extend(f"wall_{axis}_{side}_{level}_mm" for side in ("lowY","highY") for level in ("lowZ","highZ"))
    fields.extend(["contact_transfer_and_shoe_IDs","disposition_signoff_date"])
    path=ROOT/"evidence/D02_N8_FIELD_RECORD.csv"
    with path.open("w",newline="",encoding="utf-8-sig") as f:
        writer=csv.DictWriter(f,fieldnames=fields)
        writer.writeheader()
        for bed in "AB":
            for face in "FR":
                for tag in "PR":
                    for state in ("DATUM_UNLOADED","SEATED_LOOSE","SEALED","HOIST_10_PERCENT","RESTORED"):
                        writer.writerow(dict(valve=bed+face+tag,state=state))


def main():
    result=json.loads((ROOT/"evidence/D02_GEOMETRY_RESULT.json").read_text())
    assert result["status"]=="PASS_N8_NOMINAL_GEOMETRY" and (result["seats"],result["front_skid_links"],result["rear_skid_links"])==(32,4,4)
    for name,value in result["step_sha256"].items():
        assert sha((ROOT/"cad"/name).read_bytes())==value,name
    field_record()
    items=[ROOT/"README_CN.md",ROOT/"run.ps1",ROOT/".gitignore"]
    for folder in ("cad","drawings","evidence","source"):
        items.extend(f for f in (ROOT/folder).iterdir() if f.is_file())
    required=("cad/D02_DAMPER_SUPPORTS.step","cad/D02_LOAD_PATH_REVIEW.step","drawings/D02_N8_LOAD_PATH.svg",
              "drawings/D02_N8_LOAD_PATH.png","evidence/D02_N8_FIELD_RECORD.csv","evidence/D02_MEMBER_SCREEN.json")
    entries={f.relative_to(ROOT).as_posix():sha(f.read_bytes()) for f in sorted(items)}
    assert all(n in entries for n in required)
    manifest=ROOT/"SHA256SUMS.txt"
    manifest.write_text("".join(f"{v}  {n}\n" for n,v in entries.items()),encoding="utf-8")
    output=ROOT/"D02_CAD_REVIEW_PACKAGE.zip"
    with zipfile.ZipFile(output,"w",zipfile.ZIP_DEFLATED,compresslevel=7) as z:
        for name in [*entries,manifest.name]:
            z.write(ROOT/name,name)
    with zipfile.ZipFile(output) as z:
        assert z.testzip() is None
        assert set(z.namelist())==set(entries)|{manifest.name}
        assert z.read(manifest.name)==manifest.read_bytes()
        assert all(sha(z.read(n))==v for n,v in entries.items())
    print(output.name,output.stat().st_size,"bytes;",len(entries),"file hashes and CRC verified")


if __name__=="__main__":
    main()
