$ErrorActionPreference = 'Stop'
$d02Bundled = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
if ($env:D02_PYTHON) { $d02Python = $env:D02_PYTHON }
elseif (Test-Path -LiteralPath $d02Bundled) { $d02Python = $d02Bundled }
else { $d02Python = 'python' }
foreach ($stage in 'verify_fit.py', 'detail.py', 'package.py') {
    & $d02Python -B -u -X utf8 (Join-Path $PSScriptRoot "source/$stage")
    if ($LASTEXITCODE -ne 0) { throw "D02 stopped during $stage" }
}
