"""Reimport full D04 STEP, measure contacts, pipe clearances and installation tools."""
import argparse
import json
import math
from pathlib import Path
import cadquery as cq
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
from build import ROOT, occurrences, read, sha
from pin_detail import CENTRES, R_GLAND, R_PIPE, Z, WALL, INNER, faces_at, contact_x, service


def bounds(s):
    b=s.BoundingBox()
    return (b.xmin,b.ymin,b.zmin,b.xmax,b.ymax,b.zmax)

def lower_bound(a,b):
    return math.sqrt(sum(max(0,a[i]-b[i+3],b[i]-a[i+3])**2 for i in range(3)))

def nearest(a,b):
    d=BRepExtrema_DistShapeShape(a.wrapped,b.wrapped)
    d.Perform()
    assert d.IsDone()
    points=[d.PointOnShape1(1),d.PointOnShape2(1)]
    return {"mm":round(d.Value(),6),"xyz_mm":[[round(v,5) for v in (p.X(),p.Y(),p.Z())] for p in points]}

def y_contact(a,b,y):
    def plane(s):
        return [f for f in s.Faces() if all(abs(x-y)<1e-5 for x in (f.BoundingBox().ymin,f.BoundingBox().ymax))]
    return sum(f.intersect(g).Area() for f in plane(a) for g in plane(b))

def group_of(path):
    return next(g for g in ("DAMPERS","SHELL","HEAT_EXCHANGERS") if any(x.startswith(g) for x in path))

def parts_of(path):
    doc,tree,root=read(path)
    return [(p,s,bounds(s)) for p,lb,loc,s in occurrences(tree,root)]

def clearance_screen(probe,targets):
    closest=None
    hits=[]
    for score,p,s in sorted(((lower_bound(bounds(probe),b),p,s) for p,s,b in targets),key=lambda v:v[0]):
        if closest and score>max(closest['mm']+.00001,.0001):
            break
        d=nearest(probe,s)
        if closest is None or d['mm']<closest['mm']:
            closest={**d,"part":"/".join(p)}
        if d['mm']<.0001:
            vol=probe.intersect(s).Volume()
            if vol>.001:
                hits.append(["/".join(p),round(vol,5)])
    assert closest is not None
    return {"closest":closest,"penetrations":hits}

def verify(state,envelope):
    path=ROOT/"cad"/f"D04_C09R1_INSTALLED_{state}.step"
    parts=parts_of(path)
    installed={}
    hx=[]
    for p,s,b in parts:
        if group_of(p)=="HEAT_EXCHANGERS":
            hx.append((p,s,b))
        else:
            assert p[-1] not in installed,p
            installed[p[-1]]=s
    assert len(hx)==2196 and len(installed)==494+244
    spans=parts_of(envelope)
    assert sha(envelope)=="499cd9868814c8cf9f5c026c38edbdba36f1c3eef23520187c1f2437b84e4c9d" and len(spans)==82
    out={"state":state,"full_step_sha256":sha(path),"D03_envelope_sha256":sha(envelope),"beds":{}}
    for bed,y in CENTRES.items():
        def item(name):
            return installed[f"D04_{bed}_{name}"]
        boot=item("WET_BOOT")
        inner,outer=item("INNER_KEEPER"),item("OUTER_KEEPER")
        pipe,=[s for p,s,b in hx if bed+"_UPPER" in p and p[-1]=="W2_D35_END_PIPE"]
        rear=installed[f"AIR_REAR_{bed}_O"]
        seat=installed[f"DAMPER_SEAT_{bed}_UPPER_DEEP_O"]
        pad=installed[f"DAMPER_STATIC_GASKET_{bed}_UPPER_O"]
        fitted={"SEAT":seat,"STATIC_PAD":pad,"INNER_KEEPER":inner,"OUTER_KEEPER":outer,"BOOT":boot}
        assert all(s.isValid() and len(s.Solids())==1 for n,s in installed.items()
                   if n.startswith(f"D04_{bed}_") or s is pad)
        clears={key:nearest(s,pipe) for key,s in fitted.items()}
        for k in ("SEAT","STATIC_PAD","INNER_KEEPER","OUTER_KEEPER"):
            assert clears[k]["mm"]>=2.999, (k,clears[k])
        assert clears["BOOT"]["mm"]<.00001
        # Each full half-face including both ends of its split is bedded in the membrane.
        contact={}
        for h in ("LOW","HIGH"):
            gland=installed[f"C09_SPLIT_GLAND_{bed}_UPPER_W2_{h}"]
            contact[h]={"boot":contact_x(boot,gland,WALL),
                        "inner_keeper":contact_x(inner,gland,INNER),
                        "outer_keeper_through_web":contact_x(outer.translate((1,0,0)),gland,WALL)}
            nominal=math.pi*(R_GLAND**2-R_PIPE**2)/2
            assert abs(contact[h]["boot"]-nominal)<.001 and min(contact[h].values())>1,contact[h]
        interfaces={"rear_to_boot":contact_x(rear,boot,WALL),"old_pad_to_boot_lap":contact_x(pad,boot,WALL-1)}
        pipe_faces=[f for f in pipe.Faces() if f.geomType()=="CYLINDER"]
        bore_area=sum(f.intersect(g).Area() for f in boot.Faces() if f.geomType()=="CYLINDER"
                      for g in pipe_faces if lower_bound(bounds(f),bounds(g))<1e-6)
        assert abs(bore_area-2*math.pi*R_PIPE*3)<.01,bore_area
        interfaces["boot_to_pipe_OD"]=bore_area
        if bed=="A":
            interfaces["side_return_to_side_panel"]=y_contact(boot,installed["AIR_SIDE_OUT_A_O"],-816.5)
            assert interfaces["side_return_to_side_panel"]>=8*34-.001
        else:
            interfaces["boot_to_steel_at_port"]=contact_x(boot,seat,WALL-3)
            # The actual rear-port void inside the 1 mm web must terminate on
            # the steel seat, allowing the remaining pad to mediate where present.
            from pin_detail import annulus
            web=annulus(WALL-1,WALL,y,28,R_PIPE)
            unsupported=web
            for panel in [rear]+[installed[f"C09_SPLIT_GLAND_{bed}_UPPER_W2_{h}"] for h in ("LOW","HIGH")]:
                unsupported=unsupported.cut(panel.translate((-1,0,0)))
            aperture=faces_at(unsupported,WALL-1)
            backed=sum(f.translate((-2,0,0)).intersect(g).Area() for f in aperture for g in faces_at(seat,WALL-3))
            assert abs(backed-sum(f.Area() for f in aperture))<.001
            interfaces["port_zone_projected_on_steel"]=backed
        assert min(interfaces.values())>1,interfaces
        tools={}
        for side,tool in service(bed).items():
            tag=side.split("_")[-1]
            # Socket encloses only the nut and stud being turned.
            excluded={f"D04_{bed}_STUD_{tag}",f"D04_{bed}_LOCKNUT_{tag}"}
            tools[side]=clearance_screen(tool,[t for t in parts if t[0][-1] not in excluded])
            assert not tools[side]["penetrations"],tools[side]
        # Pull the outer keeper parallel to the studs after both nuts come off.
        # Extrude the actual end profile. This preserves the open pipe saddle.
        pull_faces=faces_at(outer,WALL-3)
        sweep=cq.Compound.makeCompound([cq.Solid.extrudeLinear(f.outerWire(),f.innerWires(),(-12,0,0))
                                         for f in pull_faces]+[outer])
        excluded={f"D04_{bed}_{n}" for n in ("OUTER_KEEPER","STUD_LOW","STUD_HIGH","LOCKNUT_LOW","LOCKNUT_HIGH")}
        tools["KEEPER_PULL_12"]=clearance_screen(sweep,[t for t in parts if t[0][-1] not in excluded])
        assert not tools["KEEPER_PULL_12"]["penetrations"],tools["KEEPER_PULL_12"]
        # Each modified pad is a strict subtraction from R1; include added hardware
        # explicitly against every D03 motion and service envelope.
        motion={}
        for kind in ("MOTION","SERVICE"):
            names={f"{station}_{tier}_{kind}" for station in "AB" for tier in ("UPPER","LOWER")}
            targets=[t for t in spans if names.intersection(t[0])]
            assert len(targets)==(46 if kind=="MOTION" else 36)
            rows=[(n,clearance_screen(s,targets)) for n,s in installed.items() if n.startswith(f"D04_{bed}_")]
            assert not any(r["penetrations"] for n,r in rows),rows
            n,r=min(rows,key=lambda pair:pair[1]["closest"]["mm"])
            motion[kind]={"D04_part":n,**r["closest"]}
        out["beds"][bed]={"pipe_clearance":clears,"gland_face_contacts_mm2":contact,"other_contacts_mm2":interfaces,
                          "D03_envelope_min":motion,"local_service":tools}
    (ROOT/"evidence"/f"detail_{state}.json").write_text(json.dumps(out,indent=2))
    print("Measured",state,flush=True)

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("state",choices=["S1","S2"])
    parser.add_argument("D03_envelope",type=Path)
    args=parser.parse_args()
    verify(args.state,args.D03_envelope)
