"""Dimensioned local detail. Each filled region is a plane cut of the released STEP."""
import math
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
from matplotlib.patches import Patch
import cadquery as cq
from build import ROOT
from verify import parts_of
from pin_detail import Z,CENTRES

COL={"Panel":"#d3d9dc","Split gland":"#a189bb","Pin seat":"#26645e","Static pad":"#8dc4b8",
     "Wet boot":"#ed9e44","Keepers":"#496281","Fasteners":"#384555","W2 tube":"#74a9d2"}

def section(ax,shape,axis,value,colour,project):
    pos=[0.,0.,0.]
    pos[axis]=value
    norm=[0.,0.,0.]
    norm[axis]=1.
    plane=cq.Face.makePlane(4000,4000,tuple(pos),tuple(norm))
    geo=shape.intersect(plane)
    for face in geo.Faces():
        pts,tris=face.tessellate(.015)
        coords=np.array([project(p.toTuple()) for p in pts])
        if len(coords):
            ax.add_collection(PolyCollection(coords[np.array(tris)],facecolors=colour,
                                             edgecolors="none",antialiased=False))
        for e in face.Edges():
            n=2 if e.geomType()=="LINE" else max(8,int(e.Length()/.7))
            if e.Length()<1e-6:
                continue
            points=np.array([project(e.positionAt(t).toTuple()) for t in np.linspace(0,1,n)])
            ax.plot(points[:,0],points[:,1],linewidth=.48,color="#39454b")

def make():
    parts=parts_of(ROOT/"cad/D04_C09R1_INSTALLED_S1.step")
    hardware={p[-1]:s for p,s,b in parts if "HEAT_EXCHANGERS" not in p}
    fig,axes=plt.subplots(2,2,figsize=(12.4,11.6))
    fig.patch.set_facecolor("#ffffff")
    fig.subplots_adjust(top=.875,bottom=.10,hspace=.39,wspace=.22,left=.08,right=.97)
    fig.text(.07,.966,"Upper Pin seat  /  W2 rear-wall crossing",fontsize=22,weight="bold",color="#24333e")
    fig.text(.07,.934,"D04 on C09R1   ·   Actual STEP sections   ·   Global frame, dimensions in mm",fontsize=11,color="#465666")
    for idx,(bed,y) in enumerate(CENTRES.items()):
        pipe,=[s for p,s,b in parts if bed+"_UPPER" in p and p[-1]=="W2_D35_END_PIPE"]
        rear=hardware[f"AIR_REAR_{bed}_O"]
        side=hardware["AIR_SIDE_OUT_A_O" if bed=="A" else "AIR_SIDE_IN_B_O"]
        gland=[hardware[f"C09_SPLIT_GLAND_{bed}_UPPER_W2_{h}"] for h in ("LOW","HIGH")]
        seat=hardware[f"DAMPER_SEAT_{bed}_UPPER_DEEP_O"]
        gasket=hardware[f"DAMPER_STATIC_GASKET_{bed}_UPPER_O"]
        boot=hardware[f"D04_{bed}_WET_BOOT"]
        inner=hardware[f"D04_{bed}_INNER_KEEPER"]
        outer=hardware[f"D04_{bed}_OUTER_KEEPER"]
        nuts=[s for n,s in hardware.items() if n.startswith(f"D04_{bed}_LOCKNUT_")]
        studs=[s for n,s in hardware.items() if n.startswith(f"D04_{bed}_STUD_")]
        ax=axes[0,idx]
        ax.set(title=f"Bed {bed}   |   Rear view along +X",xlabel="Y  −  W2 centre",ylabel="Z  −  1122.35",
               xlim=(-34,39),ylim=(-45,35),aspect="equal")
        project=lambda p: (p[1]-y,p[2]-Z)
        for shapes,coord,k in [([rear],-501,"Panel"),(gland,-501,"Split gland"),
            ([gasket],-503.4,"Static pad"),([boot],-502,"Wet boot"),([pipe],-501,"W2 tube"),
            ([outer],-503.3,"Keepers"),(nuts+studs,-506,"Fasteners")]:
            for shape in shapes:
                section(ax,shape,0,coord,COL[k],project)
        # Hidden gland OD and both splits, projected through the wet membrane.
        t=np.linspace(0,2*math.pi,181)
        ax.plot(22.5*np.cos(t),22.5*np.sin(t),"--",color=COL["Split gland"],lw=1)
        for sign in (-1,1):
            ax.plot([0,0],[sign*17.5,sign*22.5],color="#6f498c",ls="--",lw=1.5)
        ax.text(.025,.025,f"W2 at Y {y:.3f}",transform=ax.transAxes,fontsize=9,
                bbox={"facecolor":"white","edgecolor":"none","alpha":.85})
        ax=axes[1,idx]
        if bed=="A":
            ax.set(title="A   |   Fold onto the outboard skin",xlabel="Y  −  W2 centre",ylabel="Global X",
                   xlim=(-34,12),ylim=(-510,-488),aspect="equal")
            project=lambda p:(p[1]-y,p[0])
            dimension,value=2,Z
        else:
            ax.set(title="B   |   Return onto the steel Pin seat",xlabel="Z  −  W2 centre",ylabel="Global X",
                   xlim=(12,33),ylim=(-512,-495),aspect="equal")
            project=lambda p:(p[2]-Z,p[0])
            dimension,value=1,y
        for shapes,k in [([rear,side],"Panel"),(gland,"Split gland"),([seat],"Pin seat"),
                         ([gasket],"Static pad"),([boot],"Wet boot"),([pipe],"W2 tube"),
                         ([inner,outer],"Keepers")]:
            for shape in shapes:
                section(ax,shape,dimension,value,COL[k],project)
        if bed=="A":
            ax.annotate("8 mm side bond",(-25.4,-496),(-13,-491.5),ha="center",fontsize=8.5,
                        arrowprops={"arrowstyle":"->","color":"#374151"})
        else:
            ax.annotate("Steel-backed return",(25,-503),(26.7,-498.1),ha="center",fontsize=8.5,
                        arrowprops={"arrowstyle":"->","color":"#374151"})
    for ax in axes.flat:
        ax.set_axisbelow(True)
        ax.grid(alpha=.16)
        ax.tick_params(labelsize=9)
        for spine in ax.spines.values(): spine.set_color("#b2bdc3")
    fig.legend([Patch(facecolor=c) for c in COL.values()],list(COL),loc="lower center",ncol=4,
               frameon=False,bbox_to_anchor=(.5,.022),fontsize=10)
    fig.savefig(ROOT/"D04_PIN_DETAIL.png",dpi=170,bbox_inches="tight",pad_inches=.25)
    plt.close(fig)

if __name__=="__main__":
    make()
