"""Compare RT4 pair lists, assemble the review ZIP, then read back every archived byte."""
import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED

ROOT=Path(__file__).resolve().parents[1]
ZIP_NAME="D04_PIN_W2_REVIEW.zip"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def normalized_pairs(screen):
    return sorted((a.split("/")[-1],b.split("/")[-1],v)
                  for a,b,v in screen["DAMPERS_x_DAMPERS"]["overlaps"])

def pack(r1):
    for state in ("S1","S2"):
        screen=read(ROOT/"evidence"/f"screen_{state}.json")
        original=read(r1/f"screen_{state}.json")
        assert normalized_pairs(screen)==normalized_pairs(original) and len(normalized_pairs(screen))==12
        assert screen["inventory"]=={"SHELL":494,"DAMPERS":244,"HEAT_EXCHANGERS":2196}
        assert screen["threshold_mm3"]==.001 and all(
            not screen[group]["overlaps"] for group in ("DAMPERS_x_HEAT_EXCHANGERS","SHELL_x_DAMPERS","SHELL_x_HEAT_EXCHANGERS"))
        built=read(ROOT/"evidence"/f"build_{state}.json")
        assert built["source_sha256"]==read(r1/"SHA256.json")[built["source"]]
        assert sha(ROOT/"cad"/built["output"])==built["output_sha256"]==read(ROOT/"evidence"/f"detail_{state}.json")["full_step_sha256"]
        service=read(ROOT/"evidence"/f"service_{state}.json")
        assert len(service["sequence"])==14 and all(
            not (s["installed"]["penetrations"] or s["P0"]["penetrations"]) for s in service["sequence"].values())
        if state=="S1":
            assert sha(ROOT/"cad/D04_LOCAL_SERVICE.step")==service["service_STEP_sha256"]
    files=[ROOT/"README_CN.md",ROOT/"D04_PIN_DETAIL.png",*sorted((ROOT/"cad").glob("*.step")),
           *sorted((ROOT/"evidence").glob("*.json")),*sorted((ROOT/"source").glob("*.py"))]
    manifest={p.relative_to(ROOT).as_posix():sha(p) for p in files}
    manifest_file=ROOT/"SHA256.json"
    manifest_file.write_text(json.dumps(manifest,indent=2)+"\n",encoding="utf-8")
    dest=ROOT/ZIP_NAME
    with ZipFile(dest,"w",compression=ZIP_DEFLATED,compresslevel=6) as archive:
        for p in [*files,manifest_file]:
            archive.write(p,p.relative_to(ROOT).as_posix())
    with ZipFile(dest) as archive:
        assert archive.testzip() is None and set(archive.namelist())==set(manifest)|{"SHA256.json"}
        for name,digest in manifest.items():
            assert hashlib.sha256(archive.read(name)).hexdigest()==digest
    print(dest.name,sha(dest),flush=True)

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("C09R1_RT4",type=Path)
    pack(parser.parse_args().C09R1_RT4)
