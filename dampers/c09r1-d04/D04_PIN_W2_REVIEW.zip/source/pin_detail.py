"""Local D04 upper W2/Pin interface. Dimensions in the C09R1 machine frame (mm)."""
import cadquery as cq

CENTRES = {"A": -791.575, "B": 73.425}
Z = 1122.35
WALL = -501.5
INNER = -500.0
R_PIPE, R_RELIEF, R_GLAND, R_SKIRT = 17.5, 20.5, 22.5, 28.0


def box(x0, y0, z0, x1, y1, z1):
    return cq.Solid.makeBox(x1-x0, y1-y0, z1-z0, (x0, y0, z0))


def cylinder(x0, x1, y, z, r):
    return cq.Solid.makeCylinder(r, x1-x0, (x0, y, z), (1, 0, 0))


def annulus(x0, x1, y, outer, inner):
    return cylinder(x0, x1, y, Z, outer).cut(cylinder(x0-1, x1+1, y, Z, inner))


def faces_at(shape, x):
    return [f for f in shape.Faces() if abs(f.BoundingBox().xmin-x)<1e-5
            and abs(f.BoundingBox().xmax-x)<1e-5]


def contact_x(a, b, x):
    return sum(f.intersect(g).Area() for f in faces_at(a,x) for g in faces_at(b,x))


def hex_nut(y,z):
    # M4 AF7 all-metal locking nut, unthreaded CAD representation.
    prism = (cq.Workplane("YZ", origin=(-508.5,y,z)).polygon(6,7,circumscribed=True)
             .extrude(4).val())
    return prism.cut(cylinder(-509,-504,y,z,2))


def detail(bed, parts):
    y = CENTRES[bed]
    pad_name = f"DAMPER_STATIC_GASKET_{bed}_UPPER_O"
    pad = parts[pad_name]
    rear = parts[f"AIR_REAR_{bed}_O"]
    glands = [parts[f"C09_SPLIT_GLAND_{bed}_UPPER_W2_{h}"] for h in ("LOW","HIGH")]
    # Disposable wet-moulded flashing. The 1 mm web bridges both gland splits.
    web = annulus(WALL-1, WALL, y, R_SKIRT, R_PIPE)
    lip = annulus(WALL-3, WALL-1, y, 19.5, R_PIPE)
    if bed == "A":
        tongue = box(WALL-1,-817.5,Z-17,WALL,-810,Z+17)
        web = web.intersect(box(-504,-817.5,Z-32,-500,y+32,Z+32)).fuse(tongue)
        corner = box(WALL,-817.5,Z-17,INNER,-815,Z+17)
        side_leg = box(INNER,-817.5,Z-17,INNER+8,-816.5,Z+17)
        seal = web.fuse(lip,corner,side_leg)
    else:
        # Where the aperture interrupts the rear wall, turn the seal into the
        # existing Pin steel land. Use the real cutout, not a nominal rectangle.
        unsupported = web
        for panel in [rear,*glands]:
            unsupported = unsupported.cut(panel.translate((-1,0,0)))
        returns = [cq.Solid.extrudeLinear(f.outerWire(),f.innerWires(),(-2,0,0))
                   for f in faces_at(unsupported,WALL-1)]
        assert returns
        transition = cq.Compound.makeCompound(returns).cut(pad)
        seal = web.fuse(lip,transition)
    seal = seal.clean()
    pad = pad.cut(seal).clean()
    # Inner tongue is spot-welded at its foot before HX installation. Outer
    # tongue is removable; its 1 mm stepped heel rests directly on the wall.
    def tongue(x0,x1):
        blank = box(x0,y-13,Z-40,x1,y+13,Z-15)
        return blank.cut(cylinder(x0-1,x1+1,y,Z,R_RELIEF)).clean()
    inner = tongue(INNER,INNER+2)
    outer = tongue(WALL-3,WALL-1).fuse(box(WALL-1,y-13,Z-40,WALL,y+13,Z-31)).clean()
    hardware = {}
    for sign,side in ((-1,"LOW"),(1,"HIGH")):
        yy,zz = y+8*sign,Z-35.5
        outer = outer.cut(cylinder(-507,-501,yy,zz,2.25))
        hardware["STUD_"+side] = cylinder(WALL-10,WALL,yy,zz,2)
        hardware["LOCKNUT_"+side] = hex_nut(yy,zz)
    new = {"WET_BOOT":seal, "INNER_KEEPER":inner, "OUTER_KEEPER":outer.clean(), **hardware}
    assert all(s.isValid() and len(s.Solids())==1 for s in [pad,*new.values()])
    return pad_name,pad,{f"D04_{bed}_{n}":s for n,s in new.items()}


def service(bed):
    y=CENTRES[bed]
    # Open rail on the rear side. Envelope includes socket wall and axial
    # approach past the nut, and conservative prisms for straight keeper pull.
    out = {f"SOCKET_{side}":cylinder(-540,-504.5,y+d,Z-35.5,5.5)
           for side,d in (("LOW",-8),("HIGH",8))}
    return out
