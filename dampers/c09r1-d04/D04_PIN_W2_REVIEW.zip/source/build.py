"""Patch two hash-pinned C09R1 full installed STEP files, keeping their XCAF trees."""
import argparse
import hashlib
import json
from pathlib import Path

import cadquery as cq
from OCP.IFSelect import IFSelect_RetDone
from OCP.STEPCAFControl import STEPCAFControl_Reader, STEPCAFControl_Writer
from OCP.STEPControl import STEPControl_AsIs
from OCP.TCollection import TCollection_ExtendedString as Str
from OCP.TDataStd import TDataStd_Name
from OCP.TDF import TDF_Label, TDF_LabelSequence
from OCP.TDocStd import TDocStd_Document
from OCP.TopLoc import TopLoc_Location
from OCP.XCAFDoc import XCAFDoc_DocumentTool
from pin_detail import detail

ROOT=Path(__file__).resolve().parents[1]
HASHES={"S1":"43e28c1f54ee4cb1cb4da7ce50c655a81eb7e93741a666d729d13d9110574fa8",
        "S2":"6ede2eacc7f3b7f5e2a2b3553d151b09210c02f85a807468c641cd8e95fd6d05"}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def name(label):
    attr=TDataStd_Name()
    return attr.Get().ToExtString() if label.FindAttribute(TDataStd_Name.GetID_s(),attr) else ""

def read(path):
    doc=TDocStd_Document(Str("D04"))
    reader=STEPCAFControl_Reader()
    reader.SetNameMode(True)
    assert reader.ReadFile(str(path))==IFSelect_RetDone and reader.Transfer(doc)
    tree=XCAFDoc_DocumentTool.ShapeTool_s(doc.Main())
    roots=TDF_LabelSequence()
    tree.GetFreeShapes(roots)
    assert roots.Length()==1
    return doc,tree,roots.Value(1)

def occurrences(tree,label,loc=TopLoc_Location(),path=()):
    if tree.IsReference_s(label):
        definition=TDF_Label()
        tree.GetReferredShape_s(label,definition)
        yield from occurrences(tree,definition,loc*tree.GetLocation_s(label),path+(name(label),))
    elif tree.IsAssembly_s(label):
        children=TDF_LabelSequence()
        tree.GetComponents_s(label,children)
        for i in range(1,children.Length()+1):
            yield from occurrences(tree,children.Value(i),loc,path+(name(label),))
    else:
        yield path,label,loc,cq.Shape.cast(tree.GetShape_s(label).Moved(loc))

def build(src,state):
    assert sha(src)==HASHES[state], src
    dest=ROOT/"cad"/f"D04_C09R1_INSTALLED_{state}.step"
    doc,tree,root=read(src)
    selected={}
    for path,label,loc,s in occurrences(tree,root):
        part=path[-1]
        if part.startswith(("AIR_REAR_","C09_SPLIT_GLAND_","DAMPER_STATIC_GASKET_")):
            assert part not in selected
            selected[part]=(label,loc,s)
    parts={key:v[2] for key,v in selected.items()}
    group=tree.NewShape()
    TDataStd_Name.Set_s(group,Str("DAMPERS_D04_DETAIL"))
    added={}
    delta={}
    for bed in "AB":
        pad_name,pad,new=detail(bed,parts)
        label,loc,old=selected[pad_name]
        tree.SetShape(label,pad.wrapped.Moved(loc.Inverted()))
        delta[pad_name]=round(old.Volume()-pad.Volume(),6)
        assert delta[pad_name]>1
        for key,s in new.items():
            definition=tree.AddShape(s.wrapped,False)
            TDataStd_Name.Set_s(definition,Str(key))
            instance=tree.AddComponent(group,definition,TopLoc_Location())
            TDataStd_Name.Set_s(instance,Str(key))
            added[key]=round(s.Volume(),6)
    ref=tree.AddComponent(root,group,TopLoc_Location())
    TDataStd_Name.Set_s(ref,Str("DAMPERS_D04_DETAIL"))
    tree.UpdateAssemblies()
    TDataStd_Name.Set_s(root,Str(dest.stem))
    writer=STEPCAFControl_Writer()
    writer.SetNameMode(True)
    writer.SetColorMode(True)
    assert writer.Transfer(root,STEPControl_AsIs) and writer.Write(str(dest))==IFSelect_RetDone
    result={"source":src.name,"source_sha256":HASHES[state],"output":dest.name,"output_sha256":sha(dest),
            "pad_removed_mm3":delta,"added_mm3":added}
    (ROOT/"evidence"/f"build_{state}.json").write_text(json.dumps(result,indent=2))
    return dest

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input_dir",type=Path)
    parser.add_argument("states",nargs="*",default=["S1","S2"],choices=["S1","S2"])
    args=parser.parse_args()
    for state in args.states:
        print(build(args.input_dir/f"C09R1_INSTALLED_{state}.step",state),flush=True)
