"""Release sequence around upper W2. Export the checked service keep-outs in machine coordinates."""
import argparse
import json
from pathlib import Path
import cadquery as cq
from build import ROOT,sha
from verify import parts_of,clearance_screen,bounds,nearest
from pin_detail import CENTRES,INNER,WALL,Z,faces_at,box,cylinder,service

P0={"C08_WATER_ISLAND_P0.step":"14f7500e03f76bf46a3a09da987c552e626aff58c5733fbe7041561e435c2d5b",
    "C08_WATER_SERVICE_P0.step":"bb98b03a57e90718189b4ccc1d30e90a9bde22bd6e395e4fc348ffd15a431e70"}

def draw_back(s,x,travel):
    swept=[cq.Solid.extrudeLinear(f.outerWire(),f.innerWires(),(-travel,0,0)) for f in faces_at(s,x)]
    return s.fuse(*swept).clean()

def run(state,p0_path):
    parts=parts_of(ROOT/"cad"/f"D04_C09R1_INSTALLED_{state}.step")
    named={p[-1]:s for p,s,b in parts if "HEAT_EXCHANGERS" not in p}
    p0=[]
    for n,expected in P0.items():
        assert sha(p0_path/n)==expected
        p0.extend([((n,)+p,s,b) for p,s,b in parts_of(p0_path/n)])
    report={"state":state,"P0_sha256":P0,"sequence":{},"P0_local_part_min":{}}
    assy=cq.Assembly(name="D04_LOCAL_SERVICE")
    envelopes={}
    for bed,y in CENTRES.items():
        prefix=f"D04_{bed}_"
        new=[(n,clearance_screen(s,p0)) for n,s in named.items() if n.startswith(prefix)]
        assert not any(r["penetrations"] for n,r in new)
        n,r=min(new,key=lambda pair:pair[1]["closest"]["mm"])
        report["P0_local_part_min"][bed]={"D04_part":n,**r["closest"]}
        def check(label,s,removed):
            key=prefix+label
            scene=[t for t in parts if t[0][-1] not in removed]
            hit=clearance_screen(s,scene)
            water=clearance_screen(s,p0)
            assert not (hit["penetrations"] or water["penetrations"]), (key,hit,water)
            report["sequence"][key]={"absent_or_mating":sorted(removed),"installed":hit,"P0":water}
            # Use one solid where possible; a conservative box may have multiple solids.
            assert s.isValid() and s.Solids()
            assy.add(s,name=key)
            envelopes[key]=s
        jaw=prefix+"OUTER_KEEPER"
        nuts={prefix+"LOCKNUT_"+side for side in ("LOW","HIGH")}
        for name,s in service(bed).items():
            side=name.split("_")[-1]
            # The tool seats on the outer jaw. Report the nearest independent obstruction.
            check(name,s,{jaw,prefix+"LOCKNUT_"+side,prefix+"STUD_"+side})
        keeper=draw_back(named[jaw],WALL-3,12)
        check("KEEPER_PULL_12",keeper,{jaw,*nuts})
        for side in ("LOW","HIGH"):
            stud=prefix+"STUD_"+side
            d=nearest(keeper,named[stud])["mm"]
            assert abs(d-.25)<.001,(side,d)
            report["sequence"][prefix+"KEEPER_PULL_12"]["clearance_to_"+side+"_stud_mm"]=d
        for side,sign in (("LOW",-1),("HIGH",1)):
            n=f"C09_SPLIT_GLAND_{bed}_UPPER_W2_{side}"
            removed={n,jaw,*nuts,prefix+"WET_BOOT",f"DAMPER_STATIC_GASKET_{bed}_UPPER_O",
                     f"DAMPER_SEAT_{bed}_UPPER_DEEP_O"}
            check(side+"_GLAND_AXIAL_2",draw_back(named[n],WALL,2),removed)
            # At -2 X the half clears the sheet. Its distance to the tube axis
            # can only increase as it moves in its own half-plane. This pris-
            # matic bound with the straight bore removed contains the full pull.
            lo,hi=sorted([y,y+sign*(22.5+25)])
            bound=box(WALL-2,lo,Z-22.5,INNER-2,hi,Z+22.5)
            bound=bound.cut(cylinder(WALL-3,INNER-1,y,Z,17.5))
            check(side+"_GLAND_RADIAL_25",bound,removed)
    if state=="S1":
        step=ROOT/"cad/D04_LOCAL_SERVICE.step"
        assy.save(str(step))
        back=parts_of(step)
        assert len(back)==len(envelopes)==14
        for p,s,b in back:
            assert p[-1] in envelopes and s.isValid()
            assert abs(s.Volume()-envelopes[p[-1]].Volume())<.001
        report["service_STEP_sha256"]=sha(step)
    (ROOT/"evidence"/f"service_{state}.json").write_text(json.dumps(report,indent=2))
    print("Verified local release",state,flush=True)

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("state",choices=["S1","S2"])
    parser.add_argument("p0_dir",type=Path)
    args=parser.parse_args()
    run(args.state,args.p0_dir)
