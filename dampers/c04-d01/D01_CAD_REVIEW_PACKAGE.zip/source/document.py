"""Produce review drawings and handoff tables from the actual check results."""
import bootstrap
from bootstrap import ROOT
import csv
import hashlib
import json
import math
import zipfile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

def read(path):
    return json.loads((ROOT/path).read_text(encoding='utf-8'))

def table(name, rows):
    with (ROOT/'tables'/name).open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

cfg=read('design.json')
result=read('evidence/D01_INTERFACE_CHECKS.json')
data=read('evidence/D01_DRAW_DATA.json')
separation=read('evidence/D01_DAMPER_SEPARATION.json')
readback=read('evidence/D01_STEP_READBACK.json')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
colors={'P':'#167f9d','R':'#d77d2c'}
fig,axs=plt.subplots(1,2,figsize=(17,9),gridspec_kw={'width_ratios':[1.2,1]})
ax=axs[0]
shell=data['shell']
ax.add_patch(Rectangle((shell[0],shell[1]),shell[3]-shell[0],shell[4]-shell[1],fill=False,lw=1.5,ec='#84939f'))
for p in data['placements']:
    b=p['bounds'];ax.add_patch(Rectangle((b[0],b[1]),b[3]-b[0],b[4]-b[1],fc=colors[p['type']],alpha=.19,ec=colors[p['type']]))
    cy=p['centre_Y']; x=p['flange_X']; sign=-1 if p['face']=='F' else 1
    off=cfg['adapter_offset_including_host_gasket']
    ax.add_patch(Rectangle((min(x+sign*(off+2),x+sign*(off+182)),cy-353),180,706,fill=False,lw=1.0,ec=colors[p['type']]))
    ax.add_patch(Rectangle((min(x+sign*2,x+sign*off),cy-353),off-2,706,fc='#687d8b',alpha=.25,ec='none'))
    if p['type']=='P':ax.text(x+sign*90,cy,p['id'][:2],ha='center',va='center',fontsize=11,fontweight='bold')
for a in data['actuators']:
    b=a['bounds'];ax.add_patch(Rectangle((b[0],b[1]),b[3]-b[0],b[4]-b[1],fc='#9e4c9c',alpha=.10,ec='#9e4c9c',ls='--'))
for f in data['feedback']:
    if f['id'][-1]!='P':continue
    b=f['bounds'];ax.add_patch(Rectangle((b[0],b[1]),b[3]-b[0],b[4]-b[1],fc='#e6b52b',alpha=.45,ec='#b38510'))
a=cfg['bed_A_Y'];b=a+cfg['candidate_bed_pitch']
ax.annotate('',xy=(550,a),xytext=(550,b),arrowprops={'arrowstyle':'<->','color':'#263b4d'})
ax.text(575,(a+b)/2,f"{cfg['candidate_bed_pitch']:.0f} bed pitch",rotation=90,va='center')
ax.set(xlabel='X / mm',ylabel='Y / mm',title='Plan: eight real damper envelopes\nP/R overlap in this projection; all dimensions in mm')
ax.set_aspect('equal');ax.autoscale_view();ax.grid(alpha=.15)
ax=axs[1]
for bed,cy in (('A',a),('B',b)):
    for tag,(z,h) in cfg['ports'].items():
        ax.add_patch(Rectangle((cy-353,z-38),706,h+76,fill=False,lw=1.8,ec=colors[tag]))
        ax.add_patch(Rectangle((cy-315,z),630,h,fc=colors[tag],alpha=.14,ec='none'))
        ax.text(cy,z+h/2,bed+' / '+tag,ha='center',va='center',fontsize=12,fontweight='bold',color=colors[tag])
    for p in data['placements']:
        if p['bed']!=bed or p['face']!='F':continue
        e=p['bounds'];ax.add_patch(Rectangle((e[1],e[2]),e[4]-e[1],e[5]-e[2],fill=False,ls=':',ec=colors[p['type']],alpha=.7))
gap=cfg['candidate_bed_pitch']-706
ax.annotate('',xy=(a+353,115),xytext=(b-353,115),arrowprops={'arrowstyle':'<->'})
ax.text((a+b)/2,135,f'{gap:.0f} flange gap',ha='center',fontsize=9)
physical_gap=next(x for x in data['placements'] if x['id']=='BFP')['bounds'][1]-next(x for x in data['placements'] if x['id']=='AFP')['bounds'][4]
ax.text(.04,.96,f'Minimum feedback hardware gap: {physical_gap:.1f}\nOne cover withdraws {cfg["feedback_cover_withdrawal"]:.0f}; other cover stays fitted.\nA/B share gravity and pressure direction.\nB uses a NEW derived hand; qualification remains open.',transform=ax.transAxes,va='top',fontsize=10,bbox={'facecolor':'#eef3f6','edgecolor':'none','pad':10})
ax.set(xlabel='Y / mm',ylabel='Z / mm',title='Front interfaces: net openings unchanged\nSolid outlines: flanges; dotted outlines: component envelopes')
ax.set_ylim(80,1390);ax.set_xlim(a-1010,b+1010);ax.set_aspect('equal');ax.grid(alpha=.15)
fig.suptitle('AirTransformer dampers D01 | GEOMETRY CANDIDATE',fontsize=18,fontweight='bold',x=.08,ha='left')
fig.legend(handles=[Rectangle((0,0),1,1,fc=colors['P'],alpha=.5,label='Process P'),
                    Rectangle((0,0),1,1,fc=colors['R'],alpha=.5,label='Regeneration R'),
                    Rectangle((0,0),1,1,fc='#9e4c9c',alpha=.3,label='Actuator selection reserve'),
                    Rectangle((0,0),1,1,fc='#e6b52b',alpha=.5,label='One-cover service')],
           loc='upper center',bbox_to_anchor=(.75,.88),ncol=2,frameon=False,fontsize=9)
fig.text(.08,.025,'Proposed 1280 mm host interface. Delivered C04 remains unchanged. No CFD, FE, loaded operation or manufacturing release.',fontsize=10,color='#4e5e68')
fig.subplots_adjust(left=.07,right=.98,bottom=.10,top=.87,wspace=.2)
fig.savefig(ROOT/'drawings/D01_LAYOUT_AND_SERVICE.png',dpi=160,facecolor='white')
fig.savefig(ROOT/'drawings/D01_LAYOUT_AND_SERVICE.svg',facecolor='white')
plt.close(fig)

fig,axs=plt.subplots(2,1,figsize=(12,10),gridspec_kw={'height_ratios':[1.4,1]})
for ax,(tag,(z,h)) in zip(axs,cfg['ports'].items()):
    H=h+76
    ax.add_patch(Rectangle((-353,0),706,H,fc='#f1f5f7',ec='#3d5363',lw=1.5))
    ax.add_patch(Rectangle((-315,38),630,h,fc='white',ec=colors[tag],lw=1.8))
    rows=[r for r in data['studs'] if r['id'].startswith('AF'+tag+'.')]
    for r in rows:ax.add_patch(plt.Circle((r['y']-cfg['bed_A_Y'],r['z']-(z-38)),4.5,fill=False,color='#243947',lw=.7))
    ax.annotate('',xy=(-353,-24),xytext=(353,-24),arrowprops={'arrowstyle':'<->'})
    ax.text(0,-32,'706',ha='center',va='top')
    ax.text(0,H+20,f'{tag}: {len(rows)} x diameter 9 | M8 weld stud, {cfg["stud_free_length"]:g} mm free after weld',ha='center',fontsize=12,fontweight='bold')
    ax.text(0,38+h/2,f'NET 630 x {h:.0f}\nBody 180 | adapter metal {cfg["adapter_metal_depth"]:g} | two gaskets 2.00 each\nFlange 3 + washer 1.6 + nut 6.5',ha='center',va='center',fontsize=12,color=colors[tag])
    ax.set_aspect('equal');ax.set_xlim(-430,430);ax.set_ylim(-55,H+55);ax.axis('off')
fig.suptitle('D01 external interface | R21 hole pattern retained',fontsize=18,fontweight='bold',y=.97)
fig.text(.12,.035,'Coordinates: tables/D01_M8_STUD_COORDINATES.csv.\nStud welds on the 2.5 mm host flange and seal flatness require a coupon and measurement.\nEngineering candidate. This overview is not a released fabrication drawing.',fontsize=9,color='#4e5e68')
fig.subplots_adjust(top=.91,bottom=.10,hspace=.20)
fig.savefig(ROOT/'drawings/D01_FLANGE_STUD_INTERFACE.png',dpi=160,facecolor='white')
fig.savefig(ROOT/'drawings/D01_FLANGE_STUD_INTERFACE.svg',facecolor='white')
plt.close(fig)

rows=[]
ids=['AFP','AFR','ARP','ARR','BFP','BFR','BRP','BRR']
routes={'A_P_B_R':{'AFP','ARP','BFR','BRR'},'A_R_B_P':{'AFR','ARR','BFP','BRP'}}
for route,opens in routes.items():
    for state,description,cmd,fan,gate in (
        ('T1','减风至规定的零流量/零速条件','KEEP_OLD','RAMP_TO_STOP','零流量/零速阈值及传感器由控制负责人定义；不得只靠固定延时'),
        ('T2','全关，确认八阀均关','ALL_CLOSED','STOP','逐阀确认CLOSED；任一未确认则禁止开新风路'),
        ('T3','水路切换等待','ALL_CLOSED','STOP','水路负责人返回切换完成和允许送风；本版不定义四三通阀过渡水力安全'),
        ('T4','开新风路','NEW_ROUTE','STOP','同一选通箱另一阀保持CLOSED；新风路两端均OPEN后才允许起风机'),
        ('RUN','稳定运行','NEW_ROUTE','RAMP_TO_DUTY','持续监测互斥、反馈合理性、压差及泄漏；失配进入FAULT')):
        r=dict(route=route,state=state,description=description,fan=fan,advance_gate=gate,
               timing='按实选执行器实测行程和PLC超时设定；尚未定值')
        r.update({i:('CLOSED' if cmd=='ALL_CLOSED' else ('KEEP_OLD' if cmd=='KEEP_OLD' else ('OPEN' if i in opens else 'CLOSED'))) for i in ids})
        rows.append(r)
fault=dict(route='ANY',state='FAULT',description='停风并发出全关命令；锁存故障，禁止自动续开',fan='STOP',
           advance_gate='隔离并排故；失电失效位及制动方式须由执行器实选确认',timing='实际失电/卡滞试验后定值')
fault.update({i:'COMMAND_CLOSED_POSITION_NOT_ASSUMED' for i in ids});rows.append(fault)
table('D01_BREAK_BEFORE_MAKE.csv',rows)
host_requests=[
 dict(item='床距',value=cfg['candidate_bed_pitch'],unit='mm',owner='shell2',status='D01候选几何'),
 dict(item='床A全局Y位移',value=0,unit='mm',owner='shell2',status='保持A床接口'),
 dict(item='床B全局Y位移',value=cfg['candidate_bed_pitch']-cfg['original_bed_pitch'],unit='mm',owner='shell2',status='相对C04平移；不改变芯体方向'),
 dict(item='主壳体Y最小',value=data['shell'][1],unit='mm',owner='shell2',status='不含驱动及执行器'),
 dict(item='主壳体Y最大',value=data['shell'][4],unit='mm',owner='shell2',status='不含驱动及执行器'),
 dict(item='主壳体宽度',value=data['shell'][4]-data['shell'][1],unit='mm',owner='shell2',status='不含驱动及执行器'),
 dict(item='风阀轴向移出',value=cfg['adapter_offset_including_host_gasket'],unit='mm',owner='dampers2',status='含2mm主垫与33mm金属接框'),
 dict(item='四根后侧套管缩短',value=cfg['adapter_offset_including_host_gasket']+4,unit='mm',owner='shell2',status='已在候选参考CAD落实；按真实双端垫对齐'),
 dict(item='风阀独立支架',value='待设计',unit='',owner='shell2/dampers2',status='S1未关闭；不得由薄母板承受阀重'),
 dict(item='侧板开孔',value='native/D01_PANEL_CUTOUTS.json',unit='',owner='shell2',status='逐件包络+15mm；可拆盖板及框架刚度待详设')]
table('D01_HOST_INTERFACE_REQUEST.csv',host_requests)
closure=[
 dict(id='D1',change=f'八阀真实组件安装；建议床距{cfg["candidate_bed_pitch"]:.0f}，原840保留失败证据',evidence='D01_DAMPER_SEPARATION.json; D01_EIGHT_DAMPERS_INSTALLED.step',status='PASS_EXTERNAL_GEOMETRY_ONLY',remaining='壳体负责人接受新床距；独立承重支架与外部风管另行集成'),
 dict(id='D2',change='侧板按逐件全回转包络+15mm开孔；加入250x250x250执行器选型空间',evidence='D01_PANEL_CUTOUTS.json; D01_INTERFACE_CHECKS.json',status='GEOMETRY_CHECKED_ACTUATOR_HOLD',remaining='实选执行器、连接法兰、反力矩支承和实际拔出路径'),
 dict(id='D3',change='B床使用真正镜像的新手性派生几何，重力/压差方向与A床一致',evidence='D01_HAND_DEFINITION.json; D01_MIRROR_DISPOSITION.csv',status='DERIVED_HAND_CANDIDATE_QUALIFICATION_HOLD',remaining='右手件出图、购件安装确认、冷/湿/热密封与反馈验证；不能沿用R21签发页直接制造'),
 dict(id='D4',change='外接螺栓改M8x55焊钉；33mm金属接框+2mm主垫形成35mm移出；局部口袋避让反馈支脚；新增R阀第二端面垫',evidence='D01_M8_STUD_COORDINATES.csv; D01_ADAPTER_POCKETS.json; D01_FLANGE_STUD_INTERFACE.svg',status='INTERFACE_DEFINED_PROCESS_HOLD',remaining='2.5mm母板焊钉试片、接框口袋出图、焊后平面度、实际夹紧压缩和承重脱开设计'),
 dict(id='C8',change='给出先关后开和停风/位置确认状态表',evidence='D01_BREAK_BEFORE_MAKE.csv',status='CONTROL_REQUIREMENT_DEFINED_NOT_COMMISSIONED',remaining='实选执行器时间、故障位、独立反馈及水路联锁后由PLC负责人实现'),
 dict(id='S1',change='输出真实风阀接口及包络；本次未设计承重支架',evidence='D01_PLACEMENTS.json',status='OPEN_HOST_OWNER',remaining='独立阀架到地基的受力链；薄板法兰只承担气密连接'),
 dict(id='R21_INTERNAL',change='保留原生实体及既有问题，不将外部包络通过写成整阀通过',evidence='C04_R21_BASELINES.zip; R21_COMPONENT_SCOPE.json',status='INHERITED_HOLDS',remaining='膜片端部捕获、转子捕获、G1/止挡/驱动柔度及采购件资格')]
table('D01_REVIEW_CLOSEOUT.csv',closure)

scope=read('evidence/R21_COMPONENT_SCOPE.json')
excluded=sum(not r['retained'] for r in scope['rows'])
hardware_replaced=read('evidence/OUTER_FLANGE_HARDWARE_REPLACEMENTS.json')
text=f'''# L2-MI dampers2｜C04 风阀 D01 几何整改候选

日期：2026-11-05。状态：**{result['status']}；不作为制造放行或试验运行许可。**

![布置与检修包络](drawings/D01_LAYOUT_AND_SERVICE.png)

本版保留 R21 的阀芯、180 mm 阀体深度、P 630×345 / R 630×180 净口及原 706 mm 法兰孔阵列。原 C04、R21 文件未改写。
主要调整是装机手性、真实驱动占位和外接紧固。每个接口增加33 mm金属接框及2 mm主垫，使风阀移出35 mm；接框的局部让位槽避开反馈支脚，未削减阀芯和反馈零件。后侧四根套管按真实两端垫及接框相应缩短39 mm。
旧C02 R100S的R112/R113共四个20 mm抬高段源实例，由新密封接框替代，不再叠加装入本机；[替换记录](evidence/D01_RETIRED_MACHINE_INTERFACES.json)保留来源。未撤销旧批次或指示报废库存。
为得到可检查的双床候选，提出 **1280 mm 床距**（原840增加440）；这是一项提交给 shell2 的接口要求，尚未纳入其正式壳体版本。
床A保持原位，床B整体沿+Y移440 mm。参考主壳体Y范围由−852…+852改为−852…+1292 mm，宽2144 mm，驱动及执行器外伸另计。明确的壳体接入项见 [接口请求表](tables/D01_HOST_INTERFACE_REQUEST.csv)。
床 B 使用标识为 D01_MH 的真正镜像派生几何，不能拿原件旋转180°替代。左右手间重力及气流/压差方向相同；新右手件的制造和性能资格仍待建立。

## CAD 与可编辑数据

- [八阀装机 STEP](cad/D01_EIGHT_DAMPERS_INSTALLED.step)：原生风阀组件、候选加宽参考壳体、实际驱动及新焊钉；所有八个位置均有独立名称。
- [床 A 风阀接口 STEP](cad/D01_BED_A_DAMPER_INTERFACES.step)：四只原手性阀，不含床 B 派生件；**没有独立支架，不是可直接建造的冷流试验总装**。
- [连续运动/执行器/反馈拆卸空间 STEP](cad/D01_SERVICE_ENVELOPES.step)：参考空间，不是实物和采购件。
- [装配变换](native/D01_PLACEMENTS.json)、[侧板开孔](native/D01_PANEL_CUTOUTS.json)、[参数](design.json)、[重建代码](source/build.py)。修改参数后重建，不从截图量尺寸。
- `native/*_D01_ADAPTER.brep`使用装机全局坐标；加工须另建基准、出让位口袋图并审批，不能直接把文件原点当作下料零点。
- [法兰与焊钉接口图](drawings/D01_FLANGE_STUD_INTERFACE.svg)、[逐孔坐标](tables/D01_M8_STUD_COORDINATES.csv)、[整改闭环表](tables/D01_REVIEW_CLOSEOUT.csv)。

## 几何核查范围

1. 在原840 mm床距上，以真实零件再次得到四组同层 A/B 硬干涉，前后 P/R 均有失败记录；没有把空的占位块检查当作通过。
2. 候选八阀的28种两两组合，逐件连续运动包络互不相交。以源件包围盒绕实际轴的最大角点半径建立全360°外包络，因此包含0–90°的所有中间角度；该证明只针对外部接口，不证明原阀内部运动合格。
3. 与候选参考壳体的静态实体干涉、连续运动外包络干涉、新接框/焊钉/垫片实体、Ø20×25短套筒沿Z侧向50 mm进入（顶/底排从边外，侧排沿法兰边从内侧；含Ø22×10棘轮头及100 mm沿边手柄）、单只反馈盖沿轴100 mm拔出及执行器选型空间分别检查，原始结果见 [D01_INTERFACE_CHECKS.json](evidence/D01_INTERFACE_CHECKS.json)。反馈盖不得同时向中间拔出。工具尺寸是选型限界，需要实物工具及人手试装；不是供应商供货声明。
4. 当前参考 CAD 通过不代表原 C04 整机通过。加宽后的框架只是接口参照；支撑、刚度、密封、排水、水路和风道流场均未在本版关闭。
5. STEP独立重新导入：{'; '.join(f"{r['file']} = {r['readback_solids']} 个有效实体" for r in readback)}。未运行CFD、FE或任何物理试验。

新增接口的连续运动复核另由导出AP242重新读取全部976个新接口实例，逐件对照运动包络；B200在两条净口边沿轴向分段，避免把阀叶弦长错误地延伸到外侧细轴段。[独立复核结果](evidence/D01_NEW_INTERFACES_CONTINUOUS_MOTION.json)只证明外部连续几何间隙，不替代载荷、捕获、密封或内部接触验证。

## 组件归属与紧固修改

R21是含试验设施的冷装配，不是纯产品装配。本版排除源标识的试验台、仪表、原接收框，并用1 mm实体距离、四轮连接传播识别随产品的通用紧固件；其余未能关联的硬件不计入装机，共排除{excluded}条源记录。
这是**几何集成范围推断，不是制造BOM或采购数量依据**；每个源 occurrence 的取舍及关联父件均在 [组件范围表](evidence/R21_COMPONENT_SCOPE.json)。采购图和正式装配分配仍需归属负责人确认。
源外接螺栓/螺母/垫圈共{len(hardware_replaced)}条记录改由新接口定义，[替换清单](evidence/OUTER_FLANGE_HARDWARE_REPLACEMENTS.json)逐件可查。
其中含R阀五处改过料号的HW_R12_M8X40；这些孔位改用新焊钉后，G843的新夹紧、支承及预紧链仍须单独详设。本版只保留其空间实体，不把它记作已完成的反馈承重连接。

本版八阀到壳体接口共{result['new_stud_count']}根M8焊钉。有效外露55 mm，穿过主垫2、金属接框33、阀垫2、阀法兰3、垫圈1.6及螺母6.5，名义螺纹外露6.9 mm；实际有效牙长及端倒角需实物检查。新主垫逐孔设2 mm金属压缩限位；源阀垫原有限位保留。让位槽未侵入两端面距净口20 mm的原密封带（原螺栓孔及压缩限位不变），内侧气路边壁保持至少2 mm，实际值见 [接框让位](native/D01_ADAPTER_POCKETS.json)。G843仍是原版暂缓件，仅保留其实体占位，不取得承重资格。接框仅定义气密安装接口，不承担未验证的整阀重量。
R21 R阀原来只有一端外接垫，本版复制同一R106压缩态轮廓用于第二端面，标识D01_R106_SECOND_FACE；软料自由厚度及压缩限位沿用来源要求，不能按压缩态CAD直接切自由料。
薄2.5 mm母板上的焊钉必须做焊接试片及焊后平面度/夹紧压缩检查。外接风管另一端的紧固及支承另行定义；本表不是全机紧固件总量。

## 仍须闭合的条件

- shell2确认1280 mm接口；840 mm不能靠左右旋转或交换端头通过。本版没有擅自覆盖C04。
- D01_MH右手件需单独出图及冷热/湿态/压差密封、反馈、驱动和购件安装确认；R21原签发页不能自动覆盖镜像件。
- 左右手的编码器零点、反馈正方向和开关限位分别标定，不能直接复制控制极性。G843及其五处夹紧的承载定义继续HOLD。
- 实选执行器、输入适配器、动态扭矩限制和拆卸服务空间仍待确认；250 mm方盒只是明确的选型限界。
- 每只风阀及选通箱需独立支架。**不能把阀重交给2.5 mm法兰。** S1承重链、原R21膜片/捕获/柔度问题继续HOLD。
- 红队其余 S2–S8、W1–W5、A1–A3 仍由相应负责人处理；冷流C1–C8尚未全部实现。再生模式优先试验，沿用红队G0/G1门槛。
- [先关后开状态表](tables/D01_BREAK_BEFORE_MAKE.csv)已写；执行器实测行程时间、失效位、PLC实现、独立位置确认和水路联锁尚待集成。

## 复现

Python3.12 + CadQuery2.8.0 / OCP7.9.3.1.1、NumPy2.3.5、SciPy1.18.1、Matplotlib。本机可运行 `run.ps1`；其他环境安装依赖后依次运行 `source/build.py`、`source/check_motion_interfaces.py`、`source/verify.py`、`source/document.py`，最后运行 `source/verify.py --package`（均使用 `python -X utf8`）。
`inputs/C04_R21_BASELINES.zip`含21份未改动基线。重建只向本版`.work/`及输出目录写入，不运行旧版制造/打包脚本，不覆盖源交付。
`inputs/BASELINE_MANIFEST.json`逐件记录来源路径和SHA256；源审查来自 fredshuc/buildfly 的 claude/jolly-hopper-mndk80 分支，审查基线cb6c2b5，完整审查随包保留。
'''
(ROOT/'README_CN.md').write_text(text,encoding='utf-8')
table('D01_DELIVERABLES.csv',[dict(file=str(p.relative_to(ROOT)).replace('\\','/'),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
                           for p in sorted(ROOT.rglob('*')) if p.is_file() and not any(x in p.parts for x in ('.work','.runtime','__pycache__')) and p.name not in ('D01_DELIVERABLES.csv','D01_CAD_REVIEW_PACKAGE.zip')])
package=ROOT/'D01_CAD_REVIEW_PACKAGE.zip'
with zipfile.ZipFile(package,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and p!=package and not any(x in p.parts for x in ('.work','.runtime','__pycache__')):
            z.write(p,str(p.relative_to(ROOT)).replace('\\','/'))
print('Drawings, readme, closeout, control table and package ready:',package.stat().st_size,'bytes')
