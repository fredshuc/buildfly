"""Independently check new interfaces against continuous moving-part bounds.

Read new hardware from the exported AP242, not the in-memory build. Slice B200
at the two net-port edges before bounding its rotation: otherwise a whole-rotor
box spuriously extends the blade chord along the outboard slender shafts.
"""
import bootstrap
from bootstrap import ROOT
from native import load,bb,box,overlap
from build import CFG,product_placement,place_bound,swept_test_bounds
import hashlib
import json
import numpy as np
import cadquery as cq
from OCP.STEPCAFControl import STEPCAFControl_Reader
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString
from OCP.XCAFDoc import XCAFDoc_DocumentTool
from OCP.TDataStd import TDataStd_Name
from OCP.TDF import TDF_Label,TDF_LabelSequence
from OCP.TopLoc import TopLoc_Location

def name(label):
    attr=TDataStd_Name()
    return attr.Get().ToExtString() if label.FindAttribute(TDataStd_Name.GetID_s(),attr) else ''

path=ROOT/'cad/D01_EIGHT_DAMPERS_INSTALLED.step'
reader=STEPCAFControl_Reader();reader.SetNameMode(True)
assert reader.ReadFile(str(path)).value==1
doc=TDocStd_Document(TCollection_ExtendedString('doc'));assert reader.Transfer(doc)
st=XCAFDoc_DocumentTool.ShapeTool_s(doc.Main());interfaces=[];definitions={}
def walk(label,loc,group='',occ=''):
    target=label
    if st.IsReference_s(label):
        target=TDF_Label();assert st.GetReferredShape_s(label,target)
        loc=loc*st.GetLocation_s(label)
    nm=occ or name(label) or name(target)
    if st.IsAssembly_s(target):
        group='INTERFACES' if nm=='INTERFACES' or name(target)=='INTERFACES' else group
        seq=TDF_LabelSequence();st.GetComponents_s(target,seq)
        for i in range(1,seq.Length()+1):walk(seq.Value(i),loc,group)
    elif group=='INTERFACES':
        local=cq.Shape.cast(st.GetShape_s(target));world=local.moved(cq.Location(loc))
        key=name(target);definitions[key]=local
        interfaces.append(dict(name=nm,shape=world,bounds=bb(world),definition=key))
seq=TDF_LabelSequence();st.GetFreeShapes(seq)
for i in range(1,seq.Length()+1):walk(seq.Value(i),TopLoc_Location())
assert len(interfaces)==976,('Missing neutral-format interfaces',len(interfaces))
directory=ROOT/'native/definitions';directory.mkdir(exist_ok=True)
for key,shape in definitions.items():
    assert shape.isValid(),key
    shape.exportBrep(str(directory/(key+'.brep')))

_,products=load();moving=[];split_records=[]
for tag,rows in products.items():
    for row in rows:
        o=row['o']
        if not(o.get('moving') or o['pn'] in ('BUY504','BUY_R13_BK2','BUY_R13_7206','BUY520','BUY521')):continue
        bounds=[]
        if o['pn']=='B200_R13':
            b=row['bounds'];cuts=sorted(set([b[1],b[4]]+[v for v in (-723.,-93.) if b[1]<v<b[4]]))
            for low,high in zip(cuts,cuts[1:]):
                cutter=box([b[0]-1,low,b[2]-1,b[3]+1,high,b[5]+1])
                clipped=row['shape'].intersect(cutter)
                if clipped.Volume()>.001:
                    segment=dict(o=o,shape=clipped,bounds=bb(clipped))
                    bounds.append(swept_test_bounds(segment))
            split_records.append(dict(config=tag,part=o['occurrence'],shaft_Y_cuts=cuts,segment_count=len(bounds)))
        else:bounds=[swept_test_bounds(row)]
        for bed in 'AB':
            for face in 'FR':
                p=product_placement(tag,bed,face,CFG['candidate_bed_pitch'])
                moving.extend(dict(valve=bed+face+tag,part=o['occurrence'],bounds=place_bound(b,p,bed)) for b in bounds)
hits=[];candidates=0
for item in interfaces:
    for sweep in moving:
        if overlap(item['bounds'],sweep['bounds'],1e-5):
            candidates+=1
            volume=item['shape'].intersect(box(sweep['bounds'])).Volume()
            if volume>.001:hits.append(dict(interface=item['name'],valve=sweep['valve'],part=sweep['part'],enclosure_overlap_mm3=volume))
report=dict(status='PASS_NEW_INTERFACES_CONTINUOUS_MOTION' if not hits else 'FAIL_NEW_INTERFACES_CONTINUOUS_MOTION',
            interface_occurrences_read_from_STEP=len(interfaces),native_interface_definitions=len(definitions),
            continuous_segment_enclosures=len(moving),overlap_candidates=candidates,clashes=hits,
            B200_segmentation=split_records,step_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
            scope='Continuous full-rotation external clearance only; not inherited internal contacts, support or loaded/hot qualification.')
(ROOT/'evidence/D01_NEW_INTERFACES_CONTINUOUS_MOTION.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(report['status'],len(interfaces),'STEP interfaces;',len(moving),'continuous enclosures;',len(hits),'clashes',flush=True)
assert not hits,hits[:12]
