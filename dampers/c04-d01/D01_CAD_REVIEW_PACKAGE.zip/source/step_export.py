"""AP242 assembly with shared definitions and proper rotations for both hands."""
import bootstrap
from bootstrap import ROOT
from native import read_brep, transform, bb
import hashlib
import json
import numpy as np
import cadquery as cq
from OCP.gp import gp_Trsf
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString
from OCP.XCAFDoc import XCAFDoc_DocumentTool, XCAFDoc_ShapeTool, XCAFDoc_ColorGen
from OCP.TDataStd import TDataStd_Name
from OCP.Quantity import Quantity_ColorRGBA
from OCP.STEPCAFControl import STEPCAFControl_Writer
from OCP.STEPControl import STEPControl_AsIs
from OCP.Interface import Interface_Static
from OCP.TopLoc import TopLoc_Location

SHAPES={}

def location(r,t):
    g=gp_Trsf();g.SetValues(*r[0],t[0],*r[1],t[1],*r[2],t[2]);return TopLoc_Location(g)

def export(name,placed,placements,definitions,host,hardware,single=False):
    doc=TDocStd_Document(TCollection_ExtendedString('XmlOcaf'))
    st=XCAFDoc_DocumentTool.ShapeTool_s(doc.Main());ct=XCAFDoc_DocumentTool.ColorTool_s(doc.Main())
    XCAFDoc_ShapeTool.SetAutoNaming_s(False)
    root=st.NewShape();TDataStd_Name.Set_s(root,TCollection_ExtendedString(name))
    labels={};groups={};native=[];max_error=0.;volume_checks={}
    out=ROOT/'native/definitions';out.mkdir(exist_ok=True)
    def add(key,shape,group,occ,r,t,color):
        if key not in labels:
            label=st.NewShape();st.SetShape(label,shape.wrapped)
            TDataStd_Name.Set_s(label,TCollection_ExtendedString(key))
            ct.SetColor(label,Quantity_ColorRGBA(*color),XCAFDoc_ColorGen);labels[key]=label
        if group not in groups:
            g=st.NewShape();TDataStd_Name.Set_s(g,TCollection_ExtendedString(group));groups[group]=g
            st.AddComponent(root,g,TopLoc_Location())
        component=st.AddComponent(groups[group],labels[key],location(r,t))
        TDataStd_Name.Set_s(component,TCollection_ExtendedString(occ))
        native.append(dict(occurrence=group+'/'+occ,definition=key,R=np.array(r).tolist(),t=np.array(t).tolist()))
    for p in placements:
        vid=p['id']
        if single and p['bed']!='A':continue
        m=np.array(p['test_to_install_R']);t=np.array(p['test_to_install_t']);cy=p['centre_Y']
        for row in placed[vid]:
            o=row['o'];pn=o.get('source_pn',o['pn']);r0=np.array([o['u'],o['v'],o['n']]).T
            if pn not in SHAPES:SHAPES[pn]=read_brep(definitions[pn]['brep'])
            base=SHAPES[pn];r=m@r0;origin=m@np.array(o['o'])+t
            key='R21_'+pn
            if p['bed']=='B':
                key='D01_MH_'+pn
                if key not in SHAPES:
                    SHAPES[key]=base.mirror('YZ')
                    SHAPES[key].exportBrep(str(out/(key+'.brep')))
                    v=abs(SHAPES[key].Volume()-base.Volume());assert v<max(.001,base.Volume()*1e-9),(key,v)
                    assert SHAPES[key].isValid(),key
                    volume_checks[key]=v
                base=SHAPES[key]
                mirror=np.diag([1.,-1.,1.]);local_mirror=np.diag([-1.,1.,1.])
                r=mirror@r@local_mirror
                origin=mirror@origin+np.array([0.,2*cy,0.])
            assert abs(np.linalg.det(r)-1)<1e-8,(vid,key,'improper placement')
            candidate=transform(base,r,origin)
            err=max(abs(a-b) for a,b in zip(bb(candidate),row['bounds']));max_error=max(max_error,err)
            assert err<1e-5,(vid,o['occurrence'],err)
            add(key,base,vid,o['occurrence'],r,origin,(.12,.5,.67,1.) if vid[-1]=='P' else (.89,.47,.16,1.))
    for hn,(hs,hc) in host.items():
        if single and not hn.startswith(('AF_','AR_','AF','AR','A_')):continue
        add('HOST_'+hn,hs,'HOST',hn,np.eye(3),np.zeros(3),(.68,.72,.75,.3))
    for h in hardware:
        if single and not h['name'].startswith('A'):continue
        key=h.get('export_key','INTERFACE_'+h['name'])
        shape=h.get('export_shape',h['shape']);r=h.get('export_R',np.eye(3));t=h.get('export_t',np.zeros(3))
        add(key,shape,'INTERFACES',h['name'],r,t,(.65,.65,.68,1.))
    st.UpdateAssemblies()
    boot=STEPCAFControl_Writer()
    Interface_Static.SetCVal_s('write.step.schema','AP242DIS')
    Interface_Static.SetCVal_s('write.step.unit','MM');Interface_Static.SetCVal_s('xstep.cascade.unit','MM')
    Interface_Static.SetIVal_s('write.step.assembly',2)
    writer=STEPCAFControl_Writer();writer.SetNameMode(True);writer.SetColorMode(True)
    assert writer.Transfer(doc,STEPControl_AsIs)
    path=ROOT/'cad'/(name+'.step');assert writer.Write(str(path)).value==1
    (ROOT/'native'/(name+'_OCCURRENCES.json')).write_text(json.dumps(native,indent=2),encoding='utf-8')
    return dict(file=path.name,occurrences=len(native),shared_definitions=len(labels),max_native_vs_study_bounds_error_mm=max_error,
                new_mirror_volume_errors_mm3=volume_checks,sha256=hashlib.sha256(path.read_bytes()).hexdigest())
