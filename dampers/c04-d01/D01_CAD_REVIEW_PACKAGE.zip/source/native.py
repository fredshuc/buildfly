"""Read the named R21 definitions without running any historical build/export."""
import bootstrap
from bootstrap import ROOT
import collections
import hashlib
import io
import json
import zipfile
from pathlib import Path
import cadquery as cq
import numpy as np
from OCP.BRep import BRep_Builder
from OCP.BRepTools import BRepTools
from OCP.TopoDS import TopoDS_Shape
from OCP.gp import gp_Trsf

def box(bounds):
    return cq.Solid.makeBox(*(bounds[i+3] - bounds[i] for i in range(3)), cq.Vector(*bounds[:3]))

def bb(shape):
    b = shape.BoundingBox()
    return [b.xmin, b.ymin, b.zmin, b.xmax, b.ymax, b.zmax]

def transform(shape, matrix, translation):
    g = gp_Trsf()
    g.SetValues(*matrix[0], translation[0], *matrix[1], translation[1], *matrix[2], translation[2])
    return shape.moved(cq.Location(g))

def read_brep(text):
    shape = TopoDS_Shape()
    BRepTools.Read_s(shape, io.BytesIO(text.encode()), BRep_Builder())
    return cq.Shape.cast(shape)

def include(o):
    return (o.get('physical_class') not in ('DRY_TEST_FACILITY', 'WET_TEST_SUPPORT')
            and o.get('scope') != 'FIXTURE' and not o['pn'].startswith('BUY53')
            and o.get('physical_class') != 'LOCAL_RECEIVER_CANDIDATE')

def hardware(pn):
    return pn.startswith(('H14', 'HW', 'STD'))

def overlap(a, b, tolerance=0):
    return all(min(a[i+3], b[i+3]) - max(a[i], b[i]) > tolerance for i in range(3))

def load():
    archive = ROOT / 'inputs/C04_R21_BASELINES.zip'
    manifest = json.loads((ROOT / 'inputs/BASELINE_MANIFEST.json').read_text(encoding='utf-8'))
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == manifest['archive_sha256']
    with zipfile.ZipFile(archive) as z:
        for item in manifest['files']:
            data = z.read(item['member'])
            assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256'], item['member']
        definitions = json.loads(z.read('R21/native/R20_PARTS.json'))
        all_occ = {tag: json.loads(z.read(f'R21/native/R20_{tag}_OCCURRENCES.json')) for tag in 'PR'}
    definitions = {p['pn']: p for p in definitions}
    cache = ROOT / '.work/native_cache'
    cache.mkdir(parents=True,exist_ok=True)
    key=hashlib.sha256((manifest['archive_sha256']+Path(__file__).read_text(encoding='utf-8')).encode()).hexdigest()
    marker=cache/'index.json'
    if marker.exists():
        saved=json.loads(marker.read_text(encoding='utf-8'))
        if saved.get('key')==key and all(hashlib.sha256((cache/f'{tag}.brep').read_bytes()).hexdigest()==saved[tag]['sha256'] for tag in 'PR'):
            products={}
            for tag in 'PR':
                ss=cq.Shape.importBrep(str(cache/f'{tag}.brep')).Solids()
                rr=saved[tag]['rows'];assert len(ss)==len(rr)
                products[tag]=[dict(o=r['o'],bounds=r['bounds'],shape=s,attachment_parent=r.get('attachment_parent')) for r,s in zip(rr,ss)]
            (ROOT/'evidence/R21_COMPONENT_SCOPE.json').write_text(json.dumps(saved['scope'],indent=2),encoding='utf-8')
            print('Exact-hash native cache loaded.',flush=True)
            return definitions,products
    wanted = {o['pn'] for oo in all_occ.values() for o in oo if include(o)}
    shapes = {pn: read_brep(definitions[pn]['brep']) for pn in sorted(wanted)}
    assert all(s.isValid() for s in shapes.values())
    products = {}
    scope = []
    for tag, oo in all_occ.items():
        selected, candidates = [], []
        for o in oo:
            if include(o):
                s = transform(shapes[o['pn']], np.array([o['u'], o['v'], o['n']]).T, o['o'])
                row = dict(o=o, shape=s, bounds=bb(s))
                (candidates if hardware(o['pn']) else selected).append(row)
            else:
                scope.append(dict(config=tag, occurrence=o['occurrence'], pn=o['pn'], retained=False,
                                  reason='SOURCE_FACILITY_INSTRUMENT_OR_REPLACED_RECEIVER'))
        # R21 tags test-rig screws as PURCHASED_COMPLETE too. Infer attachment by
        # geometry, rather than copying those unassigned screws into the machine.
        # Four passes admit washer/nut stacks. This is an integration scope rule,
        # NOT a replacement for the issued manufacturing allocation/BOM.
        for iteration in range(4):
            linked, remaining = [], []
            for row in candidates:
                near = [p for p in selected if overlap(row['bounds'], p['bounds'], -1.01)]
                parent = next((p for p in near if row['shape'].distance(p['shape']) <= 1.0), None)
                if parent:
                    row['attachment_parent'] = parent['o']['occurrence']
                    linked.append(row)
                else:
                    remaining.append(row)
            selected += linked
            candidates = remaining
            if not linked:
                break
        for row in selected:
            scope.append(dict(config=tag, occurrence=row['o']['occurrence'], pn=row['o']['pn'], retained=True,
                              reason='GEOMETRICALLY_ATTACHED_HARDWARE' if hardware(row['o']['pn']) else 'SOURCE_PRODUCT_OR_FUNCTIONAL_PURCHASE',
                              attachment_parent=row.get('attachment_parent')))
        for row in candidates:
            scope.append(dict(config=tag, occurrence=row['o']['occurrence'], pn=row['o']['pn'], retained=False,
                              reason='UNASSIGNED_HARDWARE_NO_PRODUCT_CONTACT_WITHIN_1MM_FOUR_PASSES'))
        products[tag] = selected
        print(tag, 'integration occurrences', len(selected), 'unassigned hardware', len(candidates), flush=True)
    (ROOT / 'evidence').mkdir(exist_ok=True)
    scope_data=dict(
        authority='GEOMETRIC_INTEGRATION_SCOPE_ONLY_NOT_FACTORY_BOM', hardware_link_distance_mm=1.0,
        link_passes=4, rows=scope)
    (ROOT / 'evidence/R21_COMPONENT_SCOPE.json').write_text(json.dumps(scope_data,indent=2),encoding='utf-8')
    saved=dict(key=key,scope=scope_data)
    for tag,rows in products.items():
        path=cache/f'{tag}.brep';cq.Compound.makeCompound([r['shape'] for r in rows]).exportBrep(str(path))
        saved[tag]=dict(sha256=hashlib.sha256(path.read_bytes()).hexdigest(),rows=[{k:v for k,v in r.items() if k!='shape'} for r in rows])
    marker.write_text(json.dumps(saved),encoding='utf-8')
    return definitions, products

if __name__ == '__main__':
    definitions, products = load()
    report = {}
    for tag, rows in products.items():
        env = [bb(r['shape']) for r in rows]
        report[tag] = dict(occurrences=len(rows), solids=sum(len(r['shape'].Solids()) for r in rows),
                           bounds=[min(b[i] for b in env) for i in range(3)] + [max(b[i] for b in env) for i in range(3,6)],
                           classes=dict(collections.Counter(r['o'].get('physical_class') for r in rows)),
                           moving=[dict(pn=r['o']['pn'], occurrence=r['o']['occurrence'], moving=r['o']['moving'], bounds=bb(r['shape']))
                                   for r in rows if r['o'].get('moving')],
                           fasteners=[dict(pn=pn, name=definitions[pn]['name']) for pn in sorted({r['o']['pn'] for r in rows})
                                      if pn.startswith(('HW','STD','H14'))])
    (ROOT / '.work').mkdir(exist_ok=True)
    (ROOT / '.work/product_probe.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps({tag: {k:v for k,v in d.items() if k not in ('moving','fasteners')} for tag,d in report.items()}, indent=2))
