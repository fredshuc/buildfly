"""Optional local dependency discovery; CAD data never depends on these paths."""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parents[1]
for directory in os.environ.get('CADQUERY_LIBDIRS', '').split(os.pathsep):
    if directory:
        sys.path.insert(0, directory)
try:
    import cadquery
except ModuleNotFoundError:
    for directory in (WORKSPACE / 'R5_WORK/early_vendor', WORKSPACE / 'R5_WORK/runtime_ready'):
        if directory.is_dir():
            sys.path.append(str(directory))
os.environ.setdefault('MPLBACKEND', 'Agg')
