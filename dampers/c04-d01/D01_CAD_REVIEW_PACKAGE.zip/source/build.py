"""D01: actual R21 damper integration, opposite-hand candidate and interface checks.

No historical installed BRep is edited. No CFD, FE, loaded motion or manufacture
release is implied. R21 internal clearances/film/capture holds remain in force.
"""
import bootstrap
from bootstrap import ROOT
from native import bb, box, transform, read_brep, overlap, load
import csv
import hashlib
import io
import itertools
import json
import math
import sys
import time
import zipfile
import cadquery as cq
import numpy as np
import step_export

CFG = json.loads((ROOT / 'design.json').read_text(encoding='utf-8'))
OUT = ROOT
for directory in ('cad', 'native', 'tables', 'evidence', 'drawings', '.work'):
    (OUT / directory).mkdir(exist_ok=True)

def dump(path, obj):
    (OUT / path).write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding='utf-8')

def table(name, rows):
    if rows:
        with (OUT / 'tables' / name).open('w', newline='', encoding='utf-8-sig') as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)

def envelope(bounds):
    return [min(b[i] for b in bounds) for i in range(3)] + [max(b[i] for b in bounds) for i in range(3, 6)]

def move_bounds(b, m, t):
    points = [np.array(m) @ np.array(v) + np.array(t)
              for v in itertools.product(*[(b[i], b[i+3]) for i in range(3)])]
    return [min(p[i] for p in points) for i in range(3)] + [max(p[i] for p in points) for i in range(3)]

def swept_test_bounds(row):
    """Conservative analytic 360-degree enclosure, not sampled-angle proof.

    Every point lies in its original XZ AABB about the recorded shaft. The
    largest AABB-corner radius therefore encloses every intermediate angle.
    BUY504 gearing and BK2/7206/limiter proxies are rotationally bounded too,
    even though R21 does not consistently mark those dry proxies as moving.
    """
    o, b = row['o'], row['bounds']
    rotating = o.get('moving') or o['pn'] in ('BUY504', 'BUY_R13_BK2', 'BUY_R13_7206', 'BUY520', 'BUY521')
    if not rotating:
        return b
    axis_x = {'P1': 83., 'P2': -82., 'R1': -82.}.get(o.get('moving'))
    if axis_x is None:
        axis_x = 83. if abs((b[0]+b[3])/2-83.) < abs((b[0]+b[3])/2+82.) else -82.
    radius = math.hypot(max(abs(b[0]-axis_x), abs(b[3]-axis_x)), max(abs(b[2]-1583), abs(b[5]-1583)))
    return [axis_x-radius, b[1], 1583-radius, axis_x+radius, b[4], 1583+radius]

def flange_holes(height):
    nx, ny = math.ceil(668/70), math.ceil((height+38)/70)
    rows = [(y, z) for y in np.linspace(-334, 334, nx+1) for z in (19., height+57.)]
    rows += [(y, 19.+(height+38)*i/ny) for y in (-334., 334.) for i in range(1, ny)]
    return rows

def remove_outer_hardware(tag, row):
    pn, b = row['o']['pn'], row['bounds']
    if pn.startswith('STD01'):
        return True
    if not pn.startswith(('H14','HW','STD')):
        return False
    # Only outer-flange stacks; gland and middle-seam M8 pieces are retained.
    top = 211. if tag == 'P' else 46.
    x, y, z = ((b[i]+b[i+3])/2 for i in range(3))
    return ((z < 1520 or z > 1650) and
            any(math.hypot(x-(top-hz), y-(-408+hy)) < .6
                for hy, hz in flange_holes(CFG['ports'][tag][1])))

def original_host():
    target = OUT / '.work/C04'
    target.mkdir(exist_ok=True)
    with zipfile.ZipFile(OUT / 'inputs/C04_R21_BASELINES.zip') as z:
        for member in z.namelist():
            if member.startswith(('C04/', 'C02/')):
                p = OUT / '.work' / member
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_bytes(z.read(member))
    sys.path.insert(0, str(target))
    code = (target / 'build_c04.py').read_text(encoding='utf-8').split('errors=check(installed)')[0]
    saved = list(sys.argv)
    sys.argv = [str(target / 'build_c04.py'), str(OUT / '.work/C02/native')]
    ns = dict(__file__=str(target / 'build_c04.py'), __name__='C04_REFERENCE_ONLY')
    exec(compile(code, str(target / 'build_c04.py'), 'exec'), ns)
    sys.argv = saved
    return ns

def product_placement(tag, bed, face, pitch):
    cy = CFG['bed_A_Y'] + (pitch if bed == 'B' else 0)
    # C04 uses outside = OUTER+2, not OUTER. Derive rather than duplicate a
    # reservation datum: FOOT=28+32/2+80*.32; OUTER=FOOT+320.
    outside = 28+32/2+80*.32+320+2
    flange = 265-outside-2.5 if face == 'F' else 485+outside+2.5
    offset = CFG['adapter_offset_including_host_gasket']
    x_low = flange-182-offset if face == 'F' else flange+2+offset
    z_base = CFG['ports'][tag][0]-38
    top = 211. if tag == 'P' else 46.
    m = np.array([[0.,0.,1.],[0.,1.,0.],[-1.,0.,0.]])
    t = np.array([x_low-1493, cy+408, z_base+top])
    return dict(cy=cy, flange=flange, x_low=x_low, z_base=z_base, m=m, t=t)

def place_shape(s, placement, bed):
    s = transform(s, placement['m'], placement['t'])
    return s.mirror('XZ', (0, placement['cy'], 0)) if bed == 'B' else s

def place_bound(bounds, placement, bed):
    b = move_bounds(bounds, placement['m'], placement['t'])
    if bed == 'B':
        b[1], b[4] = 2*placement['cy']-b[4], 2*placement['cy']-b[1]
    return b

def rect_cut(panel_shape, panel_bb, projected, axis, margin):
    b = list(projected)
    for k in range(3):
        if k == axis:
            b[k], b[k+3] = panel_bb[k]-1, panel_bb[k+3]+1
        else:
            b[k] -= margin
            b[k+3] += margin
    if overlap(b, panel_bb, 1e-7):
        return box(b), b
    return None, None

def make_hardware(placement, face, height, tag, valve_id):
    sign = -1 if face == 'F' else 1
    interface, solids, tools = [], [], []
    for number, (hy, hz) in enumerate(flange_holes(height), 1):
        y, z = placement['cy']+hy, placement['z_base']+hz
        x, length = placement['flange'], CFG['stud_free_length']
        axis = cq.Vector(sign, 0, 0)
        stud = cq.Solid.makeCylinder(4, length, cq.Vector(x,y,z), axis)
        stack = CFG['adapter_offset_including_host_gasket']+5
        washer = cq.Solid.makeCylinder(8, 1.6, cq.Vector(x+sign*stack,y,z), axis).cut(
            cq.Solid.makeCylinder(4.2, 1.6, cq.Vector(x+sign*stack,y,z), axis))
        # A clearance bore represents the threaded joint without fictitious
        # hard interference between major-thread envelopes.
        nut = cq.Workplane('YZ', origin=(x+sign*(stack+1.6),y,z)).polygon(6, 13/math.cos(math.pi/6)).extrude(sign*6.5).val()
        nut = nut.cut(cq.Solid.makeCylinder(4.2, 6.5, cq.Vector(x+sign*(stack+1.6),y,z), axis))
        local_stud=cq.Solid.makeCylinder(4,length,cq.Vector(0,0,0),cq.Vector(1,0,0))
        local_washer=cq.Solid.makeCylinder(8,1.6,cq.Vector(0,0,0),cq.Vector(1,0,0)).cut(cq.Solid.makeCylinder(4.2,1.6,cq.Vector(0,0,0),cq.Vector(1,0,0)))
        local_nut=cq.Workplane('YZ').polygon(6,13/math.cos(math.pi/6)).extrude(6.5).val().cut(cq.Solid.makeCylinder(4.2,6.5,cq.Vector(0,0,0),cq.Vector(1,0,0)))
        for suffix,shape,local,u in (('STUD',stud,local_stud,0),('WASHER',washer,local_washer,stack),('NUT',nut,local_nut,stack+1.6)):
            solids.append(dict(name=f'{valve_id}_M8_{number:02d}_{suffix}',shape=shape,kind='NEW_INTERFACE_HARDWARE',
                               export_key='D01_M8_'+suffix,export_shape=local,export_R=np.diag([sign,1,sign]),
                               export_t=np.array([x+sign*u,y,z])))
        # Compact socket comes radially from outside the flange, rather than
        # travelling axially through the gland/rotor. The enclosure also includes
        # a 22-diameter ratchet head and a 100 mm handle parallel to the edge.
        u0=length+.1; u1=u0+CFG['flange_socket_length']
        stub=cq.Solid.makeCylinder(CFG['flange_socket_OD']/2,CFG['flange_socket_length'],cq.Vector(x+sign*u0,y,z),axis)
        head=cq.Solid.makeCylinder(CFG['ratchet_head_OD']/2,10,cq.Vector(x+sign*u1,y,z),axis)
        horizontal=abs(hz-19)<.01 or abs(hz-height-57)<.01
        handle_b=[min(x+sign*(u1+2),x+sign*(u1+8)),y-6,z-6,
                  max(x+sign*(u1+2),x+sign*(u1+8)),y+6,z+6]
        handle_b[4 if horizontal else 5]+=100
        handle=box(handle_b)
        b=bb(stub);travel=CFG['flange_socket_radial_insertion']
        # Top/bottom rows come from beyond the edge; side-row sockets travel
        # parallel to that edge towards the bolt, staying inboard of A709.
        # An outboard-Y approach would pass through the feedback structure.
        k=2
        direction=(-1 if hz<height/2+38 else 1) if horizontal else (1 if hz<=height/2+38 else -1)
        off=[0.,0.,0.];off[k]=direction*travel
        end=stub.translate(off)
        middle=bb(stub)
        middle[k],middle[k+3]=min((y if k==1 else z),(y if k==1 else z)+off[k]),max((y if k==1 else z),(y if k==1 else z)+off[k])
        insertion=stub.fuse(end,box(middle)).clean()
        tool=cq.Compound.makeCompound([insertion,head,handle])
        tools.append(dict(name=f'{valve_id}_SOCKET_{number:02d}', shape=tool,bounds=bb(tool),
                          method='20x25 socket, 22x10 ratchet head, 100 mm edge-parallel handle; exact capsule for radial 50 mm insertion'))
        interface.append(dict(id=f'{valve_id}.{number:02d}', x=x, y=y, z=z, normal_X=sign,
                              hole_diameter=9., stud=f'M8 x {length:g} FREE AFTER WELD', washer=1.6, nut=6.5,
                              seal_installed_each=2., adapter_metal=CFG['adapter_metal_depth'], flange=3.,
                              attachment='WELD_TO_C04_2.5MM_FLANGE_COUPON_AND_FLATNESS_HOLD'))
    return solids, tools, interface

def bounded_pair(a, b):
    if not overlap(envelope([u['sweep'] for u in a]),envelope([v['sweep'] for v in b]),1e-5):return []
    hits = [(u['o']['pn'], v['o']['pn']) for u in a for v in b if overlap(u['sweep'], v['sweep'], 1e-5)]
    return hits

def main():
    start = time.time()
    print('Loading immutable R21 definitions and integration scope...', flush=True)
    definitions, source_products = load()
    replaced = []
    retired_interfaces=[]
    products = {}
    for tag, rows in source_products.items():
        products[tag] = []
        for row in rows:
            if row['o']['pn'] in ('R112','R113'):
                retired_interfaces.append(dict(config=tag,occurrence=row['o']['occurrence'],pn=row['o']['pn'],
                    reason='REPLACE_C02_R100S_20MM_MACHINE_EXTENSION_WITH_D01_SEALED_ADAPTER_NOT_A_ROTOR_CHANGE',
                    stock_disposition='Retain prior C02 definition/issued stock; no cancellation or scrapping instruction.'))
                continue
            if remove_outer_hardware(tag, row):
                replaced.append(dict(config=tag, occurrence=row['o']['occurrence'], pn=row['o']['pn'],
                                     reason='REPLACE_OUTER_FLANGE_BOLT_STACK_WITH_ACCESSIBLE_M8_WELD_STUD'))
            else:
                products[tag].append(row)
    dump('evidence/OUTER_FLANGE_HARDWARE_REPLACEMENTS.json', replaced)
    dump('evidence/D01_RETIRED_MACHINE_INTERFACES.json',retired_interfaces)
    # R21 R has one external gasket only. Both installed interfaces are defined
    # here using the same unmodified compressed R106 pattern.
    low_r = next(r for r in products['R'] if r['o']['pn'] == 'R106')
    extra_o=dict(low_r['o']);extra_o.update(pn='D01_R106_SECOND_FACE', occurrence='D01_R106_SECOND_FACE',source_pn='R106')
    extra_o['o']=(np.array(extra_o['o'])+np.array([0,0,182])).tolist()
    extra = dict(o=extra_o,
                 shape=low_r['shape'].translate((0,0,182)))
    extra['bounds'] = bb(extra['shape'])
    products['R'].append(extra)

    pitch = CFG['candidate_bed_pitch']
    placed, placements, tools, hardware, bolt_table = {}, [], [], [], []
    for bed, face, tag in itertools.product('AB', 'FR', 'PR'):
        ident = bed+face+tag
        p = product_placement(tag, bed, face, pitch)
        rows = []
        for row in products[tag]:
            rows.append(dict(o=row['o'], shape=place_shape(row['shape'],p,bed),
                             bounds=place_bound(row['bounds'],p,bed),
                             sweep=place_bound(swept_test_bounds(row),p,bed)))
        placed[ident] = rows
        pl = dict(id=ident, bed=bed, face=face, type=tag, centre_Y=p['cy'], flange_X=p['flange'],
                  flange_z_min=p['z_base'], body_face_to_face=180., handedness='D01_MH_NEW_HAND' if bed=='B' else 'R21_REFERENCE_HAND',
                  test_to_install_R=p['m'].tolist(), test_to_install_t=p['t'].tolist(),
                  mirror_plane_Y=p['cy'] if bed=='B' else None, gravity=CFG['gravity'], flow=CFG['flow_directions'][tag],
                  bounds=envelope([r['bounds'] for r in rows]), sweep_bounds=envelope([r['sweep'] for r in rows]))
        placements.append(pl)
        hh, tt, bt = make_hardware(p,face,CFG['ports'][tag][1],tag,ident)
        hardware += hh
        tools += tt
        bolt_table += bt
    dump('native/D01_PLACEMENTS.json', placements)
    table('D01_PORTS_AND_HANDS.csv', [{k:json.dumps(v) if isinstance(v,(list,dict)) else v for k,v in r.items()} for r in placements])
    table('D01_M8_STUD_COORDINATES.csv', bolt_table)
    print('Eight actual damper placements prepared.', flush=True)

    # The previous 840-pitch candidate is explicitly tested using the same
    # complete integration scope, including protruding cover screws.
    original_pairs, candidate_pairs = [], []
    for face, tag in itertools.product('FR', 'PR'):
        a, b = placed['A'+face+tag], placed['B'+face+tag]
        candidate_pairs.append(dict(pair='A'+face+tag+':B'+face+tag, conservative_overlap_pairs=len(bounded_pair(a,b))))
        pb = product_placement(tag,'B',face,CFG['original_bed_pitch'])
        old_b = [dict(o=r['o'], shape=place_shape(r['shape'],pb,'B'),bounds=place_bound(r['bounds'],pb,'B'),sweep=place_bound(swept_test_bounds(r),pb,'B')) for r in products[tag]]
        old_envelope=envelope([r['bounds'] for r in old_b])
        hits=[]
        for aa in a:
            if not overlap(aa['bounds'],old_envelope,1e-5):continue
            for br in old_b:
                if overlap(aa['bounds'],br['bounds'],1e-5):
                    v=aa['shape'].intersect(br['shape']).Volume()
                    if v>.001:
                        hits.append(dict(a=aa['o']['occurrence'], b=br['o']['occurrence'], volume_mm3=v))
                        if len(hits)>=8: break
            if len(hits)>=8: break
        original_pairs.append(dict(pair='A'+face+tag+':B'+face+tag, first_eight_actual_clashes=hits))
    # Test every cross-valve combination, including P/R and front/rear.
    inter_valve=[]
    for a,b in itertools.combinations(placed,2):
        hits=bounded_pair(placed[a],placed[b])
        if hits: inter_valve.append(dict(a=a,b=b,overlap_count=len(hits),examples=hits[:8]))
    dump('evidence/D01_DAMPER_SEPARATION.json',dict(original_pitch=CFG['original_bed_pitch'],
         candidate_pitch=pitch, original_first_clashes=original_pairs, candidate_same_level_pairs=candidate_pairs,
         all_28_valve_pairs_with_conservative_overlap=inter_valve,
         method='Analytic full-rotation AABB enclosure; no overlap proves continuous external clearance. Does not test inherited internal interference.'))
    assert all(x['first_eight_actual_clashes'] for x in original_pairs), 'Expected original D1 must reproduce'
    assert not inter_valve, inter_valve
    print('Original 840 mm interference reproduced; candidate continuous inter-valve separation passes.',flush=True)

    ns=original_host()
    old=ns['installed']
    delta=pitch-CFG['original_bed_pitch']
    host={}
    for name,(s,c) in old.items():
        if 'RESERVE_' in name or 'DRIVE_RESERVE' in name:
            continue
        if name in ('FRONT_SKIN','BACK_SKIN','ROOF','FLOOR') or name.startswith('BASE_Y_CROSS_'):
            continue
        if name.startswith('B') or name=='SIDE_850.0' or name=='SIDE_850' or name=='BASE_SILL_800' or name=='ROOF_RAIL_820' or name.endswith(', 800)'):
            s=s.translate((0,delta,0))
        # Source side skins are replaced below, regardless of string formatting.
        if name.startswith('SIDE_'): continue
        host[name]=(s,c)
    left,right=-852.,852.+delta
    front,rear=ns['front'],1312.
    centres=[CFG['bed_A_Y'],CFG['bed_A_Y']+pitch]
    for label,x in (('FRONT_SKIN',front-2),('BACK_SKIN',rear-2)):
        s=ns['box'](x,left,104,2,right-left,2446)
        for cy in centres:
            if label=='FRONT_SKIN':
                s=s.cut(ns['box'](x-1,cy-360,142,5,720,984))
            else:
                for z,h in CFG['ports'].values(): s=s.cut(ns['box'](x-1,cy-315,z,5,630,h))
        host[label]=(s,'shell')
    for y in (left,right-2):
        host['D01_SIDE_'+str(y)]=(ns['box'](front,y,104,rear-2-front,2,2446),'shell')
    host['ROOF']=(ns['box'](front-2,left,2550,rear-front+2,right-left,2),'shell')
    host['FLOOR']=(ns['box'](front-2,left,102,rear-front+2,right-left,2),'shell')
    for x in (275,435): host['BASE_Y_CROSS_'+str(x)]=(ns['rhs'](x,-800,52,40,1600+delta,50,1),'shell')
    # Both native outer gaskets plus the specified adapter offset are included;
    # the original reservation had neither. Shorten all four rear sleeves.
    for bed,cy in zip('AB',centres):
        for tag,(z,h) in CFG['ports'].items():
            x=product_placement(tag,bed,'R',pitch)['x_low']+182
            sleeve=ns['box'](x,cy-316.5,z-1.5,rear-2-x,633,h+3).cut(ns['box'](x-1,cy-315,z,rear-x+2,630,h))
            host[bed+tag+'_DISCHARGE_SLEEVE']=(sleeve,'shell')

    adapters=[];adapter_pockets=[]
    for vid,rows in placed.items():
        bed,face,tag=vid
        p=product_placement(tag,bed,face,pitch);sign=-1 if face=='F' else 1
        x=p['flange'];cy=p['cy'];z=p['z_base'];h=CFG['ports'][tag][1]
        def ring(u,depth,hole_d):
            lo=min(x+sign*u,x+sign*(u+depth));s=ns['box'](lo,cy-353,z,depth,706,h+76)
            s=s.cut(ns['box'](lo-1,cy-315,z+38,depth+2,630,h))
            holes=[cq.Solid.makeCylinder(hole_d/2,depth+2,cq.Vector(lo-1,cy+hy,z+hz),cq.Vector(1,0,0)) for hy,hz in flange_holes(h)]
            return s.cut(*holes)
        frame=ring(2,CFG['adapter_metal_depth'],9)
        fb=bb(frame);pockets=[]
        for row in rows:
            pn=row['o']['pn']
            if not pn.startswith(('G84','G836','HW_FB','HW_R8_HOOD')):continue
            if not overlap(fb,row['bounds'],1e-5):continue
            intersection=frame.intersect(row['shape'])
            if intersection.Volume()<=.001:continue
            # G843 has a base before one end flange and uprights outside the
            # other. Its whole-part AABB is not the occupied section. Pocket
            # only the actual intersection. The deferred receiver is retained
            # as geometry and receives no load-path qualification here.
            rb=bb(intersection);margin=.5 if pn=='G843' else CFG['adapter_pocket_margin']
            rb=[v-margin if i<3 else v+margin for i,v in enumerate(rb)]
            pockets.append(box(rb))
            adapter_pockets.append(dict(valve=vid,source_part=row['o']['occurrence'],bounds=rb,
                                        pocket_margin=margin,airway_side_wall_minimum_mm=min(abs(rb[1]-cy),abs(rb[4]-cy))-315))
        if pockets:frame=frame.cut(*pockets)
        assert frame.isValid() and len(frame.Solids())==1,vid
        # Keep the original perforated 20 mm seal band intact at both faces.
        # Bolt/stop holes are inherited; this is no assertion that the original
        # gasket has a solid uninterrupted 20 mm land at its bolt holes.
        for u in (2,CFG['adapter_offset_including_host_gasket']-1):
            face_band=ring(u,1,9).intersect(ns['box'](min(x+sign*u,x+sign*(u+1))-1,cy-335,z+18,3,670,h+40))
            missing=face_band.cut(frame).Volume()
            assert missing<.001,(vid,u,'seal-face material removed',missing)
        assert all(r['airway_side_wall_minimum_mm']>=1.99 for r in adapter_pockets if r['valve']==vid),(vid,'thin airway wall')
        adapters.append(dict(name=vid+'_D01_ADAPTER_'+str(int(CFG['adapter_metal_depth'])),shape=frame,kind='NEW_INTERFACE_ADAPTER'))
        frame.exportBrep(str(OUT/'native'/(vid+'_D01_ADAPTER.brep')))
        gasket=ring(0,2,16.2)
        adapters.append(dict(name=vid+'_D01_HOST_GASKET_INSTALLED_2',shape=gasket,kind='NEW_COMPRESSED_GASKET'))
        for j,(hy,hz) in enumerate(flange_holes(h),1):
            origin=cq.Vector(x,cy+hy,z+hz);axis=cq.Vector(sign,0,0)
            limiter=cq.Solid.makeCylinder(8,2,origin,axis).cut(cq.Solid.makeCylinder(4.2,2,origin,axis))
            local_limiter=cq.Solid.makeCylinder(8,2,cq.Vector(0,0,0),cq.Vector(1,0,0)).cut(cq.Solid.makeCylinder(4.2,2,cq.Vector(0,0,0),cq.Vector(1,0,0)))
            adapters.append(dict(name=f'{vid}_D01_GASKET_STOP_{j:02d}',shape=limiter,kind='NEW_INTERFACE_LIMITER',
                                 export_key='D01_HOST_GASKET_STOP',export_shape=local_limiter,export_R=np.diag([sign,1,sign]),
                                 export_t=np.array([x,cy+hy,z+hz])))
    dump('native/D01_ADAPTER_POCKETS.json',adapter_pockets)
    hardware+=adapters

    # Side/back penetrations are generated from component sweeps and nut-tool
    # spaces, never from the former 160x170x220 placeholder.
    cuts=[]
    for name,(skin,c) in list(host.items()):
        if not ('SKIN' in name or name.startswith('D01_SIDE_')): continue
        axis=1 if name.startswith('D01_SIDE_') else 0
        pb=bb(skin)
        projected=[(vid, r['sweep']) for vid,rr in placed.items() for r in rr]
        projected += [(t['name'],t['bounds']) for t in tools]
        boxes=[]
        for owner,b in projected:
            if not overlap(pb,b,-1e-7): continue
            cut,cb=rect_cut(skin,pb,b,axis,CFG['panel_opening_margin'])
            if cut:
                boxes.append(cut)
                cuts.append(dict(panel=name,owner=owner,axis=axis,bounds=cb,margin=CFG['panel_opening_margin']))
        if boxes: skin=skin.cut(*boxes)
        assert skin.isValid(),name
        host[name]=(skin,c)
    dump('native/D01_PANEL_CUTOUTS.json',cuts)
    table('D01_PANEL_CUTOUTS.csv',[dict(panel=r['panel'],owner=r['owner'],axis=r['axis'],bounds=json.dumps(r['bounds']),margin=r['margin']) for r in cuts])
    print('Reference host widened for interface study; real drive cut-outs created.',flush=True)
    host_bounds={n:bb(s) for n,(s,c) in host.items()}
    product_bounds={n:envelope([r['bounds'] for r in rr]) for n,rr in placed.items()}

    # Existing C04 reservations for HX/water are references, so excluded only
    # when labelled RESERVE above; the remaining host geometry participates.
    static_hits=[]
    sweep_hits=[]
    for vid,rows in placed.items():
        for hn,(hs,hc) in host.items():
            hb=host_bounds[hn]
            for row in rows:
                if overlap(hb,row['bounds'],1e-5):
                    volume=hs.intersect(row['shape']).Volume()
                    if volume>.001: static_hits.append(dict(valve=vid,host=hn,part=row['o']['occurrence'],volume_mm3=volume))
                if overlap(hb,row['sweep'],1e-5):
                    volume=hs.intersect(box(row['sweep'])).Volume()
                    if volume>.001: sweep_hits.append(dict(valve=vid,host=hn,part=row['o']['occurrence'],enclosure_overlap_mm3=volume))
        print('Host static and continuous enclosure checked:',vid,flush=True)
    # New interfaces participate in the check too. Threaded engagement is
    # represented by clearance bores; it is not a hard-clash exemption.
    new_hardware_hits=[]
    for item in hardware:
        ib=bb(item['shape']);own=item['name'][:3]
        for hn,(hs,hc) in host.items():
            if overlap(ib,host_bounds[hn],1e-5) and item['shape'].intersect(hs).Volume()>.001:
                new_hardware_hits.append(dict(item=item['name'],obstruction=hn))
        for vid,rr in placed.items():
            if not overlap(ib,product_bounds[vid],1e-5):continue
            for r in rr:
                if overlap(ib,r['bounds'],1e-5) and item['shape'].intersect(r['shape']).Volume()>.001:
                    new_hardware_hits.append(dict(item=item['name'],obstruction=vid+':'+r['o']['occurrence']))
    print('New adapter/stud/gasket interfaces checked.',flush=True)
    # Tool access is an installation clearance check, one socket at a time.
    tool_hits=[]
    for tool in tools:
        for hn,(hs,hc) in host.items():
            if overlap(tool['bounds'],host_bounds[hn],1e-5) and hs.intersect(tool['shape']).Volume()>.001:
                tool_hits.append(dict(tool=tool['name'],obstruction=hn))
        own=tool['name'][:3]
        for vid,rows in placed.items():
            if not overlap(tool['bounds'],product_bounds[vid],1e-5):continue
            for row in rows:
                if overlap(tool['bounds'],row['bounds'],1e-5) and row['shape'].intersect(tool['shape']).Volume()>.001:
                    tool_hits.append(dict(tool=tool['name'],obstruction=vid+':'+row['o']['occurrence']))

    feedback=[]
    feedback_hits=[]
    for vid,rows in placed.items():
        cover=[r for r in rows if r['o']['pn'].startswith('G833')]
        assert len(cover)==1,vid
        b=cover[0]['bounds']; pull=CFG['feedback_cover_withdrawal']; sign=1 if vid[0]=='A' else -1
        swept=list(b);swept[1 if sign<0 else 4]+=sign*pull
        feedback.append(dict(id=vid,bounds=swept,pull_Y=sign*pull))
        for other,rr in placed.items():
            if other==vid: continue
            for r in rr:
                if overlap(swept,r['sweep'],1e-5): feedback_hits.append(dict(cover=vid,other=other,part=r['o']['occurrence']))
    dump('native/D01_FEEDBACK_SERVICE.json',feedback)

    # Explicit future actuator selection volume: not a selected OEM actuator.
    actuators=[]
    for p in placements:
        rows=placed[p['id']]
        limiters=[r for r in rows if r['o']['pn']=='BUY521']
        b=envelope([r['bounds'] for r in limiters]);size=CFG['actuator_placeholder_size_XYZ']; centre=[(b[i]+b[i+3])/2 for i in range(3)]
        if p['bed']=='A': a=[centre[0]-size[0]/2,b[1]-size[1],centre[2]-size[2]/2,centre[0]+size[0]/2,b[1],centre[2]+size[2]/2]
        else: a=[centre[0]-size[0]/2,b[4],centre[2]-size[2]/2,centre[0]+size[0]/2,b[4]+size[1],centre[2]+size[2]/2]
        actuators.append(dict(id=p['id'],bounds=a,status='SELECTION_RESERVE_NOT_PURCHASED_OR_QUALIFIED'))
    dump('native/D01_ACTUATOR_RESERVES.json',actuators)
    reserve_hits=[]
    for a in actuators:
        for hn,(hs,hc) in host.items():
            if overlap(a['bounds'],host_bounds[hn],1e-5) and hs.intersect(box(a['bounds'])).Volume()>.001:
                reserve_hits.append(dict(reserve=a['id'],obstruction=hn))
        for vid,rr in placed.items():
            if vid==a['id']: continue
            for r in rr:
                if overlap(a['bounds'],r['sweep'],1e-5):reserve_hits.append(dict(reserve=a['id'],obstruction=vid+':'+r['o']['occurrence']))
    mirror=[dict(source_pn=pn,candidate_pn='D01_MH_'+pn,kind=definitions[pn]['kind'],material=definitions[pn]['material'],
                 rule='REFLECT_LOCAL_X_THEN_USE_PROPER_PLACEMENT_ROTATION',
                 qualification='NEW_MAKE_HAND_DRAWING_OR_OEM_MOUNTING_CONFIRMATION_REQUIRED')
            for pn in sorted({r['o']['pn'] for rr in products.values() for r in rr if r['o']['pn'] in definitions})]
    table('D01_MIRROR_DISPOSITION.csv',mirror)
    dump('native/D01_HAND_DEFINITION.json',dict(
        reflection=[[1,0,0],[0,-1,0],[0,0,1]],
        description='A true derived mirror geometry, not a 180-degree rigid rotation. Gravity and pressure direction equal between beds.',
        manufacture='Candidate derived hand only; source R21 manufacturing pages do not release these mirrored definitions.',
        rotation_rule='M_global * R_source * M_local, with M_local=diag(-1,1,1), determinant +1; mirrored local BRep required.',
        material_volume_invariant=True))

    verification=dict(status='PASS_INTERFACE_GEOMETRY' if not(static_hits or sweep_hits or tool_hits or feedback_hits or reserve_hits or new_hardware_hits) else 'FAILED_INTERFACE_GEOMETRY',
        scope='External interfaces of the retained R21 integration scope; inherited internal interference and functional qualification not rerun.',
        threshold_mm3=.001, analytic_sweep='Every moving component enclosed through 360 degrees about its shaft; stronger than 0-90 degree external envelope.',
        original_pitch=CFG['original_bed_pitch'],candidate_pitch=pitch, static_host_clashes=static_hits,
        continuous_host_enclosure_clashes=sweep_hits, socket_clashes=tool_hits,
        feedback_withdrawal_clashes=feedback_hits, actuator_reserve_clashes=reserve_hits,
        new_interface_hardware_clashes=new_hardware_hits,
        source_occurrences={k:len(v) for k,v in source_products.items()}, installed_occurrences={k:len(v) for k,v in placed.items()},
        new_stud_count=len(bolt_table), host_solids=sum(len(s.Solids()) for s,c in host.values()),
        known_holds=['D01 opposite hand manufacturing and seal/feedback/pressure qualification', 'Actual actuator and output adapter',
                     'Independent damper/cassette support and ground load path S1','R21 inherited film/capture/drive compliance holds',
                     'C04 S2/S3/S4/S5/S6/W1-W5/A1-A3 remain outside this revision'], elapsed_seconds=time.time()-start)
    dump('evidence/D01_INTERFACE_CHECKS.json',verification)
    print('Geometry results:',verification['status'], 'static',len(static_hits),'sweep',len(sweep_hits),
          'socket',len(tool_hits),'cover',len(feedback_hits),'actuator',len(reserve_hits),flush=True)
    if verification['status'].startswith('FAILED'):
        print('No STEP release: inspect failed interfaces before exporting.',flush=True)
        sys.exit(2)
    # Export only after the candidate geometry checks pass.
    path=OUT/'cad/D01_EIGHT_DAMPERS_INSTALLED.step'
    exports=[step_export.export('D01_EIGHT_DAMPERS_INSTALLED',placed,placements,definitions,host,hardware)]
    # Also supply a bed-A article, with no mirrored parts or widened host claim.
    single_path=OUT/'cad/D01_BED_A_DAMPER_INTERFACES.step'
    exports.append(step_export.export('D01_BED_A_DAMPER_INTERFACES',placed,placements,definitions,host,hardware,single=True))
    dump('evidence/D01_SHARED_DEFINITION_EXPORT.json',exports)
    # Lightweight neutral views include physical envelopes, explicit actuator
    # reserves, and one-cover-at-a-time service enclosures as separate names.
    reserve_asm=cq.Assembly(name='D01_SERVICE_ENVELOPES_REFERENCE')
    for p in placements:reserve_asm.add(box(p['sweep_bounds']),name=p['id']+'_FULL_ROTATION_BOUND',color=cq.Color(.2,.6,.7,.2))
    for a in actuators:reserve_asm.add(box(a['bounds']),name=a['id']+'_ACTUATOR_SELECTION_RESERVE',color=cq.Color(.7,.3,.6,.2))
    for f in feedback:reserve_asm.add(box(f['bounds']),name=f['id']+'_ONE_COVER_SERVICE',color=cq.Color(.8,.65,.1,.2))
    reserve_asm.save(str(OUT/'cad/D01_SERVICE_ENVELOPES.step'))
    for name,(s,c) in host.items():
        if name.startswith('D01_SIDE_'):s.exportBrep(str(OUT/'native'/('D01_'+name+'.brep')))
    # Fresh neutral-format readback, with geometry signatures rather than
    # timestamp-dependent STEP file hashes as the comparison criterion.
    readbacks=[]
    for file,expected in ((path,sum(len(r['shape'].Solids()) for rr in placed.values() for r in rr)+sum(len(s.Solids()) for s,c in host.values())+len(hardware)),
                          (single_path,sum(len(r['shape'].Solids()) for vid,rr in placed.items() if vid[0]=='A' for r in rr)+sum(len(s.Solids()) for n,(s,c) in host.items() if n.startswith(('AF_','AR_','AF','AR','A_')))+sum(h['name'].startswith('A') for h in hardware))):
        read=cq.importers.importStep(str(file)).val()
        count=len(read.Solids())
        record=dict(file=file.name,expected_solids=expected,readback_solids=count,valid=read.isValid(),bounds=bb(read),
                    volume_mm3=read.Volume(),sha256=hashlib.sha256(file.read_bytes()).hexdigest())
        assert count==expected and record['valid'],record
        readbacks.append(record)
        print('STEP readback',file.name,count,'solids valid',flush=True)
    dump('evidence/D01_STEP_READBACK.json',readbacks)
    # Compact data for drawing production without importing thousands of solids.
    dump('evidence/D01_DRAW_DATA.json',dict(placements=placements, feedback=feedback, actuators=actuators,
         shell=[front-2,left,0,rear,right,2552],studs=bolt_table,ports=CFG['ports']))
    print('Completed in',round(time.time()-start,1),'seconds.',flush=True)
    if verification['status'].startswith('FAILED'):sys.exit(2)

if __name__=='__main__':main()
