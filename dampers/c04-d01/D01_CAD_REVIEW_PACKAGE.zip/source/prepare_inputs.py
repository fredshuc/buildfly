"""Archive the delivered, unmodified baselines. Run only when importing inputs."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parents[1]
entries = []
for name in ('R20_PARTS.json', 'R20_P_OCCURRENCES.json', 'R20_R_OCCURRENCES.json', 'R21_COORDINATE_FRAMES.json'):
    entries.append((WORKSPACE / 'R21_WORK/deliverables/native' / name, 'R21/native/' + name))
for name in ('R21_BASELINE_IMMUTABILITY.json', 'R21_RUNTIME_VERSIONS.json'):
    entries.append((WORKSPACE / 'R21_WORK/deliverables/evidence' / name, 'R21/evidence/' + name))
entries.append((WORKSPACE / 'R21_WORK/deliverables/R21_REVIEW_TEXT_EN.md', 'R21/R21_REVIEW_TEXT_EN.md'))
for name in ('build_c04.py', 'design.py', 'network.py', 'flow_checks.json', 'README.md', 'RED_TEAM_HANDOFF_EN.md'):
    entries.append((WORKSPACE / 'AirTransformerShell/revisions/C04' / name, 'C04/' + name))
for bed in 'AB':
    for valve in ('VL', 'VU'):
        for item in ('BODY', 'ACTUATOR'):
            name = f'{bed}_{valve}_{item}.brep'
            entries.append((WORKSPACE / 'AT_SHELL2_2V_C02_20261104/deliverables/native' / name, 'C02/native/' + name))

manifest = []
archive = ROOT / 'inputs/C04_R21_BASELINES.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as output:
    for path, member in entries:
        data = path.read_bytes()
        output.writestr(member, data)
        manifest.append(dict(member=member, source=str(path.relative_to(WORKSPACE)).replace('\\', '/'),
                             bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
(ROOT / 'inputs/BASELINE_MANIFEST.json').write_text(json.dumps(dict(
    archive=archive.name, archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
    source_repository='fredshuc/buildfly', review_branch='claude/jolly-hopper-mndk80',
    review_baseline_commit='cb6c2b5', files=manifest), indent=2), encoding='utf-8')
print('Archived', len(manifest), 'baseline files:', archive.stat().st_size, 'bytes')
