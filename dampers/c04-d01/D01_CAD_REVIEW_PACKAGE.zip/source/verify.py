"""Independent metadata, provenance, proper-placement and package checks."""
from pathlib import Path
import csv
import hashlib
import io
import json
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
def read(path):return json.loads((ROOT/path).read_text(encoding='utf-8'))
def digest(data):return hashlib.sha256(data).hexdigest()
def det(a):return (a[0][0]*(a[1][1]*a[2][2]-a[1][2]*a[2][1])
                  -a[0][1]*(a[1][0]*a[2][2]-a[1][2]*a[2][0])
                  +a[0][2]*(a[1][0]*a[2][1]-a[1][1]*a[2][0]))

manifest=read('inputs/BASELINE_MANIFEST.json')
archive=(ROOT/'inputs/C04_R21_BASELINES.zip').read_bytes()
assert digest(archive)==manifest['archive_sha256']
unchanged=[]
with zipfile.ZipFile(io.BytesIO(archive)) as z:
    for row in manifest['files']:
        data=z.read(row['member']);assert len(data)==row['bytes'] and digest(data)==row['sha256']
        original=ROOT.parents[1]/row['source']
        if original.is_file():
            assert digest(original.read_bytes())==row['sha256'],str(original)
            unchanged.append(row['source'])
    immutable=json.loads(z.read('R21/evidence/R21_BASELINE_IMMUTABILITY.json'))
    r21_checked=0
    for row in immutable:
        if row['file'].startswith('native/'):
            assert digest(z.read('R21/'+row['file']))==row['sha256'],row['file']
            r21_checked+=1
    assert r21_checked==3
    remote=read('inputs/C04_REMOTE_IDENTITY.json')
    for row in remote['files']:
        data=z.read('C04/'+row['file']);blob=hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()
        assert row['exact'] and blob==row['remote_git_blob_sha']==row['local_git_blob_sha']
checks=read('evidence/D01_INTERFACE_CHECKS.json')
assert checks['status']=='PASS_INTERFACE_GEOMETRY',checks['status']
for key in ('static_host_clashes','continuous_host_enclosure_clashes','socket_clashes',
            'feedback_withdrawal_clashes','actuator_reserve_clashes','new_interface_hardware_clashes'):
    assert checks[key]==[],key
motion=read('evidence/D01_NEW_INTERFACES_CONTINUOUS_MOTION.json')
assert motion['status']=='PASS_NEW_INTERFACES_CONTINUOUS_MOTION' and motion['clashes']==[]
separation=read('evidence/D01_DAMPER_SEPARATION.json')
assert len(separation['original_first_clashes'])==4
assert all(r['first_eight_actual_clashes'] for r in separation['original_first_clashes'])
assert not separation['all_28_valve_pairs_with_conservative_overlap']
for name in ('D01_EIGHT_DAMPERS_INSTALLED','D01_BED_A_DAMPER_INTERFACES'):
    rows=read('native/'+name+'_OCCURRENCES.json')
    assert len({r['occurrence'] for r in rows})==len(rows)
    assert all(abs(det(r['R'])-1)<1e-8 for r in rows),'Improper native placement: '+name
readback=read('evidence/D01_STEP_READBACK.json')
for row in readback:
    assert row['valid'] and row['readback_solids']==row['expected_solids']
    assert digest((ROOT/'cad'/row['file']).read_bytes())==row['sha256']
ports=read('native/D01_PLACEMENTS.json')
assert len(ports)==8
for tag in 'PR':
    assert len({tuple(p['gravity']) for p in ports if p['type']==tag})==1
    assert len({tuple(p['flow']) for p in ports if p['type']==tag})==1
with (ROOT/'tables/D01_M8_STUD_COORDINATES.csv').open(encoding='utf-8-sig',newline='') as f:
    studs=list(csv.DictReader(f))
assert len(studs)==240
assert all(float(r['hole_diameter'])==9 for r in studs)
cfg=read('design.json')
stack=2+cfg['adapter_metal_depth']+2+3+cfg['washer_thickness']+cfg['nut_height']
assert abs(cfg['stud_free_length']-stack-6.9)<1e-8
proof=dict(status='PASS_METADATA_AND_PROVENANCE',archive_files_checked=len(manifest['files']),
           R21_native_files_matching_source_immutability=r21_checked,C04_text_files_matching_remote_commit=len(remote['files']),
           local_original_files_unchanged=len(unchanged),all_native_placements_det_plus_one=True,
           source_step_readbacks=readback,flange_studs=240,nominal_thread_protrusion_mm=round(cfg['stud_free_length']-stack,3),
           interface_check_sha256=digest((ROOT/'evidence/D01_INTERFACE_CHECKS.json').read_bytes()),
           scope='Metadata/provenance only; CAD readback and geometric results produced by build.py. No new physical validation.')
if '--package' in sys.argv:
    with zipfile.ZipFile(ROOT/'D01_CAD_REVIEW_PACKAGE.zip') as z:
        assert z.testzip() is None
        rows=list(csv.DictReader(io.StringIO(z.read('tables/D01_DELIVERABLES.csv').decode('utf-8-sig'))))
        for row in rows:
            data=z.read(row['file']);assert len(data)==int(row['bytes']) and digest(data)==row['sha256'],row['file']
        assert not any(x.startswith(('.work/','.runtime/')) for x in z.namelist())
        print('Package CRC and',len(rows),'manifest file hashes verified.')
else:
    (ROOT/'evidence/D01_PROVENANCE_AND_METADATA_CHECK.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
print('Metadata and provenance PASS;',len(unchanged),'original local files unchanged.')
