$ErrorActionPreference = 'Stop'
$taskBundledPython = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
if (Test-Path -LiteralPath $taskBundledPython) { $taskPython = $taskBundledPython } else { $taskPython = 'python' }
& $taskPython -u -X utf8 (Join-Path $PSScriptRoot 'source\build.py')
if ($LASTEXITCODE -ne 0) { throw 'D01 geometry check or STEP validation failed. Inspect evidence/D01_INTERFACE_CHECKS.json.' }
& $taskPython -u -X utf8 (Join-Path $PSScriptRoot 'source\check_motion_interfaces.py')
if ($LASTEXITCODE -ne 0) { throw 'D01 new interfaces block a continuous motion enclosure.' }
& $taskPython -u -X utf8 (Join-Path $PSScriptRoot 'source\verify.py')
if ($LASTEXITCODE -ne 0) { throw 'D01 source provenance or metadata verification failed.' }
& $taskPython -u -X utf8 (Join-Path $PSScriptRoot 'source\document.py')
if ($LASTEXITCODE -ne 0) { throw 'D01 drawing or package generation failed.' }
& $taskPython -u -X utf8 (Join-Path $PSScriptRoot 'source\verify.py') --package
if ($LASTEXITCODE -ne 0) { throw 'D01 package verification failed.' }
