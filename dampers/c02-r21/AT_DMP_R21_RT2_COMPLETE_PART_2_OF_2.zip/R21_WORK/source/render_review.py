from pathlib import Path
import json,subprocess,sys
from PIL import Image,ImageDraw
from pypdf import PdfReader
W=Path(__file__).resolve().parents[1];D=W/'deliverables';Q=W/'qa';Q.mkdir(exist_ok=True)
exe=r'C:\Users\Gebruiker\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdftoppm.exe'
jobs=[('REVIEW',D/'drawings/AT_DMP_R21_P1_MASTER_AND_RT2_REVIEW_EN.pdf'),('CURRENT',D/'factory/R21_CURRENT_ISSUED_PAGES.pdf')]
if '--review-only' in sys.argv:jobs=jobs[:1]
out=[]
for tag,p in jobs:
 n=len(PdfReader(p).pages)
 subprocess.run([exe,'-r','65'if tag=='CURRENT'else'85','-png',str(p),str(Q/tag)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=300)
 files=sorted(Q.glob(tag+'-*.png'))
 if len(files)!=n:raise ValueError((tag,len(files),n))
 count=12 if tag=='CURRENT' else 6
 for st in range(0,n,count):
  cols=3 if count==12 else 2;ww=750 if count==12 else 1050;hh=530;im=Image.new('RGB',(cols*ww,((count+cols-1)//cols)*hh),'white');dr=ImageDraw.Draw(im)
  for j,ip in enumerate(files[st:st+count]):
   m=Image.open(ip).convert('RGB');m.thumbnail((ww-12,hh-35));x=j%cols*ww;y=j//cols*hh;im.paste(m,(x,y+25));dr.text((x+7,y+7),ip.name,fill='black')
  im.save(Q/f'{tag}_MONTAGE_{st//count+1:02d}.jpg',quality=88)
 out.append(dict(file=str(p.relative_to(D)),pages=n,rendered=len(files)))
if '--review-only' in sys.argv:
 old=json.loads((D/'evidence/R21_PDF_RENDER.json').read_text());out+= [q for q in old if 'factory' in q['file']]
(D/'evidence/R21_PDF_RENDER.json').write_text(json.dumps(out,indent=2));print(out)
