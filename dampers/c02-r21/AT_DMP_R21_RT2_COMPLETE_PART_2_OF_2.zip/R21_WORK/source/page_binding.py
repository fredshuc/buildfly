from pathlib import Path
import hashlib,json
from pypdf import PdfReader
W=Path(__file__).resolve().parents[1];R=W.parent;D=W/'deliverables'
def sig(p):
 def visit(obj,seen):
  obj=obj.get_object()
  if id(obj)in seen:return []
  seen.add(id(obj));out=[]
  if hasattr(obj,'get_data'):out.append(hashlib.sha256(obj.get_data()).hexdigest())
  if isinstance(obj,dict):
   for k,v in obj.items():
    if k not in ['/Parent','/P']:out+=visit(v,seen)
  elif isinstance(obj,list):
   for v in obj:out+=visit(v,seen)
  return out
 contents=p.get_contents();return dict(media=list(p.mediabox),rotation=p.rotation,content=hashlib.sha256(contents.get_data()if contents else b'').hexdigest(),resource_streams=sorted(visit(p['/Resources'],set())))
old=PdfReader(R/'R20_WORK/deliverables/factory/CURRENT_ISSUED_PAGES.pdf');new=PdfReader(W/'input/F07/drawings/AT_DMP_P1_SP06_PRODUCT_FAB_RELEASE_R20_L1_F07_EN.pdf');cur=PdfReader(D/'factory/R21_CURRENT_ISSUED_PAGES.pdf');rr=[]
for i,p in enumerate(list(old.pages)+list(new.pages)):
 a=sig(p);b=sig(cur.pages[i])
 if a!=b:raise ValueError(i+1)
 rr.append(dict(page=i+1,decoded_content_and_resource_streams_equal=True,content_sha256=a['content'],resource_stream_count=len(a['resource_streams'])))
(D/'evidence/R21_PAGE_GRAPHICS_BINDING.json').write_text(json.dumps(rr,indent=2));print('243 page content and resource streams identical',flush=True)
