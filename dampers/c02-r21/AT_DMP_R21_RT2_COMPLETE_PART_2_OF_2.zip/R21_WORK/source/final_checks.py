from pathlib import Path
import json,csv,hashlib,collections,datetime
from pypdf import PdfReader
R=Path(__file__).resolve().parents[2];W=R/'R21_WORK';D=W/'deliverables';T=D/'tables';E=D/'evidence'
def rows(n):return list(csv.DictReader((T/n).open(encoding='utf-8-sig')))
checks=[]
def check(name,cond,detail):
 if not cond:raise ValueError((name,detail))
 checks.append(dict(check=name,status='PASS',detail=detail))
idx=rows('R21_CURRENT_FACTORY_ENTRY_INDEX.csv');bom=rows('R21_NET_NEED_BOM.csv');gaps=rows('R21_CLASSIFIED_GAPS.csv')
check('entry keys unique',len({(q['PN'],q['allocation'])for q in idx})==len(idx)==172,len(idx))
book=PdfReader(D/'factory/R21_CURRENT_ISSUED_PAGES.pdf');check('pages',len(book.pages)==243,len(book.pages))
for q in idx:
 for n in q['current_PDF_pages'].split(','):check('page '+q['PN']+' '+n,1<=int(n)<=243,q['allocation'])
 for kind in ['STEP','DXF']:
  if q[kind]:
   p=D/'factory'/q['packet']/q[kind];check('file '+q['PN']+' '+kind,p.is_file(),str(p.relative_to(D)))
check('net',sum(int(q['net_physical_need'])for q in bom)==2265,2265)
check('credit',sum(int(q['issued_scoped_quantity'])for q in bom)==689,689)
check('unissued',sum(int(q['not_yet_issued_quantity'])for q in bom)==1576,1576)
check('gaps',len(gaps)==88,len(gaps))
check('rows balance',all(int(q['net_physical_need'])==int(q['issued_scoped_quantity'])+int(q['not_yet_issued_quantity'])for q in bom),'220 rows')
for q in bom:
 if q['physical_family']=='COMMON_FACILITY':check('common '+q['PN'],int(q['net_physical_need'])==max(int(q['P_count']),int(q['R_count'])),q['quantity_rule'])
check('F07 exact quantities',sum(int(q['issued_scoped_quantity'])for q in bom if q['physical_family']=='PRODUCT'and q['release']=='F07')==144,'product only; independent station not deducted')
check('no factory results fabricated',all(q['manufacturing_status']=='UNCONFIRMED'and q['arrival_status']=='UNCONFIRMED'and q['measurement_status']=='UNCONFIRMED'for q in bom),'all current rows')
check('nine later items',len(rows('R21_BODY_TOOL_NINE_LATER_MEMBERS.csv'))==9,9)
check('D542 later exact identities',len(rows('R21_D542_EXACT_LATER_MEMBERS.csv'))==66,66)
check('RT2 <=10',len(rows('R21_RT2_TEN_DECISIONS.csv'))==10,10)
fo=json.loads((D/'factory/F07_PROCESS_AND_SCOPE_OVERRIDES.json').read_text())
for pn,remaining in [('J404',2.45),('A709',4.45)]:
 q=fo['parts'][pn];minimum=q['total_thickness_mm'][0]-q['pocket_depth_mm'][1];check(pn+' dimensional interval',minimum>=remaining,dict(interval_min=minimum,inspection_min=remaining))
films=json.loads((E/'R21_FILM_BRANCH_DIAGNOSTIC.json').read_text())
for q in films:check(q['PN']+' diagnostic only',q['native_valid']and q['DXF_import_valid']and q['DXF_import_solids']==1 and max(q['material_difference_mm3'])<1e-6 and q['decision']=='DIAGNOSTIC_ONLY_NO_CONFIG_CHANGE','Valid topology does not release contour/retention')
# Snapshot exact historical control rows; do not combine maxima from different rows.
hist=json.loads((D/'history/R14/evidence/R14_TWO_PLANE_DEFLECTION_SENSITIVITY.json').read_text());cr=[]
for q in hist['rows']:
 cr.append(dict(case=q['case'],pose=q['pose'],bearing_k_N_mm=q['bearing_k'],plate_k_N_mm=q['local_plate_k'],relative_X_mm=q['planes'][0]['relative_at_gear_mm'],relative_Y_mm=q['planes'][1]['relative_at_gear_mm'],transverse_vector_norm_mm=q['relative_transverse_norm_mm'],relative_angle_norm_mrad=q['relative_angle_norm_mrad'],scope=q['scope']))
with(T/'R21_INHERITED_G1_NAMED_ROWS.csv').open('w',encoding='utf-8-sig',newline='')as h:w=csv.DictWriter(h,fieldnames=list(cr[0]));w.writeheader();w.writerows(cr)
rt=rows('R21_RT2_TEN_DECISIONS.csv')
for q in rt:
 if q['id']=='RT2-04':q['known_evidence']='R14 P_driven_jam/bench k25000/20000: relativeX0.109827mm, transverse vector norm0.323603mm and angle norm0.484775mrad; not a pure centre-distance change. Other cases are separate named rows. R17 stop0.243898/0.351214deg are ideal/conservative screens; suppliers unconfirmed.'
with(T/'R21_RT2_TEN_DECISIONS.csv').open('w',encoding='utf-8-sig',newline='')as h:w=csv.DictWriter(h,fieldnames=list(rt[0]));w.writeheader();w.writerows(rt)
rep=dict(status='PASS_WITH_STATED_SCOPE',checks=checks,check_count=len(checks),new_native_validity='396 definitions checked valid with solids by reproduce_current.py;1506/1073 rigid placements and unique occurrences passed',new_full_STEP_reimport=False,full_collision_rerun=False,loaded_solver_rerun=False,product_geometry_changed=False,full_C02='PARTIAL / NOT_FOR_MANUFACTURE')
(E/'R21_FINAL_QA.json').write_text(json.dumps(rep,indent=2));print('QA',len(checks),'checks',flush=True)
