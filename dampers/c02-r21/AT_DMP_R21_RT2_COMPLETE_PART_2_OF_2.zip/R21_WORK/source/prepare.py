from pathlib import Path
import json,zipfile,hashlib,shutil,csv
R=Path(__file__).resolve().parents[2]; W=R/'R21_WORK'; D=W/'deliverables'
for n in ['tables','evidence','drawings','native','step','factory','diagnostics']:(D/n).mkdir(parents=True,exist_ok=True)
def verify(p):
 with zipfile.ZipFile(p) as z:
  if z.testzip():raise ValueError('CRC')
  m=json.loads(z.read('MANIFEST_SHA256.json'))
  if isinstance(m,dict):m=m.get('files',m.get('entries',[]))
  for q in m:
   b=z.read(q.get('path',q.get('file')))
   if len(b)!=q.get('bytes',q.get('size')) or hashlib.sha256(b).hexdigest()!=q['sha256']:raise ValueError(q)
 return dict(file=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),members=len(z.namelist()),manifest=len(m),passed=True)
proof=[verify(W/'input/AT_DMP_R20_L1_RELEASE_AND_R21_ORDER_20261013.zip')]
for p in (R/'R20_WORK/delivery').glob('*.zip'):proof.append(verify(p))
f07=W/'input/signed/factory/AT_DMP_P1_R20_SP06_PRODUCT_FAB_RELEASE_20261013.zip';proof.append(verify(f07))
with zipfile.ZipFile(f07)as z:z.extractall(W/'input/F07')
with zipfile.ZipFile(R/'R20_WORK/delivery/AT_DMP_P1_R20_MANUFACTURING_MASTER_20261012.zip')as z:z.extractall(W/'input/master20')
shutil.copytree(W/'input/master20/factory',D/'factory',dirs_exist_ok=True)
for p in (R/'R20_WORK/deliverables/native').glob('*.json'):shutil.copy2(p,D/'native'/p.name)
for p in (R/'R20_WORK/deliverables/step').glob('*COMPLETE*.stp'):shutil.copy2(p,D/'step'/p.name)
for p in (R/'R20_WORK/deliverables/tables').glob('*.csv'):shutil.copy2(p,D/'tables'/p.name)
for p in (R/'R20_WORK/deliverables/evidence').glob('*.json'):shutil.copy2(p,D/'evidence'/p.name)
shutil.copytree(W/'input/F07',D/'factory/F07_PRODUCT',dirs_exist_ok=True)
shutil.copy2(f07,D/'factory/reference_issued_archives_DO_NOT_BATCH_PRODUCE'/f07.name)
shutil.copy2(W/'input/signed/R20_L1_F07_PROCESS_AND_SCOPE_OVERRIDES.json',D/'factory/F07_PROCESS_AND_SCOPE_OVERRIDES.json')
(D/'evidence/R21_INPUT_INTEGRITY.json').write_text(json.dumps(proof,indent=2))
ledger=dict(order='R21',T0='2026-10-13T00:56:55Z',claim_completed_utc='2026-10-13T00:59:10Z',engineering_deadline='2026-10-13T02:06:55Z',return_deadline='2026-10-13T02:26:55Z',max_iterations=5,status='ENGINEERING_ACTIVE',iterations=[dict(number=1,start='2026-10-13T00:56:55Z',scope='Input verification, F07 incorporation and physical allocation',status='ACTIVE')],clock_note='T0 is first actual local input check, before successful L1 read; heartbeat timestamp not used to backdate.')
(W/'ledger.json').write_text(json.dumps(ledger,indent=2))
print(json.dumps(proof,indent=2));print('F07 files',*[str(p.relative_to(W/'input/F07'))for p in (W/'input/F07').rglob('*')if p.is_file()],sep='\n')
