import json,copy
import build_c02 as b
import ezdxf
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
import numpy as np
D=b.OUT; pm={p['pn']:p for p in json.loads((D/'native/R20_PARTS.json').read_text())}
out=[]
for cfg,pn,H in [('P','P109',339),('R','R109',174)]:
 p=pm[pn]; old=b.ex.readshape(p['brep']); s=old
 holes=[f for f in p['features'] if f['type']=='hole' and (f['y']<3 or f['y']>H-3)]
 for f in holes:
  y=-1 if f['y']<3 else f['y']
  height=f['y']+1 if f['y']<3 else H-f['y']+1
  s=s.cut(b.box(f['d'],height,2).translate((f['x']-f['d']/2,y,-1)))
 s=s.clean()
 face=min([f for f in s.Faces()if f.geomType()=='PLANE' and abs(f.normalAt().z)>.99],key=lambda f:f.Center().z)
 path=D/'diagnostics'/f'{pn}_OPEN_SLOT_DIAGNOSTIC_ONLY.dxf'
 b.cq.exporters.export(b.cq.Compound.makeCompound(face.Wires()),str(path))
 doc=ezdxf.readfile(path); audit=doc.audit(); imported=b.cq.importers.importDXF(str(path)).extrude(.25).val()
 diff=[abs(s.cut(imported).Volume()),abs(imported.cut(s).Volume())]
 occ=json.loads((D/f'native/R20_{cfg}_OCCURRENCES.json').read_text()); q=next(q for q in occ if q['pn']==pn)
 def local(shape,q2):
  world=b.tr(shape,q2['o'],q2['u'],q2['v'],q2['n'])
  rot=np.array([q['u'],q['v'],q['n']]);origin=-rot@np.array(q['o'])
  return b.tr(world,origin.tolist(),rot[:,0].tolist(),rot[:,1].tolist(),rot[:,2].tolist())
 near=[]; metal=[]
 for x in occ:
  if x['pn']not in [cfg+'110',cfg+'108','B200_R13']:continue
  sh=local(b.ex.readshape(pm[x['pn']]['brep']),x);bb=b.ex.bb(sh)
  if bb[3]<-10 or bb[0]>100 or bb[4]<-10 or bb[1]>H+10 or bb[2]>30 or bb[5]<-30:continue
  near.append(dict(PN=x['pn'],occurrence=x['occurrence'],bounds_in_film_coordinates=bb))
  if x['pn']==cfg+'110':metal.append((x,sh))
 framechecks=[]
 for x,sh in metal:
  bb=b.ex.bb(sh);t=bb[5]-bb[2]
  for y0 in [0,H-5]:
   volume=sh.intersect(b.box(87,5,t+2).translate((0,y0,bb[2]-1))).Volume()
   framechecks.append(dict(frame=x['occurrence'],film_end_strip=[y0,y0+5],frame_projection_area_mm2=volume/t,strip_nominal_area_mm2=435))
 fig,axs=plt.subplots(1,2,figsize=(9,7))
 for ax,shape,title in [(axs[0],old,'Inherited tangent end holes'),(axs[1],s,'Open slots - diagnostic, NOT RELEASED')]:
  segs=[[(e.positionAt(float(t)).x,e.positionAt(float(t)).y)for t in np.linspace(0,1,2 if e.geomType()=='LINE'else 40)]for e in shape.Edges()]
  ax.add_collection(LineCollection(segs,linewidths=.7));ax.autoscale();ax.set_aspect('equal');ax.set_title(title,fontsize=9);ax.set_xlabel('X mm');ax.set_ylabel('Y mm');ax.grid(alpha=.2)
 fig.suptitle(pn+' end strategy / free PTFE 0.25 mm');fig.tight_layout();fig.savefig(D/'drawings'/f'{pn}_DIAGNOSTIC.png',dpi=140);plt.close(fig)
 out.append(dict(PN=pn,holes=holes,native_valid=s.isValid(),solids=len(s.Solids()),DXF_audit_errors=audit.has_errors,DXF_import_valid=imported.isValid(),DXF_import_solids=len(imported.Solids()),material_difference_mm3=diff,removed_mm3=old.Volume()-s.Volume(),nearby_actual_parts=near,frame_end_strip_projection=framechecks,decision='DIAGNOSTIC_ONLY_NO_CONFIG_CHANGE',reason='Open slot makes deliberate free boundary; existing disconnected end tabs remain removed. No continuous end-lip retention/contact demonstration. Stop optional branch rather than release a cutting shape without the associated safe retention definition. No new film or frame installed; actual 0/45/90 and control-domain motion checks NOT performed for this rejected diagnostic.'))
(D/'evidence/R21_FILM_BRANCH_DIAGNOSTIC.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2),flush=True)
