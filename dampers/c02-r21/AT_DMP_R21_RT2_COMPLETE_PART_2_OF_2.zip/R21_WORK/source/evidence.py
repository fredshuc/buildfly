from pathlib import Path
import json,hashlib,shutil,csv,importlib.metadata
R=Path(__file__).resolve().parents[2];W=R/'R21_WORK';D=W/'deliverables';E=D/'evidence';H=D/'history'
def cp(p,d):d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
for rnd in ['R14','R15','R17','R18','R19']:
 for p in (R/(rnd+'_WORK/deliverables/evidence')).glob('*.json'):cp(p,H/rnd/'evidence'/p.name)
 for p in (R/(rnd+'_WORK/deliverables/tables')).glob('*.csv'):cp(p,H/rnd/'tables'/p.name)
 for p in (R/(rnd+'_WORK/source')).glob('*.py'):cp(p,H/rnd/'source'/p.name)
 reports=list((R/(rnd+'_WORK/deliverables')).glob('*RETURN*.md'))
 for p in reports:cp(p,H/rnd/p.name)
for p in (R/'R17_INPUT/signed/deliverables').glob('*.md'):cp(p,H/'RT1_L1_DISPOSITION'/p.name)
for p in (W/'input/signed').glob('*.md'):cp(p,H/'R21_SIGNED'/p.name)
cp(W/'input/AT_DMP_R20_L1_RELEASE_AND_R21_ORDER_20261013.zip',H/'R21_SIGNED/AT_DMP_R20_L1_RELEASE_AND_R21_ORDER_20261013.zip')
# Minimal actual inputs for the inherited two-plane diagnostic, kept at original paths in a reproduction subset.
deps=['R14_WORK/source/r14_deflection.py','R14_WORK/source/build_c02.py','R14_WORK/source/step_io.py','R14_WORK/deliverables/native/R14_PARTS.json','R14_WORK/deliverables/evidence/R14_MASS_AND_FLOOR.json','R13_WORK/deliverables/evidence/R13_COMPLIANCE_THERMAL.json','R7_WORK/source/r6_finite_base.py','R15_WORK/source/r15_wet_response.py','R15_WORK/source/build_c02.py','R15_WORK/source/step_io.py','R15_WORK/deliverables/evidence/R15_ROTOR_MASS.json']
for rel in deps:cp(R/rel,D/'historical_reproduction'/rel)
# Do not run these inherited diagnostic solvers in R21. Isolated copy permits exact reviewer reproduction.
versions={k:importlib.metadata.version(k)for k in ['cadquery','cadquery-ocp','numpy','scipy','ezdxf','reportlab','pypdf']}
(E/'R21_RUNTIME_VERSIONS.json').write_text(json.dumps(versions,indent=2))
proof=[]
for n in ['R20_PARTS.json','R20_P_OCCURRENCES.json','R20_R_OCCURRENCES.json']:
 a=R/'R20_WORK/deliverables/native'/n;b=D/'native'/n
 if a.read_bytes()!=b.read_bytes():raise ValueError(n)
 proof.append(dict(file='native/'+n,bytes=b.stat().st_size,sha256=hashlib.sha256(b.read_bytes()).hexdigest(),inherited_byte_identical=True))
for n in ['R20_P_COMPLETE_COLD_REFERENCE.stp','R20_R_COMPLETE_COLD_REFERENCE.stp']:
 a=R/'R20_WORK/deliverables/step'/n;b=D/'step'/n
 if a.read_bytes()!=b.read_bytes():raise ValueError(n)
 proof.append(dict(file='step/'+n,bytes=b.stat().st_size,sha256=hashlib.sha256(b.read_bytes()).hexdigest(),inherited_byte_identical=True,readback='R20 independent readback inherited; no new full STEP import in R21'))
g1=R/'R20_WORK/input/releases/F05/step/parts/G903_R18.stp';g2=D/'factory/current/PRODUCT_OR_SHARED_FACILITY/G903/G903_R18.stp'
if g1.read_bytes()!=g2.read_bytes():raise ValueError('guard STEP alias')
(E/'R21_G903_ALIAS_CORRECTION.json').write_text(json.dumps(dict(source='F05_ISSUED_STAGES.csv row PN=G903_R18, quantity1, REPLACEMENT',old_index_name='G903',current_index_name='G903_R18',current_P_count=1,current_R_count=1,physical_quantity=1,rule='same sequential common guard; no additional plate',STEP_sha256=hashlib.sha256(g1.read_bytes()).hexdigest(),same_signed_and_current_STEP=True,old_credit=688,new_credit=689,old_gap_rows=89,new_gap_rows=88,new_unissued=1576,changes='Allocation correction only; no new issue/no geometry change'),indent=2))
(E/'R21_BASELINE_IMMUTABILITY.json').write_text(json.dumps(proof,indent=2))
(D/'native/R21_METADATA_OVERRIDES.json').write_text(json.dumps(dict(geometry='R20 native byte-identical',manufacturing_precedence='R21 current index plus mandatory_process F06 and F07_PRODUCT signed pages override legacy notes in native catalog; raw BRep metadata is not a parallel shop instruction.',product_F07=json.loads((W/'input/signed/R20_L1_F07_PROCESS_AND_SCOPE_OVERRIDES.json').read_text()),guard='G903_R18 one common replacement; existing F05, no additional original G903'),indent=2))
print('Evidence snapshots and minimal historical inputs copied; inherited solvers NOT run. Versions',versions)
