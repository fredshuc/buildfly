from pathlib import Path
import json,hashlib,zipfile,csv,shutil,datetime
R=Path(__file__).resolve().parents[1];D=R/'deliverables';E=D/'evidence';out=R/'delivery';out.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
P=read(D/'native/R14_PARTS.json');pm={p['pn']:p for p in P};B=read(E/'R14_BATCH_BOM.json');cov={r['PN']:r for r in read(E/'R14_DRAWING_COVERAGE.json')}
for q in B:
 q['drawing']=pm[q['PN']].get('drawing','');q['drawing_page']=cov.get(q['PN'],{}).get('first_page','supplier specification');q['drawing_pdf']=cov.get(q['PN'],{}).get('pdf','');q['STEP']='step/parts/'+q['PN']+'_R14.stp'
 if pm[q['PN']]['kind']=='REFERENCE':q['new_required_qty']=0;q['release']='REFERENCE_NOT_PROCUREMENT'
with (D/'tables/R14_BOM.csv').open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(B[0]));w.writeheader();w.writerows(B)
stats={batch:{'PN':len([q for q in B if q['batch']==batch]),'pieces':sum(q['new_required_qty'] for q in B if q['batch']==batch)} for batch in ['SP02','SP03']}
report='# R14 engineering return / cold fabrication candidates\n\n'+json.dumps(stats,indent=2)+'\n\n'
for batch in ['SP02','SP03']:report+=batch+': '+', '.join(q['PN']+' x'+str(q['new_required_qty']) for q in B if q['batch']==batch)+'\n\n'
report+='''The two independent batch ZIPs contain same-version drawings, part STEP and the complete quantity/procurement table. L1 issuance is required; no loaded/hot/powered operation is released. SP01 three parts remain byte-identical, credited once. A01/A02/B01/E01 plus SP01 remain34 PN122 pieces already issued. Full C02 PARTIAL / NOT_FOR_MANUFACTURE.

Actual P272/R249/service206 instances;79 independent part STEP and3 assembly readbacks passed. Nominal cold all-pair checks36856/30876/21115: zero unapproved overlaps after spatial thread clipping. Three conservative continuous envelopes and four tubular nut-tool envelopes are clear under documented preconditions. Full input dismantling, real transfer, supplier tool access and loaded joints remain HOLD. No whole-valve four-state rerun.

DOCUMENTARY ERRATA (takes precedence over review PDF): final TF904 is46x46x10, not50. Final geometric mass P467.837063kg,R449.098180kg,S411.377227kg; the review PDF mass table retains the prior pad mass by0.361728kg. The two-plane diagnostic is in R14_TWO_PLANE_DEFLECTION_SENSITIVITY.json: weak spring cases retain radial centre change0.109827mm and tilt up to4.863355mrad. Relative tangential displacement is not first-order centre-distance change. G1 NOT_CLOSED. The first beam identity check had reversed arguments and failed; retained as negative evidence. Corrected identity error7.81e-18mm. No supplier hot/contact acceptance inferred.

R15 receives44 signed reaction rows at78/38Nm normal inputs, pressure3/5,500,1500,2000Pa and jam/stop cases; wet near reaction approximately1.50kN is retained. Wet displacement/rotation remains NOT_SOLVED, requiring R15 contact model. DB thermal axial/radial signs corrected, no hot qualification.

TIME EXCEPTION: T0 08:16:56Z; engineering deadline09:26:56Z, formal delivery target09:46:56Z. At09:42:04Z the clock overrun was detected and engineering stopped. Final PDFs finished09:42:29Z. This return does NOT claim compliance with70minute engineering cutoff. Three documented iterations only; no sixth or borrowed allowance. Remaining work is explicitly held; no new engineering after detection. Round1/2 boundary08:40 is reconstructed, not instrumented.

Known holds by use: D521_R14 loaded clamp zone; input/stop dynamic calibration and capture/joint proof; frame weld/slip/prying/floor proof; guard reach/containment; full wet capture and service load transfer; wet interface displacement/seal contact. Independent cold parts remain candidates. No D540 handle supplied by this batch. Actuator remains purchased placeholder.

Measurement return: actual PN/revision, material, journal/bore/thread dimensions, ring orientation, selected ring thickness,20C +/-20N endplay10..30um, drag, two-plane bearing/gear indicators, input endplay0.05..0.15, clamp/witness movement, stop angles, floor contact, mass, raw loading/unloading data. Quarantine failed features; no undocumented machining of bearing/seal/thread/capture features. Loaded measurement needs separate signed release; B feedback is never sole protection.
'''
(D/'L2_TO_L1_R14_RETURN_EN.md').write_text(report,encoding='utf-8')
srcs=read(R.parent/'R13_WORK/deliverables/SOURCE_REGISTER.json');srcs+=[dict(url='https://cdn.skfmediahub.skf.com/api/public/0901d1968065f1f4/pdf_preview_medium/0901d1968065f1f4_pdf_preview_medium.pdf',scope='DB thermal sign; not system approval'),dict(url='https://www.metinvestholding.com/pl/products/steel-grades/s355jr',scope='345MPa for20/25/30mm stock')];(D/'SOURCE_REGISTER.json').write_text(json.dumps(srcs,indent=2))
with (D/'tables/R14_FACTORY_RETURN.csv').open('w',newline='',encoding='utf-8-sig') as f:csv.writer(f).writerow(['actual_revision','PN','key_dimensions','assembly_issue','raw_test_data','engineering_disposition','P1_replacement','P2_change'])
ledger=read(R/'EXECUTION_LEDGER.json');ledger['status']='FROZEN_TIME_EXCEPTION';ledger['overrun_detected_utc']='2026-10-12T09:42:04Z';ledger['rounds'][-1]['end_utc']='2026-10-12T09:42:04Z';(R/'EXECUTION_LEDGER.json').write_text(json.dumps(ledger,indent=2))
files=[p for p in D.rglob('*') if p.is_file()]+list((R/'source').glob('*.py'))+[R/'EXECUTION_LEDGER.json']
signed=R.parent/'R14_INPUT/AT_DMP_R13_L1_REVIEW_AND_R14_ORDER_20261012.zip';files+=[signed]
for batch in ['SP02','SP03']:
 selected=[D/'L2_TO_L1_R14_RETURN_EN.md',D/'tables/R14_BOM.csv',D/'tables/R14_FACTORY_RETURN.csv',D/'drawings'/f'AT_DMP02_C02_R14_{batch}_COLD_FABRICATION_EN.pdf']+[D/q['STEP'] for q in B if q['batch']==batch]
 with zipfile.ZipFile(out/f'AT_DMP_R14_{batch}_CANDIDATE_20261012.zip','w',zipfile.ZIP_DEFLATED,6) as z:
  for p in selected:z.write(p,str(p.relative_to(D)))
manifest=[]
main=out/'AT_DMP02_C02_R14_ENGINEERING_RETURN_20261012.zip'
with zipfile.ZipFile(main,'w',zipfile.ZIP_DEFLATED,6) as z:
 for p in files:
  name=str(p.relative_to(R)).replace('\\','/') if p.is_relative_to(R) else 'signed_input/'+p.name;z.write(p,name);manifest.append(dict(path=name,bytes=p.stat().st_size,sha256=sha(p)))
 z.writestr('MANIFEST.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(main) as z:
 if z.testzip():raise ValueError('CRC')
 for m in manifest:
  data=z.read(m['path'])
  if len(data)!=m['bytes'] or hashlib.sha256(data).hexdigest()!=m['sha256']:raise ValueError(m['path'])
receipt=[dict(file=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in out.glob('*.zip')];(out/'LOCAL_RECEIPT.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(dict(batches=stats,files=receipt),indent=2))
