import json,math,copy,collections,hashlib,ast
import numpy as np
import build_c02 as b
E=b.OUT/'evidence';P=json.loads((b.OUT/'native/R14_PARTS.json').read_text());pm={p['pn']:p for p in P};S={p['pn']:b.ex.readshape(p['brep']) for p in P}
O=json.loads((b.OUT/'native/R14_P_CORE_OCCURRENCES.json').read_text());SR=json.loads((b.OUT/'native/R14_SERVICE_OCCURRENCES.json').read_text());F=json.loads((b.OUT/'native/R14_FRAME_OCCURRENCES.json').read_text())
service=copy.deepcopy(O)
for q in service:
 if q['pn']=='H14_M12X110':q['pn']='HW_R13_M12X80';q['o'][1]-=25
 if q['pn']=='HW_R13_W12' and q['o'][1]==-75:q['o'][1]=-100
service+=SR+F;b.dump(b.OUT/'native/R14_S_ASSEMBLY.json',service)
# Per-configuration actual geometric mass, purchased known-mass overrides. HBK remains conservative allocation.
mass={p['pn']:p['volume_mm3']*(8.8e-6 if p['material']=='CuSn12' else 7.85e-6) for p in P}
mass.update(BUY_R13_7206=.194,BUY_R13_BK2=4,BUY520=1.98,BUY521=1.98,BUY531=4,BUY530=2.0,REF_WET_STUB=0)
massrows=[]
for cfg in ['P','R','S']:
 rows=json.loads((b.OUT/f'native/R14_{cfg}_ASSEMBLY.json').read_text());total=0;mom=np.zeros(3)
 for q in rows:
  m=mass[q['pn']];ss=b.tr(S[q['pn']],q['o'],q['u'],q['v'],q['n']);total+=m;mom+=m*np.array(ss.Center().toTuple())
 cg=mom/total;w=total*9.81;left=-440;right=640;front=-290;rear=1140;mind=min(cg[0]-left,right-cg[0],cg[2]-front,rear-cg[2]);operator=200000/450;h=839+125
 massrows.append(dict(configuration=cfg,mass_kg=total,CG_mm=cg.tolist(),gravity_N=w,foot_polygon_XZ=[left,right,front,rear],operator_screen_N=operator,overturning_reserve_ratio=w*mind/(operator*h+200000),sliding_reserve_ratio_at_mu03=.30*w/operator,left_rail_reaction_N=w*(560-cg[0])/920,right_rail_reaction_N=w*(cg[0]+360)/920,limits='Cold horizontal floor only; six feet level/contact checked. Mu0.30 must be measured or separately anchor. HBK2kg allocation not catalogue mass; weigh assembly. No overhead lifting from model.'))
b.dump(E/'R14_MASS_AND_FLOOR.json',dict(configurations=massrows,part_masses=mass,handling='Assemble on final-level floor in subassemblies. Move steel frame with fork truck under two1350mmRHS rails before precisionboxassembly; secure load. No hoisting from unqualified holes. Whole assembled unit move only under separate weighed lift plan.'))
# Signed reactions in both bending planes for P/R and two gravity orientations.
def react(f,z,m=0):r1=(f*(z+13)+m)/116;return [f-r1,r1]
cases=[('P_normal78_3Pa',78,3,True,False),('P_normal78_5Pa',78,5,True,False),('R_normal38_5Pa',38,5,False,False),('hold500',0,500,False,False),('structure1500',0,1500,False,False),('sensitivity2000',0,2000,False,False),('P_active_jam',200,1500,False,True),('P_driven_jam',200,1500,True,True),('R_jam',200,1500,False,True),('P_stop0',200,0,True,False),('P_stop90',200,0,True,False)]
controls=[];I=math.pi*30**4/64;EI=200000*I
for pose,gaxis in [('bench',1),('P_installed_reference',0)]:
 for name,T,pr,mesh,jam in cases:
  for sign in [-1,1]:
   ft=T*1000/82.5 if mesh else 0;fr=abs(ft)*math.tan(math.radians(20));rx=np.array(react(fr,35));ry=np.array(react(sign*ft,35))
   for pn,z in [('BUY504',39.4632622903),('D870',S['D870'].Center().z)]:
    if name.startswith('R') and pn=='BUY504':continue
    rr=np.array(react(mass[pn]*9.81,z));rx+=rr if gaxis==0 else 0;ry+=rr if gaxis==1 else 0
   coupling=1050*.03+4*9.81;axial=71*(961.5*17.2e-6*80+.15+.03);moment=10000
   ry+=np.array(react(sign*coupling,-99.5,sign*moment))
   # Input-chainoverhang allocation: bound10kg atZ220 into output, independentinputhousingat383.
   inputload=10*9.81*(383-220)/(383-148);ry+=np.array(react(inputload,148)) if gaxis==1 else 0;rx+=np.array(react(inputload,148)) if gaxis==0 else 0
   stopforce=200000/60 if 'stop' in name else 0
   if name=='P_stop0':ry+=np.array(react(sign*stopforce,148))
   if name=='P_stop90':rx+=np.array(react(sign*stopforce,148))
   resultant=np.hypot(rx,ry);Mx=max(abs(rx[0])*48,abs(rx[1])*68);My=max(abs(ry[0])*48,abs(ry[1])*68);vm=math.sqrt((2*32*math.hypot(Mx,My)/(math.pi*30**3))**2+3*(1.8*16*T*1000/(math.pi*30**3))**2)
   edge=T*1000/77 if jam else 0;wetweight=874091.5230567266*7.93e-6*9.81;wp=pr*.617*.154;near=(wp+edge+wetweight)/2+coupling*(1+83.5/637)+moment/637;far=(wp+edge+wetweight)/2-coupling*83.5/637-moment/637
   controls.append(dict(case=name,direction=sign,pose=pose,torque_Nm=T,pressure_Pa=pr,gear_Ft_N=sign*ft,gear_Fr_N=fr,front_Rx_Ry_N=[float(rx[0]),float(ry[0])],rear_Rx_Ry_N=[float(rx[1]),float(ry[1])],bearing_resultants_N=resultant.tolist(),shortshaft_notched_VM_screen_MPa=vm,stop_force_N=stopforce,coupling_axial_N=sign*axial,coupling_moment_allocated_Nm=sign*10,wet_near_N=near,wet_far_N=far,wet_transverse_direction='Worst-directionscalar radial screen; not fullwetcontactsolution',wet_displacement_rotation='NOT_SOLVED; measure/closewithR15jointmodel',scope='Two-plane equilibrium and conservative inputmassallocation; not assembled contact/life or dynamic maximum. Physical planes used, no unqualified NSK a shift.'))
b.dump(E/'R14_CONTROL_REACTIONS.json',controls)
# Existing R6 finite beam kernel identity; no new nonlinear solver.
src=(b.ROOT.parent/'R7_WORK/source/r6_finite_base.py').read_text();node=next(n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef) and n.name=='beamk');exec(ast.get_source_segment(src,node));k=beamk(116,EI);err=abs(np.linalg.solve(k[2:,2:],np.array([100,0]))[0]-100*116**3/(3*EI))
if err>1e-10:raise ValueError(('beamkernel_identity',err))
b.dump(E/'R14_REUSED_BEAM_CHECK.json',dict(source='R7_WORK/source/r6_finite_base.py:beamk',sha256=hashlib.sha256(src.encode()).hexdigest(),cantilever_identity_error=err))
# DB sign-corrected thermal decomposition. Internal pitchradius not provided; useexplicit sensitivity15..31.
thermal=[]
for name,shaftT,ringT,outerT in [('cold',20,20,20),('inner_uniform70',70,70,20),('rings70_shaft20',20,70,20),('whole70',70,70,70)]:
 inner=100*12e-6*(shaftT-20)+16*12e-6*(ringT-20);outer=116*12e-6*(outerT-20)
 for rr in [15,23,31]:
  radial=2*rr*12e-6*(ringT-outerT)/math.tan(math.radians(40));net=inner-outer-radial
  thermal.append(dict(case=name,assumed_pitch_radius_mm=rr,inner_axial_growth_mm=inner,outer_axial_growth_mm=outer,radial_equivalent_closure_mm=radial,DB_signed_gap_change_mm=net,cold_10um_diagnostic_mm=.010+net,cold_30um_diagnostic_mm=.030+net,limits='Sign/decomposition sensitivity only. Real racegeometry, radialdistribution, capelasticity, externalaxialload and inducedbearingthrust not rebalanced. Positive/negative scalar is not operating PASS/failure.'))
b.dump(E/'R14_DB_THERMAL_SIGN.json',thermal)
screen=dict(stop_arm_force_N=200000/60,stop_post_nominal_bending_MPa=(200000/60)*155/(36*30**2/6),stop_post_Kt2_screen_MPa=2*(200000/60)*155/(36*30**2/6),stop_material_min_yield_MPa=345,key_shear_MPa=(200000/15)/(8*32),key_bearing_MPa=(200000/15)/(3*32),front_nut_thread_shear_MPa=2000/(.5*math.pi*29*6),cradle_topweb_bending_at50N_MPa=50*36.5/(4*(8*6.75**2/6)),cradle_vertical_per_N=200,cradle_lateral_per_N=50,shelf_500N_not_rating=True,limitations=['Static screens, nominalsections withdeclaredKt only; jointslip/prying/fatigue notclosed.','StoparmcaptureM8 ispositive, but noimpact/lifetimeapproval.','SP01 loadeduse stillnotreleased; candidateinput andframeconditional untilcalibration/measurement.'])
b.dump(E/'R14_LOCAL_STRENGTH.json',screen)
print('EVIDENCE','controls',len(controls),'masses',[(q['configuration'],q['mass_kg']) for q in massrows],flush=True)

