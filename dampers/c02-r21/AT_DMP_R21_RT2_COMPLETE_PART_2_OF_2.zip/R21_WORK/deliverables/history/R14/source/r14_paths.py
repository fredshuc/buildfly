import json
import build_c02 as b
E=b.OUT/'evidence';P=json.loads((b.OUT/'native/R14_PARTS.json').read_text());S={p['pn']:b.ex.readshape(p['brep']) for p in P};O=json.loads((b.OUT/'native/R14_S_ASSEMBLY.json').read_text())
def world(o):return b.tr(S[o['pn']],o['o'],o['u'],o['v'],o['n'])
def hits(s,rows):
 out=[];aa=b.ex.bb(s)
 for o in rows:
  q=world(o);bb=b.ex.bb(q)
  if not all(min(aa[k+3],bb[k+3])-max(aa[k],bb[k])>1e-5 for k in range(3)):continue
  v=abs(s.intersect(q).Volume())
  if v>.001:out.append(dict(occ=o['occurrence'],PN=o['pn'],volume=v))
 return out
# Conservative continuous translation envelope: independent nested sections retain minimum openings.
plate=b.box(345,165,108).translate((-90,-100,88))
for x in [0,165]:plate=plate.cut(b.cyl(55.9,110,(x,0,87)))
env=plate
for x in [0,165]:
 env=env.fuse(b.cyl(62,101,(x,0,95)).cut(b.cyl(30,103,(x,0,94))))
 env=env.fuse(b.cyl(94,96.7,(x,0,111)).cut(b.cyl(55.9,94,(x,0,110))))
moving=lambda q:q['pn'] in ['D875','D877','D879'] or (q['pn']=='BUY_R13_7206' and q['o'][2]==95) or (q['pn']=='HW_R13_M5X20' and q['o'][2]>100)
fixed=[q for q in O if not moving(q) and not(q['pn'] in ['D873','HW_R13_M4TIP'] and q['o'][2]>100) and not(q['pn'] in ['HW_R13_M10X45','HW_R13_W10'] and q['o'][2]>0)]
res=[dict(stage='REAR_MODULE_0_TO_85_CONTINUOUS_CONSERVATIVE',hits=hits(env,fixed),limits='Input, stop and guard removed after independent wet capture; bearing/cradle state S. Full input removal/load transfer still HOLD.')]
b.cq.exporters.export(env,str(b.OUT/'step/TOOL_REAR_MODULE_SWEEP_R14.stp'),exportType='STEP')
tools=[]
for o in O:
 if o['pn']!='D873':continue
 x,y,z=o['o'];start=-79 if z<0 else 119;t=b.cyl(55,50,(x,y,start)).cut(b.cyl(31,52,(x,y,start-1)))
 target=[q for q in O if q!=o and q['pn'] not in ['BUY_R13_BK2','HW_R13_M4TIP']]
 tools.append(dict(target=o['occurrence'],hits=hits(t,target),scope='Annular tubular tool envelope, no handle swing qualification. Coupling and input removed; excludes target nut.'))
 b.cq.exporters.export(t,str(b.OUT/'step'/('TOOL_NUT_'+o['occurrence']+'.stp')),exportType='STEP')
# Stop sector conservative envelope excludes own coaxial rotating hub and shaft; full disk quadrant bounds outer arm travel.
sector=b.cyl((80**2+10**2)**.5*2,16,(0,0,140)).intersect(b.box(100,100,18).translate((-10,-10,139))).cut(b.cyl(60,18,(0,0,139)))
for cfg in ['P','R']:
 rr=json.loads((b.OUT/f'native/R14_{cfg}_ASSEMBLY.json').read_text());fixed=[q for q in rr if not(q['pn'] in ['D886','D888','D884','D870','D894','D873'] and q['o'][0]==0)]
 res.append(dict(stage=cfg+'_STOP_0_TO_90_CONSERVATIVE',hits=hits(sector,fixed),limits='Geometric swept arm only; neither gear phase/backlash nor impact strength qualification.'))
b.dump(E/'R14_CONTINUOUS_ENVELOPES_AND_TOOLS.json',dict(paths=res,tools=tools,cradle_insertion='R13 samples inherited for unchanged surroundings; changed shim/spacer continuous insertion not proved. Measured transfer HOLD.',load_transfer='Install four cradles with bearings retained; prove contact at <=20N indicator reversal, then controlled transfer <=200N vertical/50N lateral per cradle. Do not remove wet J401/studs/pins. Loaded procedure requires independent wet capture and joint proof before use.'))
print('PATHS',res,'TOOLS',tools,flush=True)

