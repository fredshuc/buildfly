# R15 formal engineering return - SP04 wet manufacturing candidates

## SP04-A: 11 PN / 28 pieces

J401 x1, J403 x1, J404 x1, J405 x4, J406 x2, J407 x1, J408 x8, F604 x4, STD03C x4, STD05B x1, D542 x1

## SP04-B: 16 PN / 71 pieces

P108_FREE_R15 x4, R108_FREE_R15 x4, J402_FREE_R15 x1, S302_FREE_R15 x6, P111-1400 x4, P111-0200 x4, P111-0100 x4, P111-0050 x4, P111-0020 x8, P111-0010 x4, R111-1400 x4, R111-0200 x4, R111-0100 x4, R111-0050 x4, R111-0020 x8, R111-0010 x4

## SP04-C: 3 PN / 3 pieces

TF910L x1, TF910R x1, TF912 x1

## SP04-PURCHASE: 4 PN / 32 pieces

BUY548 x24, BUY402 x1, HW_N6 x5, HW_W6_1p6_12 x2

Total34 PN134pieces, all P1_FABRICATION_CANDIDATE pending L1 issue. A is one fixed-end measurement set, not six machine glands. B supplies one P/R set of dynamic free foam and grouped side shims plus one J402 static coupon. C is test-only. Procurement is listed separately. No factory order or physical work performed. Previous77distinctPN225pieces remain issued under original scope; no ECO to their geometry.

New geometry is four true FREE cutting definitions and TF910L/R split-wall coupons plus a positively captured TF912 mandrel.27inherited PN BReps remain byte-identical. J404 obsolete three-disc note replaced with current two-series/three-parallel six-disc stack. Shim pages now contain full profile coordinates, not a reference to an absent proxy drawing. No new main bearing or whole-valve product geometry.

Same-version evidence:34part STEP independent readbacks; fixed-end62instances, three-rotor selected wet section45instances and four actual tool poses independently exported/read back.16DXFs re-opened;39page manufacturing and9page engineering PDFs rendered and visually checked.1891nominal coupon pairs have zero hard overlaps;24discrete D542 positions pass. These are not continuous sweeps, hand access or loaded fixture qualification. No whole-valve four-state run; historical9/9/23/23 retained, not cleared.

Exact wet mapping: physical bearing land centres s15/-652 give667mm span;637mm is wall-face spacing. R13-trimmed rotor mass6.185329kg. Thrust pin s46 to wet grip centroid103.5 gives57.5mm effective wet thermal segment; dry endpoint motion remains independent. Ten selected signed pressure/normal/jam/stop rows solve finite-land thermal radial clearance with fixed housing roots. All converge<1e-3N. Full vectors at the two actual faces and equilibrium balances are recorded. Do not transfer the same1.5kN scalar to both ends or both planes.

The numerical result remains DIAGNOSTIC: fixed housing is not an installed stiffness bound; front J404/pin/PTFE axial/seat compliance and full torsion are not solved. Jam shafts show roughly9mrad local slopes and about2mm displacement. The far-end reused normal-interface model is one-way, with one four-stud set, unmeasured material/shell/friction parameters.16histories converge, but original1000N P-250000w proxy reaches0 in a named case; original mapping is NOT closed. Maximum calculated far thin-head force1693.817N is not a full-machine upper bound.1800N/head remains mandatory. Hot hardware histories do not constitute a rebalanced coupled shaft/seat thermal solution. No physical test or fully coupled hot acceptance is claimed.

Manufacturing purpose: scatter machining, gauging and unloaded dimensional fit. Nominal compressed CAD does not authorize loading to its drawn height.1450..1470N is a historical trial target, not process release. Real guarded fixture restraint, individual-force instrumentation, calibration and staged stopping limits must be accepted before spring compression,20N reversal, pressure, torque or heat. The captured mandrel is not a substitute production shaft. Actual shell/flange stiffness is not represented by simple coupons.

Measurements: spring force/height/hysteresis and temperature lag; four simultaneous stud forces; F604 contact/gap; J402 backed and bridge-region compression/recovery; J401 tilt; J407 fitted bore and drag; thrust endplay; side and end squeeze every<=50mm; soft root tear/retention; later leak/pressure-drop/resistance/life in a released rig. Change named replaceable F604/J405/J406/J407/shim groups or S301 adjustment; no unrecorded machining of journals, full threads or capture parts.

R16 inherits two short CSVs for issued batches/ECO and integration holds. Include whole valve/R13 trims/R14 dry input/L1-F02 together, close input removal, guard reach, welded frame/floor, actual transfer/handling, P space and R root. R14 final PDFs were58pages (10+16+32), with correct final masses; do not repeat stale57page/oldmass errata. R14 time exception remains historical. Full C02 PARTIAL/NOT_FOR_MANUFACTURE; actuator stays a purchased placeholder.

R15 timing is in EXECUTION_LEDGER.json. Signed instruction was obtained after user completed Cloudflare; T0 was NOT reset. Formal file return then40minutes, one read only for signedR16. R16 completion stops the sequence; noR17 or new red-team window.

Actual engineering freeze: 2026-10-12T13:35:59Z; 51.5 minutes; 3 recorded iterations. Remaining allowance is not a new engineering authorization.
