import json,hashlib
import build_c02 as b
E=b.OUT/'evidence';base=b.ROOT.parent/'R12_WORK/deliverables/native';P=json.loads((base/'PARAMETRIC_PARTS_C02.json').read_text());O=json.loads((base/'OCCURRENCES_C02.json').read_text());pm={p['pn']:p for p in P};wp=json.loads((b.OUT/'native/R15_WET_INTERFACE_REFERENCE.json').read_text());trim=next(p for p in wp if p['pn']=='B200_R13');bp=json.loads((b.ROOT.parent/'R14_WORK/deliverables/native/R14_PARTS.json').read_text());coupling=next(p for p in bp if p['pn']=='BUY_R13_BK2');sel={'B200','J401','J407','J403','J404','J405','J406','A709'};occ=[];parts={};shapes={}
for o in O:
 if o['pn'] not in sel:continue
 p=trim if o['pn']=='B200' else pm[o['pn']];q=dict(o);q['pn']=p['pn'];q['occurrence']='R15REF_'+q['occurrence'];parts[p['pn']]=p;occ.append(q)
parts[coupling['pn']]=coupling
for tag,origin in [('P2',[-439,-970.5,1533]),('P1',[-439,-970.5,1368]),('R',[-82,-970.5,1583])]:occ.append(dict(pn=coupling['pn'],occurrence='R15REF_BK2_'+tag,o=[origin[0],origin[1]+162,origin[2]],u=[0,0,-1],v=[1,0,0],n=[0,-1,0],scope='REFERENCE',note='Purchased annular envelope only; no vendor detail/capacity approval'))
for o in occ:shapes[o['occurrence']]=b.tr(b.ex.readshape(parts[o['pn']]['brep']),o['o'],o['u'],o['v'],o['n'])
b.dump(b.OUT/'native/R15_WET_SECTION_REFERENCE_PARTS.json',list(parts.values()));b.dump(b.OUT/'native/R15_WET_SECTION_REFERENCE_OCCURRENCES.json',occ)
b.ex.export_step('AT_DMP_R15_THREE_ROTOR_WET_SECTION_REFERENCE',[dict(definition=o['occurrence'],occurrence=o['occurrence'],scope='REFERENCE') for o in occ],shapes)
b.dump(E/'R15_SOURCE_BINDING.json',dict(R12_files=[dict(path=str(f.relative_to(b.ROOT.parent)),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()) for f in [base/'PARAMETRIC_PARTS_C02.json',base/'OCCURRENCES_C02.json']],scope='Selected physical section, not full valve/bench installation. Omitted fasteners/static and dynamic seals remain necessary; no assembly release implied. Trimmed shafts are reference not SP04 order.',source_parts=[dict(PN=p['pn'],brep_sha256=hashlib.sha256(p['brep'].encode()).hexdigest()) for p in parts.values()]))
print('WET SECTION',len(occ),flush=True)
