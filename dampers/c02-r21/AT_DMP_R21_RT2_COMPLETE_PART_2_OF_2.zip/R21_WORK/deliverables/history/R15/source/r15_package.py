from pathlib import Path
import json,hashlib,zipfile,shutil
R=Path(__file__).resolve().parents[1];D=R/'deliverables';E=D/'evidence';out=R/'delivery';out.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pack(target,entries):
 manifest=[]
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,6) as z:
  for p,name in entries:
   z.write(p,name);manifest.append(dict(path=name,bytes=p.stat().st_size,sha256=sha(p)))
  z.writestr('MANIFEST.json',json.dumps(manifest,indent=2))
 with zipfile.ZipFile(target) as z:
  if z.testzip():raise ValueError('CRC')
  for q in manifest:
   data=z.read(q['path'])
   if len(data)!=q['bytes'] or hashlib.sha256(data).hexdigest()!=q['sha256']:raise ValueError(q)
 return dict(file=target.name,bytes=target.stat().st_size,sha256=sha(target),CRC_members=len(manifest)+1,manifest_items=len(manifest),verified=True)
qa=json.loads((E/'R15_FINAL_QA.json').read_text());qa['PDF_visual_review']='All48pages rendered; montages inspected, changed actual section page inspected individually after caption correction; final foil coordinate pages inspected.';(E/'R15_FINAL_QA.json').write_text(json.dumps(qa,indent=2))
ledger=json.loads((R/'EXECUTION_LEDGER.json').read_text(encoding='utf-8-sig'));report=D/'L2_TO_L1_R15_RETURN_EN.md';report.write_text(report.read_text()+'\nActual engineering freeze: '+ledger['engineering_frozen_utc']+'; '+str(ledger['engineering_minutes'])+' minutes; '+str(ledger['actual_iterations'])+' recorded iterations. Remaining allowance is not a new engineering authorization.\n')
factory=[D/'drawings/AT_DMP02_C02_R15_SP04_MANUFACTURING_CANDIDATE_EN.pdf',D/'tables/R15_SP04_BOM.csv',D/'tables/R15_FACTORY_RETURN.csv',report]+list((D/'step/parts').glob('*.stp'))+list((D/'dxf').glob('*.dxf'))+[D/'step/AT_DMP_R15_FIXED_END_REFERENCE.stp',D/'step/AT_DMP_R15_D542_TOOL_POSES.stp']
receipt=[pack(out/'AT_DMP_R15_SP04_FABRICATION_CANDIDATE_20261012.zip',[(p,str(p.relative_to(D)).replace('\\','/')) for p in factory])]
# Minimal accurate historical dependencies, preserving sibling folders required by the reused source.
deps=['R12_WORK/deliverables/native/PARAMETRIC_PARTS_C02.json','R12_WORK/deliverables/native/OCCURRENCES_C02.json','R12_WORK/deliverables/native/KITS_C02.json','R13_WORK/deliverables/native/R13_WET_INTERFACE_PARTS.json','R13_WORK/source/r13_documents.py','R13_WORK/deliverables/SOURCE_REGISTER.json','R14_WORK/deliverables/native/R14_PARTS.json','R14_WORK/deliverables/evidence/R14_CONTROL_REACTIONS.json','R14_WORK/deliverables/evidence/R14_TWO_PLANE_DEFLECTION_SENSITIVITY.json','R10_WORK/source/r10_a_contact.py','R10_WORK/deliverables/evidence/R10_ROOT_GEOMETRY.json','R9_WORK/deliverables/evidence/R9_HOOD_LOAD_CHAIN.json','R9_WORK/source/r9_documents.py','R7_WORK/source/r6_finite_base.py']
files=list(D.rglob('*'))+list((R/'source').glob('*.py'))+[R/'EXECUTION_LEDGER.json'];files=[p for p in files if p.is_file()]
entries=[(p,str(p.relative_to(R.parent)).replace('\\','/')) for p in files]
entries += [(R.parent/p,p) for p in deps]
entries += [(p,str(p.relative_to(R.parent)).replace('\\','/')) for p in (R.parent/'R15_INPUT').rglob('*') if p.is_file()]
entries += [(out/'AT_DMP_R15_SP04_FABRICATION_CANDIDATE_20261012.zip','R15_WORK/delivery/AT_DMP_R15_SP04_FABRICATION_CANDIDATE_20261012.zip')]
receipt.append(pack(out/'AT_DMP02_C02_R15_ENGINEERING_RETURN_20261012.zip',entries))
(out/'LOCAL_RECEIPT.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt,indent=2))
