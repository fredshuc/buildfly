import json,math
from pathlib import Path
import numpy as np
import build_c02 as b
R=b.ROOT.parent;E=b.OUT/'evidence'
source=R/'R10_WORK/source/r10_a_contact.py';ns={'__file__':str(source)}
exec(source.read_text().split('params=[')[0],ns)
rows=json.loads((E/'R15_SIGNED_WET_RESPONSE.json').read_text())['cases'];out=[]
# Single inherited, explicitly unmeasured mid sensitivity. No fitting until it passes.
model=ns['Model'](6.,1.,1e6,4000);q0,d0,res0,it0=model.calibrate();P0=model.P.copy()
for r in rows:
 far=r['ends'][1];F=np.array(far['F_worldXYZ_N']);M=np.array(far['M_worldXYZ_Nmm'])
 u=np.array([0,0,1]) if r['rotor']=='R' else np.array([1,0,0]);v=np.array([1,0,0]) if r['rotor']=='R' else np.array([0,0,-1])
 moment=np.array([-M@v,M@u]);f=np.zeros(ns['nd']);f[ns['jt']+1:ns['jt']+3]+=(15/40)*moment/ns['L'];f[ns['jb']+1:ns['jb']+3]+=(25/40)*moment/ns['L']
 # Far-end gland at20C in every named selected row. Add two independent hardware temperature histories on jam row, not a different load row.
 histories=[('cold20',20,20,False)] if not r['jam'] else [('cold20',20,20,False),('hardware70_studMinus10',70,-10,False),('hardwareMinus10_stud70_loss',-10,70,True)]
 for name,Ts,Tb,loss in histories:
  seg=[(3,17.2e-6,100,185000),(.5,17.2e-6,80,185000),(40,17.2e-6,100,185000),(4.5,17.2e-6,100,185000),(1,11.5e-6,108.94,210000),(4.5,12e-6,None,None)];L=sum(x[0] for x in seg);keq=1/(L/(185000*20.1)+1/4000+sum(l/(a*ee) for l,al,a,ee in seg if ee));dt=keq*(sum(l*al*(Ts-20) for l,al,a,ee in seg)-L*11.9e-6*(Tb-20))-(keq*.008+20 if loss else 0)
  model.P=P0+dt;q,d,res,it=model.solve(f,q0)
  proxy=np.maximum(0,1460+dt-250000*(ns['Vs']@(q-q0)));Fn=np.linalg.norm(F[[0,2]]);cap=min(sum(d['gasket'])+sum(d['stop']),sum(d['hard']))
  model.P=P0;qr,dr,rr,ir=model.solve(np.zeros(ns['nd']),q)
  out.append(dict(case=r['case'],end='far_A709',hardware_history=name,hardware_C=Ts,stud_C=Tb,thermal_force_delta_N=dt,bolt_total_N=d['bolt'].tolist(),original_P_minus_250000w_proxy_N=proxy.tolist(),gasket_compression_mm=[float(min(.3-d['root_gap'])),float(max(.3-d['root_gap']))],gasket_open_cells=int(sum(d['gasket']==0)),F604_gap_mm=d['stop_gap'].tolist(),F604_contact_N=d['stop'].tolist(),J401_root_tilt_mrad=(q[ns['jb']+1:ns['jb']+3]/ns['L']*1000).tolist(),root_moment_worldXYZ_Nmm=M.tolist(),transverse_worldXYZ_N=F.tolist(),slip_capacity_at_mu012_N=.12*cap,no_slip_screen=Fn<=.12*cap,elastic_cold_unload_difference_mm=float(max(abs(qr-q0))),residual_N=res,converged=res<1e-3,scope='One-way far-end normal-interface diagnostic only. Four through-studs once; no feedback to radial beam. Unmeasured Eapp6MPa, shell factor1, foundation1e6N/mm and stack4000N/mm. Hot hardware rows superpose thermal preload on same mechanical reaction but do NOT re-solve shaft/seat thermal pose: not fully coupled hot qualification. Front J404 must not inherit A709 model. Elastic unload is conditional on no slip and material domain.'))
b.dump(E/'R15_FAR_CONTACT_DIAGNOSTIC.json',dict(cases=out,metric_status='1000N ORIGINAL_PROXY_MAPPING_HOLD; 1800N total force per physical thin head retained',front='J404/thrust-capture normal compliance NOT solved here; machining only',test_performed=False))
print('CONTACT',len(out),'converged',sum(x['converged'] for x in out),'maxbolt',max(max(x['bolt_total_N']) for x in out),flush=True)
