import json,itertools
import numpy as np
import build_c02 as b
from r11_common import volume
E=b.OUT/'evidence';P=json.loads((b.OUT/'native/R15_SP04_PARTS.json').read_text());pm={p['pn']:p for p in P};tool=b.ex.readshape(pm['D542']['brep']);rp=json.loads((b.OUT/'native/R15_FIXED_END_REFERENCE_PARTS.json').read_text());s={p['pn']:b.ex.readshape(p['brep']) for p in rp};O=json.loads((b.OUT/'native/R15_FIXED_END_REFERENCE_OCCURRENCES.json').read_text());world={o['occurrence']:b.tr(s[o['pn']],o['o'],o['u'],o['v'],o['n']) for o in O};rows=[];defs={};rr=[]
for x,y in itertools.product([-24,24],repeat=2):
 sg=1 if y>0 else -1
 for shift in [0,5,10,15,20,25]:
  sh=b.tr(tool,(x,y+sg*shift,-6),(sg,0,0),(0,sg,0),(0,0,1));bb=b.ex.bb(sh);hits=[]
  for name,other in world.items():
   bo=b.ex.bb(other)
   if any(bb[i+3]<bo[i]-1e-6 or bo[i+3]<bb[i]-1e-6 for i in range(3)):continue
   vv=volume(sh,other)
   if vv>.001:hits.append([name,vv])
  rows.append(dict(stud_xy=[x,y],withdrawal_mm=shift,hard=hits,passed=not hits))
  if shift==0:name=f'D542_{x}_{y}';defs[name]=sh;rr.append(dict(definition=name,occurrence=name,scope='FIXTURE'))
b.ex.export_step('AT_DMP_R15_D542_TOOL_POSES',rr,defs)
b.dump(E/'R15_TOOL_CHECK.json',dict(positions=rows,all_pass=all(x['passed'] for x in rows),scope='Four actual D542 poses and six discrete25mm withdrawals; not continuous sweep or hand/access qualification. Coupon planeZ=-3..0, toolZ=-6..-3. No dry preload tightening authorised.'))
print('TOOLS',len(rows),sum(x['passed'] for x in rows),flush=True)
