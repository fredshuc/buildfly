from pathlib import Path
import json,hashlib,csv,zipfile,shutil,datetime
import numpy as np
from pypdf import PdfReader
import ezdxf
R=Path(__file__).resolve().parents[1];D=R/'deliverables';E=D/'evidence'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
P=read(D/'native/R15_SP04_PARTS.json');old={p['pn']:p for p in read(R.parent/'R12_WORK/deliverables/native/PARAMETRIC_PARTS_C02.json')};unchanged=[]
for p in P:
 if p['pn'] in old:
  same=p['brep']==old[p['pn']]['brep']
  if not same:raise ValueError(('unexpected inherited geometry change',p['pn']))
  unchanged.append(dict(PN=p['pn'],BRep_byte_identical=True,sha256=hashlib.sha256(p['brep'].encode()).hexdigest()))
for f in (D/'dxf').glob('*.dxf'):
 doc=ezdxf.readfile(f)
 if doc.units!=4 or len(doc.modelspace())==0 or doc.audit().errors:raise ValueError(('DXF',f))
proof=read(E/'R15_PART_STEP_READBACK.json')
if len(proof)!=len(P) or not all(q['passed'] for q in proof):raise ValueError('part QA')
if read(E/'R15_REFERENCE_COLLISION.json')['hard']:raise ValueError('hard interference')
wet=read(E/'R15_SIGNED_WET_RESPONSE.json')['cases'];ct=read(E/'R15_FAR_CONTACT_DIAGNOSTIC.json')['cases']
if not all(q['converged'] for q in wet+ct):raise ValueError('unconverged diagnostic')
pdfs={p.name:len(PdfReader(str(p)).pages) for p in (D/'drawings').glob('*.pdf')}
if list(sorted(pdfs.values()))!=[9,39]:raise ValueError(pdfs)
bom=[]
for i,p in enumerate(P):bom.append(dict(PN=p['pn'],batch=p['batch'],quantity=p['quantity'],material=p['material'],drawing=p['drawing'],drawing_page=i+6,drawing_pdf='AT_DMP02_C02_R15_SP04_MANUFACTURING_CANDIDATE_EN.pdf',STEP='step/parts/'+p['pn']+'_R15.stp',DXF='dxf/'+p['pn']+'_R15.dxf' if (D/'dxf'/f"{p['pn']}_R15.dxf").exists() else '',status='P1_FABRICATION_CANDIDATE'))
with (D/'tables/R15_SP04_BOM.csv').open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(bom[0]));w.writeheader();w.writerows(bom)
with (D/'tables/R15_FACTORY_RETURN.csv').open('w',newline='',encoding='utf-8-sig') as f:csv.writer(f).writerow(['physical_revision_serial','PN','critical_dimensions','assembly_problem','raw_measurement_file','uncertainty_temperature','engineering_disposition','P1_replacement','P2_change'])
ledger=[['A01/A02/B01','R12-L1/E01','31 PN119pieces','Same original scopes; E01 only one B measurement set'],['SP01','R13-L1-F01','3 PN3pieces','D878/TF880/TF884 scatter/unloaded'],['SP02/SP03','R14-L1-F02','43 PN103pieces','Scatter only; TF903..908 not welded/load-rated bench'],['SP04','R15 candidate','34 PN134pieces','Not issued; no full valve or loaded/hot test release']]
with (D/'tables/R16_RELEASE_AND_ECO_LEDGER.csv').open('w',newline='',encoding='utf-8-sig') as f:csv.writer(f).writerows([['batch','revision','quantity','scope']]+ledger)
issues=[['G1','two-plane measured stiffness/thermal DB behaviour','R14 separate box + R13 interfaces','No loaded system acceptance'],['Wet front end','J404 thrust/pin, axial/seat compliance','R15 s0/46/52.09 and original four-stud chain','Do not reuse A709 plate model'],['Wet coupled contact','radial/root/thermal feedback and actual seal laws','R15 signed rows + R10 one-way diagnostics','Original1000N mapping unresolved; 1800N remains'],['Dynamic seal','worst tolerance movement, retention tear, leakage and drag','Free cuts vs unchanged R12 installed geometry','No full four-state rerun'],['Input/service','complete dismantling and measured transfer','R14 input, split cradles and original wet capture','No remove-before-support'],['Guard','reach/ports/containment/tool travel','R14 G900..G904/TF909','No powered test'],['Frame/floor','actual welds, restraint, slip and weighed handling','TF903..908 plus SP01 and ground','43 scatter release not bench rating'],['Host/roots','P real space and R replacement root','P host interface; R01/G843 deferred','No assumed host stiffness'],['Actuator','purchased placeholder/interface only','Mechanical shaft/limited input retained','Await supplier CAD'],['External review','R16 overall package then STOP','User transfers to external red team','Do not startR17 or a red-team window']]
with (D/'tables/R16_INTEGRATION_OPEN_ITEMS.csv').open('w',newline='',encoding='utf-8-sig') as f:csv.writer(f).writerows([['item','next_evidence','accurate_interface','restriction']]+issues)
summary=dict(inherited_unchanged=unchanged,new_PNs=[p['pn'] for p in P if p['pn'] not in old],part_STEP=len(proof),assembly_STEP_instances=[62,45],tool_STEP_instances=4,DXF=len(list((D/'dxf').glob('*.dxf'))),PDF_pages=pdfs,local_collision_pairs=1891,unapproved_hard_intersections=0,tool_discrete_positions=24,wet_rows=len(wet),contact_histories=len(ct),max_wet_force_balance_N=max(max(abs(v) for v in r['force_balance_N']) for r in wet),max_wet_moment_balance_Nmm=max(max(abs(v) for v in r['moment_balance_Nmm']) for r in wet),physical_tests=False,full_C02='PARTIAL / NOT_FOR_MANUFACTURE',historical_fullvalve_hard_counts=[9,9,23,23],historical_scope='Inherited unchanged coverage only; no new full-valve collision pass claimed',failures=[{'stage':'First STEP export','reason':'STP extension required explicit STEP exporter; stopped before output proof, corrected without geometry change'},{'stage':'First drawing generation','reason':'Missing HexColor import; stopped, corrected; incomplete PDF replaced before final rendering'},{'stage':'Section page QA','reason':'Caption overlap corrected and final PDF re-rendered'}])
(E/'R15_FINAL_QA.json').write_text(json.dumps(summary,indent=2))
report='# R15 formal engineering return - SP04 wet manufacturing candidates\n\n'
for batch in ['SP04-A','SP04-B','SP04-C','SP04-PURCHASE']:
 pp=[p for p in P if p['batch']==batch];report+=f"## {batch}: {len(pp)} PN / {sum(p['quantity'] for p in pp)} pieces\n\n"+', '.join(p['pn']+' x'+str(p['quantity']) for p in pp)+'\n\n'
report+='''Total34 PN134pieces, all P1_FABRICATION_CANDIDATE pending L1 issue. A is one fixed-end measurement set, not six machine glands. B supplies one P/R set of dynamic free foam and grouped side shims plus one J402 static coupon. C is test-only. Procurement is listed separately. No factory order or physical work performed. Previous77distinctPN225pieces remain issued under original scope; no ECO to their geometry.

New geometry is four true FREE cutting definitions and TF910L/R split-wall coupons plus a positively captured TF912 mandrel.27inherited PN BReps remain byte-identical. J404 obsolete three-disc note replaced with current two-series/three-parallel six-disc stack. Shim pages now contain full profile coordinates, not a reference to an absent proxy drawing. No new main bearing or whole-valve product geometry.

Same-version evidence:34part STEP independent readbacks; fixed-end62instances, three-rotor selected wet section45instances and four actual tool poses independently exported/read back.16DXFs re-opened;39page manufacturing and9page engineering PDFs rendered and visually checked.1891nominal coupon pairs have zero hard overlaps;24discrete D542 positions pass. These are not continuous sweeps, hand access or loaded fixture qualification. No whole-valve four-state run; historical9/9/23/23 retained, not cleared.

Exact wet mapping: physical bearing land centres s15/-652 give667mm span;637mm is wall-face spacing. R13-trimmed rotor mass6.185329kg. Thrust pin s46 to wet grip centroid103.5 gives57.5mm effective wet thermal segment; dry endpoint motion remains independent. Ten selected signed pressure/normal/jam/stop rows solve finite-land thermal radial clearance with fixed housing roots. All converge<1e-3N. Full vectors at the two actual faces and equilibrium balances are recorded. Do not transfer the same1.5kN scalar to both ends or both planes.

The numerical result remains DIAGNOSTIC: fixed housing is not an installed stiffness bound; front J404/pin/PTFE axial/seat compliance and full torsion are not solved. Jam shafts show roughly9mrad local slopes and about2mm displacement. The far-end reused normal-interface model is one-way, with one four-stud set, unmeasured material/shell/friction parameters.16histories converge, but original1000N P-250000w proxy reaches0 in a named case; original mapping is NOT closed. Maximum calculated far thin-head force1693.817N is not a full-machine upper bound.1800N/head remains mandatory. Hot hardware histories do not constitute a rebalanced coupled shaft/seat thermal solution. No physical test or fully coupled hot acceptance is claimed.

Manufacturing purpose: scatter machining, gauging and unloaded dimensional fit. Nominal compressed CAD does not authorize loading to its drawn height.1450..1470N is a historical trial target, not process release. Real guarded fixture restraint, individual-force instrumentation, calibration and staged stopping limits must be accepted before spring compression,20N reversal, pressure, torque or heat. The captured mandrel is not a substitute production shaft. Actual shell/flange stiffness is not represented by simple coupons.

Measurements: spring force/height/hysteresis and temperature lag; four simultaneous stud forces; F604 contact/gap; J402 backed and bridge-region compression/recovery; J401 tilt; J407 fitted bore and drag; thrust endplay; side and end squeeze every<=50mm; soft root tear/retention; later leak/pressure-drop/resistance/life in a released rig. Change named replaceable F604/J405/J406/J407/shim groups or S301 adjustment; no unrecorded machining of journals, full threads or capture parts.

R16 inherits two short CSVs for issued batches/ECO and integration holds. Include whole valve/R13 trims/R14 dry input/L1-F02 together, close input removal, guard reach, welded frame/floor, actual transfer/handling, P space and R root. R14 final PDFs were58pages (10+16+32), with correct final masses; do not repeat stale57page/oldmass errata. R14 time exception remains historical. Full C02 PARTIAL/NOT_FOR_MANUFACTURE; actuator stays a purchased placeholder.

R15 timing is in EXECUTION_LEDGER.json. Signed instruction was obtained after user completed Cloudflare; T0 was NOT reset. Formal file return then40minutes, one read only for signedR16. R16 completion stops the sequence; noR17 or new red-team window.
'''
(D/'L2_TO_L1_R15_RETURN_EN.md').write_text(report,encoding='utf-8')
shutil.copy2(R.parent/'R13_WORK/deliverables/SOURCE_REGISTER.json',D/'INHERITED_SOURCE_REGISTER.json')
(D/'README_REPRODUCTION.md').write_text('Extract the complete archive with sibling R15_WORK/R12_WORK/R13_WORK/R14_WORK/R10_WORK/R9_WORK/R7_WORK folders. CadQuery/OCP, NumPy/SciPy, ReportLab/pypdf, ezdxf and Poppler are required; no new solver platform. Set AT_C02_FONT to a compatible NotoSansSC font. Run geometry -> wet_response -> contact -> export -> tools -> wet_export -> documents -> render -> closeout. Historical source files are dependencies only; do not run their complete old engineering loops. R15 outputs are manufacturing candidates, not load-test permissions. All exact input fingerprints and limitations travel with the return.',encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k!='inherited_unchanged'},indent=2))
