import json,hashlib,zipfile,shutil
from pathlib import Path
R=Path('R18_WORK');D=R/'deliverables';O=R/'delivery';O.mkdir(exist_ok=True)
qa={'PDF_pages':99,'rendered':99,'visual_review':'All17montages reviewed; final changedSP05cover andWS17integrationpages rechecked, no clipping/overlap observed.','STEP_files':52,'DXF_files':26,'limits':'Geometry readback and drawing checks are not physical manufacture or load qualification.'}
(D/'evidence/R18_FINAL_DELIVERY_QA.json').write_text(json.dumps(qa,indent=2))
(D/'FACTORY_README.txt').write_text('R18 P1 FACTORY CANDIDATES - NOT RELEASED BY L1\n33 manufacturing-state PN /101 pieces =100 newpieces +oneG903 replacement/rework position.\nRead the three English PDF booklets with tables/R18_CANDIDATE_BATCHES.csv. Quantity is per first P/R prototype set withsharedrig, not duplicated for alternative states.\nB200_R13 x3 andR100S x1 are assembly operations using the listed looseparts, notextra purchases.\nFour half-shell weld routes andWS17welding areONHOLD. Reference STEP files are not procurement lines. No shell weld execution underthisissue.\nRAW/FREE part states replace their installed references;neverstackboth.\nSTEP mm exact nominal geometry; PDF tolerances, threads, materials andprocesscontrol govern. DXF outlines are1:1mm. G903DXF usespartX/Zas2D X/Y.\nNo assembly rotation, clamping preload, pressure, heating, structural proof orcapture/feedback qualification released. Factory progressunconfirmed. Send measureddata usingthe includedform.\n')
# Self-contained manufacturing selection, explicitly omitting failed deposit solids and engineering audit.
factory={}
for sub in ['step/parts','dxf','tables']:
 for f in (D/sub).rglob('*'):
  if f.is_file():factory[str(f.relative_to(D)).replace('\\','/')]=f
for f in (D/'drawings').glob('*.pdf'):factory['drawings/'+f.name]=f
for rel in ['step/R18_ROTOR_WELD_FIXTURE.stp','step/R100S_R18_WELD_MATERIAL.stp','native/R18_SHELL_ASSEMBLIES.json','FACTORY_README.txt']:factory[rel]=D/rel

def pack(name,files):
 rows=[dict(path=k,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for k,p in sorted(files.items())];path=O/name
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for k,p in sorted(files.items()):z.write(p,k)
  z.writestr('MANIFEST_SHA256.json',json.dumps(rows,indent=2))
 with zipfile.ZipFile(path) as z:
  if z.testzip() is not None:raise ValueError('CRC')
  for q in rows:
   data=z.read(q['path'])
   if len(data)!=q['bytes'] or hashlib.sha256(data).hexdigest()!=q['sha256']:raise ValueError(q['path'])
 return dict(file=str(path.resolve()),bytes=path.stat().st_size,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),members=len(rows)+1,manifest_entries=len(rows),CRC_and_manifest='PASS')
a=pack('AT_DMP_P1_R18_SP05_ROTOR_FACTORY_CANDIDATES_20261012.zip',factory)
eng={}
for folder in [D,R/'source']:
 for f in folder.rglob('*'):
  if f.is_file() and '__pycache__' not in f.parts:eng[str(f).replace('\\','/')]=f
for f in (R/'qa').glob('*montage*.jpg'):eng[str(f).replace('\\','/')]=f
for f in [R/'EXECUTION_LEDGER.json',R/'delivery'/Path(a['file']).name]:eng[str(f).replace('\\','/')]=f
base=['R17_WORK/deliverables/native/R17_PARTS.json','R17_WORK/deliverables/native/R17_P_OCCURRENCES.json','R17_WORK/deliverables/native/R17_R_OCCURRENCES.json','R17_WORK/deliverables/tables/R17_W1_DISPOSITION.csv','R12_WORK/deliverables/native/KITS_C02.json','R15_WORK/deliverables/evidence/R15_SIGNED_WET_RESPONSE.json']
for v in base:eng[v]=Path(v)
for f in Path('R18_INPUT').rglob('*'):
 if f.is_file():eng[str(f).replace('\\','/')]=f
b=pack('AT_DMP02_C02_R18_ENGINEERING_RETURN_20261012.zip',eng)
for f in (D/'drawings').glob('*.pdf'):shutil.copy2(f,O/f.name)
report=D/'L2_TO_L1_AT_DMP02_C02_R18_RETURN_20261012_EN.md';shutil.copy2(report,O/report.name)
(O/'PACKAGE_RECEIPT.json').write_text(json.dumps([a,b],indent=2));print(json.dumps([a,b],indent=2))
