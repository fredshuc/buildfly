import json,math
import numpy as np
import build_c02 as b
N=b.OUT/'native';E=b.OUT/'evidence';pm={p['pn']:p for p in json.loads((N/'R18_PARTS.json').read_text())};a=json.loads((N/'R18_SHELL_ASSEMBLIES.json').read_text())['R100S'];A=np.array(a['reference_world_matrix']);o=np.array(a['reference_world_origin']);ws=[]
for x,sx in [(-172,1),(8,-1)]:
 for y,sy in [(-723,1),(-93,-1)]:
  p=[(x,y,1468),(x+sx*math.sqrt(2),y,1468),(x,y+sy*math.sqrt(2),1468)];wire=b.cq.Wire.makePolygon([b.vec(v) for v in p+[p[0]]]);s=b.cq.Solid.extrudeLinear(wire,[],b.vec((0,0,20)));ws.append(s)
parts=[b.tr(b.ex.readshape(pm[q['pn']]['brep']),A@np.array(q['o'])+o,A@np.array(q['u']),A@np.array(q['v']),A@np.array(q['n'])) for q in a['items']];rows=[];checks=[]
for i,s in enumerate(ws):
 touches=[j for j,p in enumerate(parts) if s.distance(p)<.001];checks.append(dict(seam=i+1,touches=touches,pass_=len(touches)==2))
 ss=b.tr(s,-A.T@o,A.T[:,0],A.T[:,1],A.T[:,2]);rows.append(dict(id=f'R100S_W{i+1}',brep=b.brep(ss),bbox=b.ex.bb(ss)))
b.dump(N/'R18_RISER_WELDS.json',rows);b.dump(E/'R18_RISER_WELD_CHECK.json',checks);b.ex.export_step('R100S_R18_WELD_MATERIAL',[dict(definition=q['id'],occurrence=q['id'],scope='R') for q in rows],{q['id']:b.ex.readshape(q['brep']) for q in rows});print(checks)
