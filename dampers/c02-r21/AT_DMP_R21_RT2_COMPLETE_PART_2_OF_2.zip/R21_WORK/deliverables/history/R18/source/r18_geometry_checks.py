import json,itertools,math,collections
import numpy as np
import build_c02 as b
R=b.ROOT.parent;N=b.OUT/'native';E=b.OUT/'evidence';pm={p['pn']:p for p in json.loads((N/'R18_PARTS.json').read_text())};S={pn:b.ex.readshape(p['brep']) for pn,p in pm.items()};ass=json.loads((N/'R18_SHELL_ASSEMBLIES.json').read_text());weld=json.loads((N/'R18_SHELL_WELDS.json').read_text())
def broad(a,c):return all(min(a[k+3],c[k+3])-max(a[k],c[k])>1e-5 for k in range(3))
out=[];worldweld={};transform={}
for pn,a in ass.items():
 A=np.array(a['reference_world_matrix']);o=np.array(a['reference_world_origin']);new=b.tr(S[pn+'_R18REF'],o,A[:,0],A[:,1],A[:,2]);old=S[pn];diff=[abs(new.cut(old).Volume()),abs(old.cut(new).Volume())];out.append(dict(assembly=pn,recomposed_vs_old_mm3=diff,pass_=max(diff)<.001,expanded_parts=len(a['items'])))
 if pn not in weld:continue
 Q=np.array([[0,0,-1],[0,1,0],[1,0,0]]) if pn[0]=='P' else np.eye(3);t=np.array([1451,0,2022]) if pn[0]=='P' else np.zeros(3);AA=Q@A;oo=Q@o+t;transform[pn]=(AA,oo)
 for w in weld[pn]['welds']:worldweld[w['id']]=b.tr(b.ex.readshape(w['brep']),oo,AA[:,0],AA[:,1],AA[:,2])
b.dump(E/'R18_SHELL_RECOMPOSITION.json',out)
hits=[];tested=0
for tag in ['P','R']:
 O=json.loads((R/f'R17_WORK/deliverables/native/R17_{tag}_OCCURRENCES.json').read_text());W={q['occurrence']:b.tr(S[q['pn']],q['o'],q['u'],q['v'],q['n']) for q in O};BB={k:b.ex.bb(s) for k,s in W.items()}
 for wn,w in worldweld.items():
  if not wn.startswith(tag):continue
  wb=b.ex.bb(w)
  for q in O:
   k=q['occurrence']
   if not broad(wb,BB[k]):continue
   tested+=1;v=abs(w.intersect(W[k]).Volume())
   if v>.001:hits.append(dict(config=tag,weld=wn,part=k,PN=q['pn'],mm3=v))
 for angle in [5,45,85,90]:
  for q in O:
   if q['pn']!='B200_R13':continue
   sh=W[q['occurrence']];axis=[q['o'][0],0,1583];sgn=-1 if q.get('moving')=='P2' else 1;sh=sh.rotate(axis,[axis[0],-1,axis[2]],sgn*angle);bb=b.ex.bb(sh)
   for wn,w in worldweld.items():
    if not wn.startswith(tag) or not broad(bb,b.ex.bb(w)):continue
    tested+=1;v=abs(w.intersect(sh).Volume())
    if v>.001:hits.append(dict(config=tag,weld=wn,part=q['occurrence'],PN=q['pn'],angle_deg=angle,mm3=v))
b.dump(E/'R18_SHELL_WELD_NEIGHBOURS.json',dict(pairs_boolean=tested,hits=hits,scope='Only new shell deposited material versus all configured neighbours atzero and realrotors5/45/85/90; no fullhistoricalpair rerun'))
# New staged shaft contains finished reference; central blade zone unchanged.
raw=S['B202_R18RAW'];fin=S['B202_R13'];missing=abs(fin.cut(raw).Volume());b.dump(E/'R18_ROTOR_STAGE_CHECK.json',dict(finished_missing_from_raw_mm3=missing,raw_contains_final=missing<.001,raw_bbox=b.ex.bb(raw),final_bbox=b.ex.bb(fin),same_rotor_definition_instances=3,part_order={'B202_R18RAW':3,'B201':6},assembly_operation_count=3,notes='Final reference nominaldiameter30; smaller h7/h8 limits on drawing. Remove4mm sacrificialpads eachend; all finishedpinholes afterwelding.'))
print('RECOMPOSE',[(x['assembly'],x['pass_']) for x in out],'NEIGHBOUR_HITS',len(hits),'RAW_CONTAINS',missing,flush=True)

