import json,csv,math,hashlib
from pathlib import Path
R=Path('R18_WORK');D=R/'deliverables';E=D/'evidence'
# Archive explicit final hold scopes, manufacturing operations and ordinary fixture hardware.
ops=[dict(PN='B200_R13',quantity=3,operation='Weld/straighten/finish/inspect, using3B202_R18RAW+6B201 already counted',status='P1_FABRICATION_CANDIDATE_PENDING_L1'),dict(PN='R100S',quantity=1,operation='Weld four R112/R113 sheets already counted inSP05',status='P1_WELD_FABRICATION_CANDIDATE_PENDING_L1')]+[dict(PN=k,quantity=1,operation='Do not weld orpost-machine until204neighbour conflicts resolved',status='WELD_HOLD_NOT_SUBMITTED') for k in ['P100F','P100B','R100F','R100B']]
(D/'tables/R18_ASSEMBLY_OPERATIONS.json').write_text(json.dumps(ops,indent=2))
hw=[dict(item='ISO4762 M8x85 class8.8',quantity=4,use='TF931toTF930'),dict(item='ISO7089 M8 washer,1.6mm',quantity=4,use='Under four screwheads'),dict(item='External toolmaker clamps',quantity=6,use='Oneat eachTF932blade rest; actual reach verified by fabricator beforetacking'),dict(item='Smooth padded shaft hold-down straps/clamps',quantity=2,use='AtVblocks, no teeth onfuturejournal; indicate axis afterclamping')]
(D/'tables/R18_ROTOR_SHOP_HARDWARE.json').write_text(json.dumps(hw,indent=2))
# Actual stop lever distinction and physical response outputs in one reproducible record.
d=json.loads((E/'R18_STOP_TO_SEAL_MAP.json').read_text());d['actual_contact_normal']='worldX';d['actual_torque_arm_range_mm']=[50,80];d['uniform_pressure_torque_arm_mm']=65;d['centroid_radial_distance_mm']=65.76473218982953
for T in [78,200]:
 radius=65;F=T*1000/radius;delta=F*155**3/(3*200000*81000);theta=delta/radius;d['rows'].append(dict(T_Nm=T,contact_radius_mm=radius,force_N=F,stop_deflection_mm=delta,shaft_angle_deg=math.degrees(theta),blade_edge_displacement_mm=77*math.sin(theta),scope='Uniform-pressure centroid normal-X lever65mm; fixedrootdiagnostic, not pressure redistribution solution'))
(E/'R18_STOP_TO_SEAL_MAP.json').write_text(json.dumps(d,indent=2))
# Configuration scope index prevents manufacturing-state parts being installed as extra layers.
(D/'native/R18_CONFIGURATION_README.txt').write_text('R18 installed P/R occurrence lists inherit R17 exactly except one G903->G903_R18 substitution each. P and R are alternate assemblies using the shared dry test rig; guard ECOquantity1. RAW and FREE manufacturing definitions are supply stages, NOT extra installed occurrences. R100S and rotor welding are separately submitted operations; four half-shell welds and WS17 partial welds remain internal HOLD. Original366BReps byte-identical;22newdefinitions include manufacturing references andfixtures, not22newproductPN. Full R17 installed STEP exports may be reused by scope with the explicit guard ECO. No wholevalve load, heat, pressure orcontinuous-path acceptance isadded.\n')
# Copy exact factory measuring record, no fabricated results.
fields=['part_or_serial','revision','material_lot','feature_or_stage','nominal_and_tolerance','measured_value','instrument','date_operator','deviation','disposition','engineering_return_reference']
with (D/'tables/R18_FACTORY_INSPECTION_RETURN.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(fields)
 for pn,ft,req in [('B200_R13/P1','final shaft length','825.50+/-0.10'),('B200_R13/P2','journal runout','<=0.03'),('B200_R13/R','blade sweep','radius<=77.10'),('R100S','free-state planes','flat0.20/parallel0.20'),('G903_R18','trimmed length','1046.50+/-0.20'),('SP05soft','incoming free thickness','per PN sheet; no installed thickness asstock')]:w.writerow([pn,'R18','',ft,req,'','','','','',''])
print('operations and measurement records written')
