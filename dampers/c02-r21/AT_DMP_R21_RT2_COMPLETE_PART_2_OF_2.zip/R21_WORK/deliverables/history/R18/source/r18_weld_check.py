import json,itertools
import build_c02 as b
N=b.OUT/'native';E=b.OUT/'evidence';pm={p['pn']:p for p in json.loads((N/'R18_PARTS.json').read_text())};ass=json.loads((N/'R18_SHELL_ASSEMBLIES.json').read_text());weld=json.loads((N/'R18_SHELL_WELDS.json').read_text());out=[]
for pn,wa in weld.items():
 items=ass[pn]['items'];ss={q['id']:b.tr(b.ex.readshape(pm[q['pn']]['brep']),q['o'],q['u'],q['v'],q['n']) for q in items}
 for w in wa['welds']:
  shape=b.ex.readshape(w['brep']);touch=[];intr=[]
  for k,s in ss.items():
   d=shape.distance(s)
   if d<.001:touch.append(k);v=shape.intersect(s).Volume();intr.append([k,v])
  out.append(dict(assembly=pn,weld=w['id'],touching_parts=touch,part_overlap_mm3=intr,valid=shape.isValid(),attachment_check=len(touch)>=2))
b.dump(E/'R18_WELD_ATTACHMENT_CHECK.json',out);print('WELD ATTACH',len(out),'FAIL',[q['weld'] for q in out if not q['attachment_check']],flush=True)
