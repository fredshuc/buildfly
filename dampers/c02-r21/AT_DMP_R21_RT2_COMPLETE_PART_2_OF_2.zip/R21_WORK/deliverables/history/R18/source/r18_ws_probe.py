import json
from pathlib import Path
p=json.loads(Path('R18_WORK/deliverables/native/R18_PARTS.json').read_text())
for q in p:
 if q['pn'].startswith(('TF920','TF921','TF922','TF923','TF924','TF925','TF926')):
  print(q['pn'],q['bbox'],q['notes'])
for tag in ['P','R']:
 o=json.loads(Path(f'R18_WORK/deliverables/native/R18_{tag}_OCCURRENCES.json').read_text())
 print(tag)
 for q in o:
  if q['pn'].startswith(('TF920','TF921','TF922','TF923','TF924','TF925','TF926')):print(q['pn'],q['o'],q['u'],q['v'],q['n'])
