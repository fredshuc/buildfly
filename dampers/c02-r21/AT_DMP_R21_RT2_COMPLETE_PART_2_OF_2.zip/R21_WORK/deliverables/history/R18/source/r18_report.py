import json,datetime,collections
from pathlib import Path
R=Path('R18_WORK');D=R/'deliverables';E=D/'evidence';t='2026-10-12T19:35:05Z';p=R/'EXECUTION_LEDGER.json';d=json.loads(p.read_text());d['rounds'][-1]['end_utc']=t;d['engineering_frozen_utc']=t;d['status']='ENGINEERING_FROZEN_CLOSEOUT';d['actual_iterations']=3;d['engineering_minutes']=35.6666666667;d['effort_scope']='Principal manufacturing work dominated all three rounds; auxiliaryG903/stop/WS17 work limited to the final checks. Approximately80percent engineering attention on shells/rotors/stablewetmanufacturing, estimated allocation rather than independent stopwatch measurement.';p.write_text(json.dumps(d,indent=2))
c=json.loads((E/'R18_CANDIDATES.json').read_text());tables=[]
for batch in ['SP05','ROTOR','ROTOR_TOOL','GUARD_ECO']:
 qs=[q for q in c if q['batch']==batch];tables.append('| '+batch+' | '+str(len(qs))+' | '+str(sum(q['quantity'] for q in qs))+' | '+', '.join(q['PN']+' x'+str(q['quantity']) for q in qs)+' |')
report='''# R18 manufacturing candidates and engineering return

From L2 MI dampers2 to L1 MI dampers. Signed order AT-DMP02-MFG-C02-R18, 12 October 2026. All new batches below are **P1_FABRICATION_CANDIDATE, pending L1 release**. The complete C02 remains **PARTIAL / NOT_FOR_MANUFACTURE**. Existing L1 releases retain their named scope.

## Proposed factory batches

33 manufacturing-state PN /101 pieces comprise100 newly proposed pieces and one G903 replacement or rework position. P/R are alternate shared-rig configurations; the guard is not ordered twice. Three rotor weld/finish operations and one R100S riser weld operation use already-counted materials and are not additional component purchases.

| Batch | PN | Pieces | Exact proposed supply |
|---|---:|---:|---|
'''+ '\n'.join(tables)+'''

**First independent functional manufacturing group:** B202_R18RAW x3 plus B201 x6, one reusable TF930/TF931/TF932 fixture, and B200_R13 x3 weld/finish/inspect operations. All three rotors have the same actual geometry. The shaft blank includes0.15mm radial finishing stock outside the unchanged blade zone and two removable4mm centre pads; final length825.50mm. The actual connection section, four nominala2 seams, balanced TIG sequence, coupon/WPS hold point, journal protection, straightening, finish grinding, final6H6 pin drilling and serial inspection are defined. Shop hardware is separately listed, including four M8x85 screws/washers and external clamps. Fixture clamp selection/fit is a physical shop setup hold point; clamps are not represented as collision-qualified CAD.

**R100S** is a separate riser welding candidate: R112 x2 plus R113 x2 already withinSP05, four actuala1 corner deposits, exact assembly coordinates,20mm height and free-state plane checks. The four deposits touch the intended sheets and do not intersect current R neighbours. Joining the riser to R107 or an unknown roof is outside this candidate.

**SP05** is a loose-piece/stage batch, not permission to weld four valve half-shells. Raw side plates retain0.25mm radial allowance for paired post-weld axle/gland finishing. Six free-state soft definitions replace installed compressed thicknesses for cutting; they are not extra installed layers. P109/R109 remain isolated because film/foam notes and corner definition conflict. Existing P104/R104 and R17 F04 components are not reordered. Shell-related small-hole patterns and S301 corner relief retain revision exposure from the weld conflicts below; L1 should choose which stage blanks to commit before joint correction.

The factory candidate package contains the BOM, three English drawing booklets, component/reference STEP,26DXF, assembly-operation list, shop hardware and one measurement-return form. Internal failed weld material, source code and detailed collision records stay in the engineering package.

## Shell welding and post-weld machining

Five local shell assemblies were rebuilt from actual split KIT components. Both directions of material difference against inherited unwelded geometry return0. The four half-shell routes define real component placement, seal-face datums, tacking/back-step sequence, distortion control, paired2.00mm hard-spacer setup,38mm axle clearance finishing,6.5mm gland pilots, axis spacing and inspection. They are deliberately **WELD_HOLD, not submitted for execution**.

The48 nominala2 deposited seams touch their intended sheets. However458 evaluated new-weld/neighbour pairs produce204 interference records:100 against HW_W6_1p6_12,32 each against STD08B/HW_W3_0p5_7/HW_N3,6 against S301A and2 against S301B. The new deposits did not intersect the actual rotors at0/5/45/85/90degrees checked. This does not clear the fastener/seat conflicts or the historical whole-valve collisions. Weld size was not reduced to manufacture a pass. Required next correction is a coordinated weld joint, fastening access and seat-corner detail, with affected sheets reissued explicitly.

## Local integration

G903_R18 trims45.50mm from the existing wet-end projection, preserves four mounting holes and13mm front-hole setback, and closes against the shifted G901 end wall. One new panel OR one documented rework replaces the original position. Old F04 G903 remains traceable. Current P minimum P107 gap changes1.000 to39.012818mm; R197.000 to200.823305mm. A stated1.30mm cold manufacturing/position budget leaves37.712818/199.523305mm. No new panel-neighbour intersection appears in these states. These numbers provide no loaded, thermal, fragment or general reach qualification.

The actual tall closed-stop contact is a480mm2 face at worldX=-92, Z1633..1663 about P2 axisX=-82,Z1583. Because force normal isX, the moment arm is50..80mm, with65mm uniform-pressure centroid;65.764732mm radial distance is not that force lever. At normal78Nm, the inherited fixed-root beam diagnostic gives blade-edge upper projections0.184079mm at50mm arm,0.108922mm at65mm,0.071906mm at80mm. The actual pressure distribution and receiver/root/shell compliance remain unsolved. A hypothetical30percent nominal compression with28..32percent setting band leaves0.02 times measured free thickness per direction; this is not an adopted loaded seal criterion. Normal functional acceptance remains HOLD. Proposed cold5/10/20Nm measurement stages require separate test authorization, independent torque measurement, capture and floor support; no200Nm physical proof is requested.

WS17 received34 real deposited seam definitions:8 rail/leg,16 foot,6 cross-rail and4 lower edge-retainer seams. Both P/R checks show intended attachment and no neighbour material intersection. Two actual joint-definition gaps prevent a complete welding candidate: the flush OD20 sleeves have no projecting land for the inheriteda3 fillet, and the retainer upper60mm edge is flush with the rail top, so the second inheriteda4 seam lacks a fillet land. Groove/preparation and the retainer joint must be drawn before welding. Removable receiver/sleeve-bolt/TF925 fixing chain and free-state rail/foot inspection are documented; all ten floor contacts and load distribution remain unqualified.

Load rows preserve the frozen R15 response and correct station fields: bearing stationss15/-652, effective span667mm, wall spacing637mm, coupling centroid103.5mm and near-bearing overhang88.5mm. LOCAL_DRY_STOP identifies P1 input through both gears to the P2 short-shaft/D886/tall-stop/frame path. Wet torque0 does not remove200Nm dry gear transmission. No new batch solve or artificial pressure/maintenance/fault load sum was made.

## Verification and exact model scope

52 STEP files have fresh-document export/readback records covering entity validity/count, bounds and two-direction material difference. The final file fingerprints match those records.26DXF audit without errors/fixes and use millimetres. The three PDFs contain58+12+29=99 pages, all rendered; final visual review is recorded separately. The rotor-stage solid contains the finished reference without missing material. Nominal fixture checks exclude only intended screw/base thread engagement and contain no other hard intersection.

R18 native catalog388definitions retains all366 original BRep strings exactly and adds22 supply-state, fixture, reference or ECO definitions. Installed P1506/R1073 occurrence counts are unchanged, with only G903->G903_R18 substituted in each alternate configuration. Manufacturing RAW/FREE solids and diagnostic weld deposits are not installed as extra layers. Existing complete R17 STEP may be inherited with the explicit guard delta; no fresh whole-valve collision clearance is asserted. Historical wet9/9/23/23 remains unchanged and unrerun.

The signed input archive was1782109bytes, SHA256 d929a6acf078ef0a4058929e19bbd5a96495bec74890a6575d1bc40731fa537b;25ZIP members passed CRC and24manifest entries passed size/hash checks. R17-L1-F04 process corrections are incorporated: TF920P32actualholes; R28references/23actual; S355JRH RHS specification; TF9241Nm seating withdrawn. Cumulative127PN/578pieces is an issued-definition count only; purchase/manufacture/arrival is unconfirmed.

## Remaining scope and timing

G1, actual loaded seal/clamp compliance, thermal coupling, feedback capture/accuracy, full maintenance transfer and operating/pressure qualification remain HOLD. SP04 is one fixed-end measurement station; the other five stations and floating-endSTD04C interfaces remain an explicit supply gap. B01/E01 do not silently become three installed feedback units. The actuator stays a purchased placeholder.

T0 was2026-10-12T18:59:25Z. Engineering froze2026-10-12T19:35:05Z after3 recorded iterations,35.666667minutes. Work emphasis remained shell, rotor and stable wet manufacturing; approximately80percent attention is an estimated allocation, not a separate stopwatch measurement. No remaining engineering allowance is reused. Formal return completion, package fingerprints and Library links will be recorded in the delivery receipt after upload and transmission. Upload UI confirmation does not assert remote re-download hashing or L1 acceptance.

After formal return, the existing automation will be scheduled once for completion+40minutes to read signed R19. It will pause on that claim; no polling if no new order. The user-authorized cycle ends after the R21 return.
'''
# Exact computed65mm row replaces any rounded prose typo.
st=json.loads((E/'R18_STOP_TO_SEAL_MAP.json').read_text());v=next(x['blade_edge_displacement_mm'] for x in st['rows'] if x['T_Nm']==78 and x['contact_radius_mm']==65);report=report.replace('0.108922mm',f'{v:.6f}mm')
(D/'L2_TO_L1_AT_DMP02_C02_R18_RETURN_20261012_EN.md').write_text(report,encoding='utf-8')
print('report',len(report),'centroid edge',v)
