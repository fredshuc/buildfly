import sys,json
import build_c02 as b
pm={p['pn']:p for p in json.loads((b.OUT/'native/R18_PARTS.json').read_text())}
allpn=json.loads((b.OUT/'evidence/R18_EXPORT_LIST.json').read_text())
for pn in allpn:
 s=b.ex.readshape(pm[pn]['brep']);b.ex.export_step('parts/'+pn+'_R18',[dict(definition=pn,occurrence=pn,scope='P')],{pn:s})
print('EXPORTED',len(allpn),flush=True)
