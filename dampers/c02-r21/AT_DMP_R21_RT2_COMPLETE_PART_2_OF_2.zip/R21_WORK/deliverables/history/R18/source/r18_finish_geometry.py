import json,math,numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
import build_c02 as b
N=b.OUT/'native';E=b.OUT/'evidence';pm={p['pn']:p for p in json.loads((N/'R18_PARTS.json').read_text())};S={k:b.ex.readshape(p['brep']) for k,p in pm.items()}
# Freeze known shell-weld rejection in native status.
a=json.loads((N/'R18_SHELL_ASSEMBLIES.json').read_text())
for k in a:a[k]['status']='WELD_HOLD_204_NEIGHBOUR_INTERSECTIONS' if k!='R100S' else 'RISER_WELD_CANDIDATE_PENDING_NEIGHBOUR_CHECK'
b.dump(N/'R18_SHELL_ASSEMBLIES.json',a)
c=json.loads((E/'R18_CANDIDATES.json').read_text());q=dict(c[0]);q.update(PN='G903_R18',quantity=1,batch='GUARD_ECO',geometry_revision='R18_ECO',material='S235JR',replaces='G903 F04 replacement or rework, not additive',drawing='AT_DMP_R18_SHELL_AND_INTEGRATION_EN.pdf',STEP='step/parts/G903_R18.stp');c=[x for x in c if x['PN']!='G903_R18']+[q];b.dump(E/'R18_CANDIDATES.json',c);b.cw('R18_CANDIDATE_BATCHES.csv',c)
# Rotor actual cross-section: thin slice, projected real edges.
fig,ax=plt.subplots(figsize=(13,4));s=S['B200_R13'].intersect(b.box(.02,180,50).translate((308.49,-90,-25)))
for e in s.Edges():
 pts=[e.positionAt(float(t)).toTuple() for t in np.linspace(0,1,2 if e.geomType()=='LINE' else 70)];ax.plot([p[1] for p in pts],[p[2] for p in pts],color='#17445a',linewidth=1)
ax.set_aspect('equal');ax.set_xlim(-20,20);ax.set_ylim(-18,18);ax.grid(alpha=.2);ax.set_xlabel('Blade chord Y mm');ax.set_ylabel('Z mm');ax.set_title('ACTUAL B200_R13 section at X308.5: diameter30 / plate2.5 / four weld regions')
fig.tight_layout();fig.savefig(b.OUT/'drawings/ROTOR_ACTUAL_SECTION.png',dpi=160);plt.close(fig)
# Actual fixture assembly, without claiming external shop clamps are modelled.
items=[('TF930',(0,0,0)),('TF931',(-100,0,0)),('TF931',(660,0,0))]+[('TF932',(x,y,0)) for x in [80,300,530] for y in [-50,50]]
sol={f'{pn}_{i}':S[pn].translate(o) for i,(pn,o) in enumerate(items)}
sol['RAW_SHAFT']=b.tr(S['B202_R18RAW'],(-135,0,0),(0,1,0),(0,0,1),(1,0,0));sol['BLADE_POS']=S['B201'].translate((0,15.1,-1.25));sol['BLADE_NEG']=S['B201'].translate((0,-77,-1.25))
# Four real screw/washers representations with shank/head and clearance; threads on drawing govern.
for x in [-100,660]:
 for y in [-35,35]:
  z=6.6;sol[f'M8_{x}_{y}']=b.cyl(8,85,(x,y,z-85)).fuse(b.cyl(13,8,(x,y,z)))
  sol[f'W8_{x}_{y}']=b.cyl(16,1.6,(x,y,5)).cut(b.cyl(8.4,1.6,(x,y,5)))
b.ex.export_step('R18_ROTOR_WELD_FIXTURE',[dict(definition=k,occurrence=k,scope='FIXTURE') for k in sol],sol)
# Check stage fit excluding threaded screw/base intersection, which is explicitly intended.
hits=[]
ks=list(sol)
for i,k in enumerate(ks):
 for j in ks[i+1:]:
  if k.startswith('TF930') and j.startswith('M8_'):continue
  v=abs(sol[k].intersect(sol[j]).Volume())
  if v>.001:hits.append(dict(a=k,b=j,mm3=v))
b.dump(E/'R18_ROTOR_FIXTURE_CHECK.json',dict(hits=hits,scope='Nominal stage parts and four bolts; intended screw/base thread overlap excluded; external toolmaker clamps require physical shop setup and are not claimed collision checked.'))
fig,axs=plt.subplots(2,1,figsize=(14,5))
for ax,ab in zip(axs,[(0,1),(0,2)]):
 for k,v in sol.items():
  lines=[]
  for e in v.Edges():lines.append([tuple(e.positionAt(float(t)).toTuple()[h] for h in ab) for t in np.linspace(0,1,2 if e.geomType()=='LINE' else 30)])
  ax.add_collection(LineCollection(lines,colors='#bd692c' if k.startswith(('RAW','BLADE')) else '#17445a',linewidths=.5))
 ax.autoscale();ax.set_aspect('equal');ax.grid(alpha=.15)
fig.tight_layout();fig.savefig(b.OUT/'drawings/ROTOR_FIXTURE.png',dpi=140);plt.close(fig)
# Riser deposit vs current actual R neighbours.
O=json.loads((N/'R18_R_OCCURRENCES.json').read_text());ar=a['R100S'];A=np.array(ar['reference_world_matrix']);o=np.array(ar['reference_world_origin']);ws=json.loads((N/'R18_RISER_WELDS.json').read_text());hitsr=[]
for w in ws:
 sh=b.tr(b.ex.readshape(w['brep']),o,A[:,0],A[:,1],A[:,2]);bb=b.ex.bb(sh)
 for q in O:
  part=b.tr(S[q['pn']],q['o'],q['u'],q['v'],q['n']);cc=b.ex.bb(part)
  if not all(min(bb[k+3],cc[k+3])-max(bb[k],cc[k])>1e-5 for k in range(3)):continue
  v=abs(sh.intersect(part).Volume())
  if v>.001:hitsr.append(dict(weld=w['id'],PN=q['pn'],instance=q['occurrence'],mm3=v))
b.dump(E/'R18_RISER_NEIGHBOURS.json',dict(hits=hitsr,scope='4 actual a1 deposited seams against current R zero-state neighbours; host joint not included.'))
a['R100S']['status']='WELD_HOLD_NEIGHBOUR_INTERSECTION' if hitsr else 'P1_WELD_FABRICATION_CANDIDATE_PENDING_L1';b.dump(N/'R18_SHELL_ASSEMBLIES.json',a)
# True coincident face contact: solid boolean loses zero-thickness contact.
O=json.loads((N/'R18_P_OCCURRENCES.json').read_text());W={q['pn']:b.tr(S[q['pn']],q['o'],q['u'],q['v'],q['n']) for q in O if q['pn'] in ['D886','TF900']};faces=[]
for f in W['D886'].Faces():
 for g in W['TF900'].Faces():
  if f.distance(g)>1e-5:continue
  co=f.intersect(g)
  for ff in co.Faces():
   p=ff.Center().toTuple();faces.append(dict(area=ff.Area(),center=p,radius_from_P2_mm=math.hypot(p[0]+82,p[2]-1583),bbox=b.ex.bb(ff)))
b.dump(E/'R18_ACTUAL_STOP_CONTACT.json',dict(faces=faces,axis_world_XZ=[-82,1583],method='Pairwise coincident face intersection, not solid-volume common.'))
print('FIXTURE_HITS',hits,'RISER_HITS',hitsr,'STOP_CONTACT',faces,flush=True)

