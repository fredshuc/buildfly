from pathlib import Path
p=Path('R18_WORK/source/r18_documents.py');s=p.read_text();s=s.replace("para('Factory must record actual material lot", "para('Scope stop: these are loose-piece/stage candidates only. Four half-shell welding routes have known weld-to-fastener/seat-beam conflicts; see the integration booklet. Their final installation is not released. L1 should select which shell blanks to commit before joint correction; affected small-hole patterns and seat-beam corner relief retain revision exposure. The three-rotor group and R100S route have independent candidate boundaries.');\npara('Factory must record actual material lot")
s=s.replace("external toolmakerclamps at rests;", "six external toolmakerclamps at rests andtwo smooth paddedshaft hold-downs atVblocks; ")
p.write_text(s)
