from pathlib import Path
import json
D=Path('R19_WORK/deliverables');f=list((D/'evidence').rglob('*READBACK.json'));print('STEPS',len(list((D/'step').rglob('*.stp'))),'QA',len(f));print(str(json.loads(f[0].read_text()))[:1400])
