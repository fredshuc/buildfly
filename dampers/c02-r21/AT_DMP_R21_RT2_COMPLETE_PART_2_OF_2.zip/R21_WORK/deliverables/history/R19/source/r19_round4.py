import json,zipfile,hashlib,ezdxf
from pathlib import Path
R=Path.cwd();D=R/'R19_WORK/deliverables';z=zipfile.ZipFile(R/'R19_INPUT/AT_DMP_R18_L1_RELEASE_AND_R19_ORDER_20261012.zip');m=json.loads(z.read('MANIFEST_SHA256.json'))
for x in m:
 d=z.read(x['path'])
 if len(d)!=x['bytes']or hashlib.sha256(d).hexdigest()!=x['sha256']:raise ValueError(x['path'])
qa=[]
for p in (D/'dxf').glob('*.dxf'):
 d=ezdxf.readfile(p);a=d.audit();qa.append(dict(file=p.name,errors=len(a.errors),units=d.units))
 if a.errors:raise ValueError(p)
(D/'evidence/R19_DXF_QA.json').write_text(json.dumps(qa,indent=2));(D/'evidence/R19_SIGNED_INPUT_QA.json').write_text(json.dumps(dict(bytes=z.filename and Path(z.filename).stat().st_size,CRC=z.testzip(),manifest_entries=len(m),sha256=hashlib.sha256(Path(z.filename).read_bytes()).hexdigest()),indent=2))
p=R/'R19_WORK/ledger.json';j=json.loads(p.read_text());j['iterations'][2].update(end='2026-10-12T20:55:30Z',status='COMPLETE');j['iterations'].append(dict(round=4,start='2026-10-12T20:55:30Z',end='2026-10-12T20:57:00Z',scope='Same-version shell geometry, drawing, profile and source input QA; inspect actual representative sections; bearing and placement final checks',status='COMPLETE'));j['iterations'].append(dict(round=5,start='2026-10-12T20:57:00Z',scope='WS17 two joint definitions and drawings; final affected delta checks only; engineering freeze at end',status='ACTIVE'));p.write_text(json.dumps(j,indent=2));print('DXF',len(qa),'MANIFEST',len(m))
