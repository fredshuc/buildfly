import json
P={p['pn']:p for p in json.load(open('R19_WORK/deliverables/native/R19_PARTS.json',encoding='utf-8'))};print({k:v for k,v in P['STD08B'].items()if k not in ['brep']})
