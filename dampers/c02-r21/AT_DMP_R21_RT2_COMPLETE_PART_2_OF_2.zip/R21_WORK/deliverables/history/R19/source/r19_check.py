import json,math,collections,numpy as np
import build_c02 as b
R=b.ROOT.parent;D=R/'R18_WORK/deliverables';N=b.OUT/'native';E=b.OUT/'evidence';pm={p['pn']:p for p in json.loads((N/'R19_PARTS.json').read_text())};S={k:b.ex.readshape(p['brep'])for k,p in pm.items()};ass=json.loads((N/'R19_SHELL_ASSEMBLIES.json').read_text());weld=json.loads((N/'R19_SHELL_WELDS.json').read_text());W={};poses={}
for pn,a in ass.items():
 A=np.array(a['reference_world_matrix']);o=np.array(a['reference_world_origin']);Q=np.array([[0,0,-1],[0,1,0],[1,0,0]])if pn[0]=='P'else np.eye(3);t=np.array([1451,0,2022])if pn[0]=='P'else np.zeros(3);A=Q@A;o=Q@o+t;poses[pn]=(A,o)
 for w in weld[pn]:W[w['id']]=b.tr(b.ex.readshape(w['brep']),o,*A.T)
def broad(a,c):return all(min(a[k+3],c[k+3])-max(a[k],c[k])>1e-6 for k in range(3))
hits=[];parents=[];tests=0;od={};world={}
for tag in ['P','R']:
 O=json.loads((N/f'R19_{tag}_OCCURRENCES.json').read_text());od[tag]={q['occurrence']:q for q in O};world[tag]={q['occurrence']:b.tr(S[q['pn']],q['o'],q['u'],q['v'],q['n'])for q in O};BB={k:b.ex.bb(s)for k,s in world[tag].items()}
 for wn,w in W.items():
  if not wn.startswith(tag):continue
  for q in O:
   k=q['occurrence']
   if not broad(b.ex.bb(w),BB[k]):continue
   tests+=1;v=abs(w.intersect(world[tag][k]).Volume())
   if v>.001:
    row=dict(weld=wn,part=k,PN=q['pn'],mm3=v)
    if k==wn.split('_',1)[1].removesuffix('_FUSION'):parents.append(row)
    else:hits.append(row)
 for angle in [5,45,85,90]:
  for q in O:
   if q['pn']!='B200_R13':continue
   axis=[q['o'][0],0,1583];s=world[tag][q['occurrence']].rotate(axis,[axis[0],-1,axis[2]],(-1 if q.get('moving')=='P2'else 1)*angle)
   for wn,w in W.items():
    if not wn.startswith(tag)or not broad(b.ex.bb(w),b.ex.bb(s)):continue
    tests+=1;v=abs(w.intersect(s).Volume())
    if v>.001:hits.append(dict(weld=wn,part=q['occurrence'],angle=angle,mm3=v))
# All original204 exact neighbours checked against the relevant revised full-shell fusion layer.
old=json.loads((D/'evidence/R18_SHELL_WELD_NEIGHBOURS.json').read_text())['hits'];closed=[]
for h in old:
 pn=h['weld'].split('_')[0];vs=[abs(W[w['id']].intersect(world[h['config']][h['part']]).Volume())for w in weld[pn]];closed.append(dict(old_weld=h['weld'],part=h['part'],PN=h['PN'],old_mm3=h['mm3'],new_max_mm3=max(vs),pass_=max(vs)<.001))
b.dump(E/'R19_NEW_FUSION_NEIGHBOURS.json',dict(boolean_pairs=tests,unapproved_hits=hits,declared_parent_remelt=parents,scope='final flush fusion partition vs actual final neighbours; parent remelt explicitly declared, not external weld volume; rotors0/5/45/85/90 discrete'))
b.dump(E/'R19_ORIGINAL_204_RECHECK.json',closed)
# F05 retained main-piece check; old deleted pieces must not count as installed material.
f05=[]
for pn in ['P110','R110']:
 oldshape=b.ex.readshape(next(p['brep']for p in json.loads((D/'native/R18_PARTS.json').read_text())if p['pn']==pn));f05.append(dict(PN=pn,solid_count=len(S[pn].Solids()),removed_mm3=oldshape.cut(S[pn]).Volume(),added_mm3=S[pn].cut(oldshape).Volume(),bbox=b.ex.bb(S[pn])))
b.dump(E/'R19_F05_INHERITANCE.json',f05)
print('NEW_HITS',len(hits),hits[:15],'OLD204fail',sum(not x['pass_']for x in closed),'pairs',tests,flush=True)
