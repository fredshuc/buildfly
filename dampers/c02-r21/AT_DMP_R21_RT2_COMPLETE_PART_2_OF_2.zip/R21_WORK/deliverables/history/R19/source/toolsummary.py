import json,collections
p=json.load(open('R19_WORK/deliverables/evidence/R19_TOOL_ACCESS.json'));print(collections.Counter((r['tool'],bool(r['hits']))for r in p['results']));print([r for r in p['results'] if r['tool']=='HW_N3'][:5]);print(collections.Counter(h['part'].rsplit('_',1)[0]for r in p['results']for h in r['hits']))
