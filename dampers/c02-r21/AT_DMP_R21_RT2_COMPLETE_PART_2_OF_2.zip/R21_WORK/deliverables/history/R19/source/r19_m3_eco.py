import json,numpy as np
from pathlib import Path
R=Path.cwd();D=R/'R19_WORK/deliverables';old=json.loads((R/'R18_WORK/deliverables/evidence/R18_SHELL_WELD_NEIGHBOURS.json').read_text())['hits'];out=[]
for tag in ['P','R']:
 p=D/f'native/R19_{tag}_OCCURRENCES.json';O=json.loads(p.read_text());target={h['part']for h in old if h['config']==tag and h['PN']in ['HW_W3_0p5_7','HW_N3']}
 for q in O:
  if q['occurrence']in target:
   before=q['o'];q['o']=(np.array(q['o'])-.5*np.array(q['n'])).tolist();q['placement_revision']='R19_M3_BEARING_SEAT';out.append(dict(config=tag,occurrence=q['occurrence'],PN=q['pn'],old_origin=before,new_origin=q['o'],shift_mm=.5,reason='close inherited0.50mm airgap at0.50mm washer; nut follows; no screw/hole/soft shape change'))
 p.write_text(json.dumps(O,indent=2))
(D/'evidence/R19_M3_PLACEMENT_ECO.json').write_text(json.dumps(out,indent=2));print('CHANGED_PLACEMENTS',len(out))
