import json,copy,csv,collections
import build_c02 as b
R=b.ROOT.parent;N=b.OUT/'native';E=b.OUT/'evidence';(E/'parts').mkdir(exist_ok=True);pm={p['pn']:p for p in json.loads((N/'R19_PARTS.json').read_text())};S={p:b.ex.readshape(v['brep'])for p,v in pm.items()};ass=json.loads((N/'R19_SHELL_ASSEMBLIES.json').read_text());weld=json.loads((N/'R19_SHELL_WELDS.json').read_text())
ex=['P102A','P102B','P102C','P102D','P102E','R102A','R102B','S301A','S301B','P110','R110']+[p for p in pm if p.endswith('_R19PREP')]+['P103F','P103B','R103F','R103B']
for pn in ex:b.ex.export_step('parts/'+pn+'_R19',[dict(definition=pn,occurrence=pn,scope='P')],{pn:S[pn]})
qa=[]
for pn,a in ass.items():
 shapes={};rows=[];oldsh=[];un=[];wmap={x['id'].split('_',1)[1].removesuffix('_FUSION'):x for x in weld[pn]}
 for q in a['final_items']:
  s=b.tr(S[q['pn']],q['o'],q['u'],q['v'],q['n']);oldsh.append(s)
  if q['id']in wmap:
   ws=b.ex.readshape(wmap[q['id']]['brep']);parent=s.cut(ws).clean();wid=wmap[q['id']]['id'];shapes[wid]=ws;rows.append(dict(definition=wid,occurrence=wid,scope='DRIVE'));un.append(ws)
  else:parent=s
  name=q['id']+'_PARENT';shapes[name]=parent;rows.append(dict(definition=name,occurrence=name,scope='P'));un.append(parent)
 b.ex.export_step(pn+'_R19_FINAL_PARTITION',rows,shapes)
 # Material partition union and comparison; no double-volume between weld and parent.
 joined=un[0]
 for s in un[1:]:joined=joined.fuse(s)
 old=oldsh[0]
 for s in oldsh[1:]:old=old.fuse(s)
 dif=[abs(joined.cut(old).Volume()),abs(old.cut(joined).Volume())];qa.append(dict(assembly=pn,material_difference_mm3=dif,partition_volume_sum_mm3=sum(s.Volume()for s in un),union_volume_mm3=joined.Volume(),pass_=max(dif)<.001 and abs(sum(s.Volume()for s in un)-joined.Volume())<.001))
 sh={};ro=[]
 for q in a['preparation_items']:
  name=q['id'];sh[name]=b.tr(S[q['pn']],q['o'],q['u'],q['v'],q['n']);ro.append(dict(definition=name,occurrence=name,scope='P'))
 b.ex.export_step(pn+'_R19_PREWELD',ro,sh)
 sh={q['id']:b.ex.readshape(q['brep'])for q in weld[pn]};b.ex.export_step(pn+'_R19_FUSION_LAYER',[dict(definition=k,occurrence=k,scope='DRIVE')for k in sh],sh)
b.dump(E/'R19_PARTITION_RECOMPOSITION.json',qa);print('PARTS',len(ex),'ASSEMBLY',len(qa),'FAIL',[x for x in qa if not x['pass_']],flush=True)
# Conversion quantities: same physical stock; zero new hardware order.
rows=[]
qty={'P102A':2,'P102B':4,'P102C':4,'P102D':4,'P102E':2,'R102A':4,'R102B':8,'S301A':3,'S301B':1,'P103F_R19PREP':2,'P103B_R19PREP':2,'R103F_R19PREP':2,'R103B_R19PREP':2,'P104_R19PREP':4,'R104_R19PREP':4}
for p,n in qty.items():rows.append(dict(PN=p,quantity=n,material=pm[p]['material'],prior_stage='F05_S0'if not p.startswith(('P104','R104'))else'F04_RELEASED_FINISHED_BLANK',conversion='same physical material; no duplicate purchase',drawing='AT_DMP_R19_SHELL_FACTORY_EN.pdf',STEP='step/parts/'+p+'_R19.stp',status='P1_WELD_PREPARATION_CANDIDATE_NOT_RELEASED',factory_progress='UNKNOWN'))
b.cw('R19_CONVERSION_BOM.csv',rows)
b.dump(E/'R19_EXPORT_PARTS.json',ex)
