import json,numpy as np
import build_c02 as b
R=b.ROOT.parent;D=R/'R18_WORK/deliverables';pm={p['pn']:p for p in json.loads((D/'native/R18_PARTS.json').read_text())};S={p:b.ex.readshape(v['brep'])for p,v in pm.items()};a=json.loads((D/'native/R18_SHELL_ASSEMBLIES.json').read_text())['P100F'];A=np.array(a['reference_world_matrix']);o=np.array(a['reference_world_origin']);Q=np.array([[0,0,-1],[0,1,0],[1,0,0]]);A=Q@A;o=Q@o+[1451,0,2022];O=json.loads((D/'native/R18_P_OCCURRENCES.json').read_text());od={q['occurrence']:q for q in O};hits=json.loads((D/'evidence/R18_SHELL_WELD_NEIGHBOURS.json').read_text())['hits'];seen=set()
for h in hits:
 if not h['weld'].startswith('P100F') or h['PN']in seen:continue
 seen.add(h['PN']);q=od[h['part']];U=np.column_stack([q['u'],q['v'],q['n']]);s=b.tr(S[q['pn']],A.T@(np.array(q['o'])-o),*(A.T@U).T);print(h,'bboxLocal',b.ex.bb(s),'placement',q)
