import json,math,collections,numpy as np
import build_c02 as b
R=b.ROOT.parent;N=b.OUT/'native';E=b.OUT/'evidence';pm={p['pn']:p for p in json.loads((N/'R19_PARTS.json').read_text())};S={k:b.ex.readshape(p['brep'])for k,p in pm.items()};old=json.loads((R/'R18_WORK/deliverables/evidence/R18_SHELL_WELD_NEIGHBOURS.json').read_text())['hits']
def broad(a,c):return all(min(a[k+3],c[k+3])-max(a[k],c[k])>1e-5 for k in range(3))
def tool(af,back,tip,outer,L,t):
 s=b.box(back+tip,outer,t).translate((-back,-outer/2,0));s=s.fuse(b.box(L-back,af,t).translate((-L,-af/2,0)));return s.cut(b.box(back+tip+1,af,t+2).translate((-af/math.sqrt(3)-.15,-af/2,-1))).clean()
T={'HW_N3':tool(5.6,5,2.5,9,30,2),'HW_N6':tool(10.2,8,4.5,15,40,3)}
for pn,t in T.items():
 name='TOOL_R19_'+pn;b.ex.export_step(name,[dict(definition=name,occurrence=name,scope='FIXTURE')],{name:t})
results=[];selected={};tests=0
for tag in ['P','R']:
 O=json.loads((N/f'R19_{tag}_OCCURRENCES.json').read_text());W={q['occurrence']:b.tr(S[q['pn']],q['o'],q['u'],q['v'],q['n'])for q in O};BB={k:b.ex.bb(s)for k,s in W.items()};wh=[h for h in old if h['config']==tag and h['PN']=='HW_W6_1p6_12'];targets={h['part']for h in old if h['config']==tag and h['PN']=='HW_N3'}
 for q in O:
  if q['pn']=='HW_N6' and any(np.linalg.norm(np.array(q['o'])-np.array(next(v['o']for v in O if v['occurrence']==h['part'])))<12 for h in wh):targets.add(q['occurrence'])
 for q in O:
  if q['occurrence']not in targets:continue
  best=None
  for deg in [0,180,60,240,120,300]:
   local=T[q['pn']].rotate((0,0,0),(0,0,1),deg).translate((0,0,1));base=b.tr(local,q['o'],q['u'],q['v'],q['n']);dir=-(math.cos(math.radians(deg))*np.array(q['u'])+math.sin(math.radians(deg))*np.array(q['v']));hs=[]
   for dist in [0,10,30]:
    s=base.translate(tuple(dir*dist));bb=b.ex.bb(s)
    for v in O:
     k=v['occurrence']
     if not broad(bb,BB[k]):continue
     tests+=1;vol=abs(s.intersect(W[k]).Volume())
     if vol>.001:hs.append(dict(part=k,mm3=vol,withdrawal_mm=dist))
   item=dict(config=tag,nut=q['occurrence'],tool=q['pn'],rotation_deg=deg,hits=hs,nominal_only=True)
   if best is None or len(hs)<len(best['hits']):best=item
   if not hs:selected[tag+'_'+q['occurrence']]=base;break
  results.append(best)
b.dump(E/'R19_TOOL_ACCESS.json',dict(results=results,boolean_pairs=tests,pass_count=sum(not r['hits']for r in results),scope='Manufacturable open-jaw profile envelopes; three discrete withdrawal positions; no torque, hand access or continuous path qualification'))
b.dump(N/'R19_TOOL_POSITIONS.json',[dict(id=k,brep=b.brep(s))for k,s in selected.items()])
rows=[dict(definition=k,occurrence=k,scope='FIXTURE')for k in selected];b.ex.export_step('R19_SELECTED_TOOL_POSITIONS',rows,selected)
print('TOOLS',len(results),'PASS',sum(not r['hits']for r in results),'FAIL',[r for r in results if r['hits']][:3],flush=True)
