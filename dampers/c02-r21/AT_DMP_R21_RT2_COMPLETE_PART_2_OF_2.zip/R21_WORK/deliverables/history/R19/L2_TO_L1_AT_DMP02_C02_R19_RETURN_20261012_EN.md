# L2 to L1 - AT-DMP02-MFG-C02-R19
Date: 2026-10-12. Engineering frozen 2026-10-12T21:01:21Z.

The four half-shells are submitted as P1_WELD_FABRICATION_CANDIDATE with specific coupon and first-piece hold points. They are not released by L1.

## First decisions requested
- P100F/P100B/R100F/R100B: one weld operation each, using the same physical stock. Convert the13 F05 S0 targets /40pieces to their defined features and preparation. Apply the edge-preparation process ECO to8 existing P104/R104 pieces. This is15 physical definitions /48operations, not48new orders.
- WS17: review groove preparation on TF921L/R (one each), unchanged four sleeves, and actual three-sided TF926 welds. Fabrication and dimensional inspection only; carrying valve weight is expressly separate.
- F05 stable pieces, three rotor processes and R100S continue unchanged. No factory progress or measurements were received.

## Half-shell design and actual change
A single external prepared flush topology replaces the old fillets in all three families. The wall bevel is1.00mm axial x2.50mm across thickness with0.50mm root;103 outer faceZ3,104 outer faceZ0. A conventional2.5mm axial45degree bevel would approach the endM3holes, so it was not used. No internal corner fillet enters the S301 bars. Their end threads, net sections and seal support remain unchanged; the alternative corner relief was rejected because it approaches the M5 entry edge.

Full3mm wall-to-mating-member fusion must be demonstrated on same304L/thickness/joint coupons, including the nearby end hole, starts/stops and corner. The factory must supply its actual WPS, clamps and withdrawal trial. Macrosections, not VT/PT alone, establish hidden root fusion. Actual supplier capability is not claimed. Failure stops product welding and returns the section/settings to engineering. No retired a2 throat is credited.

The final nominal fusion volumes are partitions of the original wall material, including groove fill and a root remelt band. They are not extra beads. Four independently exported final parent/weld partitions reconstruct the old final shell with two-way difference0 and no duplicate volume. Six preparation states preserve pilot allowance; final machining remains paired with2.00mm hard spacers,38mm clearance bores and6.5mm gland holes.637mm wall spacing and667mm support-land spacing remain distinct.

All204 original named weld/neighbour records are zero under the new fusion layer. The new-layer broad-phase check executed174 Boolean pairs;16 exact parent remelt identities are declared explicitly, not treated as unknown interference. No unapproved new hit. Actual rotors0/5/45/85/90degrees were checked against the new fusion layer; this is discrete nominal evidence, not continuous hot/loaded clearance. Old full-valve9/9/23/23 history was not rerun or erased.

## Additional real bearing defect corrected
The representative section exposed0.50mm air gaps between32 endM3 washers and their shell wall. Each washer and its nut move0.50mm toward the wall:64placement changes total, with no screw, hole, bar or soft-profile change. All moved pieces were checked against actual final neighbours:0hard hits. All32nuts have nominal4mm engagement and2.25mm tip projection on the existing fully threadedM3x16 screws. Supplier effective thread and actual tolerance still require inspection.

The132 washer face probes (100M6 and32M3) give full nominal metal support after this correction. This is a0.02mm contact-probe area result, not a loaded pressure/stiffness certification. F05 P110/R110 single connected shapes are inherited exactly; each removes22.26mm3 from the old3-solid definition.

## Tools and assembly order
Initial generic wrench trials failed and remain archived. The current body-fastening stage uses anOD13.4/AF10.2 tubularM6 tool and a2mm open-hexM3 crowfoot.82nut locations pass the documented staged discrete entry/withdrawal positions.82matching hex-drive bit70mm axial prism envelopes are also clear; handles/hands are excluded. M3 withdrawal is8mm clear of engagement, then axial exit.

The stage occurs on external assembly support before gland, feedback, dry-input and namedM8 mount hardware. The seven exact laterM8 washer/nut occurrences and later obstructions are retained in R19_TOOL_STAGE_CHECK.json. No loaded J401 is removed to make room. Full final-state maintenance access is not claimed. Tool manufacture/procurement, dry trial and torque capacity remain required before actual fastening; no tightening torque or preload test is released.

## WS17 two joint closures
Eight annular groove fills useD24 mouths and2mm preparation depth at the existingD20/ID11/L80 sleeves. The minimum effective throat is1.30mm after finishing, not2mm and not the retireda3. Rail wall remaining>=2.80mm must be measured; stock that cannot meet this stops. Ends remain flush+/-0.02 and the receiver remains removable.

Each TF926 uses the retained lowera4x60 plus two real verticala4x20 seams. The nonexistent upper fillet is withdrawn. Eight new side seams plus eight groove fills augment the34 inherited deposits to50records. BothP/R neighbour checks show0unapproved intersections; all32new joint/state checks touch real mating parts. Two rail preparation STEP and actual weld/partition layers are supplied. Unit-load weld-group coefficients are diagnostic only; anchors, receiver/ground compliance, preload, lifting and actual valve support are not accepted.

## Delivery scope
44current STEP files plus3retired initial-tool diagnostic STEP in the engineering archive; all47have independent AP242 readbacks.23individual part definitions, shell pre-weld/final partitions/fusion layers, actual section references, current tools, WS joint layers and a72-instance active change layer are included.13DXF face profiles,47-page shell factory booklet and7-pageWS/review booklet were reopened/rendered and visually inspected. The factory archive omits the retired tool trials and internal code.

Catalogue388 ->396:386oldBReps unchanged; onlyP110/R110 takeF05 corrections;8manufacturing preparation states added. FullP/R native occurrences are included; the combined change-layer STEP prefixes alternativesP_/R_ and must not be installed as one configuration.

C02 remains PARTIAL / NOT_FOR_MANUFACTURE. G1, real front/rear seal/stop compliance,1000N proxy mapping,1800N/head protection, feedback capture, thermal coupling, five remaining wet stations/PTFE and complete maintenance remain open. No5/10/20/200Nm physical load is authorised. The actuator stays an external purchased placeholder.

## Execution and next claim
T0 2026-10-12T20:25:08Z;5 recorded iterations; engineering frozen 2026-10-12T21:01:21Z; engineering36.216667minutes. Main shell work beforeWS occupied83.48%of elapsed engineering allocation. A draft future ledger transition was corrected before use; the correction is retained, with no budget inferred from it. No sixth iteration.

After formal file return, schedule exactly one R20 claim40minutes from actual return completion. No polling; signedR20 only. R21formalreturn stops the authorised cycle.
