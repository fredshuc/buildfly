import json,hashlib,zipfile
import build_c02 as b
ROOT=b.ROOT.parent
sig=ROOT/'R17_INPUT/signed'
for q in json.loads((sig/'FILE_MANIFEST.json').read_text()):
 p=sig/q['path']
 if len(p.read_bytes())!=q['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=q['sha256']:raise ValueError(q)
with zipfile.ZipFile(ROOT/'R17_INPUT/AT_DMP_RT1_L1_DISPOSITION_AND_R17_ORDER_20261012.zip') as z:
 if z.testzip():raise ValueError('CRC')
b.dump(b.OUT/'evidence/SIGNED_INPUT_VERIFIED.json',dict(members=len(z.namelist()),manifest=14,sha256='6e23a6a69d76e6d5c9969943aa6ada30b9053b96b7b0354eb2d46ac5dca774ab'))
P=json.loads((ROOT/'R16_WORK/deliverables/native/R16_PARTS.json').read_text());pm={p['pn']:p for p in P}
for tag in ['P','R']:
 O=json.loads((ROOT/f'R16_WORK/deliverables/native/R16_{tag}_OCCURRENCES.json').read_text())
 print(tag)
 for q in O:
  if q['pn'] not in ['P107B','P107','R107','F620','F621','F622','F623','G842','G843']:continue
  s=b.tr(b.ex.readshape(pm[q['pn']]['brep']),q['o'],q['u'],q['v'],q['n'])
  if tag=='P':s=b.tr(s,[1451,0,2022],[0,0,1],[0,1,0],[-1,0,0])
  print(q['occurrence'],q['pn'],b.ex.bb(s),q['o'],pm[q['pn']]['notes'],pm[q['pn']]['features'])
