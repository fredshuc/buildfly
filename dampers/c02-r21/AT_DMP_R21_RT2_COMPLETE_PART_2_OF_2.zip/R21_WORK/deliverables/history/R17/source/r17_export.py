import sys,json
import build_c02 as b
from r17_check import states
tag=sys.argv[1];angle=float(sys.argv[2]) if len(sys.argv)>2 else 0;O,W=states(tag,angle)
# Explicitly render the true products and all active hardware. No witness stub or test mandrel.
rows=[dict(definition=q['occurrence'],occurrence=q['occurrence'],scope=q['scope']) for q in O]
r=b.ex.export_step('AT_DMP_R17_'+tag+'_TEST_O1PRIME'+('' if angle==0 else '_END90'),rows,W)
b.dump(b.OUT/'evidence'/(f'R17_{tag}_EXPORT'+('_END90.json' if angle else '.json')),r)

