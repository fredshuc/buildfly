import json,hashlib,math,collections
import numpy as np
import ezdxf
from pathlib import Path
import build_c02 as b
R=b.ROOT;ROOT=R.parent;D=b.OUT;E=D/'evidence';N=D/'native'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
P=read(N/'R17_PARTS.json');pm={p['pn']:p for p in P};old={p['pn']:p for p in read(ROOT/'R16_WORK/deliverables/native/R16_PARTS.json')};diff=[pn for pn in old if old[pn]['brep']!=pm[pn]['brep']]
if set(diff)!={'D886','G900','TF903','G903'}:raise ValueError(('Unexpected originalBRepchanges',diff))
sets={t:read(N/f'R17_{t}_OCCURRENCES.json') for t in ['P','R']}
for t,oo in sets.items():
 if len({q['occurrence'] for q in oo})!=len(oo):raise ValueError('duplicateinstance')
 for q in oo:
  a=np.array([q['u'],q['v'],q['n']]).T
  if abs(np.linalg.det(a)-1)>1e-8:raise ValueError(('nonrigid',q))
  if q['pn'] not in pm:raise ValueError(q['pn'])
 if any(q['pn'] in ['F620','F621','F622','F623'] for q in oo):raise ValueError('oldfixtureactive')
 if t=='P' and not any(q['pn']=='P107B' for q in oo):raise ValueError('lostP107B')
 reg=next(q for q in read(E/'R17_EXPLICIT_CONTACT_REGISTER.json') if q['config']==t)
 if reg['unapproved_count']:raise ValueError(('unapprovedstatic',reg))
 motion=read(E/f'R17_{t}_MOTION.json')
 if len(motion['positions'])!=23 or any(q['new_or_increased'] for q in motion['positions']):raise ValueError('motionnotclosed')
for q in read(E/'R17_TOOL_ENTRIES.json'):
 if q['hits']:raise ValueError(('toolblocked',q))
steps=[]
for p in E.rglob('*_READBACK.json'):
 q=read(p)
 if not q.get('all_pass'):raise ValueError(('STEPfail',p))
 target=next((D/'step').rglob(q['file']))
 if hashlib.sha256(target.read_bytes()).hexdigest()!=q['sha256']:raise ValueError(('STEPfingerprint',target))
 steps.append(dict(file=q['file'],occurrences=q['occurrences'],sha256=q['sha256']))
for q in read(E/'R17_CANDIDATES.json'):
 if not(D/q['STEP']).exists():raise ValueError(('candidateSTEPpath',q))
 if hashlib.sha256(pm[q['PN']]['brep'].encode()).hexdigest()!=q['geometry_sha256']:raise ValueError(q)
dx=[]
for p in (D/'dxf').glob('*.dxf'):
 doc=ezdxf.readfile(p);audit=doc.audit()
 if audit.has_errors:raise ValueError(('DXFaudit',p))
 dx.append(dict(file=p.name,entities=len(doc.modelspace()),types=dict(collections.Counter(e.dxftype() for e in doc.modelspace()))))
out=dict(original_BRep_changed=diff,unchanged_original_count=len(old)-len(diff),active_counts={t:len(q) for t,q in sets.items()},candidate_PN=len(read(E/'R17_CANDIDATES.json')),candidate_pieces=sum(q['quantity'] for q in read(E/'R17_CANDIDATES.json')),STEPs=steps,DXFs=dx,static_unapproved=[0,0],motion_positions=[23,23],tool_entries=32,tool_blocked=0,limits='Scoped nominalgeometryQA only. Existingwetcontacts, loadedjoint/floor/feedback, continuouspaths andoverallqualificationnotclosed.')
b.dump(E/'R17_FINAL_QA.json',out);print('FINAL_QA',len(steps),'STEP',len(dx),'DXF','changed',diff,flush=True)
