import json,math,collections
import numpy as np
from scipy.spatial import ConvexHull
import build_c02 as b
from r17_check import states,S,pm
E=b.OUT/'evidence';ROOT=b.ROOT.parent;old=json.loads((ROOT/'R14_WORK/deliverables/evidence/R14_MASS_AND_FLOOR.json').read_text())['part_masses'];out=[];control=[]
def mass(q):
 pn=q['pn'];p=pm[pn];m=p['material'].lower();v=S[pn].Volume()
 if p['kind']=='BUY' and pn in old:return old[pn],'R14 frozen procurement allocation (not weighed)'
 density=2.2e-6 if 'ptfe' in m else 1.2e-6 if any(x in m for x in ['bisco','epdm','silicone','foam','rubber']) else 8.8e-6 if 'cusn' in m else 7.93e-6 if any(x in m for x in ['304','1.43','a4','a2']) else 7.85e-6
 return v*density,'BRep volume x declared density '+str(density)+' kg/mm3; installed soft-volume proxy' if density<3e-6 else 'BRep x density '+str(density)
for tag in ['P','R']:
 O,W=states(tag,0);rows=[];total=0;mom=np.zeros(3);wet=0;wmom=np.zeros(3);feet=[];rho_unc=0
 for q in O:
  m,why=mass(q);cg=np.array(W[q['occurrence']].Center().toTuple());total+=m;mom+=m*cg
  if q['source']=='R12':wet+=m;wmom+=m*cg
  if q['pn']=='TF908':
   bb=b.ex.bb(W[q['occurrence']]);feet.extend([[bb[x],bb[y]] for x in [0,3] for y in [1,4]])
  if pm[q['pn']]['kind']=='BUY':rho_unc+=.25*m
  if any(s in pm[q['pn']]['material'].lower() for s in ['bisco','epdm','silicone','foam']):rho_unc+=m
  rows.append(dict(instance=q['occurrence'],PN=q['pn'],mass_kg=m,CG_mm=cg.tolist(),basis=why))
 cg=mom/total;wcg=wmom/wet;pts=np.array(feet);poly=pts[ConvexHull(pts).vertices];weight=total*9.81;minmass=total-rho_unc
 tests=[]
 for name,T,Fextra in [('SELF_WEIGHT_TRANSFER',0,0),('NORMAL_'+tag,78 if tag=='P' else 38,0),('STATIC_200_STOP_OR_JAM',200,0)]:
  F=T*1000/450;Fx=F;My=T*1000;h=1583-744
  margins=[]
  for sign in [-1,1]:
   # floor resultant point from exactly one external hand wrench; internal gear/coupling/stop reactions cancel in this whole-rig FBD.
   cop=cg[:2]+np.array([sign*(Fx*h+My)/weight,0]);mind=min(np.cross(poly[(i+1)%len(poly)]-poly[i],cop-poly[i])/np.linalg.norm(poly[(i+1)%len(poly)]-poly[i]) for i in range(len(poly)))
   margins.append(dict(direction=sign,COP_mm=cop.tolist(),minimum_distance_to_support_edge_mm=float(mind)))
  tests.append(dict(case=name,external_hand_force_N=F,external_torque_Nm=T,hand_equivalent='Fx at axisZ1583 + My=T; equalsFx atZ2033 with450mmlever. No added internalstop/mesh torque.',floor_margins=margins,required_mu=F/(minmass*9.81) if minmass>0 else None,assumed_all_ten_feet_in_contact=True,qualification='CONDITIONAL_EQUILIBRIUM_ONLY'))
 out.append(dict(config=tag,mass_kg=total,CG_mm=cg.tolist(),wet_product_mass_kg=wet,wet_product_CG_mm=wcg.tolist(),mass_uncertainty_allocation_kg=rho_unc,foot_polygon_XY_mm=poly.tolist(),floor_Z_mm=744,tests=tests,limits=['Purchased proxies and installed soft-density allocation, not actual weighing. Welddeposit mass omitted; actual external cables/actuator notinstalled.', 'Tenfeetcontact/level and friction mustbe measured. Connectionstiffness/footreaction split notsolved; no groundrating or liftingauthorization.', 'P O1primecoldgravity doesnotqualify originalproductinstallation.']),)
 b.dump(E/f'R17_{tag}_INSTANCE_MASS.json',rows)
 # Same named load allocation in local actual support frame: gravity -Ylocal, bearing physicalplanes-13/103.
 for name,T,stop in [('NORMAL',78 if tag=='P' else 38,False),('WET_EDGE_JAM',200,False),('LOCAL_DRY_STOP',200,True)]:
  ft=T*1000/82.5 if tag=='P' else 0;fr=ft*math.tan(math.radians(20));coupling=70.74;cm=10000
  def react(F,z,M=0):rear=(F*(z+13)+M)/116;return [F-rear,rear]
  meshx=react(fr,35);meshy=react(ft,35);cr=react(coupling,-58.5,cm)
  edge=0 if stop or name=='NORMAL' else T*1000/77;rotor=S['B200_R13'].Volume()*7.93e-6*9.81
  near=(edge+rotor)/2+coupling*(1+83.5/637)+cm/637;far=(edge+rotor)/2-coupling*83.5/637-cm/637
  control.append(dict(config=tag,case=name,torque_Nm=T,pressure_Pa=0,gear_Ft_Fr_N=[ft,fr],mesh_front_rear_localX_N=meshx,mesh_front_rear_localY_N=meshy,coupling_front_rear_localY_N=cr,coupling_allocation_N=70.74,coupling_moment_allocation_Nm=10,wet_edge_N=edge,wet_near_far_N=[near,far],dry_stop_force_N=T*1000/60 if stop else 0,scope='Signed localcomponent equilibrium allocation; mirror signsforoppositedirection. Not jointcontactG1 or realcoupling stiffness. NormalP assumesfull78NmtransferredtoP2; actualsplit requiresmeasurement. No500/1500/2000pressureadded.'))
b.dump(E/'R17_MASS_FLOOR_CONTROLS.json',out);b.dump(E/'R17_LOCAL_CONTROL_LOADS.json',control)
pressure=[dict(config=t,pressure_Pa=p,force_per_leaf_N=p*.617*.154,stage='leakagehold' if p==500 else 'structureonly' if p==1500 else 'sensitivityonly',load_with_torque='NOT_AUTHORIZED_OR_COMBINED') for t in ['P','R'] for p in [500,1500,2000]];b.dump(E/'R17_PRESSURE_INTERFACE_SEPARATE.json',pressure)
# Three concrete structural screens, explicit conditional load paths and stiffness.
F=200000/60;I=36*30**3/12;L=155;delta=F*L**3/(3*200000*I);theta=math.degrees(delta/60);sig=F*L/(36*30**2/6)
wetmax=max(x['wet_product_mass_kg'] for x in out)*9.81;V=wetmax+500;railI=(80**4-70**4)/12
screen=dict(closed_TF900=dict(force_N=F,height_mm=L,I_mm4=I,post_nominal_stress_MPa=sig,Kt2_MPa=2*sig,deflection_mm=delta,endpoint_rotation_deg=theta,contact_lever_range_mm=[50,80],min_lever_conservative_force_N=4000,min_lever_fullheight_deflection_mm=4000*155**3/(3*200000*I),min_lever_fullheight_endpoint_deg=math.degrees((4000*155**3/(3*200000*I))/50),status='ENDPOINT_DEFLECTION_HOLD; idealfixedbasebeamonly, headandboltsaddcompliance; no200Nmqualification'),D886_key=dict(shear_MPa=(200000/15)/(8*32),bearing_MPa=(200000/15)/(3*32),material_min_yield_MPa=650,one_slot=True,old_second_slot_rework='NOT_DEFINED'),support=dict(vertical_screen_N=V,allocation='wetselfweight+500Ndownhandling; notoperatingtorquecombination',receiver_cantilever_mm=80,receiver_effective_strip_width_mm=36,receiver_t_mm=20,worst_single_strip_bending_MPa=V*80/(36*20**2/6),worst_single_strip_deflection_mm=V*80**3/(3*200000*(36*20**3/12)),rail_I_mm4=railI,one_rail_555span_deflection_mm=V*555**3/(48*200000*railI),one_leg_bending_500N_MPa=500*632/(railI/40),one_leg_fixedroot_deflection_500N_mm=500*632**3/(3*200000*railI),leg_to_rail_weld='two80mm a5fillets atfront/backleg top, not allperimeterbuttclaim',weld_direct_shear_MPa=V/(2*80*5),clamp_toe_area_mm2=10*40,clamp_distribution='NOT_MEASURED; no sealpreloadcredit',M8_tie_conservative_force_200Nm_over421mm_N=200000/421,feet='noanchorcredit, frictionandcontactmeasuredbeforeuse'),limits=['E200GPaassumed, sectionnominalandlinear. Certificateyield345MPafornewthickS355parts.', 'No buckling/fatigue/hot/couplingcontactclosure. Allscreensconditional; machinequalificationnotclaimed.', 'Receiveractualsupportarea excludingaccessholes measuredseparately; notfullidealannulus.'])
b.dump(E/'R17_STRUCTURAL_SCREENS.json',screen);print('MASS',[(x['config'],x['mass_kg'],x['wet_product_mass_kg']) for x in out]);print('STOP',screen['closed_TF900'])

