import json,math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
import build_c02 as b
from r17_check import states,S,pm,broad
from r11_common import volume
DR=b.OUT/'drawings';E=b.OUT/'evidence'
def lines(s,ab):
 out=[]
 for e in s.Edges():
  pts=[e.positionAt(float(t)).toTuple() for t in np.linspace(0,1,2 if e.geomType()=='LINE' else 33)];out.append([(p[ab[0]],p[ab[1]]) for p in pts])
 return out
guards=[]
for tag in ['P','R']:
 O,W=states(tag,0)
 for ab,name in [((1,2),'SIDE'),((0,2),'FRONT')]:
  fig,ax=plt.subplots(figsize=(13,7))
  for q in O:
   if pm[q['pn']]['kind']=='BUY' or q['pn'].startswith(('HW','H14','H17','STD','BUY')):continue
   color='#e07821' if q['source']=='R17' else '#7562a1' if q['source']=='R14' else '#167a87'
   ax.add_collection(LineCollection(lines(W[q['occurrence']],ab),colors=color,linewidths=.4,alpha=.75))
  ax.autoscale();ax.set_aspect('equal');ax.grid(alpha=.15);ax.set_xlabel('XYZ'[ab[0]]+' TEST mm');ax.set_ylabel('XYZ'[ab[1]]+' TEST mm');ax.set_title(tag+' TEST / actual wet valve + common dry rig + new wet support')
  fig.text(.02,.02,'Orange: R17 support; purple: dry rig; teal: retained valve/feedback. Small hardware remains in STEP. Projection is not clearance proof.',fontsize=9);fig.tight_layout(rect=(0,.04,1,1));fig.savefig(DR/f'{tag}_{name}.png',dpi=150);plt.close(fig)
 fig,ax=plt.subplots(figsize=(13,6));slice=b.box(650,1,350).translate((-320,-450.5,1400))
 for q in O:
  bb=b.ex.bb(W[q['occurrence']])
  if not broad(bb,b.ex.bb(slice)):continue
  ss=W[q['occurrence']].intersect(slice)
  if not ss.Solids():continue
  ax.add_collection(LineCollection(lines(ss,(0,2)),colors='#df7626' if q['source']=='R17' else '#177587',linewidths=.8))
 ax.autoscale();ax.set_aspect('equal');ax.grid(alpha=.2);ax.set_xlim(-285,280);ax.set_ylim(1440,1710);ax.set_xlabel('TEST X / mm');ax.set_ylabel('TEST Z / mm');ax.set_title(tag+' / actual material section at TEST Y=-450 +/-0.5 mm')
 for z,label in [(1488,'receiver / backing contact'),(1496,'clamp toe / assembled flange'),(1583,'shaft datum')]:ax.axhline(z,color='#a5a5a5',lw=.5,ls='--');ax.text(-282,z+3,label,fontsize=8)
 fig.tight_layout();fig.savefig(DR/f'{tag}_RECEIVER_SECTION.png',dpi=160);plt.close(fig)
 for pa,pb in [('G901','STD03C'),('G901','BUY_R13_BK2'),('G903','P107' if tag=='P' else'R107')]:
  aa=[q for q in O if q['pn']==pa];cc=[q for q in O if q['pn']==pb];ds=[(W[a['occurrence']].distance(W[c['occurrence']]),a['occurrence'],c['occurrence']) for a in aa for c in cc]
  if ds:dist,a,c=min(ds);guards.append(dict(config=tag,a=a,b=c,distance_mm=dist,scope='nominalunloadedonly; tolerance, studprotrusion and loadedmotion notqualified'))
b.dump(E/'R17_GUARD_DISTANCES.json',guards)
fig,axs=plt.subplots(1,3,figsize=(13,4.8))
for ax,angle in zip(axs,[0,45,90]):
 O,W=states('P',angle)
 for q in O:
  if q['pn'] not in ['D886','TF900','D884'] or q['source']!='R14' or (q['pn']=='D884' and q['rig_local_origin'][0]>82.5):continue
  ax.add_collection(LineCollection(lines(W[q['occurrence']],(0,2)),colors='#e77a25' if q['pn']=='D886' else '#1b5566',linewidths=.7))
 ax.autoscale();ax.set_aspect('equal');ax.set_title(f'P2 {-angle} deg / P1 +{angle} deg');ax.grid(alpha=.2)
fig.suptitle('Corrected single keyway / TF900 retained / closed tall post remains compliance HOLD');fig.tight_layout();fig.savefig(DR/'STOP_SEQUENCE.png',dpi=150);plt.close(fig)
dx=[]
for pn in ['G900','G903','TF903','TF920P','TF920R','P104','R104','S311','S313']:
 s=S[pn];bb=b.ex.bb(s);thin=int(np.argmin(np.array(bb[3:])-np.array(bb[:3])))
 if thin==0:ss=b.tr(s,u=(0,0,-1),v=(0,1,0),n=(1,0,0));maptext='DXFx=partZ, DXFy=partY'
 elif thin==1:ss=b.tr(s,u=(1,0,0),v=(0,0,-1),n=(0,1,0));maptext='DXFx=partX, DXFy=partZ'
 else:ss=s;maptext='DXFx=partX, DXFy=partY'
 faces=[f for f in ss.Faces() if f.geomType()=='PLANE' and abs(f.normalAt().z)>.999];face=max(faces,key=lambda f:f.Area());face=face.translate((0,0,-face.Center().z));p=b.OUT/'dxf'/f'{pn}_R17.dxf';b.cq.exporters.export(b.cq.Workplane('XY').newObject(face.Wires()),str(p));dx.append(dict(PN=pn,file=p.name,coordinates=maptext,source='Exact planar face wires, no polyline approximation of circles',scope='Profile/pilot reference; drawing thread/finish dimensions govern'))
b.dump(E/'R17_DXF_INDEX.json',dx);print('VISUALS',len(dx),'DXF',guards,flush=True)

