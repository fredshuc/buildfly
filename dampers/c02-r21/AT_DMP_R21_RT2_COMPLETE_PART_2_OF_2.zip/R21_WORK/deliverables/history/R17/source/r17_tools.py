import json,math
import build_c02 as b
from r17_check import states,broad,S
from r11_common import volume
E=b.OUT/'evidence';allrows=[];support=[];tools={}
for tag in ['P','R']:
 O,W=states(tag,0);BB={k:b.ex.bb(s) for k,s in W.items()}
 for q in O:
  if q['source']!='R17' or q['pn'] not in ['H17_M10X45','H17_M10X120','H17_M8X45','H17_M8X35']:continue
  x,y,z=q['o'];pn=q['pn'];tool=None;mode=''
  if pn.startswith('H17_M10'):
   # AF8 driver and 18OD non-contact socket envelope start above the screwhead.
   tool=b.cyl(18,100,(x,y,z+10.1));mode='straight socket/driver top entry,100mm'
  elif pn=='H17_M8X45':
   shaft=b.cyl(7,12,(x,y,z+8.1));sgn=-1 if x<0 else 1;handle=b.cyl(7,75,(x,y,z+20.1),(sgn,0,0));tool=shaft.fuse(handle);mode='AF6 L-key envelope, outward75mmhandle'
  else:
   tool=b.cyl(7,100,(x,y,z+8.1));mode='AF6 straight hex driver fromabove,100mm'
  bb=b.ex.bb(tool);hits=[]
  for other,ss in W.items():
   if other==q['occurrence'] or not broad(bb,BB[other]):continue
   v=volume(tool,ss)
   if v>.001:hits.append(dict(instance=other,PN=next(a['pn'] for a in O if a['occurrence']==other),mm3=v))
  ident='TOOL_'+q['occurrence'];tools[ident]=tool;allrows.append(dict(config=tag,target=q['occurrence'],tool=mode,hits=hits,status='DISCRETE_ENTRY_CLEAR' if not hits else 'BLOCKED',scope='Idealized actual-size wrench envelope at finalentry pose; notcontinuousinsertion/swingorergonomicqualification'))
 rec=next(q for q in O if q['pn']==('P107B' if tag=='P' else 'R107'));plate=next(q for q in O if q['pn']==('TF920P' if tag=='P' else 'TF920R'));rs=W[rec['occurrence']]
 # Extrude 0.10mm from true receiver underside into support; divide overlap bythickness.
 probe=rs.translate((0,0,-.10));vol=volume(probe,W[plate['occurrence']]);a=vol/.10
 support.append(dict(config=tag,receiver=rec['occurrence'],support=plate['occurrence'],supported_projected_area_mm2=a,full_receiver_metal_plan_area_mm2=rs.Volume()/3,ratio=a/(rs.Volume()/3),method='True3mmreceiver translated0.10mminto support; intersectionvolume/0.10. Accessholes,window,feedbackreliefincluded.',limit='Area is not stiffness, pressure distribution or seal acceptance; frontunbackededgeandboltaccessspansrequireconditionalbeam/measurement.'))
b.dump(E/'R17_TOOL_ENTRIES.json',allrows);b.dump(E/'R17_RECEIVER_SUPPORT_AREA.json',support)
b.dump(b.OUT/'native/R17_TOOL_BREPS.json',[dict(pn=k,brep=b.brep(s),bbox=b.ex.bb(s)) for k,s in tools.items()])
print('TOOLS',len(allrows),'BLOCKED',sum(bool(q['hits']) for q in allrows));print('SUPPORT',support)

