import json,sys,itertools
import build_c02 as b
from r17_check import states,broad
from r11_common import volume
tag=sys.argv[1];angle=float(sys.argv[2]) if len(sys.argv)>2 else 0
O,W=states(tag,angle); BB={k:b.ex.bb(s) for k,s in W.items()};changed=set(json.loads((b.OUT/'evidence/R17_CHANGED_PN.json').read_text()))
hits=[];tested=0;pairs=0
for i,a in enumerate(O):
 for c in O[i+1:]:
  if not(a['source']=='R17' or c['source']=='R17' or a['pn'] in changed or c['pn'] in changed or a.get('changed_pose') or c.get('changed_pose')):continue
  pairs+=1;aa=a['occurrence'];cc=c['occurrence']
  if not broad(BB[aa],BB[cc]):continue
  tested+=1;v=volume(W[aa],W[cc])
  if v>.001:hits.append(dict(a=aa,b=cc,PN=[a['pn'],c['pn']],mm3=v,bbox=b.ex.bb(W[aa].intersect(W[cc]))))
b.dump(b.OUT/f'evidence/R17_{tag}_DELTA_{angle:g}.json',dict(config=tag,angle=angle,pairs=pairs,boolean_pairs=tested,hits=hits,scope='All pairs touching R17 geometry/pose/newinstance; inherited unrelated contacts not recertified'))
print(tag,angle,'pairs',pairs,'boolean',tested,'hits',len(hits),flush=True)
for q in hits:print(q['a'],q['b'],round(q['mm3'],3),q['bbox'],flush=True)
if angle==0:b.dump(b.OUT/f'evidence/R17_{tag}_WORLD_BOUNDS.json',[dict(instance=q['occurrence'],PN=q['pn'],bbox=BB[q['occurrence']],volume=W[q['occurrence']].Volume(),center=W[q['occurrence']].Center().toTuple(),source=q['source']) for q in O])
