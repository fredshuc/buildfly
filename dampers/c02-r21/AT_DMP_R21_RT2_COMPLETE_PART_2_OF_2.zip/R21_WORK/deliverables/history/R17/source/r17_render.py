import pathlib,subprocess,json
from PIL import Image,ImageDraw
from pypdf import PdfReader
R=pathlib.Path(__file__).resolve().parents[1];out=R/'qa';out.mkdir(exist_ok=True)
exe=r'C:\Users\Gebruiker\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdftoppm.exe';results=[]
for f in (R/'deliverables/drawings').glob('*.pdf'):
 name='review' if 'REVIEW' in f.name else 'factory';subprocess.run([exe,'-r','70','-png',str(f),str(out/name)],check=True);pages=sorted(out.glob(name+'-*.png'));n=len(PdfReader(str(f)).pages)
 if len(pages)!=n:raise ValueError((f,len(pages),n))
 for k in range(0,n,6):
  canvas=Image.new('RGB',(2100,1560),'white');d=ImageDraw.Draw(canvas)
  for i,p in enumerate(pages[k:k+6]):
   im=Image.open(p).convert('RGB');im.thumbnail((1030,480));x=i%2*1050;y=i//2*520;canvas.paste(im,(x,y+28));d.text((x+8,y+7),p.name,fill='black')
  canvas.save(out/f'{name}_montage_{k//6+1}.jpg',quality=90)
 results.append(dict(file=f.name,pages=n,rendered=n))
(R/'deliverables/evidence/R17_PDF_RENDER_RECEIPT.json').write_text(json.dumps(results,indent=2));print(results)
