import json,collections,csv,hashlib
import build_c02 as b
from r17_check import pm,S
ROOT=b.ROOT.parent;E=b.OUT/'evidence';N=b.OUT/'native'
sets={t:json.loads((N/f'R17_{t}_OCCURRENCES.json').read_text()) for t in ['P','R']};counts={t:collections.Counter(q['pn'] for q in oo) for t,oo in sets.items()};changed=json.loads((E/'R17_CHANGED_PN.json').read_text());changed=list(dict.fromkeys(changed))
w1=['F602','F603','P104','R104','S311','S313'];w1notes={
'F602':['304L certified. OD16.00+/-0.05,ID8.50+0.10/0,length2.00+/-0.03. Facesparallel0.03,Ra3.2. Deburr0.1max; retainfullbearingland. Qty92 P+R. Loose spacer only, no sealcompression acceptance.'],
'F603':['304L certified. OD12.00+/-0.05,ID6.50+0.10/0,length2.00+/-0.03. Facesparallel0.03,Ra3.2. Deburr0.1max; retainfullbearingland. Qty58 P+R. Loose spacer only, no sealcompression acceptance.'],
'P104':['304L certified3.00+/-0.10 sheet. Finished83.00+/-0.20 x636.00+/-0.20,straightedges0.2,flat0.3/300. Deburr0.2, noholes. Qty4. Two perhalf-shell,overlapsideplates. a2continuoussealweld belongs to separateweldassemblyroute, NOT issuedbythislooseblankcandidate.'],
'R104':['304L certified3.00+/-0.10 sheet. Finished83.00+/-0.20 x636.00+/-0.20,straightedges0.2,flat0.3/300. Deburr0.2,noholes. Qty4. SameblankasP104butseparatemarkingR. Weldingandpostweldfinishnotissued.'],
'S311':['304L certified2.00+/-0.05 sheet,24.00+/-0.1 x30.00+/-0.1. Two5.50+0.10/0THRU at(6,15),(18,15),positiondiameter0.15 fromleft/bottomdatums. Contactfaceflat0.05. Deburr0.15. Qty10. SeparateS312softlayernotreleasedbythissheet.'],
'S313':['304L flatwasher OD10.00+/-0.05,ID5.50+0.10/0,t0.50+/-0.02. Flat0.03,Ra3.2. Deburr0.05max. Qty20. Two perS311; noextra duplicateorderunderhardware.']}
for pn in w1:pm[pn]['notes']=w1notes[pn];pm[pn]['process_revision']='R17-W1-01';pm[pn]['status']='W1_LOOSE_PIECE_CANDIDATE';pm[pn]['name']=dict(F602='M8 compression spacer',F603='M6 compression spacer',P104='P shell loose blank',R104='R shell loose blank',S311='Seat rail cover plate',S313='Thin shim washer')[pn]
b.dump(N/'R17_PARTS.json',list(pm.values()))
candidates=[]
for pn in changed+w1+['TF908']:
 if pn in [q['PN'] for q in candidates] or not max(counts[t][pn] for t in counts):continue
 p=pm[pn]
 if p['kind']=='BUY':continue
 qty=sum(counts[t][pn] for t in counts) if pn in w1 or pn in ['TF920P','TF920R'] else max(counts[t][pn] for t in counts)
 if pn=='TF908':qty=4
 candidates.append(dict(PN=pn,quantity=qty,batch='W1-01' if pn in w1 else 'ECO17' if pn in ['D886','G900','TF903','G903'] else 'WS17',revision=p.get('revision','C02'),process_revision=p.get('process_revision','R17'),scope='LOOSE_PIECE_FABRICATION_CANDIDATE_NOT_L1_RELEASED',material=p['material'],STEP=f'step/parts/{pn}_R17.stp',drawing='drawings/AT_DMP_R17_FACTORY_CANDIDATES_EN.pdf',manufacturing_state='UNCONFIRMED',basis='distinctPplusR' if pn in w1 else 'maxsequentialcommonrig;TF908incrementfour',geometry_sha256=hashlib.sha256(p['brep'].encode()).hexdigest()))
b.cw('R17_CANDIDATE_BATCHES.csv',candidates);b.dump(E/'R17_CANDIDATES.json',candidates)
gap=list(csv.DictReader((ROOT/'R16_WORK/deliverables/tables/R16_CONFIGURED_MANUFACTURING_GAPS.csv').open(encoding='utf-8-sig')));prior={q['PN']:q for q in gap};bom=[];purch=[]
for pn in sorted(set(counts['P'])|set(counts['R'])):
 facility=any(q['pn']==pn and q['source'] in ['R14','R17'] for q in sets['P']+sets['R']);n=max(counts[t][pn] for t in counts) if facility else sum(counts[t][pn] for t in counts);old=prior.get(pn,{});credit=int(old.get('released_quantity',0));scope=old.get('release_scope','')
 if 'ONE_MEASUREMENT' in scope:credit=0
 row=dict(PN=pn,revision=pm[pn].get('revision','C02'),P_count=counts['P'][pn],R_count=counts['R'][pn],net_configuration_need=n,prior_scoped_credit=credit,additional_quantity=max(0,n-credit),quantity_rule='MAX_COMMON_FACILITY' if facility else 'SUM_DISTINCT_WET',order_status='UNCONFIRMED',specification=' | '.join(pm[pn].get('notes',[])),material=pm[pn]['material'],release='EXISTING_SCOPE_ONLY; NEWCOUNTS_NOTORDER')
 bom.append(row)
 if pm[pn]['kind']=='BUY':purch.append(row)
b.cw('R17_CONFIGURED_BOM.csv',bom);b.cw('R17_PURCHASE_NET_NEEDS.csv',purch)
workqueue=[]
for q in csv.DictReader((ROOT/'R17_INPUT/signed/audit/W1_ORIGINAL_ROWS_FOR_REVIEW.csv').open(encoding='utf-8-sig')):
 workqueue.append(dict(PN=q['PN'],quantity=q['P1_required'],disposition='CANDIDATE_W1_01' if q['PN'] in w1 else 'REMAINING_SHOP_DEFINITION_REVIEW',reason='Singleclearloosepartdefinition' if q['PN'] in w1 else 'No blanketBRepstabilityrelease; softfreegeometry/seatload/weldrouteorinterfacepagesnotclosedthisorder'))
b.cw('R17_W1_DISPOSITION.csv',workqueue)
for pn in changed+w1+['TF908']:
 if pn not in pm or not any(q['pn']==pn for oo in sets.values() for q in oo):continue
 p=pm[pn];folder='purchase' if p['kind']=='BUY' else 'parts';b.ex.export_step(f'{folder}/{pn}_R17',[dict(definition=pn,occurrence=pn,scope='PURCHASE' if folder=='purchase' else 'FIXTURE')],{pn:S[pn]})
print('CANDIDATES',len(candidates),sum(q['quantity'] for q in candidates),'W1',sum(q['quantity'] for q in candidates if q['batch']=='W1-01'),flush=True)
