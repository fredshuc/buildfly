"""Read-only reproduction of current R21 native validity/placement and inherited hashes.
Run from any working directory: python R21_WORK/source/reproduce_current.py
Requires versions in deliverables/evidence/R21_RUNTIME_VERSIONS.json.
This does not run load cases, declare fabrication release or overwrite evidence.
"""
from pathlib import Path
import json,hashlib,numpy as np
import build_c02 as b
D=b.OUT
proof=json.loads((D/'evidence/R21_BASELINE_IMMUTABILITY.json').read_text())
for q in proof:
 p=D/q['file']
 if len(p.read_bytes())!=q['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=q['sha256']:raise ValueError(q['file'])
parts=json.loads((D/'native/R20_PARTS.json').read_text());names={q['pn']for q in parts};invalid=[]
for p in parts:
 s=b.ex.readshape(p['brep'])
 if not s.isValid() or not s.Solids():invalid.append(p['pn'])
if invalid:raise ValueError(invalid)
for cfg,n in [('P',1506),('R',1073)]:
 oo=json.loads((D/f'native/R20_{cfg}_OCCURRENCES.json').read_text())
 if len(oo)!=n or len({q['occurrence']for q in oo})!=n:raise ValueError((cfg,'count/identity'))
 for q in oo:
  rot=np.array([q['u'],q['v'],q['n']]).T
  if q['pn']not in names or np.max(abs(rot.T@rot-np.eye(3)))>1e-8 or abs(np.linalg.det(rot)-1)>1e-8:raise ValueError(q['occurrence'])
 print(cfg,n,'placements valid')
print('Native definitions',len(parts),'valid;5 inherited file hashes exact. No new STEP reimport, collision or loaded solve.')
