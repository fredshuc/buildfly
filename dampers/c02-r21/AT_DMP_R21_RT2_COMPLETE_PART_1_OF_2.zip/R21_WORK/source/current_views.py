import json,numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
import build_c02 as b
D=b.OUT;pm={p['pn']:p for p in json.loads((D/'native/R20_PARTS.json').read_text())};cache={};proof=[]
for cfg in ['P','R']:
 oo=json.loads((D/f'native/R20_{cfg}_OCCURRENCES.json').read_text());triangles=[];colors=[]
 for q in oo:
  pn=q['pn']
  if pn not in cache:
   s=b.ex.readshape(pm[pn]['brep']);vv,tt=s.tessellate(.7,.35);cache[pn]=(np.array([v.toTuple()for v in vv]),np.array(tt))
  vv,tt=cache[pn];rot=np.array([q['u'],q['v'],q['n']]).T;pts=vv@rot.T+np.array(q['o']);triangles.append(pts[tt])
  col=(.30,.51,.57,.85) if q.get('physical_class')=='PRODUCT' else (.50,.55,.60,.8)
  if pm[pn]['kind']=='BUY':col=(.63,.50,.35,.8)
  colors.extend([col]*len(tt))
 xyz=np.concatenate(triangles);cc=np.array(colors);fig,axs=plt.subplots(1,2,figsize=(14,7))
 for ax,mode in zip(axs,['overall','wet_dry_detail']):
  xx=xyz[:,:,1]+.38*xyz[:,:,0];yy=xyz[:,:,2]+.13*xyz[:,:,0];dep=xyz[:,:,0].mean(axis=1);idx=np.argsort(dep)
  poly=np.stack([xx,yy],axis=2);ax.add_collection(PolyCollection(poly[idx],facecolors=cc[idx],edgecolors='none',rasterized=True));ax.autoscale();ax.set_aspect('equal');ax.grid(alpha=.15);ax.set_xlabel('Y +0.38X (mm)');ax.set_ylabel('Z +0.13X (mm)')
  if mode=='wet_dry_detail':ax.set_xlim(-1210,50);ax.set_ylim(1410,1790)
  ax.set_title(mode.replace('_',' '))
 fig.suptitle(cfg+' current cold-test configuration | '+str(len(oo))+' actual placed instances\nAll solids tessellated; projected illustration only. No fixture qualification or hidden-detail acceptance.',fontsize=11);fig.tight_layout(rect=[0,0,1,.91]);fig.savefig(D/'drawings'/f'R21_{cfg}_CURRENT.png',dpi=135);plt.close(fig)
 proof.append(dict(config=cfg,instances=len(oo),triangles=len(xyz),native_source=f'R20_{cfg}_OCCURRENCES.json',geometry_changes=0,meaning='Every active placed native shape rendered; unqualified components still shown as baseline reference.'))
(D/'evidence/R21_CURRENT_RENDER.json').write_text(json.dumps(proof,indent=2));print(proof,flush=True)
