from pathlib import Path
import json,hashlib,zipfile,shutil,csv
R=Path(__file__).resolve().parents[2];W=R/'R21_WORK';D=W/'deliverables';O=W/'delivery';O.mkdir(exist_ok=True)
if json.loads((W/'ledger.json').read_text())['status']!='ENGINEERING_FROZEN':raise RuntimeError('Not frozen')
def pack(name,files):
 manifest=[dict(path=n,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for n,p in sorted(files.items())];dest=O/name
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for n,p in sorted(files.items()):z.write(p,n)
  z.writestr('MANIFEST_SHA256.json',json.dumps(manifest,indent=2))
 with zipfile.ZipFile(dest)as z:
  if z.testzip()is not None:raise ValueError('CRC')
  if len(z.namelist())!=len(manifest)+1:raise ValueError('members')
  for q in manifest:
   data=z.read(q['path'])
   if len(data)!=q['bytes']or hashlib.sha256(data).hexdigest()!=q['sha256']:raise ValueError(q['path'])
  if any(n.lower().endswith(('.ttf','.otf','.woff','.woff2'))for n in z.namelist()):raise ValueError('standalone font')
 return dict(file=str(dest),bytes=dest.stat().st_size,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),members=len(manifest)+1,manifest_entries=len(manifest),CRC_and_manifest='PASS')
factory={}
for p in (D/'factory').rglob('*'):
 if p.is_file() and p.name not in ['CURRENT_ISSUED_PAGES.pdf','ISSUED_SOURCE_PAGES.pdf']:factory[p.relative_to(D).as_posix()]=p
for p in (D/'tables').glob('R21_*.csv'):factory[p.relative_to(D).as_posix()]=p
for p in (D/'step').glob('*.stp'):factory[p.relative_to(D).as_posix()]=p
for name in ['R21_COORDINATE_FRAMES.json','R21_METADATA_OVERRIDES.json']:factory['native/'+name]=D/'native'/name
for name in ['R21_FINAL_QA.json','R21_MASTER_SUMMARY.json','R21_G903_ALIAS_CORRECTION.json','R21_CURRENT_PAGES_MAP.json','R21_PAGE_GRAPHICS_BINDING.json']:factory['evidence/'+name]=D/'evidence'/name
factory['drawings/AT_DMP_R21_P1_MASTER_AND_RT2_REVIEW_EN.pdf']=D/'drawings/AT_DMP_R21_P1_MASTER_AND_RT2_REVIEW_EN.pdf';factory['00_START_HERE_EN.md']=D/'00_START_HERE_EN.md'
f=pack('AT_DMP_P1_R21_MANUFACTURING_MASTER_20261013.zip',factory)
full={}
for p in D.rglob('*'):
 if not p.is_file()or'__pycache__'in p.parts:continue
 rel=p.relative_to(D)
 if rel.parts[0]=='factory'and rel.as_posix()not in factory:continue
 if rel.parts[0]=='tables'and not p.name.startswith('R21_'):continue
 full['R21_WORK/deliverables/'+rel.as_posix()]=p
for p in (W/'source').glob('*.py'):full['R21_WORK/source/'+p.name]=p
full['R21_WORK/ledger.json']=W/'ledger.json';full['00_START_HERE_EN.md']=D/'00_START_HERE_EN.md'
g=pack('AT_DMP02_C02_R21_FULL_RT2_REVIEW_20261013.zip',full)
with zipfile.ZipFile(f['file'])as z:
 if any('DIAGNOSTIC_ONLY.dxf'in n or 'P109_SP06.dxf'in n or 'R109_SP06.dxf'in n for n in z.namelist()):raise ValueError('film cutting quarantine')
 names=set(z.namelist())
 for q in csv.DictReader((D/'tables/R21_CURRENT_FACTORY_ENTRY_INDEX.csv').open(encoding='utf-8-sig')):
  for k in ['STEP','DXF']:
   if q[k]and 'factory/'+q['packet']+'/'+q[k]not in names:raise ValueError((q['PN'],k))
for p in [D/'drawings/AT_DMP_R21_P1_MASTER_AND_RT2_REVIEW_EN.pdf',D/'factory/R21_CURRENT_ISSUED_PAGES.pdf',D/'L2_TO_L1_AT_DMP02_C02_R21_RETURN_20261013_EN.md']:shutil.copy2(p,O/p.name)
(O/'PACKAGE_RECEIPT.json').write_text(json.dumps([g,f],indent=2));print(json.dumps([g,f],indent=2))
