from pathlib import Path
import csv,json,hashlib,shutil,collections
from pypdf import PdfReader,PdfWriter
R=Path(__file__).resolve().parents[2];W=R/'R21_WORK';D=W/'deliverables';T=D/'tables';F=D/'factory'
def rows(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
def cw(n,rr):
 with (T/n).open('w',encoding='utf-8-sig',newline='')as h:w=csv.DictWriter(h,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
source=R/'R20_WORK/deliverables'; index=rows(source/'tables/R20_CURRENT_FACTORY_ENTRY_INDEX.csv')
f07=rows(W/'input/F07/tables/SP06_PRODUCT_FAB_RELEASED.csv'); overrides=json.loads((W/'input/signed/R20_L1_F07_PROCESS_AND_SCOPE_OVERRIDES.json').read_text())
writer=PdfWriter();old=PdfReader(F/'CURRENT_ISSUED_PAGES.pdf');new=PdfReader(W/'input/F07/drawings/AT_DMP_P1_SP06_PRODUCT_FAB_RELEASE_R20_L1_F07_EN.pdf')
for page in old.pages:writer.add_page(page)
for page in new.pages:writer.add_page(page)
with (F/'R21_CURRENT_ISSUED_PAGES.pdf').open('wb')as h:writer.write(h)
for q in index:
 q['PDF']='R21_CURRENT_ISSUED_PAGES.pdf'
 if q['PN']=='G903' and q['release']=='F05' and q['STEP']=='G903_R18.stp':
  q['PN']='G903_R18';q['supersedes']='F05 exact replacement G903_R18, one sequential common physical guard; old G903 is alias/retired geometry, not another order.'
for q in f07:
 index.append(dict(PN=q['PN'],allocation='PRODUCT_SP06_SIX_STATIONS',release='F07',stage='P1_FAB_RELEASED_LOOSE_PARTS_AND_MATCHED_J401_J407',packet='F07_PRODUCT/step/parts',PDF='R21_CURRENT_ISSUED_PAGES.pdf',source_pages=';'.join('F07/drawings/AT_DMP_P1_SP06_PRODUCT_FAB_RELEASE_R20_L1_F07_EN.pdf:'+n for n in q['current_pdf_pages'].split(',')),STEP=Path(q['STEP']).name,DXF='',supersedes='R20 SP06 candidate drawing for this product allocation only; independent SP04 stays F03',factory_status='UNCONFIRMED',current_PDF_pages=','.join(str(int(n)+len(old.pages))for n in q['current_pdf_pages'].split(','))))
if len(index)!=172:raise ValueError(len(index))
for q in index:
 packet=F/q['packet']
 for key in ['STEP','DXF']:
  if q[key] and not(packet/q[key]).exists():raise ValueError((q['PN'],key,q[key]))
cw('R21_CURRENT_FACTORY_ENTRY_INDEX.csv',index)
bom=rows(W/'input/signed/R20_L1_F07_NET_NEED_VIEW.csv');fmap={q['PN']:q for q in f07}
for q in bom:
 if q['PN']=='G903_R18':
  signed=next(r for r in rows(R/'R20_WORK/input/releases/F05/tables/F05_ISSUED_STAGES.csv')if r['PN']=='G903_R18')
  if int(signed['quantity'])!=1:raise ValueError(signed)
  q.update(issued_scoped_quantity='1',not_yet_issued_quantity='0',release='F05',stage=signed['status'] if 'status'in signed else 'P1_FAB_RELEASED_LOOSE_OR_SPECIFIED_SHAFT_STAGE',gap='NONE_FOR_ISSUED_LOOSE_SCOPE',next_action='F05 existing one-position replacement only; no extra guard. Match actual G903_R18 STEP and current pages88-90.',PDF_pages='F05 guard pages1-3',STEP='current/PRODUCT_OR_SHARED_FACILITY/G903/G903_R18.stp',DXF='current/PRODUCT_OR_SHARED_FACILITY/G903/G903_R18_XZ.dxf')
 if q['physical_family']=='PRODUCT' and q['supply_PN'] in fmap:
  q['candidate_PDF_pages']='';q['candidate_STEP']='';q['candidate_status']='SUPERSEDED_BY_F07_PRODUCT_RELEASE'
  q['next_action']='F07 scatter-part fabrication; J401/J407 matched press and finish-bore; dimensional mating only under independent support; no preload or rotor load transfer'
 q['current_entry_key']=q['supply_PN']+' / '+('PRODUCT_SP06_SIX_STATIONS'if q['physical_family']=='PRODUCT'and q['supply_PN']in fmap else 'see current allocation index')
 q['current_entry_index']='R21_CURRENT_FACTORY_ENTRY_INDEX.csv'
 q['prior_paths_role']='Source provenance only; current file locator is R21 index, not old PDF_pages/STEP paths'
total=sum(int(q['net_physical_need'])for q in bom);credit=sum(int(q['issued_scoped_quantity'])for q in bom);gaps=[q for q in bom if int(q['not_yet_issued_quantity'])]
if (total,credit,len(gaps))!=(2265,689,88):raise ValueError((total,credit,len(gaps)))
cw('R21_NET_NEED_BOM.csv',bom)
feedback={'A703P','A703R','A704R8','A705','A706','A707','A710','B850','B851','B852','B853','HW_R11_GUIDE_M5'}
interface={'P107','P107B','R107','G840P1','G840P2','G843'}
for q in gaps:
 pn=q['PN']
 if q['kind']=='BUY':cat='PROCUREMENT_CONTRACT';act='Obtain manufacturer/standard and revision, exact interface and actual certificates per R21 purchase question row; do not infer interchangeability from CAD proxy.'
 elif pn in ['P109','R109']:cat='KNOWN_GEOMETRY_AND_RETENTION';act='Open-slot diagnostic fixes DXF topology only; develop connected end-lip retention with unchanged metal interface or explicitly approved replaceable keeper. No old DXF cutting.'
 elif pn in feedback:cat='PRODUCT_SCOPE_AND_CAPTURE';act='Independent B01/E01 specimen quantities are not product release. Close actual root capture/contact interface and submit product manufacturing allocation; retain existing specimen release.'
 elif pn in interface:cat='MISSING_PRODUCT_INTERFACE_DEFINITION';act='Resolve named product receiver/hinge/root with actual host holes and access; present one dimensioned manufacturable interface and allocation to L1.'
 elif pn=='G903_R18':cat='REPLACEMENT_ALLOCATION_REVIEW';act='Reconcile actual R18 taller P guard replacement against F05 release index; retain cold clearance evidence but do not assume automatic new quantity credit.'
 elif pn=='STD01PC':cat='CUSTOM_FASTENER_DEFINITION';act='Provide controlled full-thread/shoulder/relief definition and complete thread inspection for four product fasteners; purchased bolt substitution requires exact interface proof.'
 else:cat='NAMED_DRAWING_OR_ALLOCATION_GAP';act='Supply missing current manufacturing page and exact physical allocation; no historical independent specimen deduction.'
 q['gap_class']=cat;q['next_minimum_action']=act;q['blocks_scope']='This PN and its dependent installation/use; does not cancel unrelated signed fabrication.'
cw('R21_CLASSIFIED_GAPS.csv',gaps)
proc=rows(source/'tables/R20_PROCUREMENT_INTERFACE_REGISTER.csv')
special={'BUY504':'Gear and friction bush: tooth/face/hub/bore, real mounting, maker duty rating; no proxy-to-manufacture conversion.', 'BUY520':'Primary torque limiter: exact type/range, bidirectional static and dynamic release, re-engagement and disconnect detection; inherited settings are requirements only.', 'BUY521':'Independent second limiter: fault independence, exact release range and dynamic upper bound with real inertia; no combined rating inferred.', 'BUY530':'Torque transducer: real calibration, range, overload, uncertainty, mounting and separate safety stop.', 'BUY531':'Bellows coupling: bore/clamp dimensions, alignment and stiffness with actual temperature and torque.', 'BUY_R13_7206':'7206 bearing exact suffix, contact angle/preload class, shoulder limits, mounting condition and lubrication.', 'BUY_R13_BK2':'BK2 exact version and bore pair; torque/misalignment/axial reaction; never a lifting point.', 'BUY402':'EPDM 70 peroxide formulation, 30 x 3 dimensional contract and water/temperature/compression set lot evidence.', 'BUY548':'SCHNORR 002700A batch dimensions and complete 2-series x 3-parallel force/height curve, guide/friction/relaxation at intended temperature.', 'BUY_R9_DS001500A':'SCHNORR 001500A feedback stack 5-series x 2-parallel measured curves/hysteresis; do not mix with wet 002700A.', 'BUY703':'Encoder exact shaft/root interface, orientation, coupling and electrical supply/output contract; feedback not sole safety protection.', 'BUY704':'Encoder coupling exact bores, axial stroke, torque and permitted misalignment.'}
for q in proc:
 feat=json.loads(q['inherited_feature_contract']);types={x.get('type','')for x in feat}
 q['purchase_group']='FUNCTIONAL_PURCHASE'if q['PN']in special else 'FASTENER_OR_SMALL_HARDWARE'
 q['question']=special.get(q['PN'],'Confirm the inherited feature dimensions plus complete ISO/DIN/product standard, thread pitch/tolerance, effective full-thread length, chamfers, strength/hardness/coating and locking method; submit sample before dependent fit/locking use.')
 q['release_note']='Technical enquiry draft only; no order, substitute or supplier availability is asserted.'
 q['required_response_fields']='manufacturer; exact part and revision; drawing; material/grade; tolerances; batch certificate; deviations; availability/quotation if offered; actual delivery status'
cw('R21_PURCHASE_TECHNICAL_ENQUIRIES.csv',proc)
cw('R21_FUNCTIONAL_COMPLETENESS.csv',[
 dict(group='Shell and R100S',definition='F05/F06 manufacturing stages issued',first_assembly='Coupon + first P and R shell unclamp/match/post-machine gates; fixture acceptance missing',test_use='Pressure and operational leakage not released',next_action='Same-material restrained coupon sections and recorded first-piece dimensions'),
 dict(group='Three B200 rotors',definition='F05 6 blades +3 shaft blanks; 3 labour identities not extra material',first_assembly='Finished journal and positive external capture acceptance required',test_use='Wet loaded rotation not released',next_action='Inspect each welded/finished shaft and qualify external cradle/end catch'),
 dict(group='Six glands and thrust',definition='F07 13MAKE144; four BUY families183 supplier HOLD',first_assembly='Matched J401/J407 process released; fixed/floating allocation explicit; unloaded support only',test_use='Preload, torque, hot and rotor load transfer HOLD',next_action='F07 inspection then exact purchased seals/springs and actual station checks'),
 dict(group='Dynamic foam/PTFE/U-frame',definition='Foam/shims and one-piece frames retain signed scopes; films4P+4R not cut-released',first_assembly='Film end lip/corner retention known gap',test_use='Seal motion/leakage/life HOLD',next_action='Retained end-detail before film release; blank uncut PTFE stock only if ordered separately'),
 dict(group='Short shaft/bearings/couplings',definition='F01/F02/F04 machining scopes plus functional supplier confirmation',first_assembly='Match bores/shafts and captures; G1 compliance unresolved',test_use='Normal78/38 Nm and jam200 Nm not qualified operations',next_action='Actual bearing/coupling identity and measured supported compliance'),
 dict(group='Input/limiters/stops',definition='Finite input architecture and manufactured adapters; purchased units unconfirmed',first_assembly='Independent support and stopped/isolated fitting only',test_use='Dynamic peaks and stop deflection HOLD',next_action='Exact limiter calibration and combined support/stop acceptance'),
 dict(group='Guards/feedback root',definition='A01/A02 panels issued; product roots/feedback capture remain specific gaps',first_assembly='No powered motion before capture and hand-access closure',test_use='Feedback accuracy and thermal retention HOLD',next_action='Close root-specific receiver and independent capture; reuse stable panels'),
 dict(group='Shared dry frame/WS17/receivers',definition='Sequential common facility; F06 50-weld fabrication only',first_assembly='Ground anchors, foot contact and full valve transfer not qualified',test_use='Valve weight/preload/torque HOLD',next_action='As-built floor/anchor/frame and dedicated transfer proof'),
 dict(group='Assembly and measurement tools',definition='Issued local tools and independent SP04/B01/E01 allocations',first_assembly='Actual shop platen/capture and complete handle trial absent',test_use='SP04 four-channel proposal only',next_action='Fixture and instrumentation acceptance records, surrogate stop/overshoot checks')])
readback=PdfReader(F/'R21_CURRENT_ISSUED_PAGES.pdf');proof=[]
for i,p in enumerate(list(old.pages)+list(new.pages)):
 same=readback.pages[i].extract_text()==p.extract_text()
 if not same:raise ValueError(('PDF page',i+1))
 proof.append(dict(current_page=i+1,source='R20 current book'if i<len(old.pages)else'F07 signed book',source_page=i+1 if i<len(old.pages)else i-len(old.pages)+1,text_sha256=hashlib.sha256(p.extract_text().encode()).hexdigest()))
(D/'evidence/R21_CURRENT_PAGES_MAP.json').write_text(json.dumps(proof,indent=2))
summary=dict(index_entries=len(index),unique_stage_names=161,stage_pieces=822,current_issued_pages=len(readback.pages),configured_identities=total,net_rows=len(bom),issued_scoped_credit=credit,not_issued=total-credit,gap_rows=len(gaps),gap_classes=dict(collections.Counter(q['gap_class']for q in gaps)),purchase_rows=len(proc),physical_changes=0,factory_feedback='NONE_RECEIVED')
(D/'evidence/R21_MASTER_SUMMARY.json').write_text(json.dumps(summary,indent=2))
(F/'00_START_HERE.txt').write_text('R21 CURRENT MANUFACTURING ENTRY\nUse tables/R21_CURRENT_FACTORY_ENTRY_INDEX.csv at package root and factory/R21_CURRENT_ISSUED_PAGES.pdf. 172 PN/allocation entries;243 inherited current pages. F07_PRODUCT is released for exactly13 PN144 product pieces; matched J401/J407 press and finish-bore included. F07 dimensional override is mandatory for J404/A709. Independent SP04 remains F03. Do not use the older R20 book/index as a competing entry. Original release ZIPs are provenance only. No bulk production from STEP directory. Full assemblies are cold review references, not release of every installed piece. F06 process stops, exact quantities and current allocation govern. Read R21 review book and tables for known holds.\n',encoding='utf-8')
print(json.dumps(summary,indent=2))
