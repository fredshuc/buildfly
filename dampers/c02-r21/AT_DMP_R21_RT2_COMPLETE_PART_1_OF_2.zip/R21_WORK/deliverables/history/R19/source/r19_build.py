import json,copy,math,hashlib,zipfile
import numpy as np
import build_c02 as b
R=b.ROOT.parent;D=R/'R18_WORK/deliverables';N=b.OUT/'native';E=b.OUT/'evidence'
orig=json.loads((D/'native/R18_PARTS.json').read_text());pm={p['pn']:copy.deepcopy(p)for p in orig};S={k:b.ex.readshape(p['brep'])for k,p in pm.items()};ass=json.loads((D/'native/R18_SHELL_ASSEMBLIES.json').read_text());f05=json.loads((R/'R19_INPUT/signed/deliverables/F05_PRESS_FRAME_GEOMETRY_OVERRIDES.json').read_text())
for pn,p in f05.items():pm[pn].update(p);S[pn]=b.ex.readshape(p['brep'])
def prism(points,axis):return b.cq.Solid.extrudeLinear(b.cq.Wire.makePolygon([b.vec(p)for p in points+[points[0]]]),[],b.vec(axis))
def put(pn,s,source,stage):
 if not s.isValid() or len(s.Solids())!=1:raise ValueError((pn,'not one valid solid',len(s.Solids())))
 pm[pn]=copy.deepcopy(pm[source]);pm[pn].update(pn=pn,brep=b.brep(s),bbox=b.ex.bb(s),revision='R19',volume_mm3=s.Volume(),stage=stage,status='CANDIDATE_NOT_L1_RELEASED',source=source);S[pn]=s
# External sheet face is local Z3. Leave0.50 root across thickness; shallow groove1.00 axial x2.50 thickness.
preps={};zones={};prepqty={};material=[]
for src in ['P103F','P103B','R103F','R103B','P104','R104']:
 raw=src+'_R18RAW' if '103'in src else src;s=S[raw];bb=b.ex.bb(s);L,H,T=bb[3],bb[4],bb[5];gs=[];zs=[]
 for x,d in [(0,1),(L,-1)]:
  gs.append(prism([(x,0,.5),(x,0,3),(x+d,0,3)] if '103'in src else [(x,0,2.5),(x,0,0),(x+d,0,0)],(0,H,0)));zs.append(b.box(.50,H,3).translate((x if d==1 else x-.5,0,0)))
 if '103'in src:
  for y,d in [(0,1),(H,-1)]:
   gs.append(prism([(0,y,.5),(0,y,3),(0,y+d,3)],(L,0,0)));zs.append(b.box(L,.50,3).translate((0,y if d==1 else y-.5,0)))
 g=gs[0]
 for v in gs[1:]:g=g.fuse(v)
 fusion=zs[0]
 for v in zs[1:]+gs:fusion=fusion.fuse(v)
 g=g.intersect(s).clean();fusion=fusion.intersect(s).clean();prep=s.cut(g).clean();preps[src]=g;zones[src]=fusion
 put(src+'_R19PREP',prep,raw,'S0_TO_WELD_PREPARATION');pm[src+'_R19PREP']['preparation']='External face Z3 for103, Z0 for104; both flow endsX0/83 shallow bevel: depth1.00 axial,2.50 across thickness,0.50 root. Side103 also both longY edges;104 no long-edge bevel. Nominal zero rootgap; fit0..0.10; freeze geometry after coupon approval.'
 material.append(dict(source=src,prep=src+'_R19PREP',removed_mm3=g.Volume(),root_remelt_zone_mm3=fusion.cut(g).Volume(),single_solid=True))
# Final parent/weld partition: keep all original final material, with weld volume explicitly replacing groove + root remelt. No old external fillets credited.
worldzones={};localweld={};newass={};contacts=[];recompose=[]
for pn,a in ass.items():
 if pn=='R100S':continue
 newa=copy.deepcopy(a);newa['status']='PREPARED_FLUSH_FULL_PENETRATION_CANDIDATE_PQR_REQUIRED';ws=[];finals=[];prepitems=[]
 for q in a['items']:
  src=q['pn'];s=b.tr(S[src],q['o'],q['u'],q['v'],q['n']);finals.append(s)
  if src in zones:
   # Build nominal FINAL-zone on finished plate, not pre-bore pilot stock.
   z=zones[src].intersect(S[src]);loc=b.tr(z,q['o'],q['u'],q['v'],q['n']);ws.append(dict(id=pn+'_'+q['id']+'_FUSION',source_part=src,brep=b.brep(loc),bbox=b.ex.bb(loc),volume_mm3=loc.Volume(),role='nominal groove fill plus root remelt; final flush envelope; not excess bead'))
   qq=copy.deepcopy(q);qq['pn']=src+'_R19PREP';prepitems.append(qq)
  else:prepitems.append(q)
 newa['preparation_items']=prepitems;newa['final_items']=a['items'];newass[pn]=newa;localweld[pn]=ws
 # Inspect touching OTHER parent parts. Junctions must connect across real plate interfaces.
 for w in ws:
  z=b.ex.readshape(w['brep']);touch=[]
  for q,s in zip(a['items'],finals):
   if q['pn']==w['source_part']:continue
   if z.distance(s)<.0001:touch.append(q['id'])
  contacts.append(dict(weld=w['id'],contacts=touch,has_other_parent=bool(touch),volume_mm3=z.Volume()))
 recompose.append(dict(assembly=pn,final_parent_envelope_unchanged=True,added_outside_original_mm3=0,finished_weld_zone_count=len(ws)))
 A=np.array(a['reference_world_matrix']);o=np.array(a['reference_world_origin']);Q=np.array([[0,0,-1],[0,1,0],[1,0,0]])if pn[0]=='P'else np.eye(3);t=np.array([1451,0,2022])if pn[0]=='P'else np.zeros(3);AA=Q@A;oo=Q@o+t
 for w in ws:worldzones[w['id']]=b.tr(b.ex.readshape(w['brep']),oo,AA[:,0],AA[:,1],AA[:,2])
b.dump(N/'R19_PARTS.json',list(pm.values()));b.dump(N/'R19_SHELL_ASSEMBLIES.json',newass);b.dump(N/'R19_SHELL_WELDS.json',localweld);b.dump(E/'R19_PREP_DEFINITION.json',material);b.dump(E/'R19_WELD_PARENT_CONTACT.json',contacts);b.dump(E/'R19_FINAL_ENVELOPE.json',recompose)
# F05 overrides in active configuration point to corrected geometry; explicit native catalogue is authoritative.
for tag in ['P','R']:
 o=json.loads((D/f'native/R18_{tag}_OCCURRENCES.json').read_text())
 for q in o:
  if q['pn']in f05:q['revision']='R18-L1-F05';q['part_key']=q['pn']+'@R18-L1-F05'
 b.dump(N/f'R19_{tag}_OCCURRENCES.json',o)
b.dump(E/'R19_ROUND1_DECISION.json',dict(chosen='A external shallow prepared flush full-penetration joints for port,split,and wall corner; no change to flange holes,beam ends,soft contours',rejected_alternative='B internal fillets plus beam corner relief; corner relief approaches endM5 major-thread edge and would require further screw/hole ECO',PQR='Same304L3mm zero-gap0..0.10 representative T and corner coupons, access same as actual. Crosssection macros at straight,start/stop,corner demonstrate continuous3mm effective wall-to-flange fusion and no cracks/root lack-of-fusion. Before product weld. VT/PT not substitute.',nominal_bevel=dict(depth_axial=1,width_thickness=2.5,root=.5),engineering_status='GEOMETRY_AND_PROCESS_CANDIDATE_NOT_RELEASED'))
print('PREP',len(material),'WELD_GROUPS',sum(map(len,localweld.values())),'CONTACT_FAIL',[x for x in contacts if not x['has_other_parent']],flush=True)
