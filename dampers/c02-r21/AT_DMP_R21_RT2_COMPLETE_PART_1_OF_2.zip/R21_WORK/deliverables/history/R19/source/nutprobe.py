import json,collections
from pathlib import Path
D=Path('R19_WORK/deliverables/native');P={p['pn']:p for p in json.loads((D/'R19_PARTS.json').read_text(encoding='utf8'))}
for n in P:
 if n.startswith('HW_N'):print(n,P[n]['bbox'])
