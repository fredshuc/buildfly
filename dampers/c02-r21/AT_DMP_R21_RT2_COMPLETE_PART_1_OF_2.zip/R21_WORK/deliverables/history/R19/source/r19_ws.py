import json,copy,math,numpy as np
import build_c02 as b
R=b.ROOT.parent;N=b.OUT/'native';E=b.OUT/'evidence';P={p['pn']:p for p in json.loads((N/'R19_PARTS.json').read_text())};S={k:b.ex.readshape(p['brep'])for k,p in P.items()};old=json.loads((R/'R18_WORK/deliverables/native/R18_WS17_WELD_MATERIAL.json').read_text());new=[];rings=[]
def rec(name,s,kind,params):
 if not s.isValid():raise ValueError(name)
 new.append(dict(id=name,brep=b.brep(s),kind=kind,parameters=params,volume_mm3=s.Volume()));return s
for x in [-230,231]:
 for y in [-400,-180]:
  for z,flip in [(1388,False),(1466,True)]:
   cone=b.cq.Solid.makeCone(10 if flip else 12,12 if flip else 10,2,b.vec((x,y,z)),b.vec((0,0,1)));s=cone.cut(b.cyl(20,4,(x,y,z-1))).clean();rec(f'SLEEVE_GROOVE_{x}_{y}_{z}',s,'annular_groove_fill',dict(sleeve_OD=20,sleeve_ID=11,face_opening_diameter=24,depth=2,nominal_fusion_depth=2,minimum_effective_throat=1.30,flush=True));rings.append(s)
for x,sg in [(-250,-1),(251,1)]:
 for y in [-550,-150]:
  for yy,sy in [(y,-1),(y+60,1)]:
   v=[b.vec((x,yy,1448)),b.vec((x+sg*4*math.sqrt(2),yy,1448)),b.vec((x,yy+sy*4*math.sqrt(2),1448))];s=b.cq.Solid.extrudeLinear(b.cq.Wire.makePolygon(v+[v[0]]),[],b.vec((0,0,20)));rec(f'RETAINER_SIDE_{x}_{yy}',s,'real_vertical_fillet',dict(throat=4,length=20,root=[x,yy,1448],axis=[0,0,1],leg_directions=[[sg,0,0],[0,sy,0]]))
O=json.loads((N/'R19_P_OCCURRENCES.json').read_text());world={q['occurrence']:b.tr(S[q['pn']],q['o'],q['u'],q['v'],q['n'])for q in O};prep=[]
for q in O:
 if q['pn']not in ['TF921L','TF921R']:continue
 pn=q['pn'];base=world[q['occurrence']];cut=base
 for w in rings:cut=cut.cut(w)
 U=np.column_stack([q['u'],q['v'],q['n']]);s=b.tr(cut,-U.T@np.array(q['o']),*U.T.T).clean();nn=pn+'_R19PREP';p=copy.deepcopy(P[pn]);p.update(pn=nn,source=pn,revision='R19_PROCESS_ECO',brep=b.brep(s),bbox=b.ex.bb(s),status='WELD_PREPARATION_CANDIDATE',notes=['Four annular groove mouths per rail: both ends of each of the two existing sleeve holes. Diameter24.00 +/-0.10, depth2.00 +/-0.10 into5mm rail wall;45degree conical face fromholeD20 to mouthD24. Minimum remaining wall2.80mm. Do not enlarge the through sleeve bore or relocate holes.']);P[nn]=p;S[nn]=s;prep.append(dict(PN=nn,quantity=1,source=pn,removed_mm3=base.Volume()-cut.Volume(),single_solid=len(s.Solids())==1));b.ex.export_step('parts/'+nn,[dict(definition=nn,occurrence=nn,scope='FIXTURE')],{nn:s})
b.dump(N/'R19_PARTS.json',list(P.values()));b.dump(N/'R19_WS17_NEW_WELDS.json',new);b.dump(N/'R19_WS17_ALL_WELDS.json',old+new);b.dump(E/'R19_WS17_PREPARATIONS.json',prep)
# New deposit checks: sleeve-groove regions explicitly replace rail material, not new external collisions.
hits=[];contacts=[];pair=0
for tag in ['P','R']:
 O=json.loads((N/f'R19_{tag}_OCCURRENCES.json').read_text());W={q['occurrence']:b.tr(S[q['pn']],q['o'],q['u'],q['v'],q['n'])for q in O};BB={k:b.ex.bb(s)for k,s in W.items()}
 for r in new:
  s=b.ex.readshape(r['brep']);bb=b.ex.bb(s);touch=[];remelt=[]
  for q in O:
   k=q['occurrence'];cc=BB[k]
   if not all(min(bb[i+3],cc[i+3])-max(bb[i],cc[i])>=-1e-5 for i in range(3)):continue
   if s.distance(W[k])<1e-4:touch.append(k)
   if not all(min(bb[i+3],cc[i+3])-max(bb[i],cc[i])>1e-5 for i in range(3)):continue
   pair+=1;v=abs(s.intersect(W[k]).Volume())
   if v>.001:
    rr=dict(config=tag,weld=r['id'],part=k,PN=q['pn'],mm3=v)
    if r['kind']=='annular_groove_fill'and q['pn']in ['TF921L','TF921R']:remelt.append(rr)
    else:hits.append(rr)
  contacts.append(dict(config=tag,weld=r['id'],touching=touch,declared_groove_replacement=remelt,pass_=len(touch)>=2))
b.dump(E/'R19_WS17_NEW_JOINT_CHECK.json',dict(new_welds=len(new),total_welds=len(old+new),pairs=pair,unapproved_hits=hits,contacts=contacts))
sh={q['id']:b.ex.readshape(q['brep'])for q in old+new};b.ex.export_step('R19_WS17_COMPLETE_WELD_LAYER',[dict(definition=k,occurrence=k,scope='DRIVE')for k in sh],sh)
# True local final partitions at each joint, no double-counted rail material.
sh={};rr=[]
for q in O:
 if q['pn']not in ['TF921L','TF921R','TF926','TF927']:continue
 s=W[q['occurrence']]
 if q['pn']in ['TF921L','TF921R']:
  for w in rings:s=s.cut(w)
 k=q['occurrence'];sh[k]=s;rr.append(dict(definition=k,occurrence=k,scope='FIXTURE'))
for r in new:k=r['id'];sh[k]=b.ex.readshape(r['brep']);rr.append(dict(definition=k,occurrence=k,scope='DRIVE'))
b.ex.export_step('R19_WS17_TWO_JOINTS_PARTITION',rr,sh)
# Unit-load geometry coefficients only, no capacity or load release.
calc=dict(retainer_route='existing lowera4x60 plus two real verticala4x20; no upper fillet',area_mm2=400,centroid_Z_mm=1452,Iy_mm4=14933.3333333333,Iz_mm4=216000,normal_stress_per_1kN_at_Z1488_Yedge30_MPa=1000*(1/400+36*16/14933.3333333333+30*30/216000),sleeve_two_ring_effective_area_mm2=2*math.pi*20*1.30,sleeve_weld_average_stress_per_1kN_MPa=1000/(2*math.pi*20*1.30),scope='Rigid-root weld-group diagnostic only. Actual normal/shear/contact distribution, weld allowable and frame/anchor flexibility not qualified; no valve weight or bolt preload permission.')
b.dump(E/'R19_WS17_UNIT_LOAD.json',calc);print('WS17_NEW',len(new),'ALL',len(old+new),'HITS',hits,'CONTACTFAIL',[q for q in contacts if not q['pass_']],flush=True)

