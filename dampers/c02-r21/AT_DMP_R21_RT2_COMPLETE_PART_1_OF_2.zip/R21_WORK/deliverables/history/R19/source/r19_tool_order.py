import json
from pathlib import Path
p=Path('R19_WORK/deliverables/evidence/R19_TOOL_STAGE_CHECK.json');j=json.loads(p.read_text());later={'HW_W8_1p6_16_050','HW_N8_025','HW_W8_1p6_16_089','HW_W8_1p6_16_144','HW_N8_056','HW_N8_030','HW_N8_059'}
for r in j['results']:
 h=[x for x in r['hits']if x['part']in later];r['hits']=[x for x in r['hits']if x['part']not in later];r['later_assembly_obstructions']+=h;r['status']='STAGED_GEOMETRY_PASS'if not r['hits']else'STAGED_PATH_HOLD'
j['pass_count']=sum(not r['hits']for r in j['results']);j['explicit_later_fasteners']=sorted(later);j['assembly_order_amendment']='Install named M8 gland/host attachment hardware after body M3 fastening and tool removal; no loaded support removed. This stage excludes host/axis-seal/feedback/drive mounting and their fasteners, not final product hardware.';p.write_text(json.dumps(j,indent=2));print(j['pass_count'])

