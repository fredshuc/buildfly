import json,math,numpy as np
import build_c02 as b
R=b.ROOT.parent;N=b.OUT/'native';E=b.OUT/'evidence';pm={p['pn']:p for p in json.loads((N/'R19_PARTS.json').read_text())};S={k:b.ex.readshape(p['brep'])for k,p in pm.items()};initial=json.loads((E/'R19_TOOL_INITIAL_FAILURE.json').read_text())['results'];ass=json.loads((N/'R19_SHELL_ASSEMBLIES.json').read_text());old=json.loads((R/'R18_WORK/deliverables/evidence/R18_SHELL_WELD_NEIGHBOURS.json').read_text())['hits'];out=[];shapes={};excluded=[]
def broad(a,c):return all(min(a[k+3],c[k+3])-max(a[k],c[k])>1e-5 for k in range(3))
def hexhole(af,h):return b.cq.Workplane('XY').polygon(6,af/math.cos(math.pi/6)).extrude(h).val()
sock=b.cyl(13.4,9).cut(hexhole(10.2,11).translate((0,0,-1))).clean();b.ex.export_step('TOOL_R19_M6_TUBULAR',[dict(definition='M6_OD13p4_AF10p2_L9',occurrence='M6_OD13p4_AF10p2_L9',scope='FIXTURE')],{'M6_OD13p4_AF10p2_L9':sock})
for tag in ['P','R']:
 O=json.loads((N/f'R19_{tag}_OCCURRENCES.json').read_text());od={q['occurrence']:q for q in O};W={q['occurrence']:b.tr(S[q['pn']],q['o'],q['u'],q['v'],q['n'])for q in O};BB={k:b.ex.bb(s)for k,s in W.items()}
 # Explicit assembly stage: body plates, seats, paired static seals and their fastening only; gland/drive/feedback mounted afterwards on external assembly support.
 active={q['occurrence']for q in O if q['pn'].startswith((tag+'10','S30','S31','HW_','STD08','STD06')) or q['pn'] in ['B200_R13','P110','R110']}
 for row in initial:
  if row['config']!=tag:continue
  q=od[row['nut']];u=np.array(q['u']);v=np.array(q['v']);nn=np.array(q['n']);origin=np.array(q['o']);angle=0
  if q['pn']=='HW_N6':local=sock.translate((0,0,1));moves=[nn*d for d in [0,5,15,30]]
  else:
   hh=next(h for h in old if h['part']==q['occurrence']and h['config']==tag);a=ass[hh['weld'].split('_')[0]];A=np.array(a['reference_world_matrix']);Q=np.array([[0,0,-1],[0,1,0],[1,0,0]])if tag=='P'else np.eye(3);zdir=(Q@A)[:,2];angle=math.degrees(math.atan2(zdir@v,zdir@u));ph=math.radians(angle)
   # Asymmetric open hex crowfoot. Opening toward port; two tips end2.5mm from nutcentre, giving1.0mm nominal flange gap.
   head=b.box(7.5,10,2).translate((-5,-5,0)).fuse(b.box(20,5,2).translate((-25,-2.5,0)));hole=hexhole(5.6,4).rotate((0,0,0),(0,0,1),-angle).translate((0,0,-1));head=head.cut(hole).cut(b.box(5,6.7,4).translate((0,-3.35,-1))).clean();local=head.rotate((0,0,0),(0,0,1),angle).translate((0,0,1));openvec=math.cos(ph)*u+math.sin(ph)*v;moves=[-openvec*d for d in [0,3,8]]+[-openvec*8+nn*d for d in [5,20]]
  base=b.tr(local,origin,u,v,nn);hits=[];finalhits=[]
  for i,m in enumerate(moves):
   s=base.translate(tuple(m));bb=b.ex.bb(s)
   for k in W:
    if not broad(bb,BB[k]):continue
    vol=abs(s.intersect(W[k]).Volume())
    if vol>.001:
     h=dict(part=k,mm3=vol,position_index=i)
     if k in active:hits.append(h)
     else:finalhits.append(h)
  out.append(dict(config=tag,nut=q['occurrence'],PN=q['pn'],crowfoot_angle_deg=angle,hits=hits,later_assembly_obstructions=finalhits,positions=len(moves),status='STAGED_GEOMETRY_PASS'if not hits else'STAGED_PATH_HOLD'));shapes[tag+'_'+q['occurrence']]=base
b.dump(E/'R19_TOOL_STAGE_CHECK.json',dict(results=out,pass_count=sum(not r['hits']for r in out),policy='Shell fastening while externally fixtured; before glands, feedback and dry input. No removal of loaded J401. Actual final obstructions retained separately. Nominal discrete geometry only; tools must be manufactured/procured and dry tried; torque not issued.'))
b.dump(N/'R19_TOOL_POSITIONS.json',[dict(id=k,brep=b.brep(s))for k,s in shapes.items()]);b.ex.export_step('R19_STAGED_TOOL_POSITIONS',[dict(definition=k,occurrence=k,scope='FIXTURE')for k in shapes],shapes)
print('STAGED_TOOL',len(out),'PASS',sum(not r['hits']for r in out),'FAIL',[r for r in out if r['hits']][:5],flush=True)

