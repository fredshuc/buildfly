import json,hashlib,zipfile,shutil,io
from pathlib import Path
from pypdf import PdfReader,PdfWriter
R=Path('R19_WORK');D=R/'deliverables';O=R/'delivery';O.mkdir(exist_ok=True)
(D/'FACTORY_README.txt').write_text('R19 MANUFACTURING CANDIDATES - L1 ISSUE REQUIRED\nRead the47-page shell booklet and three-page WS17 process extract. Current R19 preparation/assembly controls supersede prior process text for these joints only.\n13 F05 S0 targets/40pieces convert using SAME physical stock. Eight existing P104/R104 receive preparation. Two existing TF921 rails receive preparation. No second order. Four half-shell weld operations and one WS17 frame operation consume listed material once.\nShop WPS/coupon/actual clamps/withdrawal and first-piece holdpoints precede product welding. Full fusion is not demonstrated by CAD. No physical torque, heating, pressure, valve carrying or preload test permission.\nSTEP PREWELD and FINAL_PARTITION are successive states; never stack both. Red fusion zones replace parent material; they are not extra loose parts. Face-profile DXF does not encode edge preparation. Use PDF and STEP.\nP110/R110 follow exact F05 connected definitions. Existing F04/F05 release archives are supplied for stable dimensions and material identity, with their own original scope. Factory progress remainsUNKNOWN.\nTool STEP are geometric envelopes for procurement/drytrial, not rated tools or additional hardware orders.\nSend actual revision, dimensions, coupon/process records and nonconformances using tables/R19_FACTORY_MEASURED_RETURN.csv. No undocumented grinding/holes/gasket patches.\n',encoding='utf8')
(D/'ENGINEERING_README.txt').write_text('R19 frozen engineering return; read the English return report and current2 PDF booklets first.\n44 current STEP,3 retained initial tool diagnostic STEP. Retired: TOOL_R19_HW_N3.stp, TOOL_R19_HW_N6.stp, R19_SELECTED_TOOL_POSITIONS.stp. Their geometry readbacks pass but their initial access trial failed; do not use them. Current tools are R19_STAGED_TOOL_POSITIONS, R19_HEX_BIT_AXIAL_ENVELOPES and TOOL_R19_M6_TUBULAR.\nFull native P/R occurrence JSON plus396-definition catalogue is the current model. The72-instance combined change STEP prefixes alternative configurationsP_/R_; never install both as one state. Shell FINAL_PARTITION and FUSION_LAYER are local datum artifacts; their reference_world transforms are in native/R19_SHELL_ASSEMBLIES.json.\nReproduction order in a separate copy: r19_build.py; r19_m3_eco.py; r19_check.py; r19_export.py; r19_tools.py(initial retained diagnostic); r19_tools_stage.py; r19_tool_order.py; r19_bits.py; r19_sections.py; r19_bearing.py; r19_m3_check.py; r19_ws.py; r19_delta.py; r19_documents.py; r19_ws_documents.py. These write outputs; do not rerun in the frozen original. RequiresCadQuery/OCP,NumPy,Matplotlib,ReportLab,pypdf,ezdxf; runtime binaries not bundled. Factory consumers need no Python.\nTransient probe/ledger scripts are audit history, not a generation pipeline. No current drawing claims loaded/thermal or physical validation.\n',encoding='utf8')
# Factory-only extract omits engineering diagnostics and remaining-program pages.
fd=R/'factory_stage/drawings';fd.mkdir(parents=True,exist_ok=True);reader=PdfReader(D/'drawings/AT_DMP_R19_WS17_AND_REVIEW_EN.pdf');w=PdfWriter()
for i in [1,2,3]:w.add_page(reader.pages[i])
w.write(fd/'AT_DMP_R19_WS17_FACTORY_PROCESS_EN.pdf')
factory={}
retired={'TOOL_R19_HW_N3.stp','TOOL_R19_HW_N6.stp','R19_SELECTED_TOOL_POSITIONS.stp','R19_ACTIVE_CONFIGURATION_CHANGE_LAYER.stp','R19_PORT_M3_SECTION_REFERENCE.stp','R19_SPLIT_M6_SECTION_REFERENCE.stp','R19_CORNER_SEAT_SECTION_REFERENCE.stp'}
for sub in ['step','dxf','tables']:
 for p in (D/sub).rglob('*'):
  if p.is_file()and p.name not in retired:factory[p.relative_to(D).as_posix()]=p
factory['drawings/AT_DMP_R19_SHELL_FACTORY_EN.pdf']=D/'drawings/AT_DMP_R19_SHELL_FACTORY_EN.pdf';factory['drawings/AT_DMP_R19_WS17_FACTORY_PROCESS_EN.pdf']=fd/'AT_DMP_R19_WS17_FACTORY_PROCESS_EN.pdf';factory['00_README.txt']=D/'FACTORY_README.txt'
for p in [Path('R18_INPUT/signed/AT_DMP_P1_R17_ECO_WS_W1_FAB_RELEASE_20261012.zip'),Path('R19_INPUT/signed/AT_DMP_P1_R18_F05_FABRICATION_AND_STOCK_RELEASE_20261012.zip')]:factory['inherited_releases/'+p.name]=p

def pack(name,files):
 manifest=[dict(path=k,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for k,p in sorted(files.items())];dest=O/name
 with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for k,p in sorted(files.items()):z.write(p,k)
  z.writestr('MANIFEST_SHA256.json',json.dumps(manifest,indent=2))
 with zipfile.ZipFile(dest)as z:
  if z.testzip()is not None:raise ValueError('CRC')
  for q in manifest:
   s=z.read(q['path'])
   if len(s)!=q['bytes']or hashlib.sha256(s).hexdigest()!=q['sha256']:raise ValueError(q['path'])
 return dict(file=str(dest.resolve()),bytes=dest.stat().st_size,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),members=len(manifest)+1,manifest_entries=len(manifest),CRC_and_manifest='PASS')
f=pack('AT_DMP_P1_R19_SHELL_WS_FACTORY_CANDIDATES_20261012.zip',factory)
eng={}
for root in [D,R/'source']:
 for p in root.rglob('*'):
  if p.is_file()and '__pycache__'not in p.parts:eng[p.as_posix()]=p
for p in (R/'qa').glob('*montage*.jpg'):eng[p.as_posix()]=p
for p in [R/'ledger.json',Path(f['file']),fd/'AT_DMP_R19_WS17_FACTORY_PROCESS_EN.pdf']:eng[p.relative_to(Path.cwd()).as_posix()if p.is_absolute()else p.as_posix()]=p
for p in Path('R18_WORK/deliverables/native').glob('*.json'):eng[p.as_posix()]=p
for name in ['R18_SHELL_WELD_NEIGHBOURS.json','R18_CANDIDATES.json']:
 p=Path('R18_WORK/deliverables/evidence')/name
 if p.exists():eng[p.as_posix()]=p
for p in Path('R18_WORK/deliverables/dxf').glob('*.dxf'):eng[p.as_posix()]=p
for p in [Path('R18_WORK/deliverables/drawings/AT_DMP_R18_SP05_FACTORY_EN.pdf'),Path('R17_WORK/deliverables/dxf/P104_R17.dxf'),Path('R17_WORK/deliverables/dxf/R104_R17.dxf'),Path('R19_INPUT/AT_DMP_R18_L1_RELEASE_AND_R19_ORDER_20261012.zip'),Path('R19_INPUT/signed/deliverables/F05_PRESS_FRAME_GEOMETRY_OVERRIDES.json')]:eng[p.as_posix()]=p
g=pack('AT_DMP02_C02_R19_ENGINEERING_RETURN_20261012.zip',eng)
for p in (D/'drawings').glob('*.pdf'):shutil.copy2(p,O/p.name)
report=D/'L2_TO_L1_AT_DMP02_C02_R19_RETURN_20261012_EN.md';shutil.copy2(report,O/report.name)
(O/'PACKAGE_RECEIPT.json').write_text(json.dumps([f,g],indent=2));print(json.dumps([f,g],indent=2));print('FACTORY_STEPS',sum(k.endswith('.stp')for k in factory))
