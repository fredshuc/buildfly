import json,math,html,csv,shutil,io
from pathlib import Path
import numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import HexColor
from pypdf import PdfReader,PdfWriter
import build_c02 as b
R=b.ROOT.parent;D=b.OUT;DR=D/'drawings';N=D/'native';E=D/'evidence';P={p['pn']:p for p in json.loads((N/'R19_PARTS.json').read_text())};S={k:b.ex.readshape(p['brep'])for k,p in P.items()};A=json.loads((N/'R19_SHELL_ASSEMBLIES.json').read_text());W,H=1190,842
class Book:
 def __init__(self,name):self.name=name;self.c=canvas.Canvas(str(DR/name),pagesize=(W,H));self.page=0
 def head(self,title,sub='R19 | mm | P1 fabrication candidate - L1 release required'):
  self.page+=1;self.y=H-112;c=self.c;c.setFillColor(HexColor('#143b4c'));c.rect(0,H-88,W,88,fill=1,stroke=0);c.setFillColorRGB(1,1,1);c.setFont('Helvetica-Bold',21);c.drawString(36,H-35,title);c.setFont('Helvetica',11);c.drawString(36,H-63,sub)
 def p(self,s,size=12):
  p=Paragraph(html.escape(s),ParagraphStyle('p',fontSize=size,leading=size*1.35));_,h=p.wrap(W-72,720)
  if self.y-h<48:raise ValueError(('overflow',self.page,s[:50]))
  p.drawOn(self.c,36,self.y-h);self.y-=h+12
 def tab(self,rows,widths=None,size=10):
  st=ParagraphStyle('t',fontSize=size,leading=size*1.25);t=Table([[Paragraph(html.escape(str(x)),st)for x in row]for row in rows],colWidths=widths or [1118/len(rows[0])]*len(rows[0]));t.setStyle(TableStyle([('GRID',(0,0),(-1,-1),.3,HexColor('#bbc9d0')),('BACKGROUND',(0,0),(-1,0),HexColor('#e0eef1')),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]));_,h=t.wrap(1118,720)
  if self.y-h<48:raise ValueError(('tableoverflow',self.page,h))
  t.drawOn(self.c,36,self.y-h);self.y-=h+12
 def im(self,path,height=330):self.c.drawImage(str(path),36,self.y-height,width=1118,height=height,preserveAspectRatio=True,anchor='c');self.y-=height+12
 def end(self):self.c.setFillColor(HexColor('#52626d'));self.c.setFont('Helvetica',9);self.c.drawString(36,25,'R19 engineering candidate / No pressure, torque, hot operation or installed load permission. Do not scale drawings.');self.c.drawRightString(W-36,25,str(self.page));self.c.showPage()
 def save(self):self.c.save();return self.page

def view(pn):
 f=DR/(pn+'_VIEW.png');s=S[pn];fig,axs=plt.subplots(1,3,figsize=(13,3.4))
 for ax,ab in zip(axs,[(0,1),(0,2),(1,2)]):
  lines=[[tuple(e.positionAt(float(t)).toTuple()[i]for i in ab)for t in np.linspace(0,1,2 if e.geomType()=='LINE'else 35)]for e in s.Edges()];ax.add_collection(LineCollection(lines,colors='#17445a',linewidths=.65));ax.autoscale();ax.set_aspect('equal',adjustable='datalim');ax.grid(alpha=.2);ax.set_xlabel('XYZ'[ab[0]]+' mm');ax.set_ylabel('XYZ'[ab[1]]+' mm')
 fig.tight_layout();fig.savefig(f,dpi=145);plt.close(fig);return f
