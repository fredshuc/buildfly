from pathlib import Path
import json, hashlib, csv, io, collections, math, time, sys
import cadquery as cq
from OCP.BRepTools import BRepTools
from OCP.BRep import BRep_Builder
from OCP.TopoDS import TopoDS_Shape
from OCP.gp import gp_Trsf
from OCP.TDocStd import TDocStd_Document
from OCP.TCollection import TCollection_ExtendedString
from OCP.XCAFDoc import XCAFDoc_DocumentTool,XCAFDoc_ShapeTool,XCAFDoc_ColorGen
from OCP.TDataStd import TDataStd_Name
from OCP.Quantity import Quantity_ColorRGBA
from OCP.STEPCAFControl import STEPCAFControl_Writer,STEPCAFControl_Reader
from OCP.STEPControl import STEPControl_AsIs
from OCP.Interface import Interface_Static
from OCP.TopLoc import TopLoc_Location
from OCP.TDF import TDF_Label,TDF_LabelSequence

OUT=None
def save(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def readshape(s):
    v=TopoDS_Shape();BRepTools.Read_s(v,io.BytesIO(s.encode()),BRep_Builder());return cq.Shape.cast(v)
def bb(s):
    b=s.BoundingBox();return [b.xmin,b.ymin,b.zmin,b.xmax,b.ymax,b.zmax]
def world(s,o):
    g=gp_Trsf();R=o['R'];t=o['t'];g.SetValues(*R[0],t[0],*R[1],t[1],*R[2],t[2]);return s.moved(cq.Location(g))
def role(d):
    k=d['definition']
    if 'DRYBAY' in k:return 'REFERENCE_DRIVE_HOUSING'
    if k.startswith('P1_AU_COMMON_') and k!='P1_AU_COMMON_R_SEAT_RISER':return 'REFERENCE_MACHINE_AIR_BOUNDARY'
    if d['category']=='ENVELOPE':return 'REFERENCE_DRIVE_LINKAGE'
    if d['category']=='OEM_PROXY':return 'P_VALVE_PROXY' if k.startswith('P1_AU_P_') else 'R_VALVE_PROXY'
    if any(x in k for x in ['_PORTAL_','_POST_CAP_','_CROSSHEAD_CAP_','_CARTRIDGE_BEARING_RAIL_','_BEARING_RAIL_CAP_','_BEARING_PAD_']):return 'LOCAL_SUPPORT_CANDIDATE'
    return 'LOCAL_RECEIVER_CLAMP_INTERFACE'
COLORS={'P_VALVE_PROXY':(.13,.52,.63,1),'R_VALVE_PROXY':(.89,.47,.13,1),'LOCAL_SUPPORT_CANDIDATE':(.40,.47,.54,1),'LOCAL_RECEIVER_CLAMP_INTERFACE':(.66,.72,.77,1),'REFERENCE_MACHINE_AIR_BOUNDARY':(.82,.85,.87,.35),'REFERENCE_DRIVE_HOUSING':(.67,.68,.71,.30),'REFERENCE_DRIVE_LINKAGE':(.71,.43,.77,.24)}
def labelname(lb):
    a=TDataStd_Name();return a.Get().ToExtString() if lb.FindAttribute(TDataStd_Name.GetID_s(),a) else ''
def export_step(name,rows,shapes):
    # Reuses the source's XCAF/AP242 path. Shapes are original world-placed BReps.
    boot=STEPCAFControl_Writer();Interface_Static.SetCVal_s('write.step.schema','AP242DIS');Interface_Static.SetCVal_s('write.step.unit','MM');Interface_Static.SetCVal_s('xstep.cascade.unit','MM');Interface_Static.SetIVal_s('write.step.assembly',2)
    doc=TDocStd_Document(TCollection_ExtendedString('XmlOcaf'));XCAFDoc_ShapeTool.SetAutoNaming_s(False)
    st=XCAFDoc_DocumentTool.ShapeTool_s(doc.Main());ct=XCAFDoc_DocumentTool.ColorTool_s(doc.Main())
    root=st.NewShape();TDataStd_Name.Set_s(root,TCollection_ExtendedString(name));groups={}
    for row in rows:
        g=row['scope'];k=row['definition'];s=shapes[k]
        if g not in groups:
            groups[g]=st.NewShape();TDataStd_Name.Set_s(groups[g],TCollection_ExtendedString(g));st.AddComponent(root,groups[g],TopLoc_Location())
        lb=st.NewShape();st.SetShape(lb,s.wrapped);TDataStd_Name.Set_s(lb,TCollection_ExtendedString(k));ct.SetColor(lb,Quantity_ColorRGBA(*COLORS[g]),XCAFDoc_ColorGen)
        oc=st.AddComponent(groups[g],lb,TopLoc_Location());TDataStd_Name.Set_s(oc,TCollection_ExtendedString(row['occurrence']))
    st.UpdateAssemblies();w=STEPCAFControl_Writer();w.SetNameMode(True);w.SetColorMode(True)
    if not w.Transfer(doc,STEPControl_AsIs):raise RuntimeError('STEP writer transfer failed')
    path=OUT/'step'/f'{name}.stp'
    if w.Write(str(path)).value!=1:raise RuntimeError('STEP write failed')
    # Fresh STEP document, names, assembly occurrences and world BReps.
    rd=STEPCAFControl_Reader();rd.SetNameMode(True)
    if rd.ReadFile(str(path)).value!=1:raise RuntimeError('STEP read failed')
    rd_doc=TDocStd_Document(TCollection_ExtendedString('XmlOcaf'))
    if not rd.Transfer(rd_doc):raise RuntimeError('STEP reader transfer failed')
    rst=XCAFDoc_DocumentTool.ShapeTool_s(rd_doc.Main());roots=TDF_LabelSequence();rst.GetFreeShapes(roots);found={}
    def walk(lb,trans,occ=''):
        trans=trans.Multiplied(XCAFDoc_ShapeTool.GetLocation_s(lb).Transformation());target=lb
        if XCAFDoc_ShapeTool.IsReference_s(lb):
            target=TDF_Label()
            if not XCAFDoc_ShapeTool.GetReferredShape_s(lb,target):raise RuntimeError('Missing referred shape')
        if XCAFDoc_ShapeTool.IsAssembly_s(target):
            seq=TDF_LabelSequence();XCAFDoc_ShapeTool.GetComponents_s(target,seq)
            for i in range(1,seq.Length()+1):walk(seq.Value(i),trans,labelname(seq.Value(i)))
        else:
            s=cq.Shape.cast(XCAFDoc_ShapeTool.GetShape_s(target)).moved(cq.Location(trans));found[occ or labelname(target)]=s
    for i in range(1,roots.Length()+1):walk(roots.Value(i),gp_Trsf())
    if set(found)!={r['occurrence'] for r in rows}:raise RuntimeError(('Occurrence mismatch',len(found),len(rows)))
    checks=[]
    for row in rows:
        a=found[row['occurrence']];b=shapes[row['definition']];bound=max(abs(i-j) for i,j in zip(bb(a),bb(b)))
        va=abs(a.Volume());vb=abs(b.Volume());diff=[abs(a.cut(b).Volume()),abs(b.cut(a).Volume())];tol=max(.001,vb*1e-8)
        ok=a.isValid() and len(a.Solids())==len(b.Solids()) and bound<.002 and max(diff)<tol
        checks.append(dict(definition=row['definition'],occurrence=row['occurrence'],valid=a.isValid(),solids=len(a.Solids()),bounds_error_mm=bound,native_volume_mm3=vb,step_volume_mm3=va,symmetric_difference_mm3=diff,material_tolerance_mm3=tol,pass_=ok))
    rec=dict(file=path.name,bytes=path.stat().st_size,sha256=sha(path),schema='AP242',unit='mm',occurrences=len(rows),all_pass=all(c['pass_'] for c in checks),checks=checks)
    save(OUT/'evidence'/f'{name}_READBACK.json',rec)
    if not rec['all_pass']:raise RuntimeError([x for x in checks if not x['pass_']])
    print('STEP verified',path.name,len(rows),flush=True);return {k:v for k,v in rec.items() if k!='checks'}
