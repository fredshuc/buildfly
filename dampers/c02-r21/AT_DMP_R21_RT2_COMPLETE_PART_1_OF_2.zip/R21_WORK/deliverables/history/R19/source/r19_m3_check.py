import json,numpy as np
import build_c02 as b
N=b.OUT/'native';E=b.OUT/'evidence';P={q['pn']:q for q in json.loads((N/'R19_PARTS.json').read_text())};S={k:b.ex.readshape(v['brep'])for k,v in P.items()};ecos=json.loads((E/'R19_M3_PLACEMENT_ECO.json').read_text());result=[];hits=[]
for tag in ['P','R']:
 O=json.loads((N/f'R19_{tag}_OCCURRENCES.json').read_text());W={q['occurrence']:b.tr(S[q['pn']],q['o'],q['u'],q['v'],q['n'])for q in O};BB={k:b.ex.bb(s)for k,s in W.items()};od={q['occurrence']:q for q in O}
 for e in ecos:
  if e['config']!=tag:continue
  k=e['occurrence'];s=W[k];bb=BB[k]
  for q in O:
   kk=q['occurrence'];cc=BB[kk]
   if kk==k or not all(min(bb[i+3],cc[i+3])-max(bb[i],cc[i])>1e-6 for i in range(3)):continue
   v=abs(s.intersect(W[kk]).Volume())
   if v>.001:hits.append(dict(config=tag,moved=k,other=kk,mm3=v))
  if e['PN']=='HW_N3':
   q=od[k];n=np.array(q['n']);o=np.array(q['o']);near=[z for z in O if z['pn']=='STD08B'and np.linalg.norm(np.cross(np.array(z['o'])-o,n))<.01 and abs(np.dot(np.array(z['o'])-o,n))<25]
   for z in near:
    zs=[np.dot(np.array(z['o'])+np.array(z['n'])*t-o,n)for t in [0,16]];lo,hi=sorted(zs);eng=max(0,min(4,hi)-max(0,lo));pro=hi-4;result.append(dict(config=tag,nut=k,screw=z['occurrence'],nominal_engagement_mm=eng,nominal_tip_protrusion_mm=pro,thread='M3x0.5 full thread L16, supplier effective thread verification required'))
b.dump(E/'R19_M3_ECO_CHECK.json',dict(hits=hits,thread_rows=result));print('ECOHITS',hits,'THREAD',len(result),'minEng',min(x['nominal_engagement_mm']for x in result),'minPro',min(x['nominal_tip_protrusion_mm']for x in result),flush=True)

