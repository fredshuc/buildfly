import json,numpy as np
import build_c02 as b
N=b.OUT/'native';E=b.OUT/'evidence';P={q['pn']:q for q in json.loads((N/'R19_PARTS.json').read_text())};S={k:b.ex.readshape(v['brep'])for k,v in P.items()};out=[]
for tag in ['P','R']:
 O=json.loads((N/f'R19_{tag}_OCCURRENCES.json').read_text());W={q['occurrence']:b.tr(S[q['pn']],q['o'],q['u'],q['v'],q['n'])for q in O};bb={k:b.ex.bb(s)for k,s in W.items()};old=json.loads((b.ROOT.parent/'R18_WORK/deliverables/evidence/R18_SHELL_WELD_NEIGHBOURS.json').read_text())['hits'];targets={h['part']for h in old if h['config']==tag and h['PN']in ['HW_W6_1p6_12','HW_W3_0p5_7']}
 for q in O:
  if q['occurrence']not in targets:continue
  s=W[q['occurrence']];parts=[];area=0;best=0
  for sign in [-1,1]:
   shift=s.translate(tuple(sign*.02*np.array(q['n'])));areas=[]
   for z in O:
    if not(z['pn'].startswith((tag+'102',tag+'103',tag+'104'))or z['pn']==tag+'110'):continue
    c=W[z['occurrence']]
    if shift.distance(c)>.001:continue
    a=abs(shift.intersect(c).Volume())/.02
    if a>.001:areas.append(dict(part=z['occurrence'],area_mm2=a))
   if sum(x['area_mm2']for x in areas)>best:best=sum(x['area_mm2']for x in areas);parts=areas
  bb0=b.ex.bb(S[q['pn']]);nom=S[q['pn']].Volume()/(bb0[5]-bb0[2]);out.append(dict(config=tag,washer=q['occurrence'],PN=q['pn'],nominal_area_mm2=nom,contact_metal_area_mm2=best,support_ratio=best/nom,parts=parts,scope='Nominal0.02mm face probe; not pressure/stiffness'))
b.dump(E/'R19_WASHER_BEARING.json',out);print('BEARING',len(out),'MIN',min(x['support_ratio']for x in out),'LOW',[x for x in out if x['support_ratio']<.98][:5],flush=True)
