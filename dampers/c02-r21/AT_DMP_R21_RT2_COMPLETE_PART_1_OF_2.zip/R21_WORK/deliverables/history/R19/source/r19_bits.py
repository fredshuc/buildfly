import json,numpy as np,math
import build_c02 as b
N=b.OUT/'native';E=b.OUT/'evidence';P={p['pn']:p for p in json.loads((N/'R19_PARTS.json').read_text())};S={k:b.ex.readshape(p['brep'])for k,p in P.items()};targets=json.loads((E/'R19_TOOL_STAGE_CHECK.json').read_text())['results'];rows=[];shapes={};poses=json.loads((N/'R19_TOOL_POSITIONS.json').read_text());later=json.loads((E/'R19_TOOL_STAGE_CHECK.json').read_text())['explicit_later_fasteners']
for tag in ['P','R']:
 O=json.loads((N/f'R19_{tag}_OCCURRENCES.json').read_text());W={q['occurrence']:b.tr(S[q['pn']],q['o'],q['u'],q['v'],q['n'])for q in O};BB={k:b.ex.bb(s)for k,s in W.items()};od={q['occurrence']:q for q in O};selected={}
 for r in targets:
  if r['config']!=tag:continue
  nut=od[r['nut']];o=np.array(nut['o']);n=np.array(nut['n']);thread='M3'if r['PN']=='HW_N3'else'M6'
  for q in O:
   ff=[f for f in P[q['pn']].get('features',[])if f.get('type')=='fastener'and f.get('thread')==thread]
   if not ff or not ff[0].get('hex'):continue
   delta=np.array(q['o'])-o
   if np.linalg.norm(np.cross(delta,n))<.01 and abs(delta@n)<60:selected[q['occurrence']]=(q,ff[0])
 for k,(q,f)in selected.items():
  af=f['hex']-.05;hh=f['head_h'];local=b.cq.Workplane('XY').polygon(6,af/math.cos(math.pi/6)).extrude(70+hh*.5).val().translate((0,0,-hh-70));s=b.tr(local,q['o'],q['u'],q['v'],q['n']);bb=b.ex.bb(s);hits=[];stage=[]
  for z in O:
   kk=z['occurrence'];cc=BB[kk]
   if not all(min(bb[i+3],cc[i+3])-max(bb[i],cc[i])>1e-6 for i in range(3)):continue
   v=abs(s.intersect(W[kk]).Volume())
   if v>.001:
    h=dict(part=kk,PN=z['pn'],mm3=v);hits.append(h)
    if (z['pn'].startswith((tag+'10','S30','S31','STD08','STD06'))or z['pn']in ['P110','R110','HW_N3','HW_N6','HW_W3_0p5_7','HW_W6_1p6_12','B200_R13'])and kk not in later:stage.append(h)
  rows.append(dict(config=tag,screw=k,AF=af,full_extension_sweep_mm=70,stage_hits=stage,later_mount_obstructions=[h for h in hits if h not in stage]));name=tag+'_BIT_'+k;shapes[name]=s;poses.append(dict(id=name,brep=b.brep(s)))
b.dump(E/'R19_HEX_BIT_ACCESS.json',rows);b.dump(N/'R19_TOOL_POSITIONS.json',poses);b.ex.export_step('R19_HEX_BIT_AXIAL_ENVELOPES',[dict(definition=k,occurrence=k,scope='FIXTURE')for k in shapes],shapes);print('BITS',len(rows),'STAGEFAIL',[q for q in rows if q['stage_hits']],flush=True)
