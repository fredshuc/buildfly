import json, pathlib
R=pathlib.Path.cwd(); P={p['pn']:p for p in json.loads((R/'R18_WORK/deliverables/native/R18_PARTS.json').read_text(encoding='utf-8'))}
a=json.loads((R/'R18_WORK/deliverables/native/R18_SHELL_ASSEMBLIES.json').read_text());print(json.dumps(a['P100F'],ensure_ascii=False)[:6000]);print('F05',list(json.loads((R/'R19_INPUT/signed/deliverables/F05_PRESS_FRAME_GEOMETRY_OVERRIDES.json').read_text()).keys()))
for pn in ['S301A','S301B','P103F','P103B']:
 print(pn,P[pn]['bbox'],P[pn]['features'][:8])
