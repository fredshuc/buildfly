from pathlib import Path
p=Path('R19_WORK/source/r19_build.py');s=p.read_text();s=s.replace("gs.append(prism([(x,0,.5),(x,0,3),(x+d,0,3)],(0,H,0)))", "gs.append(prism([(x,0,.5),(x,0,3),(x+d,0,3)] if '103'in src else [(x,0,2.5),(x,0,0),(x+d,0,0)],(0,H,0)))")
s=s.replace("External face localZ3; both flow", "External face Z3 for103, Z0 for104; both flow")
p.write_text(s,encoding='utf-8')
p=Path('R19_WORK/source/r19_check.py');s=p.read_text().replace("if q['pn']==wn.split('_')[0]:parents.append(row)","if k==wn.split('_',1)[1].removesuffix('_FUSION'):parents.append(row)");p.write_text(s,encoding='utf-8')
