import json
from pathlib import Path
from pypdf import PdfReader
D=Path('R19_WORK/deliverables')
for p in (D/'drawings').glob('*.pdf'):
 r=PdfReader(p);print(p.name,len(r.pages));print([i+1 for i,x in enumerate(r.pages)if 'TF921L_R19PREP / edge preparation' in(x.extract_text()or'')])
for f in ['R19_TOOL_STAGE_CHECK.json','R19_NEW_FUSION_NEIGHBOURS.json','R19_WS17_NEW_JOINT_CHECK.json']:
 q=json.loads((D/'evidence'/f).read_text());print(f,q.get('pass_count'),len(q.get('unapproved_hits',[])))
