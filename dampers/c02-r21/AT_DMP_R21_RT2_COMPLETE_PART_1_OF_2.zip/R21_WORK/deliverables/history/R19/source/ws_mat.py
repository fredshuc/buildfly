import json
P={x['pn']:x for x in json.load(open('R19_WORK/deliverables/native/R19_PARTS.json',encoding='utf8'))};print({k:P[k]['material']for k in ['TF921L','TF921R','TF926','TF927']})
