import json,math,numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.lines import Line2D
import build_c02 as b
R=b.ROOT.parent;N=b.OUT/'native';E=b.OUT/'evidence';DR=b.OUT/'drawings';pm={p['pn']:p for p in json.loads((N/'R19_PARTS.json').read_text())};S={p:b.ex.readshape(v['brep'])for p,v in pm.items()};ass=json.loads((N/'R19_SHELL_ASSEMBLIES.json').read_text());weld=json.loads((N/'R19_SHELL_WELDS.json').read_text());a=ass['P100F'];A=np.array([[0,0,-1],[0,1,0],[1,0,0]])@np.array(a['reference_world_matrix']);o=np.array([[0,0,-1],[0,1,0],[1,0,0]])@np.array(a['reference_world_origin'])+np.array([1451,0,2022]);O=json.loads((N/'R19_P_OCCURRENCES.json').read_text());local={}
for q in O:
 U=np.column_stack([q['u'],q['v'],q['n']]);s=b.tr(S[q['pn']],A.T@(np.array(q['o'])-o),*(A.T@U).T);local[q['occurrence']]=(q['pn'],s,'seal'if q['scope']=='SEAL'else'hardware'if q['scope']=='PURCHASE'else'parent')
if (N/'R19_TOOL_POSITIONS.json').exists():
 for q in json.loads((N/'R19_TOOL_POSITIONS.json').read_text()):
  if not q['id'].startswith('P_'):continue
  s=b.tr(b.ex.readshape(q['brep']),-A.T@o,*A.T.T);local[q['id']]=('TOOL',s,'tool')
for w in weld['P100F']:local[w['id']]=('FUSION',b.ex.readshape(w['brep']),'fusion')
pre={q['id']:(q['pn'],b.tr(S[q['pn']],q['o'],q['u'],q['v'],q['n']),'parent')for q in a['preparation_items']}
colors={'parent':'#235977','fusion':'#cc3c35','hardware':'#555d68','seal':'#3c9852','tool':'#a94cc0'}
cases=[('PORT_M3',b.box(25,.01,21).translate((24,50.995,-14)),(0,2),(24,49,-14,7),'Port wall/end flange | section localY51'),('SPLIT_M6',b.box(32,.01,25).translate((16,80.137857,-89)),(0,2),(16,48,-89,-64),'Split wall/flange | section localY80.142857'),('CORNER_SEAT',b.box(45,45,.01).translate((28,28,-63.084)),(0,1),(28,73,28,73),'Longitudinal corner/seat | section localZ-63.079')];reps=[]
for name,slab,ab,lims,title in cases:
 fig,axs=plt.subplots(1,2,figsize=(12,4.6));sections={};counts={}
 for ax,scene,label in zip(axs,[pre,local],['PRE-WELD: bevelled parent sheets','FINAL: parent, fusion, hardware, seal and tool']):
  for k,(pn,s,role) in scene.items():
   bb=b.ex.bb(s);sb=b.ex.bb(slab)
   if not all(min(bb[i+3],sb[i+3])-max(bb[i],sb[i])>1e-6 for i in range(3)):continue
   cut=s.intersect(slab)
   if cut.Volume()<1e-7:continue
   curves=[]
   for e in cut.Edges():
    curves.append([tuple(e.positionAt(float(t)).toTuple()[v]for v in ab)for t in np.linspace(0,1,2 if e.geomType()=='LINE'else 25)])
   ax.add_collection(LineCollection(curves,colors=colors[role],linewidths=1.2 if role=='fusion'else .65,zorder=10 if role=='fusion'else 5));sections[label[:3]+'_'+k]=cut;counts[label[:3]+'_'+k]=dict(PN=pn,role=role)
  ax.set_xlim(lims[:2]);ax.set_ylim(lims[2:]);ax.set_aspect('equal');ax.grid(alpha=.2);ax.set_xlabel('XYZ'[ab[0]]+' mm');ax.set_ylabel('XYZ'[ab[1]]+' mm');ax.set_title(label,fontsize=10)
 fig.suptitle(title+' | actual CAD sections, not to scale');fig.legend(handles=[Line2D([0],[0],color=c,label=k)for k,c in colors.items()],loc='lower center',ncol=5);fig.tight_layout(rect=(0,.06,1,.95));fig.savefig(DR/(name+'_SECTION.png'),dpi=180);plt.close(fig)
 b.ex.export_step('R19_'+name+'_SECTION_REFERENCE',[dict(definition=k,occurrence=k,scope='REFERENCE')for k in sections],sections);reps.append(dict(family=name,section_members=counts,slab_thickness_mm=.01,geometry_scope='Actual section cut, reference only'))
b.dump(E/'R19_REPRESENTATIVE_SECTIONS.json',reps)
print('SECTIONS',len(reps),flush=True)

