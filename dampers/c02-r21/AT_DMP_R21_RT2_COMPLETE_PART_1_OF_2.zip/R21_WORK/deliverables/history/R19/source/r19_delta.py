import json,hashlib,csv
import build_c02 as b
R=b.ROOT.parent;N=b.OUT/'native';E=b.OUT/'evidence';P={p['pn']:p for p in json.loads((N/'R19_PARTS.json').read_text())};old={p['pn']:p for p in json.loads((R/'R18_WORK/deliverables/native/R18_PARTS.json').read_text())};sh={};rows=[];eco=json.loads((E/'R19_M3_PLACEMENT_ECO.json').read_text())
for tag in ['P','R']:
 O=json.loads((N/f'R19_{tag}_OCCURRENCES.json').read_text());target={r['occurrence']for r in eco if r['config']==tag}
 for q in O:
  if q['occurrence']not in target and q['pn']not in ['P110','R110']:continue
  k=tag+'_'+q['occurrence'];sh[k]=b.tr(b.ex.readshape(P[q['pn']]['brep']),q['o'],q['u'],q['v'],q['n']);rows.append(dict(definition=k,occurrence=k,scope='P'if tag=='P'else'R'))
b.ex.export_step('R19_ACTIVE_CONFIGURATION_CHANGE_LAYER',rows,sh)
b.dump(E/'R19_NATIVE_DELTA.json',dict(old_count=len(old),new_count=len(P),changed_old_BReps=[p for p in old if old[p]['brep']!=P[p]['brep']],unchanged_old_BReps=sum(old[p]['brep']==P[p]['brep']for p in old),new_definitions=[p for p in P if p not in old],active_placement_changes=len(eco),change_layer_instances=len(rows),frozen_R18_archive_modified=False))
# Source coordinates of all seams and full same-stock routing.
rows=[]
for pn,a in json.loads((N/'R19_SHELL_ASSEMBLIES.json').read_text()).items():
 for q in a['preparation_items']:rows.append(dict(assembly=pn,physical_id=q['id'],prep_PN=q['pn'],origin=str(q['o']),u=str(q['u']),v=str(q['v']),n=str(q['n']),quantity=1,operation='same physical stock -> PREWELD -> qualified weld -> paired final machining'))
b.cw('R19_SHELL_PROCESS_COMPOSITION.csv',rows)
records=[]
for part in ['P100F','P100B','R100F','R100B','WS17']:
 for stage in ['MATERIAL_ID','GROOVE_FITUP','COUPON_ROOT_FUSION','FIXTURE_ENTRY_RELEASE','TACK_DIMENSIONS','COOL_UNCLAMP_GEOMETRY','FINAL_HOLES_PLANES','TOOL_DRY_TRIAL']:
  records.append(dict(assembly=part,stage=stage,actual_revision='',material_lot='',measured_value='',unit='',instrument_and_uncertainty='',raw_file='',result='',issue='',engineering_disposition='',P1_remake_or_rework='',P2_improvement='',operator='',date=''))
b.cw('R19_FACTORY_MEASURED_RETURN.csv',records)
print('ACTIVE_DELTA',len(sh),flush=True)
