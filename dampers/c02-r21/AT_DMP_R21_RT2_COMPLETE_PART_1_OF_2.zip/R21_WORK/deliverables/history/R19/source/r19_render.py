from pathlib import Path
import subprocess,json
from PIL import Image,ImageDraw
from pypdf import PdfReader
R=Path(__file__).resolve().parents[1];Q=R/'qa';Q.mkdir(exist_ok=True)
exe=r'C:\Users\Gebruiker\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdftoppm.exe'
results=[]
for f in (R/'deliverables/drawings').glob('*.pdf'):
 name='SHELL' if 'SHELL' in f.name else 'WS_REVIEW'
 subprocess.run([exe,'-r','70','-png',str(f),str(Q/name)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 ps=sorted(Q.glob(name+'-*.png'));n=len(PdfReader(str(f)).pages);assert len(ps)==n,(f,n,len(ps))
 for k in range(0,n,6):
  im=Image.new('RGB',(2100,1560),'white');d=ImageDraw.Draw(im)
  for i,p in enumerate(ps[k:k+6]):
   q=Image.open(p).convert('RGB');q.thumbnail((1030,480));x=i%2*1050;y=i//2*520;im.paste(q,(x,y+28));d.text((x+10,y+7),p.name,fill='black')
  im.save(Q/f'{name}_montage_{k//6+1}.jpg',quality=90)
 results.append(dict(file=f.name,pages=n,rendered=n))
(R/'deliverables/evidence/R19_PDF_RENDER.json').write_text(json.dumps(results,indent=2));print(results)

