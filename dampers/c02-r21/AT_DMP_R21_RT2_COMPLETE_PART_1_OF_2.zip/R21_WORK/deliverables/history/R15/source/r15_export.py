import json,collections,hashlib,itertools
import build_c02 as b
from r11_common import volume
E=b.OUT/'evidence';P=json.loads((b.OUT/'native/R15_SP04_PARTS.json').read_text());checks=[]
for p in P:
 pn=p['pn'];s=b.ex.readshape(p['brep']);f=b.OUT/'step/parts'/f'{pn}_R15.stp';b.cq.exporters.export(s,str(f),exportType='STEP');a=b.cq.importers.importStep(str(f)).val();diff=[abs(s.cut(a).Volume()),abs(a.cut(s).Volume())];bd=max(abs(v-w) for v,w in zip(b.ex.bb(s),b.ex.bb(a)));ok=a.isValid() and len(a.Solids())==len(s.Solids()) and max(diff)<max(.001,s.Volume()*1e-8) and bd<.001
 if not ok:raise ValueError((pn,diff,bd))
 checks.append(dict(PN=pn,valid=a.isValid(),solids=len(a.Solids()),difference_mm3=diff,bounds_error_mm=bd,passed=ok,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
 # XY planar outline is a supplementary cutting interchange, dimensions/tolerances remain on PDF.
 if p['batch']=='SP04-B':
  import ezdxf
  doc=ezdxf.new('R2010');doc.units=4;ms=doc.modelspace();edges=s.section if False else None
  z=s.BoundingBox().zmin
  for e in s.Edges():
   vs=e.Vertices()
   if not vs or any(abs(v.Z-z)>1e-5 for v in vs):continue
   if e.geomType()=='LINE':
    vv=[v.toTuple() for v in vs]
    if len(vv)==2:ms.add_line(vv[0][:2],vv[1][:2])
   elif e.geomType()=='CIRCLE':
    # Polyline sampling avoids guessed centre for partial arcs; 96 segments/turn.
    pts=[e.positionAt(i/96).toTuple()[:2] for i in range(97)];ms.add_lwpolyline(pts)
  dest=b.OUT/'dxf';dest.mkdir(exist_ok=True);doc.saveas(dest/f'{pn}_R15.dxf')
b.dump(E/'R15_PART_STEP_READBACK.json',checks)
RP=json.loads((b.OUT/'native/R15_FIXED_END_REFERENCE_PARTS.json').read_text());S={p['pn']:b.ex.readshape(p['brep']) for p in RP};O=json.loads((b.OUT/'native/R15_FIXED_END_REFERENCE_OCCURRENCES.json').read_text());sh={o['occurrence']:b.tr(S[o['pn']],o['o'],o['u'],o['v'],o['n']) for o in O}
rec=b.ex.export_step('AT_DMP_R15_FIXED_END_REFERENCE',[dict(definition=o['occurrence'],occurrence=o['occurrence'],scope='FIXTURE') for o in O],sh)
hard=[];threads=[];pairs=0
for a,c in itertools.combinations(O,2):
 sa,sc=sh[a['occurrence']],sh[c['occurrence']];ba,bc=b.ex.bb(sa),b.ex.bb(sc);pairs+=1
 if any(ba[i+3]<bc[i]-1e-6 or bc[i+3]<ba[i]-1e-6 for i in range(3)):continue
 vol=volume(sa,sc)
 if vol<.001:continue
 # Exact nominalthreadproxy per geometricsegment; no blanket pair exemption.
 q=dict(a=a['occurrence'],b=c['occurrence'],PNs=[a['pn'],c['pn']],volume_mm3=vol)
 if {a['pn'],c['pn']}=={'STD03C','HW_N6'}:
  stud=a if a['pn']=='STD03C' else c;ss=sh[stud['occurrence']];bb=b.ex.bb(sa.intersect(sc));q['thread_zone_z']=[-3,69];q['inside_declared_thread']=bb[2]>=-3-1e-6 and bb[5]<=69+1e-6
  (threads if q['inside_declared_thread'] else hard).append(q)
 elif {a['pn'],c['pn']}=={'STD05B','HW_N6'}:q['scope']='Inherited pin-bolt simplified threaded tip; nominal declared local52..62';threads.append(q)
 else:hard.append(q)
b.dump(E/'R15_REFERENCE_COLLISION.json',dict(pairs=pairs,hard=hard,threads=threads,scope='Nominal fixed-end coupon reference only; no rotor, no fixture restraint, no preload/load permit. J407 pressfit counted separately if present.'))
b.cw('R15_SP04_BOM.csv',[dict(PN=p['pn'],batch=p['batch'],quantity=p['quantity'],material=p['material'],drawing=p['drawing'],step=p['pn']+'_R15.stp',status=p['status']) for p in P])
print('EXPORT',len(checks),'parts','collision',len(hard),[(r['PNs'],r['volume_mm3']) for r in hard],flush=True)
