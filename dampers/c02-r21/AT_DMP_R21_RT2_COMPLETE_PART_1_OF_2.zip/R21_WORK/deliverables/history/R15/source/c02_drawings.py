"""Projection drawings from the same OCP parts and parameter records. A3, mm."""
from pathlib import Path
import json,math,sys,collections,os
import numpy as np
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor,Color
from reportlab.platypus import Paragraph,Table,TableStyle,SimpleDocTemplate,Spacer,PageBreak,Image
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A3,A4,landscape
from pypdf import PdfReader,PdfWriter
import build_c02 as b
O=b.OUT;FONT=os.environ.get('AT_C02_FONT',str(Path(__file__).parent/'fonts/NotoSansSC-Regular.ttf'));pdfmetrics.registerFont(TTFont('CN',FONT))
INK=HexColor('#172e42');BLUE=HexColor('#205b71');LIGHT=HexColor('#eaf0f3');RED=HexColor('#8a342a');W,H=landscape(A3)
STYLE=ParagraphStyle('p',fontName='CN',fontSize=10,leading=15,textColor=INK,wordWrap='CJK',allowWidows=0,allowOrphans=0)
SMALL=ParagraphStyle('s',parent=STYLE,fontSize=8,leading=11)
def para(c,txt,x,y,w,size=10):
 st=ParagraphStyle('x',parent=STYLE,fontSize=size,leading=size*1.45);p=Paragraph(str(txt).replace('–','-').replace('—','-').replace('−','-').replace('&','&amp;').replace('\n','<br/>'),st);_,h=p.wrap(w,10000);p.drawOn(c,x,y-h);return y-h
def header(c,title,sub,pn='',page=''):
 c.setFillColor(INK);c.rect(0,H-65,W,65,fill=1,stroke=0);c.setFillColor(HexColor('#ffffff'));c.setFont('CN',18);c.drawString(30,H-32,title);c.setFont('CN',9);c.drawString(30,H-51,sub)
 c.setStrokeColor(INK);c.setLineWidth(.6);c.rect(25,25,W-50,H-110)
 c.setFillColor(INK);c.setFont('CN',10);c.drawString(35,45,'AirTransformer  ·  AT-DMP02-MFG-C02 局部增量  ·  AU相邻P/R')
 c.setFont('CN',9);c.drawRightString(W-35,45,f'{pn}  C02  |  {page}  |  2026-10-12  |  mm')
 c.setFillColor(RED);c.setFont('CN',9);c.drawString(35,30,'局部设计审阅稿；须批准制造发行后方可用于生产。')
def edges(s):
 res=[]
 for e in s.Edges():
  n=2 if e.geomType()=='LINE' else 49
  try:res.append(np.array([e.positionAt(float(t)).toTuple() for t in np.linspace(0,1,n)]))
  except Exception:res.append(np.array([v.toTuple() for v in e.Vertices()]))
 return res
def dim(c,x1,y1,x2,y2,txt,horiz=True):
 c.setLineWidth(.4);c.setStrokeColor(BLUE);c.setFillColor(BLUE)
 c.line(x1,y1,x2,y2)
 if horiz:
  for x in [x1,x2]:c.line(x,y1-4,x,y1+4)
  c.setFont('CN',9);c.drawCentredString((x1+x2)/2,y1+4,txt)
 else:
  for y in [y1,y2]:c.line(x1-4,y,x1+4,y)
  c.saveState();c.translate(x1-5,(y1+y2)/2);c.rotate(90);c.setFont('CN',9);c.drawCentredString(0,0,txt);c.restoreState()
def view(c,s,axes,rect,label,dimshow=True):
 x,y,w,h=rect;es=edges(s);bb=b.ex.bb(s);mn=np.array(bb[:3]);mx=np.array(bb[3:]);dx=mx[axes[0]]-mn[axes[0]];dy=mx[axes[1]]-mn[axes[1]]
 scale=min((w-60)/max(dx,.01),(h-60)/max(dy,.01));ox=x+(w-dx*scale)/2;oy=y+(h-dy*scale)/2
 c.setStrokeColor(INK);c.setLineWidth(.45)
 for ee in es:
  pts=ee[:,list(axes)];pts=(pts-mn[list(axes)])*scale+np.array([ox,oy]);p=c.beginPath();p.moveTo(*pts[0]);
  for q in pts[1:]:p.lineTo(*q)
  c.drawPath(p)
 c.setFillColor(INK);c.setFont('CN',10);c.drawString(x+10,y+h-14,label)
 if dimshow:
  dim(c,ox,oy-15,ox+dx*scale,oy-15,f'{dx:.3f}'.rstrip('0').rstrip('.'))
  dim(c,ox-18,oy,ox-18,oy+dy*scale,f'{dy:.3f}'.rstrip('0').rstrip('.'),False)
 c.setFont('CN',8);c.drawString(x+10,y+4,'端视；孔/螺纹见特征表。' if w<200 else '坐标投影；轮廓边全部显示。剖孔/螺纹以右侧特征表为准。')
 return ox,oy,scale,mn
LABEL={'type':'特征','width':'宽','height':'高','thickness':'厚','x':'X','y':'Y','z':'Z','w':'宽','h':'高','d':'直径','od':'外径','id':'内径','length':'长度','depth':'深/注','axis':'轴向','fit':'配合','thread':'螺纹','effective':'有效牙长','drill_depth':'底孔深','z0':'起始Z','ends':'两端Z','bore':'孔径','t':'厚','boss_d':'轮毂外径','boss_t':'轮毂长','arm_radius':'销距','pin_d':'销孔','arm_t':'臂厚','arm_w':'臂宽','total_height':'槽顶距中心','angle_from_X':'相对+X角','radius':'半径','angle_start':'起角','angle_end':'终角','across_flats':'对边','x1':'起点X','y1':'起点Y','x2':'终点X','y2':'终点Y','closed':'闭圆','corner_Rmax':'内角R上限','bore_depth':'孔深','hub_od':'轮毂外径','hub_length':'轮毂长'}
def featuretext(f):
 LABEL.update({'xmin':'最小X','ymin':'最小Y','z0':'起始Z','centres':'中心坐标','guide_d':'导向直径','guide_length':'导向段长','head_d':'头径','head_h':'头高','hex':'内六角','underhead_length':'头下长度','nominal_deflection':'名义单片压缩','free_height':'自由高度','drill':'底孔直径'})
 typ=f.get('type','');vals=[]
 for k,v in f.items():
  if k=='type':continue
  if isinstance(v,float):v=f'{v:.4f}'.rstrip('0').rstrip('.')
  vals.append(f'{LABEL.get(k,k)}={v}')
 types={'blank':'下料外形','window':'开口','windows':'开口','holes':'孔组','hole':'孔','thread':'螺纹','pocket':'沉位','disc_spring':'碟簧','washer':'垫圈','guided_screw':'导向螺钉'}
 return types.get(typ,typ)+': '+', '.join(vals)
def part_drawings(parts):
 pdf=O/'drawings/02_ALL_SELFMADE_PARTS_C02_CN.pdf';c=canvas.Canvas(str(pdf),pagesize=(W,H));coverage=[]
 for p in parts:
  if p['kind'] in ['BUY','REFERENCE','PURCHASE_SUBPART']:continue
  pn=p['pn'];s=b.ex.readshape(p.get('free_brep') or p['brep']);features=p['features'];notes=p['notes'];pages=[]
  header(c,pn+'  '+p['name'],'三视投影与坐标尺寸表；原点/轴向以本件STP为准；任何总装坐标不替代零件加工基准。',pn,str(len(coverage)+1))
  bb=b.ex.bb(s);lens=[bb[i+3]-bb[i] for i in range(3)];order=sorted(range(3),key=lambda a:lens[a],reverse=True);aa,bbaxis,cc=order;names='XYZ'
  view(c,s,(aa,bbaxis),(35,280,595,460),f'主坐标投影 {names[aa]}–{names[bbaxis]}')
  view(c,s,(cc,bbaxis),(635,280,150,460),f'端坐标投影 {names[cc]}–{names[bbaxis]}')
  view(c,s,(aa,cc),(35,95,740,165),f'辅坐标投影 {names[aa]}–{names[cc]}')
  x=805;y=H-85;ww=W-x-35
  y=para(c,('自由态下料模型；安装压缩态另见总装。' if p.get('free_brep') else '')+'材料：'+p['material'],x,y,ww,11)-9
  y=para(c,f'手动/自动数量：{p["quantity_manual"]}/{p["quantity_auto"]}；类型：{p["kind"]}；零件图号：{p["drawing"]}',x,y,ww,10)-8
  y=para(c,p.get('datum_text') or ('基准：本焊总成采用整机XYZ；成员表给出各子件原点和基向量；子件按自己的零件图加工。' if any(f.get('type')=='assembly_datum' for f in features) else '基准：板件 A=Z0 工作面，B=Y0 边，C=X0 边；轴件 A=轴线，B=Z0端面。坐标尺寸从同一原点给出，禁串联累加。'),x,y,ww,9)-8
  y=para(c,'未注：机加工线性±0.10，角度±0.2°；激光板外形/孔位±0.20；焊件总尺寸±0.50。关键配合按专注。未注金属锐边去毛刺0.2–0.4；304L焊后去氧化皮、酸洗钝化并漂洗干燥。',x,y,ww,9)-10
  texts=[(('安装/接口参数：' if p.get('free_brep') and f.get('type')!='free_blank' else '')+featuretext(f)) for f in features]+['工艺/检验：'+n for n in notes]
  for idx,t in enumerate(texts):
   ptmp=Paragraph(t.replace('–','-').replace('—','-').replace('−','-').replace('&','&amp;'),SMALL);_,hh=ptmp.wrap(ww,10000)
   if y-hh<90:
    c.showPage();header(c,pn+'  特征表/工艺续页','与前页构成同一零件图；全部坐标单位mm。',pn,'续');x=60;y=H-100;ww=W-120
   y=para(c,t,x,y,ww,8)-5
  c.showPage();coverage.append(dict(PN=pn,drawing=p['drawing'],projection='XYZ orthographic',features=len(features),drawing_generated=True,engineering_release=False))
 c.save();b.cw('DRAWING_COVERAGE.csv',coverage);return pdf

def tableflow(rows,widths):
 data=[[Paragraph(str(v).replace('–','-').replace('—','-').replace('−','-').replace('&','&amp;'),SMALL) for v in row] for row in rows]
 t=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT');t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),LIGHT),('VALIGN',(0,0),(-1,-1),'TOP'),('GRID',(0,0),(-1,-1),.3,HexColor('#b8c6ce')),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]));return t
def report(name,title,sections):
 fn=O/'drawings'/name;doc=SimpleDocTemplate(str(fn),pagesize=A4,leftMargin=38,rightMargin=38,topMargin=54,bottomMargin=52);flow=[]
 title_style=ParagraphStyle('title',parent=STYLE,fontSize=20,leading=29)
 hstyle=ParagraphStyle('h',parent=STYLE,fontSize=13,leading=20,spaceBefore=10,spaceAfter=7,keepWithNext=True)
 flow+=[Paragraph(title,title_style),Paragraph('AirTransformer / AT-DMP02-MFG-C02 / 2026-10-12',SMALL),Spacer(1,16)]
 for heading,items in sections:
  flow.append(Paragraph(heading,hstyle))
  for item in items:
   if isinstance(item,tuple):flow.append(tableflow(item[0],item[1]));flow.append(Spacer(1,10))
   else:flow.append(Paragraph(str(item).replace('–','-').replace('—','-').replace('−','-').replace('&','&amp;').replace('\n','<br/>'),STYLE));flow.append(Spacer(1,7))
 def foot(c,d):
  c.setFont('CN',8);c.setFillColor(INK);c.drawString(38,27,'AT-DMP02 C02  ·  工程审计候选 / 未授权下料、带电或加压试验');c.drawRightString(A4[0]-38,27,str(d.page))
 doc.build(flow,onFirstPage=foot,onLaterPages=foot);return fn

