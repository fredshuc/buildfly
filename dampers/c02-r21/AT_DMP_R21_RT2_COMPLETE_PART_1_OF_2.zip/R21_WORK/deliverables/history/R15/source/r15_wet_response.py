"""Selected signed wet free bodies with reused Euler beam kernel.
Finite radial lands and thermal diametral clearance in one solve. Housing roots
are prescribed: this is a diagnostic boundary, not an installed stiffness bound.
"""
import json,math,ast,hashlib
import numpy as np
from scipy.linalg import solve
import build_c02 as b
E=b.OUT/'evidence';root=b.ROOT.parent
src=(root/'R7_WORK/source/r6_finite_base.py').read_text();node=next(n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef) and n.name=='beamk');exec(ast.get_source_segment(src,node))
mass=json.loads((E/'R15_ROTOR_MASS.json').read_text());weight=mass['mass_kg']*9.81;cg=-10-mass['local_CG_mm'][0]
land=[10,15,20,-647,-652,-657];nodes=np.array(sorted(set([-700.5,-657,-652,-647,-637,-627,-617,-318.5,-30,-20,-10,0,10,15,20,46,82,103.5,125,cg]+list(np.linspace(-627,-10,13)))));N=len(nodes);nd=4*N
def ids(z,plane):i=int(np.argmin(abs(nodes-z)));return [4*i+2*plane,4*i+2*plane+1]
K=np.zeros((nd,nd));EI=185000*math.pi*30**4/64
for i,L in enumerate(np.diff(nodes)):
 for pl in [0,1]:
  ix=[4*i+2*pl,4*i+2*pl+1,4*(i+1)+2*pl,4*(i+1)+2*pl+1];K[np.ix_(ix,ix)]+=beamk(L,EI)
contacts=[]
for z in land:contacts.append((z,100000/3,'near' if z>0 else 'far'))
# Native30.20 throat regions on each J401, conservatively sampled at both ends.
for z in [0,3,7.2,10,-637,-640,-644.2,-647]:contacts.append((z,25000,'throat_near' if z>-100 else 'throat_far'))
# Only exact node locations accepted; throat endpoints use interpolation shape vectors.
def vec(z,pl,der=0):
 v=np.zeros(nd);i=min(max(np.searchsorted(nodes,z)-1,0),N-2);L=nodes[i+1]-nodes[i];t=(z-nodes[i])/L
 a=np.array([1-3*t*t+2*t**3,L*(t-2*t*t+t**3),3*t*t-2*t**3,L*(-t*t+t**3)]) if der==0 else np.array([(-6*t+6*t*t)/L,1-4*t+3*t*t,(6*t-6*t*t)/L,-2*t+3*t*t])
 v[[4*i+2*pl,4*i+2*pl+1,4*(i+1)+2*pl,4*(i+1)+2*pl+1]]=a;return v
V=[np.vstack([vec(z,0),vec(z,1)]) for z,k,g in contacts]
def calc(q,f,gaps):
 r=K@q-f;T=K.copy();en=.5*q@K@q-q@f;re=[]
 for (z,k,g),v,gap in zip(contacts,V,gaps):
  d=v@q;rr=np.linalg.norm(d);pen=max(0,rr-gap);force=np.zeros(2)
  if pen and rr>0:
   u=d/rr;force=k*pen*u;t=k*((1-gap/rr)*np.eye(2)+(gap/rr)*np.outer(u,u));r+=v.T@force;T+=v.T@t@v;en+=.5*k*pen**2
  re.append(force)
 return en,r,T,re
def run(name,rotor,T,pressure,jam,pose,shaftT=20,seatT=20,sign=1):
 f=np.zeros(nd);loads=[]
 def force(z,F,M=(0,0),kind='external'):
  nonlocal f
  for pl in [0,1]:f+=vec(z,pl)*F[pl]+vec(z,pl,1)*M[pl]
  loads.append(dict(s_mm=z,F_worldXZ_N=list(F),bending_generalized_Nmm=list(M),kind=kind))
 # pressure at closed reference: P normal worldX, R normal worldZ.
 pdir=np.array([1.,0.]) if rotor.startswith('P') else np.array([0.,1.]);gd=np.array([0.,-1.]) if pose=='installed' else np.array([-1.,0.])
 for z,w in zip(np.linspace(-627,-10,13),[1/24]+[1/12]*11+[1/24]):force(z,pdir*pressure*.617*.154*w,kind='pressure')
 force(cg,weight*gd,kind='trimmed_rotor_gravity')
 # Correct BK2 lever and axial thermal length from fixed thrust pin s46 to clamp centroid103.5.
 Fcouple=sign*31.5*pdir+4*9.81*gd;Mgen=sign*10000*pdir
 force(103.5,Fcouple,Mgen,'BK2_0.03mm_offset_plus_full4kg_allocation_10Nm_moment_budget')
 if jam:
  for z in [-328.5,-308.5]:force(z,-sign*(200000/77)/2*pdir,kind='central20mm_edge_jam')
 gap=(30.060*(1+18e-6*(seatT-20))-30*(1+17.2e-6*(shaftT-20)))/2-.005
 throat=(30.2*(1+17.2e-6*(seatT-20))-30*(1+17.2e-6*(shaftT-20)))/2-.005
 gaps=[gap if g in ['near','far'] else throat for z,k,g in contacts]
 # Warm initial direction: zero-gap bilateral solution; solver then restores actual gaps.
 k0=K.copy()
 for (z,k,g),v in zip(contacts,V):k0+=k*v.T@v
 q=solve(k0,f,assume_a='sym');history=[]
 for it in range(100):
  en,r,kk,rr=calc(q,f,gaps);res=float(max(abs(r)));history.append(res)
  if res<1e-3:break
  dq=solve(kk+np.eye(nd)*1e-5,-r,assume_a='sym');a=1.
  while a>2**-22:
   if calc(q+a*dq,f,gaps)[0]<=en+1e-4*a*r@dq+1e-7:break
   a*=.5
  q+=a*dq
 en,r,kk,rr=calc(q,f,gaps);ends=[]
 # Forces below are SHAFT ON HOUSING, at each actual J401 wall-facing plane.
 for end,z0,gs in [('near',0,['near','throat_near']),('far',-637,['far','throat_far'])]:
  F=np.zeros(2);mg=np.zeros(2)
  for (z,k,g),v,rf in zip(contacts,V,rr):
   if g in gs:F+=rf;mg+=(z-z0)*rf
  # s dryward=-worldY. e_s cross(Fx,0,Fz)=(-Fz,0,Fx)
  axial=sign*71*(57.5*17.2e-6*(shaftT-20)+.15+.03) if end=='near' else 0
  ends.append(dict(end=end,reference_s_mm=z0,F_worldXYZ_N=[F[0],-axial,F[1]],M_worldXYZ_Nmm=[-mg[1],0,mg[0]],shaft_displacement_worldXZ_mm=[float(vec(z0,p)@q) for p in [0,1]],shaft_slope_dXZ_ds_mrad=[float(vec(z0,p,1)@q*1000) for p in [0,1]],seat_displacement_rotation='Prescribed zero for this boundary diagnostic; actual shell/seat response NOT established',axial_reference='Near fixed thrust pin carries allocated BK2 axial force; far axial support released',bearing_projected_pressure_MPa=np.linalg.norm(F)/(30*10)))
 total=np.sum(rr,axis=0);loadsum=np.sum([x['F_worldXZ_N'] for x in loads],axis=0);momcontact=sum(z*rf for (z,k,g),rf in zip(contacts,rr));momload=sum(x['s_mm']*np.array(x['F_worldXZ_N'])+x['bending_generalized_Nmm'] for x in loads)
 return dict(case=name,rotor=rotor,pose=pose,torque_Nm=T,pressure_Pa=pressure,jam=jam,sign=sign,Tshaft_C=shaftT,Tseat_C=seatT,radial_gap_mm=gap,throat_gap_mm=throat,loads=loads,ends=ends,residual_N=float(max(abs(r))),converged=max(abs(r))<1e-3,iterations=it+1,force_balance_N=(total-loadsum).tolist(),moment_balance_Nmm=(momcontact-momload).tolist(),peak_displacement_mm=max(np.hypot(q[0::4],q[2::4])),node_s_mm=nodes.tolist(),dofs=q.tolist(),scope='Conditional fixed-housing finite-land thermal-clearance solve; pressure+jams have named directions. 10Nm and full coupling weight are allocations, not measured reactions. Normal torque is a balanced pure torsional load; unknown seal drag distribution is not converted into invented transverse force. No support/pin/friction/stress qualification.')
cases=[('P_normal78_3Pa','P1',78,3,False,'installed',20,20,1),('P_normal78_5Pa_hotshaft','P1',78,5,False,'installed',70,20,1),('R_normal38_5Pa','R',38,5,False,'installed',20,20,-1),('P_hold500','P2',0,500,False,'installed',20,20,1),('R_structure1500','R',0,1500,False,'bench',20,20,1),('P_sensitivity2000','P1',0,2000,False,'installed',20,20,1),('P_active_jam200','P1',200,1500,True,'installed',20,20,1),('P_driven_jam200_hotshaft','P2',200,1500,True,'installed',70,20,-1),('R_jam200','R',200,1500,True,'bench',20,20,1),('P_stop200_dry_only','P1',0,0,False,'bench',20,20,1)]
out=[]
for c in cases:
 r=run(*c);out.append(r);print(r['case'],r['converged'],r['residual_N'],[round(np.linalg.norm(x['F_worldXYZ_N']),2) for x in r['ends']],flush=True)
b.dump(E/'R15_SIGNED_WET_RESPONSE.json',dict(cases=out,kernel_sha256=hashlib.sha256(src.encode()).hexdigest(),bearing_centres_s_mm=[15,-652],bearing_span_mm=667,wall_face_span_mm=637,mass=mass,thermal_axial_length_mm=57.5,notes=['R14 wet scalar used637mm wallface span; physical10mm lands have667mm centre spacing.','Nonlinear radial contact includes thermal gap in each named solve; rigid housing roots are diagnostic, NOT physical acceptance.','Torsional response about shaft omitted: leaf plate and weld torsion, distributed seal drag and axial pin/washer compliance require measured/structural validation. All6 reaction components listed only within stated no-axial-friction/no-bushing-torque idealisation.','Ten selected rows, not full224/150 family. No fabricated real test or proof of maximum.']))
