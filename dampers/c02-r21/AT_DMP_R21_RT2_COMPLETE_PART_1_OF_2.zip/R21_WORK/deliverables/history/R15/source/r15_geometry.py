import json,copy,hashlib,zipfile,collections,math
import numpy as np
import build_c02 as b
E=b.OUT/'evidence'; base=b.ROOT.parent/'R12_WORK/deliverables'
P=json.loads((base/'native/PARAMETRIC_PARTS_C02.json').read_text());O=json.loads((base/'native/OCCURRENCES_C02.json').read_text());pm={p['pn']:p for p in P}
S={pn:b.ex.readshape(p['brep']) for pn,p in pm.items()}
signed=b.ROOT.parent/'R15_INPUT/signed'; z=b.ROOT.parent/'R15_INPUT/AT_DMP_R14_L1_RELEASE_AND_R15_ORDER_20261012.zip'
with zipfile.ZipFile(z) as zz:
 if zz.testzip():raise ValueError('CRC')
for q in json.loads((signed/'FILE_MANIFEST.json').read_text()):
 f=signed/q['path']
 if f.stat().st_size!=q['bytes'] or hashlib.sha256(f.read_bytes()).hexdigest()!=q['sha256']:raise ValueError(q)
b.dump(E/'R15_INPUT_CHECK.json',dict(bytes=z.stat().st_size,sha256=hashlib.sha256(z.read_bytes()).hexdigest(),CRC=True,manifest=True,parts=len(P),occurrences=len(O)))
# Original world axes: all rotors run along +world Y. Section coordinate s increases dryward.
section=[]
for tag,ident in [('P1','B200_001'),('P2','B200_002'),('R','B200_003')]:
 rotor=next(x for x in O if x['occurrence']==ident);cx,cy,cz=rotor['o']
 for o in O:
  if o['pn'] not in ['J401','J402','J403','J404','J405','J406','J407','J408','F604','STD03C','STD04C','A709']:continue
  sh=b.tr(S[o['pn']],o['o'],o['u'],o['v'],o['n']);bb=b.ex.bb(sh);c=sh.Center()
  if abs(c.x-cx)>70 or abs(c.z-cz)>70:continue
  section.append(dict(rotor=tag,PN=o['pn'],occurrence=o['occurrence'],s_min=-726.5-bb[4],s_max=-726.5-bb[1],world_bbox=bb,source='R12 exact native; s= -726.5-worldY'))
b.dump(E/'R15_WET_STATIONS.json',section)
# Same native solids for metal fabrication; one fixed-end measurement set only.
qty={'J401':1,'J403':1,'J404':1,'J405':4,'J406':2,'J407':1,'J408':8,'F604':4,'STD03C':4,'STD05B':1,'D542':1,'BUY548':24,'BUY402':1,'HW_N6':5,'HW_W6_1p6_12':2}
parts=[]
for pn,n in qty.items():
 p=copy.deepcopy(pm[pn]);p.update(quantity=n,quantity_manual=n,quantity_auto=n,revision='R15_SP04_CANDIDATE',drawing=pn+'-R15',batch='SP04-A' if pn not in ['BUY548','BUY402','HW_N6','HW_W6_1p6_12'] else 'SP04-PURCHASE',status='P1_FABRICATION_CANDIDATE')
 p['notes']=[x for x in p['notes'] if not x.startswith(('R10','本修订','R6候选','干侧堆栈：'))]
 p['notes']+=['R15 replaces blanket manufacturing prohibition ONLY for this named single fixed-end measurement set, subject to L1 release. No complete valve installation or loaded/hot operation release.','Four through-studs at one end are counted once through wall/gasket/housing/spacers/cap; the opposite valve end has a separate four-stud set.','Unloaded fit only: no spring preload before approved instrumented compression fixture. 1450-1470N is a historical trial target, NOT an assembly instruction. No generic tightening torque.']
 if pn=='J403':p['notes']+=['Drawing text STD05 is superseded by actual STD05B M6 pin bolt; 6H6 holes and 6h6 plain shank retained.']
 if pn=='J404':
  p['notes']=[x for x in p['notes'] if not x.startswith('R4干侧')]
  p['notes']+=['Dry pocket diameter14.00+0.10/0, depth1.50+/-0.02. Current stack is J408 + three parallel002700A + reversed three parallel002700A + J408; supersedes old single three-disc note. Remaining metal>=2.45.']
 if pn=='J407':p['notes']+=['Measure actual J401 bore first; finish outside diameter for 0.010-0.025 diametral interference. Press and finish bore as a matched numbered housing/bush set.']
 parts.append(p)
def new(pn,name,s,mat,features,notes,qty,batch):
 p=dict(pn=pn,name=name,kind='MAKE',material=mat,features=features,notes=notes,group='seal',revision='R15',quantity=qty,quantity_manual=qty,quantity_auto=qty,drawing=pn+'-R15',batch=batch,status='P1_FABRICATION_CANDIDATE',brep=b.brep(s),free_brep=None,bbox=b.ex.bb(s),volume_mm3=s.Volume())
 if not s.isValid() or len(s.Solids())!=1:raise ValueError((pn,'invalid'))
 parts.append(p);S[pn]=s;return p
# Rebuild free soft materials from planar feature definitions. No Z scaling of a partially compressed shape.
freeproof=[]
for pn,t,n in [('P108',6.35,4),('R108',6.35,4),('J402',.8,1)]:
 old=pm[pn];f=old['features'][0];s=b.box(f['width'],f['height'],t)
 for a in old['features'][1:]:
  if a['type'] in ['hole','gland_head_relief']:s=s.cut(b.cyl(a['d'],t+2,(a['x'],a['y'],-1)))
  elif a['type']=='mount_notch':s=s.cut(b.box(a['w'],a['h'],t+2).translate((a['x'],a['y'],-1)))
  else:raise ValueError(('unhandled free feature',pn,a))
 s=s.clean();newpn=pn+'_FREE_R15';p=new(newpn,pn+' free-state cutting blank',s,old['material'],[dict(type='free_blank',width=f['width'],height=f['height'],thickness=t)]+copy.deepcopy(old['features'][1:]),['Free material only; never order the flattened installed thickness. In-plane cut profile per coordinate table and DXF. Soft material profile +/-0.20; hole centres +/-0.20. Knife/die cut; no thermal cutting.','J402: solid EPDM70 free0.80+/-0.10; installed gap nominal0.50 controlled by measured F604. Dynamic side foam: HT-870 nominal6.35, incoming6.20..6.80, select recorded shim stack for28..32% cold compression.','All head reliefs in this free blank are THROUGH, including historical installed_depth fields; do not mill a4mm pocket into foam. Match handed placement to R12 occurrences.'],n,'SP04-B')
 p['features']=[{k:v for k,v in a.items() if k not in ['installed_depth','free_depth']} for a in p['features']]
 freeproof.append(dict(PN=newpn,installed_PN=pn,free_mm=t,installed_bbox=old['bbox'],new_volume=s.Volume(),source_brep_sha256=hashlib.sha256(old['brep'].encode()).hexdigest()))
s=b.box(630,9,9.53)
for x in range(15,616,50):s=s.cut(b.cyl(2.4,12,(x,2,-1)))
new('S302_FREE_R15','End seal free-state cutting blank',s,'Rogers BISCO HT-870 9.53mm',[dict(type='free_blank',length=630,width=9,thickness=9.53),dict(type='holes',x='15:50:615',y=2,d=2.4,depth='THRU')],['Free rectangular9.53mm sheet across all9mm width. Do NOT cut root to2.945 or work band to6.671. Width9+/-0.10,length630+/-0.20,holes+/-0.20. Knife/die cut.','Incoming thickness8.40..10.00; work band y4.5..9 set26..34% cold compression with actual blade, nominal30%. y0..4 retaining root nominal2.945 compressed; root tearing/retention requires coupon test. y4..4.5 transition is representation only.','Six strips for one P/R set (P4,R2). End trim only soft material for0.5+/-0.2 overlap to actual side seals; no metal grinding.'],6,'SP04-B')
# One pair of wall-strip coupons, with the actual8mm split and38mm port, for comparing backed/unbacked gasket behaviour.
for hand,x0 in [('L',-50),('R',4)]:
 s=b.box(46,100,3).translate((x0,-50,-3));s=s.cut(b.cyl(38,5,(0,0,-4)))
 for yy in [-24,24]:s=s.cut(b.cyl(6.5,5,(-24 if hand=='L' else 24,yy,-4)))
 new('TF910'+hand,'Split-wall compression coupon '+hand,s,'EN1.4307 /304L',[dict(type='blank',xmin=x0,xmax=x0+46,ymin=-50,ymax=50,zmin=-3,zmax=0),dict(type='edge_port',x=0,y=0,d=38),dict(type='holes',x=-24 if hand=='L' else 24,y='-24,+24',d=6.5)],['Machined/flat sheet3.00+/-0.03; planarity0.03 on gasket footprint; cut profile+/-0.10, hole location+/-0.05. Deburr0.1 only; no edge sealant.','Pair held8.00+/-0.05 apart on independent metrology support before J401 fitted. This reproduces local missing-metal footprint, NOT real shell bending or flange boundary.','Unloaded coupon manufacture only. No external force or spring compression until guarded fixture/clamps/load cell calibration approved. Retain all four through-studs and nuts during any approved measurement; no rotor fitted.'],1,'SP04-C')
# A short witness mandrel supplies the actual pin/ring positive capture in the cold measurement unit.
s=b.cyl(30,80).cut(b.cyl(6,34,(0,-17,61.5),(0,1,0)))
new('TF912','Captured seal witness mandrel',s,'EN1.4307 /304L',[dict(type='shaft',diameter=30,length=80),dict(type='crossbore',axis='Y',x=0,z=61.5,d=6,fit='6H6 6.000..6.008',depth='THRU')],['OD29.979..30.000 (30h7); Ra0.8, cylindricity0.005, straightness0.02. L80.00+/-0.05; pin station61.50+/-0.02 fromZ0. Ream crossbore6H6 with J403 alignment; do not enlarge to6.5.','End lead0.2x30deg; polish/deburr cross-hole without rounding load-bearing bore. Test mandrel only, not B202 replacement.','PlacedZ=-15..65 in coupon frame; J403 crosspinZ46.5. Positive ring captured between two PTFE thrust washers and J401/J404 before any handling. No torque/pressure/hot tests authorized.'],1,'SP04-C')
# Grouped shim quantities are from actual kits, never solid1.80mm proxy orders.
kits=json.loads((base/'native/KITS_C02.json').read_text())
for root in ['P111','R111']:
 counts=collections.Counter(x['pn'] for x in kits[root])
 for pn,count in counts.items():
  p=copy.deepcopy(pm[pn]);n=count*4;p.update(quantity=n,quantity_manual=n,quantity_auto=n,revision='R15_SP04_CANDIDATE',drawing=pn+'-R15',batch='SP04-B',status='P1_FABRICATION_CANDIDATE');thickness=p['features'][0]['thickness'];p['features']=copy.deepcopy(pm[root]['features']);p['features'][0]['thickness']=thickness;p['features']=[{k:v for k,v in a.items() if k not in ['installed_depth','free_depth']} for a in p['features']];p['notes']+=['Four profile stacks for this valve type; nominal1.80 per stack, grouped measured total +/-0.015, parallel spread<=0.02. Not a single-piece thickness tolerance. Etch/precision shear thin foil, no laser heat damage. All profile holes/reliefs through; in-plane profile/registration +/-0.10.'];parts.append(p)
b.dump(b.OUT/'native/R15_SP04_PARTS.json',parts);b.dump(E/'R15_FREE_STATE_DEFINITIONS.json',freeproof)
# Reference local fixed-end assembly from exact R12; transformed to coupon coordinates: X/Y in wall, Z dryward.
allow=set(qty)|{'J402'};picked=[]
for o in O:
 if o['pn'] not in allow or o['pn'] in ['D542','BUY402']:continue
 sh=b.tr(S[o['pn']],o['o'],o['u'],o['v'],o['n']);bb=b.ex.bb(sh);c=sh.Center()
 if abs(c.x+82)>40 or abs(c.z-1583)>40 or not (-800<c.y<-720):continue
 if o['pn']=='HW_N6' and c.y>-780: # pin nut allowed
  pass
 # World-> local x=worldX+82,y=worldZ-1583,z=-worldY-726
 rot=lambda v:[v[0],v[2],-v[1]]
 oo=np.array(rot(o['o']))+np.array([82,-1583,-726]);q=dict(o);q.update(o=oo.tolist(),u=rot(o['u']),v=rot(o['v']),n=rot(o['n']));picked.append(q)
for pn in ['TF910L','TF910R']:picked.append(dict(pn=pn,occurrence=pn+'_001',o=[0,0,0],u=[1,0,0],v=[0,1,0],n=[0,0,1],scope='FIXTURE'))
picked.append(dict(pn='TF912',occurrence='TF912_001',o=[0,0,-15],u=[1,0,0],v=[0,1,0],n=[0,0,1],scope='FIXTURE'))
b.dump(b.OUT/'native/R15_FIXED_END_REFERENCE_OCCURRENCES.json',picked)
refp={o['pn']:copy.deepcopy(pm[o['pn']]) if o['pn'] in pm else next(p for p in parts if p['pn']==o['pn']) for o in picked}
b.dump(b.OUT/'native/R15_FIXED_END_REFERENCE_PARTS.json',list(refp.values()))
# Current rotor mass/CG from exact R13 trimmed BRep, not R14 uncut rotor estimate.
wet=json.loads((b.ROOT.parent/'R13_WORK/deliverables/native/R13_WET_INTERFACE_PARTS.json').read_text());rot=next(p for p in wet if p['pn']=='B200_R13');sh=b.ex.readshape(rot['brep']);b.dump(E/'R15_ROTOR_MASS.json',dict(PN=rot['pn'],volume_mm3=sh.Volume(),mass_kg=sh.Volume()*7.93e-6,local_CG_mm=sh.Center().toTuple(),density_kg_mm3=7.93e-6,axis_mapping='B200 localX along world+Y; s=-10-localX',shaft_length_mm=825.5,wet_protection='R13 protected material witness retained; not new shaft fabrication release'))
b.dump(b.OUT/'native/R15_WET_INTERFACE_REFERENCE.json',wet)
print('GEOMETRY',len(parts),'PN',sum(p['quantity'] for p in parts),'pieces','reference',collections.Counter(q['pn'] for q in picked),flush=True)
