import json,math,collections,copy
import build_c02 as b
R=b.ROOT.parent;N=b.OUT/'native';E=b.OUT/'evidence';pm={p['pn']:p for p in json.loads((N/'R18_PARTS.json').read_text())};S={pn:b.ex.readshape(p['brep']) for pn,p in pm.items()};old=S['G903'];s=old.intersect(b.box(500,5,1046.5).translate((-160,-1,-170.5))).clean();p=copy.deepcopy(pm['G903']);p.update(pn='G903_R18',revision='R18_ECO',brep=b.brep(s),bbox=b.ex.bb(s),volume_mm3=s.Volume(),status='P1_FABRICATION_CANDIDATE_NOT_L1_RELEASED');p['notes']=['S235JR3.00 sheet, X-148..328, Y0..3, Z-170.50..876.00. New finished length1046.50 +/-0.20. Datum unchanged fromR17. Trim45.50 +/-0.20 fromoldwetedgeZ-216; deburr0.3. No addedhole. Preserve fourdiameter5.5holes atX-135/315,Z-157.5/863,position+/-0.10. OldZ-203inspectionholes are removed entirely.','Rework candidate: identify actualR14/R17/F04 marking andholepattern first. Newmanufacture uses thispartdirectly; an existingF04 panelonlytrimmed. One replacementposition, NOadditional installed panel. Do not cutP107,J401 orsealparts. Front edgecoincides withG901outsideface andcovers its3mmthickness; measureoverlap andscrewsetback13mm.','No fullreach/fragment/thermal qualification; inspectcoldassembly gap atP107andG901 beforeacceptance. Remaininglowguardgaps elsewhere retainR17hold.'];pm[p['pn']]=p;S[p['pn']]=s
checks=[]
for tag in ['P','R']:
 O=json.loads((R/f'R17_WORK/deliverables/native/R17_{tag}_OCCURRENCES.json').read_text());W={q['occurrence']:b.tr(S[q['pn']],q['o'],q['u'],q['v'],q['n']) for q in O};g=next(q for q in O if q['pn']=='G903');new=b.tr(s,g['o'],g['u'],g['v'],g['n']);wet=[q for q in O if q['pn']==('P107' if tag=='P' else'R107')];dist=min(new.distance(W[q['occurrence']]) for q in wet);old_dist=min(W[g['occurrence']].distance(W[q['occurrence']]) for q in wet)
 hits=[]
 for q in O:
  if q==g:continue
  aa=b.ex.bb(new);cc=b.ex.bb(W[q['occurrence']])
  if not all(min(aa[k+3],cc[k+3])-max(aa[k],cc[k])>1e-5 for k in range(3)):continue
  v=new.intersect(W[q['occurrence']]).Volume()
  if v>.001:hits.append(dict(PN=q['pn'],instance=q['occurrence'],mm3=v))
 checks.append(dict(config=tag,old_gap_mm=old_dist,new_gap_mm=dist,manufacturing_position_budget_mm=1.3,remaining_cold_budget_mm=dist-1.3,budget_basis='trim0.2 + guard/receiver positioning0.5+0.5 + edge0.1; mustmeasure; notloaded/thermalallowance',hits=hits))
 g['pn']='G903_R18';g['revision']='R18_ECO';g['part_key']='G903_R18@R18';b.dump(N/f'R18_{tag}_OCCURRENCES.json',O)
 if tag=='P':
  a=next(q for q in O if q['pn']=='D886');d=W[a['occurrence']];t=next(q for q in O if q['pn']=='TF900');contact=d.intersect(W[t['occurrence']]);cs=[dict(area=f.Area(),center=f.Center().toTuple(),bbox=b.ex.bb(f)) for f in contact.Faces()];b.dump(E/'R18_STOP_CONTACT_GEOMETRY.json',dict(contact_faces=cs,intersection_volume=contact.Volume(),D886_bbox=b.ex.bb(d),TF900_bbox=b.ex.bb(W[t['occurrence']]),P2_axis=[-82,0,1583]))
b.dump(N/'R18_PARTS.json',list(pm.values()));b.dump(E/'R18_G903_ECO.json',dict(checks=checks,old_new_material_difference_mm3=[old.cut(s).Volume(),s.cut(old).Volume()],status='COLD_GEOMETRY_ECO_CANDIDATE',source='F04unchangedread-only;explicitR18replacement'))
b.ex.export_step('parts/G903_R18',[dict(definition='G903_R18',occurrence='G903_R18',scope='FIXTURE')],{'G903_R18':s})
# Reuse frozen accurately-stationed R15 rows without a new parameter family.
data=json.loads((R/'R15_WORK/deliverables/evidence/R15_SIGNED_WET_RESPONSE.json').read_text());b.dump(E/'R18_INHERITED_R15_WET_RESPONSE.json',data);rows=[]
for q in data['cases']:
 rows.append(dict(case=q['case'],rotor=q['rotor'],Twet_Nm=q['torque_Nm'],pressure_Pa=q['pressure_Pa'],bearing_s_mm=[15,-652],bearing_span_mm=667,wall_face_span_mm=637,coupling_centroid_s_mm=103.5,coupling_overhang_from_near_land_mm=88.5,source_case=q['case'],scope=q['scope']))
rows.append(dict(case='LOCAL_DRY_STOP_P1_TO_P2_200',rotor='P1/P2dry',Twet_Nm=0,pressure_Pa=0,bearing_s_mm=[15,-652],bearing_span_mm=667,wall_face_span_mm=637,coupling_centroid_s_mm=103.5,coupling_overhang_from_near_land_mm=88.5,source_case='P_stop200_dry_only wet branch; R17dry gear allocation separately',scope='P1input->P1gear->P2gear->D870/P2->D886->closedtallTF900->frame. Wetshafttorque0 DOES NOT remove200Nm drygearmesh; Ft2424.242N,Fr882.352N at20deg; physical stop wrench anddry bearing reactions remain separate.'))
b.dump(E/'R18_LOAD_ROW_MAP.json',rows)
I=81000;L=155;out=[]
for T in [78,200]:
 for r in [50,60,80]:
  F=T*1000/r;delta=F*L**3/(3*200000*I);theta=delta/r;out.append(dict(T_Nm=T,contact_radius_mm=r,force_N=F,stop_deflection_mm=delta,shaft_angle_deg=math.degrees(theta),blade_edge_displacement_mm=77*math.sin(theta),seal_compression_change_upper_projection_mm=77*math.sin(theta),scope='Fixedroot155mmbeamdiagnostic. Contactradiusrange, noassumedactualrootstiffness; projectionupperbound notclaimedcompressiondirection.'))
b.dump(E/'R18_STOP_TO_SEAL_MAP.json',dict(rows=out,normal_input_Nm=78,remaining_seal_tolerance='Needs actual foamfree thickness, setcompression, angle-to-contact projection andunloaded recovery measurement atbothends. No unconditionalPASS.',test_plan='No200Nmphysicalproof. Beforeanyrotating test approve actualfloor, capture,independentinputloadcell andlimitedinput. Proposed diagnosticincrements5/10/20Nm onlyafterseparateL1testrelease; dialindicator atD886contact, bothbladeends77mmradius, sealsettingpoints. Stoponloss ofcapture, contact, unexpectedsliporunrecoverablezero; deriveangle delta/r andcompareindividualmeasuredcompressionreserve. Planned limitnotanauthorization.'))
print('G903',checks,flush=True)
