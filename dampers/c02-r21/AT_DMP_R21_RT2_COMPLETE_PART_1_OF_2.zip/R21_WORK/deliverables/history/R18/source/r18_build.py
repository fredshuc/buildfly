import json,copy,csv,collections,hashlib,math
import numpy as np
import build_c02 as b
R=b.ROOT.parent;N=b.OUT/'native';E=b.OUT/'evidence'
orig=json.loads((R/'R17_WORK/deliverables/native/R17_PARTS.json').read_text());pm={p['pn']:copy.deepcopy(p) for p in orig};S={pn:b.ex.readshape(p['brep']) for pn,p in pm.items()}
kits=json.loads((R/'R12_WORK/deliverables/native/KITS_C02.json').read_text());O={t:json.loads((R/f'R17_WORK/deliverables/native/R17_{t}_OCCURRENCES.json').read_text()) for t in ['P','R']}
over=json.loads((R/'R18_INPUT/signed/deliverables/R17_L1_F04_PROCESS_AND_SCOPE_OVERRIDES.json').read_text())
for pn,q in over['process_overrides'].items():
 if 'material'in q:pm[pn]['material']=q['material']
 if pn=='TF920P':pm[pn]['notes']=[s.replace('34 diameter 24','32 diameter 24') for s in pm[pn]['notes']]
 if pn=='TF920R':pm[pn]['notes']=[s.replace('30 diameter 24','23 actual diameter 24 (28 reference positions, five removed by through-relief)') for s in pm[pn]['notes']]
 if pn=='TF924':pm[pn]['notes']=[s.replace('Seat only at1Nm for dimensional checks.','No seating torque or clamping released; externally supported unloaded dimensional comparison only.') for s in pm[pn]['notes']]
 pm[pn]['process_release_override']='R17-L1-F04'
cand=[];process={};names={};exports=[]
def put(pn,name,s,notes,mat='EN 1.4307 / 304L',kind='MAKE',features=None):
 if not s.isValid():raise ValueError(pn)
 pm[pn]=dict(pn=pn,name=name,material=mat,kind=kind,revision='R18',status='P1_FABRICATION_CANDIDATE_NOT_L1_RELEASED',brep=b.brep(s),bbox=b.ex.bb(s),volume_mm3=s.Volume(),features=features or [],notes=notes);S[pn]=s
def candidate(pn,qty,batch,notes,name=None,source=None):
 process[pn]=notes;names[pn]=name or pn;pm[pn]['process_revision']='R18';pm[pn]['notes']=notes;pm[pn]['status']='P1_FABRICATION_CANDIDATE_NOT_L1_RELEASED'
 cand.append(dict(PN=pn,quantity=qty,batch=batch,material=pm[pn]['material'],geometry_revision=pm[pn].get('revision','C02'),process_revision='R18',stage='LOOSE_PIECE_OR_STAGE_BLANK',replaces=source or '',drawing='AT_DMP_R18_SP05_FACTORY_EN.pdf' if batch=='SP05' else 'AT_DMP_R18_ROTOR_PROCESS_EN.pdf',STEP=f'step/parts/{pn}_R18.stp',status='CANDIDATE_NOT_L1_RELEASED',factory_state='UNCONFIRMED'));exports.append(pn)
qty={p['PN']:int(p['quantity']) for p in csv.DictReader((R/'R17_WORK/deliverables/tables/R17_W1_DISPOSITION.csv').open(encoding='utf-8-sig'))}
metals=['P101','P102A','P102B','P102C','P102D','P102E','R101','R102A','R102B','R112','R113','P110','R110','S301A','S301B','S301C','S303']
for pn in metals:
 f=pm[pn]['features'];bb=b.ex.bb(S[pn]);common=['Certified 304L. Local axes and origin are those of the individual STEP, not the complete valve. Datum A=lower sheet face Z0; B=left X0; C=bottom Y0. Profile +/-0.20, hole centres +/-0.10 unless explicitly tighter. Thickness per blank table; remove burrs 0.15 max, no sharp seal-contact edges.']
 if pn.startswith(('P101','R101')):common+=['3.00 +/-0.10 sheet. Laser or waterjet rough; finish contour and holes. Seal face flatness0.15/300 and0.30 overall; surface Ra3.2 or better, no transverse scratches. Window630 x345(P) or630 x180(R), cornerR<=0.5. Diameter9 +0.20/0 holes per exact coordinate schedule. Full-weld final inspection belongs to shell route; do not aggressively skim 3mm faces.']
 elif pn.startswith(('P102','R102')):common+=['3.00 +/-0.10 sheet, individual continuous split-flange blank. Cut exact contour including deliberate gaps; do not join separated pieces across gland openings. Closed circular edges diameter6.5 +0.20/0; inner contourR<=0.3. All boundary vertices and hole centres on companion coordinate pages/DXF. Fixture placement from shell composition table; not a second full-frame blank.']
 elif pn in ['R112','R113']:common+=['1.50 +/-0.08 sheet; length and20.00 height +/-0.10, edges straight0.15. R112 length630, R113 length183. Riser corner welding separate operation; no authorization to weld unknown host roof.']
 elif pn.endswith('110'):common+=['1.00 +/-0.05 sheet. Diameter3.4 +0.10/0 holes; R0.5 on exposed frame edges. Exact seat-clearance notches retained; open frame is deliberate. No clamping or seal preload released. Check final edge remains at least0.50 from blade hard end under later approved assembly.']
 elif pn.startswith('S301'):common=['304L machined bar630.00 +/-0.15 x24.00 +/-0.05 x32.00 +/-0.05. Datum A seal faceZ0, B endX0, C sideY0. A flatness0.10 over630, Ra1.6; opposite face parallel0.05. General hole centres +/-0.10.','Four end M5-6H taps: X0 and630, Y6/18, Z16; effective10 minimum, drill4.2 depth14. M2-6H from Z0, x15..615 pitch50, y13.5(A),10.5(B),9 and15(C); effective7 minimum, drill1.6 depth10. Gauge all threads; break edges0.2max. STEP cylinders are tap-drill envelopes, not finished minor-thread geometry.','Seat adjustment +/-2 remains a later measured assembly operation. This drawing releases no seal compression or screw torque.']
 elif pn=='S303':common=['304L flat bar630.00 +/-0.15 x4.00 +/-0.05 x3.00 +/-0.05; datum A bottomZ0, B X0,C Y0. Thirteen diameter2.4 +0.10/0 THRU, centres x15..615 pitch50,y2; position +/-0.10. Faces flat0.10/630; Ra1.6 contact, edgesR0.2. No torque instruction or foam compression acceptance under this loose-part stage.']
 candidate(pn,qty[pn],'SP05',common)
# Stage-specific side plates: preserve final reference, add bore and gland-screw finishing stock.
for pn in ['P103F','P103B','R103F','R103B']:
 src=pm[pn];f=src['features'];blank=f[0];s=S[pn];rect=b.box(blank['width'],blank['height'],blank['thickness'])
 for q in f:
  if q['type']=='hole' and q['d'] in [38,6.5]:
   s=s.fuse(b.cyl(q['d'],3,(q['x'],q['y'],0)).intersect(rect)).clean();s=s.cut(b.cyl(37.5 if q['d']==38 else 6.0,5,(q['x'],q['y'],-1))).clean()
 nn=pn+'_R18RAW';ff=copy.deepcopy(f)
 for q in ff:
  if q['type']=='hole' and q['d'] in [38,6.5]:q['d']=37.5 if q['d']==38 else 6.0
 put(nn,pn+' weld-stage side plate',s,[],features=ff)
 notes=['Certified304L3.00 +/-0.10 sheet. Envelope83.00 +/-0.15 x'+str(blank['height'])+' +/-0.15; localX is flow depth, Y port height. A sheetZ0,B X0,C Y0. Ordinary holes/profiles +/-0.10; thickness unchanged. Preserve all slot and small-hole geometry from coordinate schedule.', 'This RAW part replaces loose '+pn+' only for shell manufacture. Edge axle relief diameter37.50 +/-0.05 centred atX87, not38 final. Gland screw pilots diameter6.00 +/-0.05, not6.5 final. These features retain0.25 radial finish allowance. Do not enlarge until two shell halves are located with2.00mm metal setting spacers.', 'After welding and restrained straightening, paired line-machine edge reliefs to38.00 +0.10/0 with nominal stations from shell drawing; align across630mm opening todiameter0.10. Finish gland pilots6.50 +0.10/0 to paired spindle jig axes. If pilot drift consumes stock, STOP; no oversize hole or seal-face grinding.']
 candidate(nn,qty[pn],'SP05',notes,pn+' / pre-weld blank',pn);exports.append(pn)
# Soft materials with explicit free thickness; PTFE foam-inherited notes remain isolated.
soft=[]
for pn in ['P105A','P105B','P106','R105A','R106','S312']:
 p=pm[pn];s=S[pn];faces=[f for f in s.Faces() if f.geomType()=='PLANE' and abs(f.normalAt().z)>.999];face=max(faces,key=lambda f:f.Area());face=face.translate((0,0,-face.Center().z));t=.8 if pn=='S312' else 3.18
 sf=b.cq.Solid.extrudeLinear(face.outerWire(),face.innerWires(),b.vec((0,0,t)));nn=pn+'_FREE_R18';put(nn,pn+' FREE cutting blank',sf,[],p['material'],features=[dict(type='free_profile',installed_reference=pn,free_thickness=t)])
 notes=[('Solid EPDM70 AT-OR-01 free0.80 +/-0.10; installed0.50 is NOT cutting thickness.' if pn=='S312' else 'Existing specified static foam material retained: '+p['material']+'. Free nominal3.18; each incoming point2.90..3.50. Installed2.00 is NOT cutting thickness.'),'Free XY contour is the unchanged installed planar profile; cut without tensile stretch, knife/waterjet appropriate to material. Profile and hole centres +/-0.20; no adhesive repair of primary seal. Record incoming thickness at corners and every100mm, material lot and orientation.','This PN is a manufacturing-state blank, replaces the corresponding installed material quantity, not an additional installed layer. Compression and thermal properties are not qualified by cutting. Final measured setting follows separately approved metal stops and seal procedure.']
 candidate(nn,qty[pn],'SP05',notes,pn+' / free material',pn);soft.append(nn)
# Exact identical finished rotor; stages distinguish procurement from operations.
rotor=S['B200_R13'];shaft=S['B202_R13'];S['B200_R13_FINISH_REF']=rotor;pm['B200_R13_FINISH_REF']=copy.deepcopy(pm['B200_R13']);pm['B200_R13_FINISH_REF']['pn']='B200_R13_FINISH_REF';exports+=['B202_R13','B200_R13_FINISH_REF']
raw=b.cyl(30.30,833.5,(0,0,-4));raw=raw.cut(b.cyl(31,617,(0,0,135)).cut(b.cyl(30,617,(0,0,135))))
put('B202_R18RAW','Shortened rotor shaft pre-weld blank',raw,[],features=[dict(type='shaft_blank',raw_z_min=-4,raw_z_max=829.5,diameter=30.30,blade_interval=[135,752],blade_diameter=30)])
candidate('B202_R18RAW',3,'ROTOR',['304L certified round stock >=diameter32 x836; rough turn nominal30.30 +/-0.03 on Z-4..135 and752..829.5. Turn blade zoneZ135..752 to30.000/-0.020 before welding; no keyway or axial M8. Overall staged blank833.50 +/-0.20; final825.50 +/-0.10 betweenZ0 and825.5. Two sacrificial4mm end pads allow centre drilling(depth<=3) then complete removal.','Datum A finished journals common axis; B final new dry endZ0; C final cross-pin axisY. Final gripZ0..43 diameter30h7(29.979..30.000),Ra0.8. Near journal85..115 andfar772..802 diameter30h8(29.967..30.000),Ra0.6..0.8; physical bearing lands105..115/772..782. Polish sealing bands116.5..123.5 and763.5..770.5 toRa0.4,no helical lead. Runout0.03 toA, full straightness0.10.','Weld with sacrificial centres and protected turned zones. Straighten before final grinding. Finish exposed cylindrical zones to30h8 unless grip h7; retainblade attachmentzone. Remove sacrificial ends completely, endface perpendicular0.03. Drill/ream pin6H6(6.000..6.008) THROUGH localY atZ79.00 +/-0.03 only after welding; C normal tobladeplane within0.10deg. Protect polished journals from clamp teeth. Any heat straightening or repair requires separate reviewed procedure.'],source='B202_R13 finished reference')
candidate('B201',6,'ROTOR',['304L sheet2.50 +/-0.12, finished617.00 +/-0.15 x61.90 +/-0.10. Datum A sheet face, B X0 span end,C innerY0. Straightness0.10 span edge; flatness0.25. Working outer edge Ra1.6, deburrR0.3. No arbitrary material removal from final154mm chord.','Two equal blanks perB200_R13; total6for three rotors. Assembly x0..617, y15.1..77 and-77..-15.1,z-1.25..1.25. Shaft centre at(y,z)=(0,0), shaft dryx=-135,wetx690.5. Nominal radial rootgap0.152mm atplate face, set0.15..0.25. Four continuous nominala2 TIG fillets withER308L. Weld only after fixture/first-article holdpoint.'])
pm['B200_R13']['datum_text']='R18 corrected: localX is shaft axis; dryX=-135,wetX690.5. Shaft localZ=X+135. All three instances use identical definition; P1/P2/R IDs remain assembly markings.'
# Machining fixtures with complete dimensions; no product-load credit.
base=b.box(950,220,16).translate((-180,-110,-81))
for x in [-100,660]:
 for y in [-35,35]:base=base.cut(b.cyl(6.8,18,(x,y,-82)))
put('TF930','Rotor welding fixture base',base,['S355JR950x220x16,localX-180..770,Y-110..110,Z-81..-65. Upperdatum flat0.10. FourM8-6Hthrough atX-100/660,Y-35/35, effective14minimum. Ordinarypositions+/-0.10. Fixtureonly.'],'S355JR')
block=b.box(50,90,70).translate((-25,-45,-65));cut=b.cq.Workplane('YZ').polyline([(-40,18.574665),(0,-21.425335),(40,18.574665)]).close().extrude(52).val().translate((-26,0,0));block=block.cut(cut)
for y in [-35,35]:block=block.cut(b.cyl(9,72,(0,y,-66)))
put('TF931','Rotor 90 degree welding V-block',block,['S355JR; X-25..25,Y-45..45,Z-65..5.90deg V apexY0,Z-21.425335,straightthroughX. Two9THRU atX0,Y+/-35. GroundV facesRa1.6; angle90+/-0.05deg,apexheight+/-0.03; dimensions+/-0.10. Two blocks clamp tobase with fourISO4762 M8x85,class8.8 and1.6mm washers; nominal engagement13.4,complete>=12. The30.30rawshaft sits onaxisZ0; verify with indicator before tacking. Final30mmshaft is not used to set this rawfixtureheight.'],'S355JR')
rest=b.box(20,20,63.75).translate((-10,-10,-65));put('TF932','Blade fixture setting block',rest,['S355JR20x20,height63.75+/-0.02,upperfaceZ-1.25. Facesparallel0.02. Six blocks atX80/300/530,Y+/-50. Clamp tobase by ordinaryexternaltoolmakerclamps outside weld corridor; measured axis/plateplane setsdatum, not floor. Low-force holdonly, no valve load.'],'S355JR')
for pn,n in [('TF930',1),('TF931',2),('TF932',6)]:candidate(pn,n,'ROTOR_TOOL',pm[pn]['notes'])
# Shell local composition derived from original component transforms and real split kits.
assemblies={};comp_rows=[]
for pn in ['P100F','P100B','R100F','R100B','R100S']:
 fs=pm[pn]['features'][1:];ref=fs[0];A=np.array([ref['u'],ref['v'],ref['normal']]).T;origin=np.array(ref['origin']);items=[]
 for f in fs:
  fr=np.array([f['u'],f['v'],f['normal']]).T;fo=np.array(f['origin'])
  for i,k in enumerate(kits.get(f['pn'],[dict(pn=f['pn'],translation=[0,0,0],u=[1,0,0],v=[0,1,0],n=[0,0,1])])):
   kr=np.array([k['u'],k['v'],k['n']]).T;rr=A.T@fr@kr;oo=A.T@(fo+fr@np.array(k['translation'])-origin)
   it=dict(pn=k['pn'],id=f['occurrence']+('_'+str(i+1) if f['pn'] in kits else ''),o=oo.tolist(),u=rr[:,0].tolist(),v=rr[:,1].tolist(),n=rr[:,2].tolist());items.append(it);comp_rows.append(dict(assembly=pn,part=k['pn'],instance=it['id'],origin=json.dumps(it['o']),u=json.dumps(it['u']),v=json.dumps(it['v']),n=json.dumps(it['n']),supply_stage=k['pn']+'_R18RAW' if k['pn'].endswith(('103F','103B')) else k['pn'],order='ASSEMBLY_LABOUR_ONLY;components_not_duplicated'))
 shapes=[b.tr(S[it['pn']],it['o'],it['u'],it['v'],it['n']) for it in items];sh=b.comp(shapes);nn=pn+'_R18REF';put(nn,pn+' local fabrication assembly reference',sh,[],kind='WELD_ASSEMBLY');exports.append(nn);assemblies[pn]=dict(items=items,reference_world_origin=origin.tolist(),reference_world_matrix=A.tolist(),local_bbox=b.ex.bb(sh),status='WELD_PROCESS_CANDIDATE_PENDING_L1',quantity=1)
b.dump(N/'R18_SHELL_ASSEMBLIES.json',assemblies);b.cw('R18_SHELL_COMPOSITION.csv',comp_rows)
put('ROTOR_WELD_R18','Actual rotor deposited metal',rotor.cut(b.tr(shaft,(-135,0,0),(0,1,0),(0,0,1),(1,0,0))).cut(S['B201'].translate((0,15.1,-1.25))).cut(S['B201'].translate((0,-77,-1.25))),['Exact inherited deposited material difference; four longitudinal fillets.'],kind='WELD_MATERIAL');exports.append('ROTOR_WELD_R18')
b.dump(N/'R18_PARTS.json',list(pm.values()));b.dump(E/'R18_CANDIDATES.json',cand);b.dump(E/'R18_EXPORT_LIST.json',list(dict.fromkeys(exports)));b.cw('R18_CANDIDATE_BATCHES.csv',cand);b.dump(E/'R18_PROCESS_NOTES.json',process)
b.dump(E/'R18_INPUT_CHECK.json',dict(signed_bytes=1782109,sha256='d929a6acf078ef0a4058929e19bbd5a96495bec74890a6575d1bc40731fa537b',members=25,manifest=24,CRC='PASS',manifest_SHA='PASS'))
print('BUILT',len(cand),sum(x['quantity'] for x in cand),len(exports),flush=True)
