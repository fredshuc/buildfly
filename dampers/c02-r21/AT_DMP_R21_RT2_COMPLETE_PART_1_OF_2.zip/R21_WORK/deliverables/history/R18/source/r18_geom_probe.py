import json,numpy as np
from pathlib import Path
r=Path.cwd();pm={p['pn']:p for p in json.load(open('R17_WORK/deliverables/native/R17_PARTS.json',encoding='utf-8'))};kits=json.load(open('R12_WORK/deliverables/native/KITS_C02.json',encoding='utf-8'))
for k in ['P102','R102']: print(k,kits.get(k))
for pn in ['P100F','P100B','R100F','R100B']:
 fs=pm[pn]['features'][1:];a=fs[0];A=np.array([a['u'],a['v'],a['normal']]).T; o=np.array(a['origin']);print(pn)
 for f in fs:
  print(f['pn'],'o',np.round(A.T@(np.array(f['origin'])-o),3).tolist(),'R',(A.T@np.array([f['u'],f['v'],f['normal']]).T).tolist())
for tag in ['P','R']:
 oo=json.load(open(f'R17_WORK/deliverables/native/R17_{tag}_OCCURRENCES.json',encoding='utf-8'));print(tag,[(q['occurrence'],q['o'],q['u'],q['v'],q['n']) for q in oo if q['pn']=='B200_R13'])
