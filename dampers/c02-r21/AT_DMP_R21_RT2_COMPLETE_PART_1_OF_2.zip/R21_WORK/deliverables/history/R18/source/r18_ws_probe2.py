import json
from pathlib import Path
P={p['pn']:p for p in json.loads(Path('R18_WORK/deliverables/native/R18_PARTS.json').read_text())}
for n in ['TF908','TF927']:print(n,P[n]['notes'],P[n]['bbox'])
O=json.loads(Path('R18_WORK/deliverables/native/R18_P_OCCURRENCES.json').read_text())
for q in O:
 if q['pn'] in ['TF908','TF927']:print(q['occurrence'],q['pn'],q['o'],q['u'],q['v'],q['n'])
