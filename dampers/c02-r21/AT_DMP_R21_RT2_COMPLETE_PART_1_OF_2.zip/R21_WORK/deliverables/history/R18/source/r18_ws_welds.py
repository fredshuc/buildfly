import json,math,numpy as np
import build_c02 as b
N=b.OUT/'native';E=b.OUT/'evidence';P={q['pn']:q for q in json.loads((N/'R18_PARTS.json').read_text())};S={k:b.ex.readshape(v['brep']) for k,v in P.items()};rows=[];ss={}
def seam(name,root,u,v,along,throat,length):
 r=np.array(root);u=np.array(u);v=np.array(v);d=np.array(along);leg=throat*math.sqrt(2);pts=[r,r+u*leg,r+v*leg];w=b.cq.Wire.makePolygon([b.vec(p) for p in pts+[pts[0]]]);s=b.cq.Solid.extrudeLinear(w,[],b.vec(d*length));ss[name]=s;rows.append(dict(id=name,root=list(root),leg_dir1=list(u),leg_dir2=list(v),axis=list(along),length=length,throat=throat,brep=b.brep(s)))
# Four wet legs only; no change to existing six dry legs.
for ix,x in enumerate([-250,171]):
 for iy,y in enumerate([-630,-75]):
  prefix=f'LEG{ix}{iy}'
  for yy,sg in [(y,-1),(y+80,1)]:seam(prefix+'_TOP_'+str(sg),(x,yy,1388),(0,sg,0),(0,0,-1),(1,0,0),5,80)
  for xx,sg in [(x,-1),(x+80,1)]:seam(prefix+'_FOOT_X'+str(sg),(xx,y,756),(sg,0,0),(0,0,1),(0,1,0),5,80)
  for yy,sg in [(y,-1),(y+80,1)]:seam(prefix+'_FOOT_Y'+str(sg),(x,yy,756),(0,sg,0),(0,0,1),(1,0,0),5,80)
for x,sg in [(-170,1),(171,-1)]:
 for y,sy in [(-75,-1),(5,1)]:seam('CROSS_'+str(x)+'_'+str(y),(x,y,1388),(sg,0,0),(0,sy,0),(0,0,1),5,80)
 seam('CROSS_BOTTOM_'+str(x),(x,-75,1388),(sg,0,0),(0,0,-1),(0,1,0),5,80)
# Edge retainers: lower horizontal edges at Z1448 have actual mating surfaces.
# The inherited phrase two60mm edges cannot both be fillets: upper60mm edge is flush at rail topZ1468.
# Model lower a4 only and retain explicit top-edge joint hold, do not invent a fillet into receiver.
for x,sg in [(-250,-1),(251,1)]:
 for y in [-550,-150]:seam('EDGE_LOWER_'+str(x)+'_'+str(y),(x,y,1448),(sg,0,0),(0,0,-1),(0,1,0),4,60)
# Sleeves: R17 a3 fillets around FLUSH ends lack vertical sleeve land. No fictitious deposited rings.
b.dump(N/'R18_WS17_WELD_MATERIAL.json',rows);b.ex.export_step('R18_WS17_PARTIAL_WELD_MATERIAL',[dict(definition=k,occurrence=k,scope='FIXTURE') for k in ss],ss)
checks=[];hits=[];pairs=0
for tag in ['P','R']:
 O=json.loads((N/f'R18_{tag}_OCCURRENCES.json').read_text());W={q['occurrence']:b.tr(S[q['pn']],q['o'],q['u'],q['v'],q['n']) for q in O};B={k:b.ex.bb(v) for k,v in W.items()}
 for k,w in ss.items():
  bb=b.ex.bb(w);touch=[]
  for q in O:
   cc=B[q['occurrence']]
   if not all(min(bb[j+3],cc[j+3])-max(bb[j],cc[j])>=-1e-4 for j in range(3)):continue
   part=W[q['occurrence']]
   if w.distance(part)<1e-4:touch.append(q['pn']+':'+q['occurrence'])
   if not all(min(bb[j+3],cc[j+3])-max(bb[j],cc[j])>1e-5 for j in range(3)):continue
   pairs+=1;v=abs(w.intersect(part).Volume())
   if v>.001:hits.append(dict(config=tag,seam=k,PN=q['pn'],instance=q['occurrence'],mm3=v))
  checks.append(dict(config=tag,seam=k,touching=touch,two_or_more_parts=len(touch)>=2))
b.dump(E/'R18_WS17_WELD_CHECK.json',dict(seams=len(ss),pairs_boolean=pairs,contacts=checks,hits=hits,status='PARTIAL_WELD_JOINT_HOLD',unresolved=['FourTF927 OD20 flush ends in diameter20 rail holes provide no projecting sleeve land for a3 fillet; weld preparation/groove and post-weld flushness need drawing before welding.','TF926 upper60mm edge atZ1468 is flush with rail top and adjacent to removable receiver; inherited two60mm a4 note cannot be treated as two accessible fillets. Only loweredge modelled.','No receiver-to-rail weld. Receiver remains removable with through sleeves/bolts andTF925 ties.','Ten-floor-foot contact/friction and distributed real support remain unqualified.']))
print('WS17',len(ss),'hits',hits,'attachment_fail',[q for q in checks if not q['two_or_more_parts']],flush=True)
