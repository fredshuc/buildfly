import json,math
import build_c02 as b
N=b.OUT/'native';E=b.OUT/'evidence';pm={p['pn']:p for p in json.loads((N/'R18_PARTS.json').read_text())};S={pn:b.ex.readshape(p['brep']) for pn,p in pm.items()};ass=json.loads((N/'R18_SHELL_ASSEMBLIES.json').read_text());out={};routes=[]
def prism(p,u,v,n,L):return b.cq.Workplane(b.cq.Plane(origin=b.vec(p),xDir=b.vec(u),normal=b.vec(n))).polyline([(0,0),(math.sqrt(2)*2,0),(0,math.sqrt(2)*2)]).close().extrude(L).val()
for pn,a in ass.items():
 if pn=='R100S':continue
 H=345 if pn[0]=='P' else 180;items=a['items'];metal=b.comp([b.tr(S[q['pn']],q['o'],q['u'],q['v'],q['n']) for q in items]);flanges=[b.tr(S[q['pn']],q['o'],q['u'],q['v'],q['n']) for q in items if '102' in q['pn']];mask=b.comp([s.translate((0,0,3)) for s in flanges]);ws=[]
 # Fillets at the OUTSIDE of shell skin; midpoint fillets clipped to the actual split flange.
 for z,sign in [(0,-1),(-83,1)]:
  paths=[((35,38,z),(-1,0,0),(0,0,sign),(0,1,0),H),((671,38,z),(1,0,0),(0,0,sign),(0,1,0),H),((35,35,z),(0,-1,0),(0,0,sign),(1,0,0),636),((35,H+41,z),(0,1,0),(0,0,sign),(1,0,0),636)]
  for i,(p,u,v,n,L) in enumerate(paths):
   # Construct explicit triangle vertices, avoiding implicit plane orientation flips.
   vv=[b.vec(p),b.vec(tuple(p[j]+u[j]*2*math.sqrt(2) for j in range(3))),b.vec(tuple(p[j]+v[j]*2*math.sqrt(2) for j in range(3)))];wire=b.cq.Wire.makePolygon(vv+[vv[0]]);w=b.cq.Solid.extrudeLinear(wire,[],b.vec(tuple(x*L for x in n)))
   if z==-83:w=w.intersect(mask)
   if w.Volume()>1e-5:
    w=w.cut(metal);ws.append(w);routes.append(dict(assembly=pn,seam=f'{"PORT" if z==0 else "SPLIT"}_{i+1}',start=list(p),direction=list(n),nominal_length=L,throat_mm=2,leg_mm=2*math.sqrt(2),scope='continuous where actual flange metal exists; stop/restart at deliberate splits',actual_deposit_volume_mm3=w.Volume()))
 # Four INSIDE longitudinal corner seams join actual inner wall faces.
 for x,sx in [(38,1),(668,-1)]:
  for y,sy in [(38,1),(H+38,-1)]:
   p=(x,y,-81);vv=[b.vec(p),b.vec((x+sx*2.828427,y,-81)),b.vec((x,y+sy*2.828427,-81))];w=b.cq.Solid.extrudeLinear(b.cq.Wire.makePolygon(vv+[vv[0]]),[],b.vec((0,0,79))).cut(metal);ws.append(w);routes.append(dict(assembly=pn,seam=f'CORNER_{x}_{y}',start=list(p),direction=[0,0,1],nominal_length=79,throat_mm=2,leg_mm=2.828427,scope='blend terminal2mm into port/split fillets; actual corner root must pass fit-up inspection',actual_deposit_volume_mm3=w.Volume()))
 out[pn]=dict(welds=[dict(id=f'{pn}_W{i+1}',brep=b.brep(w),bbox=b.ex.bb(w),volume=w.Volume()) for i,w in enumerate(ws)],source='R18 explicit nominal weld material; no strength or pressure qualification')
 rows=[dict(definition=f'{pn}_W{i+1}',occurrence=f'{pn}_W{i+1}',scope='P') for i in range(len(ws))];b.ex.export_step(pn+'_R18_WELD_MATERIAL',rows,{q['definition']:w for q,w in zip(rows,ws)})
b.dump(N/'R18_SHELL_WELDS.json',out);b.dump(E/'R18_SHELL_WELD_ROUTES.json',routes);print('SHELL WELDS',len(routes),flush=True)
