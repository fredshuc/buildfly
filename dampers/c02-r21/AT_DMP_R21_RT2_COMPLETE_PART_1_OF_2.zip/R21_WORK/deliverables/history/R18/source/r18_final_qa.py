import json,hashlib,collections
import ezdxf
import build_c02 as b
E=b.OUT/'evidence';N=b.OUT/'native';P={p['pn']:p for p in json.loads((N/'R18_PARTS.json').read_text())}
s=b.ex.readshape(P['G903_R18']['brep']);fa=max([f for f in s.Faces() if f.geomType()=='PLANE' and abs(f.normalAt().y)>.999],key=lambda f:f.Area());fa=fa.rotate((0,0,0),(1,0,0),-90);fa=fa.translate((0,0,-fa.Center().z));path=b.OUT/'dxf/G903_R18_XZ.dxf';b.cq.exporters.export(b.cq.Workplane('XY').newObject(fa.Wires()),str(path));idx=json.loads((E/'R18_DXF_INDEX.json').read_text());idx.append(dict(PN='G903_R18',file=path.name,scope='2D XZ outline: DXFX=partX,DXFY=partZ;3mm thickness andhole definitions onprimarysheet'));b.dump(E/'R18_DXF_INDEX.json',idx)
checks=[]
for f in sorted((b.OUT/'step').rglob('*.stp')):
 recs=[r for r in E.rglob('*READBACK.json') if json.loads(r.read_text()).get('file')==f.name]
 if len(recs)!=1:raise ValueError((f,len(recs)))
 d=json.loads(recs[0].read_text());sha=hashlib.sha256(f.read_bytes()).hexdigest()
 if not d['all_pass'] or d['sha256']!=sha or not all(q['pass_'] for q in d['checks']):raise ValueError(f)
 checks.append(dict(file=str(f.relative_to(b.OUT)),bytes=f.stat().st_size,sha256=sha,occurrences=d['occurrences'],readback_pass=True))
b.dump(E/'R18_STEP_READBACK_INDEX.json',checks)
dxf=[]
for f in sorted((b.OUT/'dxf').glob('*.dxf')):
 d=ezdxf.readfile(f);a=d.audit();dxf.append(dict(file=f.name,entities=len(d.modelspace()),units=d.units,errors=len(a.errors),fixes=len(a.fixes)))
 if a.errors or a.fixes or d.units!=4:raise ValueError(dxf[-1])
b.dump(E/'R18_DXF_AUDIT.json',dxf)
orig={p['pn']:p for p in json.loads((b.ROOT.parent/'R17_WORK/deliverables/native/R17_PARTS.json').read_text())};changed=[k for k in orig if orig[k]['brep']!=P[k]['brep']];added=[k for k in P if k not in orig];oc=[]
for t in ['P','R']:
 old=json.loads((b.ROOT.parent/f'R17_WORK/deliverables/native/R17_{t}_OCCURRENCES.json').read_text());new=json.loads((N/f'R18_{t}_OCCURRENCES.json').read_text());d=[dict(old=a['pn'],new=c['pn'],instance=a['occurrence']) for a,c in zip(old,new) if a!=c];oc.append(dict(config=t,old_count=len(old),new_count=len(new),changes=d))
b.dump(E/'R18_NATIVE_DELTA.json',dict(original_count=len(orig),new_count=len(P),original_BRep_changes=changed,new_definitions=added,occurrences=oc))
if changed:raise ValueError(changed)
print('STEP',len(checks),'DXF',len(dxf),'DELTA',oc,flush=True)
