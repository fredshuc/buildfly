import json,zipfile,hashlib,collections
from pathlib import Path
r=Path.cwd();p=json.loads((r/'R17_WORK/deliverables/native/R17_PARTS.json').read_text());pm={q['pn']:q for q in p}
with zipfile.ZipFile(r/'R18_INPUT/AT_DMP_R17_L1_RELEASE_AND_R18_ORDER_20261012.zip') as z:
 assert z.testzip() is None
 m=json.loads(z.read('FILE_MANIFEST.json'))
 for e in m:
  x=z.read(e['path']);assert len(x)==e['bytes'] and hashlib.sha256(x).hexdigest()==e['sha256']
 print('INPUT VERIFIED',len(z.namelist()),len(m))
w1=list(__import__('csv').DictReader((r/'R17_WORK/deliverables/tables/R17_W1_DISPOSITION.csv').open(encoding='utf-8-sig')))
names=[x['PN'] for x in w1 if x['disposition'].startswith('REMAINING')]+['B200_R13','B202_R13','B201','P100F','P100B','R100F','R100B','R100S']
records=[{k:v for k,v in pm[n].items() if k!='brep'} for n in names if n in pm]
(r/'R18_WORK/BASELINE_FEATURES.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
for n in ['B200_R13','B202_R13','B201','P100F','P100B','R100F','R100B','R100S']:
 print(n,json.dumps({k:v for k,v in pm[n].items() if k!='brep'},ensure_ascii=False))
