import json,math
import build_c02 as b
E=b.OUT/'evidence';rows=[]
for tag in ['P','R']:
 d=json.loads((E/f'R17_{tag}_DELTA_0.json').read_text());accepted=[];unapproved=[]
 for q in d['hits']:
  a,c=q['PN'];v=q['mm3'];reason=None;expected=None
  if a=='TF909' and c in ['H14_M8X30','H14_M5X10']:
   expected=228.75849385 if c=='H14_M8X30' else 40.46393462
   reason='Inherited exact frontpost tapping/major-diameter proxy, both members moved45.5; exact instance and bounds recorded.'
  elif a=='H14_M4X12' and c=='H14_N4':expected=12.84345024;reason='Inherited exact spareport M4nut threadproxy, both members moved45.5.'
  elif a in ['TF920P','TF920R'] and c=='H17_M10X45':expected=math.pi/4*(10**2-8.5**2)*20;reason='Explicit M10-6H through tapped engagement Z1468..1488; no clearance/bodycontact exemption.'
  elif a=='TF925' and c=='H17_M8X35':expected=math.pi/4*(8**2-6.8**2)*12;reason='Explicit upper tie M8-6H engaged Z1456..1468; boltfromabove receiver.'
  if reason and abs(v-expected)<.01:q.update(classification='REGISTERED_THREAD_PROXY',reason=reason,expected_mm3=expected);accepted.append(q)
  else:unapproved.append(q)
 rows.append(dict(config=tag,raw_pairs=len(d['hits']),registered=accepted,unapproved=unapproved,unapproved_count=len(unapproved)))
b.dump(E/'R17_EXPLICIT_CONTACT_REGISTER.json',rows);print([(q['config'],q['raw_pairs'],q['unapproved_count']) for q in rows])

