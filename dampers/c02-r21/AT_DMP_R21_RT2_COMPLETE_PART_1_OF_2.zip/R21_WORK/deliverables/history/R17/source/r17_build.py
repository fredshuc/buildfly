import json,copy,collections,math
import numpy as np
import build_c02 as b
ROOT=b.ROOT.parent; N=b.OUT/'native'; E=b.OUT/'evidence'
def read(p):return json.loads((ROOT/p).read_text())
pm={p['pn']:p for p in read('R16_WORK/deliverables/native/R16_PARTS.json')}; S={p:b.ex.readshape(q['brep']) for p,q in pm.items()};changed=[]
def put(pn,name,s,notes,material='S355JR certified minimum yield345MPa',kind='MAKE',features=None):
 if not s.isValid() or len(s.Solids())!=1:raise ValueError((pn,s.isValid(),len(s.Solids())))
 pm[pn]=dict(pn=pn,name=name,kind=kind,material=material,revision='R17',group='fixture',status='P1_FABRICATION_CANDIDATE_NOT_RELEASED',brep=b.brep(s),bbox=b.ex.bb(s),volume_mm3=s.Volume(),notes=notes,features=features or []);S[pn]=s;changed.append(pn)
# Manufacture the arm at +Y with the keyseat still at +Y: one keyseat, not an instance-only rotation.
s=b.cyl(60,46,(0,0,128)).cut(b.cyl(30.03,46.2,(0,0,127.9)))
s=s.fuse(b.cyl(60,3,(0,0,174)).cut(b.cyl(9,3.2,(0,0,173.9))))
s=s.fuse(b.box(20,80,16).translate((-10,0,140)))
s=s.cut(b.cyl(30.03,46.2,(0,0,127.9)))
s=s.cut(b.box(8.05,7.35,34).translate((-4.025,11,131)))
put('D886','P2 stop hub - single corrected keyway',s,['NEW PART ONLY. 42CrMo4+QT certified Rp0.2>=650MPa. Datum A bore30.030+0.020/0,Ra1.6,Z128..174; datum B seating planeZ128 flat0.02. OD60 +/-0.1. EndwebZ174..177, axial9THRU. Face distances +/-0.03.', 'Arm20 wide X-10..10,Y0..80,Z140..156. Arm centreline and keyway centreplane are BOTH +Y at valve zero; relative angle0 +/-0.10deg. Shaft key/gear/leaf phase unchanged. One8.05+0.03/0 keyway X+/-4.025,Y11..18.35,Z131..165; roof18.35+/-0.03. Deburr0.2, no sharp transition to bore.', 'With P2 motion -90deg arm becomes +X. High TF900 stop is CLOSED; low stop OPEN. Endfaces Ra1.6,parallel0.03. OldD886 not reworked by this drawing; second-slot design and actual-part inspection absent. Mark R17 P2 and zero arrow.'],material='42CrMo4+QT Rp0.2>=650MPa')
side=S['G900'].intersect(b.box(5,230,1040.5).translate((-1,-1,45.5)))
for yy in [40,200]:side=side.cut(b.cyl(5.5,5,(-1,yy,55.5),(1,0,0)))
put('G900','Shortened side guard R17',side,['S235JR3 sheet. Retained local coordinates X0..3,Y0..225,Z45.5..1086; finished length1040.5 +/-0.2. Wet end trimmed45.5 from OLD Z0 datum. Four5.5+0.2/0 THRU X atY40/200,Z55.5/1076. Holelocations +/-0.1.', 'Original notches atZ122..154 and392..424,Y0..22 retained. New manufacture uses this outline. For existing conforming R14 sheet: identify revision, trim45.5 from old wet end, drill two new front holes; old front holes removed entirely. Inspect edges and dimensions; no freehand grinding. Other hole coordinates unchanged. Cold contact guard only.'],material='S235JR')
deck=S['TF903']
for x in [-135,315]:deck=deck.cut(b.cyl(9,14,(x,-168,-157.5),(0,1,0)))
put('TF903','Test deck R17 front post interface',deck,pm['TF903']['notes']+['R17 ADD two9+0.2/0THRU Y atX-135/315,Z-157.5,loc+/-0.1. Oldfront holesZ-203 RETAIN for TF925 wet-table tie feet with M8 throughbolts; no open-hole claim. Old rearZ863 unchanged. New/front/oldcentre separation45.5,clear ligament36.5. All unaffectedR14 machining remains. Existing part: inspect actual hole pattern before drilling; spotface tied pads after welding.'])
# Top panel remains its old envelope; relocate its two front holes. Old holes retained as small unqualified guard openings.
top=S['G903']
for x in [-135,315]:top=top.cut(b.cyl(5.5,5,(x,-1,-157.5),(0,1,0)))
put('G903','Top guard R17 front fixing holes',top,pm['G903']['notes']+['R17 twoADDED5.5THRU atX-135/315,Z-157.5. Retainoldfront5.5holesZ-203; inspection apertures remain, no reach qualification. Front overhang45.5 remains above shiftedG901; no material overlap. Existing part rework by drilling only, retain marking R14/R17.'],material='S235JR')
# Common receiver support frame: keep real flow windows and every original flange screw accessible.
all_access=[]
for tag,pn,outer in [('P','TF920P','P107B'),('R','TF920R','R107')]:
 xmax=173 if tag=='P' else 8
 s=b.box(501,765,20).translate((-250,-790,1468)).cut(b.box(xmax+176,634,22).translate((-174,-725,1467)))
 # Match holes from actual transformed receiver, in global TEST coordinates.
 q=next(x for x in read(f'R16_WORK/deliverables/native/R16_{tag}_OCCURRENCES.json') if x['pn']==outer)
 rot=np.array([[0,0,-1],[0,1,0],[1,0,0]]) if tag=='P' else np.eye(3); off=np.array([1451,0,2022]) if tag=='P' else np.zeros(3)
 rr=rot@np.array([q['u'],q['v'],q['n']]).T;oo=rot@np.array(q['o'])+off;holes=[]
 for f in pm[outer]['features']:
  if f['type']=='hole':
   xyz=oo+rr@np.array([f['x'],f['y'],0]);holes.append([float(xyz[0]),float(xyz[1]),24]);s=s.cut(b.cyl(24,22,(xyz[0],xyz[1],1467)))
 # Front R feedback base clearance; its old product root receives no structural credit.
 all_access+=holes
 if tag=='R':s=s.cut(b.box(244,68,22).translate((-204,-93,1467)))
 else:s=s.cut(b.box(371,31,22).translate((-185,-56,1467)))
 clampxs=[-230,231 if tag=='P' else 66]
 for x in clampxs:
  for y in [-650,-450,-250,-120]:s=s.cut(b.cyl(8.5,22,(x,y,1467)))
 for x in [-230,231]:
  for y in [-400,-180]:s=s.cut(b.cyl(11,22,(x,y,1467)))
 for x in [-219,231]:s=s.cut(b.cyl(9,22,(x,-742,1467)))
 notes=[f'Global TEST datums used for this fixture only. S355JR20 plate X-250..251,Y-790..-25,Z1468..1488. Flowwindow X-172..{xmax},Y-723..-93. FaceZ1488 flat0.08; selectedtopheight1488.00 +/-0.05 afterlevel/shim; finalrelative shaft alignment by indicators.', 'Original flange fasteners retained:24+0.2/0THRU at exact coordinates in HOLE_TABLE; these are access pockets, not new product holes. Eight M10-6H THRU clamp holes, drill8.5; clamp centres given inHOLE_TABLE. Four11THRU mounting holes to frame X-230/231,Y-600/-100. Holeloc+/-0.10,outline+/-0.3; edges0.5.', 'P107B/R107 real3mmframe supported on actualremainingmetal, not idealrigidplate. No support credit across24mmaccessholes. Clamp eight outerflange edges withTF924 andM10; preserve static seals. Cold dimensional assembly candidate, no pressure/torque qualification.', 'R only: underside pocket X-203..39,Y-92..-42,depth15 frombottom, leaving5mm nominal; twoTHRU uprightreliefs X-184..-154 and-10..20,Y-55..-42. This front strip is NOT loadcredited. G843 remainsunreleased; feedback root qualification remainsHOLD.' if tag=='R' else 'P107B preserved; P107 upperreceiver/unknownhost remain product-interfaceHOLD. Newtestfixture doesnotqualify finalinstallationgravity.']
 notes[0]=notes[0].replace(f'X-172..{xmax},Y-723..-93',f'X-174..{xmax+2},Y-725..-91')
 notes[1]=notes[1].replace('Y-600/-100','Y-400/-180')+' TwoM8-6HTHRUtieholesX-217/233,Y-742. AssemblyTF925upperbolts effective11.4mm.'
 notes[3]='Feedback underside clearance is THRU, no thinbridge loadcredit: '+('X-204..40,Y-93..-25.' if tag=='R' else 'X-185..186,Y-56..-25.')+' Originalreceiverretained, nochange toproductstaticseal. FeedbackrootHOLD remains.'
 put(pn,tag+' interchangeable wet receiver',s,notes,features=[dict(type='hole_table',holes=holes),dict(type='clamp_taps',x=clampxs,y=[-650,-450,-250,-120])])
def rhs(pn,L):
 s=b.box(80,80,L).cut(b.box(70,70,L+2).translate((5,5,-1)))
 put(pn,'Wet support RHS80x80x5 L'+str(L),s,[f'EN10219S355JRH RHS80x80x5,L{L}+/-0.5. Endsquare0.3. Weldassemblya5continuousaccessibleperimeter, balancedsequence. Measure/finishreceiver padsafterweld. No liftingbyopenRHS. NominalsharpCADcorners; actualmillradii mustclearadjacentparts.'],material='S355JRH RHS80x80x5')
rhs('TF921',715);rhs('TF922',632);rhs('TF923',341)
toe=b.box(45,40,10).fuse(b.box(10,40,8).translate((35,0,-8))).cut(b.cyl(11,12,(30,20,-1)))
put('TF924','Flange edge clamp with integral heel',toe,['S355JR machinedonepiece45x40x18 envelope. TopplateZ0..10;integralheelX35..45,Z-8..0. 11THRUat(30,20),loc+/-0.1. ToeX0..10 contacts outer10mmof assembledflange stack. HeelrestsTF920Z1488, toeZ1496; measured8.00 +/-0.03step. Lowerfacesparallel0.05,Ra3.2;roundededges0.3. Eight pertest. UseM10x45class8.8+2mmwasher intoTF920THRUtap; nominalcompleteengagement18mm. Firstseat1Nm only; finalclampforce/test preload notauthorized. No removaluntilvalve independentlysupported.'])
tie=b.box(50,70,12).fuse(b.box(50,8,28).translate((0,60,12))).fuse(b.box(50,30,12).translate((0,38,28))).cut(b.cyl(9,14,(25,22.5,-1))).cut(b.cyl(6.8,14,(23,48,27)))
put('TF925','Dry deck to wet receiver tie bracket',tie,['S355JR onepiece machinedC-cleat50wide:footY0..70,Z0..12;uprightY60..68,Z12..40;upperflangeY38..68,Z28..40. 9THRUZ atX25,Y22.5foot andY48upper. General+/-0.1,top/bottomparallel0.05. Origins(-242,-790,1428),(208,-790,1428). ExistingTF903oldfront9holes reused.', 'FootM8x45class8.8+washerbothsides+8mmnutbelowdeck. UpperM8x25+1.6washerinstalledfrombelow intoTF920M8THRU,11.4mm nominalengagement. Boltup onlyafterlevel/shimming; no forciblydrawingmisaligneddecks. Quantifyloadsplitbymeasurement; no rigidjointassumption.'])
# RHS sleeved throughfixings. Left/right rail supplied as separate drilling variants.
for pn,x0 in [('TF921L',-250),('TF921R',171)]:
 rail=S['TF921']
 for yy in [-400,-180]:rail=rail.cut(b.cyl(20,82,((-230 if x0<0 else 231)-x0,-1,5-yy),(0,1,0)))
 for xx,yy,dd in all_access:
  if x0-12<xx<x0+92 and -722<yy<17:rail=rail.cut(b.cyl(24,10,(xx-x0,72,5-yy),(0,1,0)))
 for yy in [-650,-450,-250,-120]:rail=rail.cut(b.cyl(12,7,((20 if x0<0 else 60),74,5-yy),(0,1,0)))
 put(pn,'Drilled wet support rail '+pn[-1],rail,pm['TF921']['notes']+[f'LocalX0..80,Y0..80,Z0..715. Two20THRUY atX{20 if x0<0 else 60},Z185/405 forTF927sleeves. Topaccesspockets24 per exactHOLE_TABLEglobalprojection,depth8 fromtop; preservebottomwall. Four12clearanceholes inTOPwallonly atsameX,Z125/255/455/655 forclamptips. STEP definespockets; drawingtablemandatory.'],features=[dict(type='access_world',holes=all_access,origin_x=x0,origin_y=5)])
cross=S['TF923']
for xx,yy,dd in all_access:
 if -182<xx<183 and -87<yy<17:cross=cross.cut(b.cyl(24,10,(yy+75,72,xx+170),(0,1,0)))
put('TF923','Wet support front crossbeam pocketed',cross,pm['TF923']['notes']+['Top24accesspockets depth8 for retained originalflangeboltheads. LocalX=globalY+75,localZ=globalX+170. Holecentres per receiverflangehole table; no undersideholes.'])
put('TF927','RHS fixing compression sleeve',b.cyl(20,80).cut(b.cyl(11,82,(0,0,-1))),['S355JR OD20-0.05/0,ID11+0.2/0,L80.00+/-0.03; endsparallel0.03. FitthroughRHS20holes,flushbothfaces; a3circumferentialfillet bothends, dressbearingfaceflushwithoutundercut. Four perframe. No5mmwallthreadcredit.'])
# Stock positive edge stops below receiver define horizontal location without friction credit.
stop=b.box(20,60,40)
put('TF926','Receiver horizontal locator block',stop,['S355JR20x60x40,outline+/-0.1. Weldtoframeonouterreceiveredge witha4two60mmlongfillets. Measured0.10..0.30 clearance toreceiver; no pullingalignmentwithbolts. Four blocksinstalled.'])
def bolt(pn,d,L,hd,hh):
 s=b.cyl(d,L,(0,0,-L)).fuse(b.cyl(hd,hh));s=s.cut(b.cq.Workplane('XY').polygon(6,(8 if d==10 else 6)/math.cos(math.pi/6)).extrude(hh*.65).val().translate((0,0,hh*.35)))
 put(pn,f'ISO4762 M{d}x{L}',s,[f'Purchased ISO4762M{d}x{L},class8.8,fullthread. Head{hd}x{hh}; checkthreadlengthandactualcertificate. Threadmajorcylinderproxy; notmodeledhelicalcontact.'],material='Class8.8',kind='BUY')
bolt('H17_M10X45',10,45,16,10);bolt('H17_M10X120',10,120,16,10);bolt('H17_M8X45',8,45,13,8);bolt('H17_M8X35',8,35,13,8)
frames={'P':dict(o=[-82,-970.5,1583],u=[1,0,0],v=[0,0,1],n=[0,-1,0]),'R':dict(o=[-82,-970.5,1583],u=[1,0,0],v=[0,0,1],n=[0,-1,0])}; sets={};ret=[]
for tag in ['P','R']:
 O=[];rot=np.array([[0,0,-1],[0,1,0],[1,0,0]]) if tag=='P' else np.eye(3);off=np.array([1451,0,2022]) if tag=='P' else np.zeros(3)
 for q0 in read(f'R16_WORK/deliverables/native/R16_{tag}_OCCURRENCES.json'):
  q=copy.deepcopy(q0)
  if q['pn'] in ['F620','F621','F622','F623']:
   ret.append(dict(config=tag,instance=q['occurrence'],PN=q['pn'],replacement='TF920'+tag+'+TF921/912/913/908+clamps',scope='TEST_ONLY historicalproductcoordinatesunchanged'));continue
  rr=rot@np.array([q['u'],q['v'],q['n']]).T;q.update(o=(rot@np.array(q['o'])+off).tolist(),u=rr[:,0].tolist(),v=rr[:,1].tolist(),n=rr[:,2].tolist(),config=tag+'_TEST_O1PRIME' if tag=='P' else 'R_TEST')
  if q['pn']=='P107B':q['physical_class']='RETAINED_REAL_RECEIVER'
  if q['source']=='R14':
   x,y,z=q['rig_local_origin'];pn=q['pn'];shift=False
   if pn=='G901' or (pn=='TF909' and z<0):shift=True
   if pn=='H14_M5X10' and (abs(z+216)<.01 or abs(z+203)<.01):shift=True
   if pn in ['H14_M8X30','H14_W8'] and abs(z+203)<.01:shift=True
   if pn=='G904' and z<0:shift=True
   if pn in ['H14_M4X12','H14_N4'] and z<0:shift=True
   if shift:q['o'][1]-=45.5;q['rig_local_origin'][2]+=45.5;q['changed_pose']=True
  if q['pn'] in changed:q['revision']='R17';q['part_key']=q['pn']+'@R17'
  O.append(q)
 def add(pn,o=(0,0,0),u=(1,0,0),v=(0,1,0),n=(0,0,1),note=''):
  ident=f'R17_{tag}_{pn}_{sum(a["pn"]==pn for a in O)+1:03d}';O.append(dict(pn=pn,occurrence=ident,o=list(o),u=list(u),v=list(v),n=list(n),source='R17',revision=pm[pn].get('revision','R14'),scope='FIXTURE',physical_class='WET_TEST_SUPPORT',config=tag+'_TEST',moving=None,note=note))
 add('TF920'+tag)
 for x in [-250,171]:
  add('TF921L' if x<0 else 'TF921R',(x,5,1388),u=(1,0,0),v=(0,0,1),n=(0,-1,0))
  for y in [-630,-75]:add('TF922',(x,y,756));add('TF908',(x,y+80,744),u=(1,0,0),v=(0,0,1),n=(0,-1,0))
 # Crossmember at nearendoutsidewindow, belowreceivermaterial.
 add('TF923',(-170,-75,1388),u=(0,1,0),v=(0,0,1),n=(1,0,0))
 # Assemblyweldedframe, four receiverfixings tappingRHS topwall insufficient -> sleeved boss stillHOLD.
 for x in [-230,231]:
  for y in [-400,-180]:add('H17_M10X120',(x,y,1490));add('HW_R13_W10',(x,y,1488));add('TF927',(x,y,1388));add('HW_R13_W10',(x,y,1386));add('HW_N10',(x,y,1376))
 edge=211 if tag=='P' else 46
 for y in [-650,-450,-250,-120]:
  add('TF924',(-200,y+20,1496),u=(-1,0,0),v=(0,-1,0));add('TF924',(edge-10,y-20,1496))
  for x in [-230,edge+20]:add('H17_M10X45',(x,y,1508));add('HW_R13_W10',(x,y,1506))
 for x in [-242,208]:
  add('TF925',(x,-790,1428));add('H17_M8X45',(x+25,-767.5,1441.6));add('H14_W8',(x+25,-767.5,1440));add('H14_W8',(x+25,-767.5,1414.4));add('HW_N8',(x+25,-767.5,1406.4));add('H17_M8X35',(x+23,-742,1489.6));add('H14_W8',(x+23,-742,1488))
 for x in [-270,251]:
  for y in [-550,-150]:add('TF926',(x,y,1448))
 sets[tag]=O;b.dump(N/f'R17_{tag}_OCCURRENCES.json',O)
b.dump(N/'R17_PARTS.json',list(pm.values()));b.dump(N/'R17_COORDINATE_FRAMES.json',frames);b.dump(E/'R17_CHANGED_PN.json',changed);b.cw('R17_FUNCTION_REPLACEMENT.csv',ret)
b.dump(E/'R17_DESIGN_HOLDS.json',['G843no loadcredit; independent feedbackcapture notclosed. Punknownrootunchanged.', 'Fixturefootcontact/loadsplit, clampforce and weldedframecompliance unmeasured; no testqualification.', 'TF900 tallclosedpost flexibility remains a conditional screen, not endpointaccuracyqualification.'])
print('BUILT',len(changed),[(t,len(o)) for t,o in sets.items()],flush=True)


