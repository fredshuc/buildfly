import json
import build_c02 as b
from r17_check import states,broad
from r11_common import volume
ROOT=b.ROOT.parent;O,W=states('P',0);records=[];shapes={}
for q in json.loads((ROOT/'R16_WORK/deliverables/native/R16_P_ROOT_WELD_MATERIAL.json').read_text()):
 s=b.tr(b.ex.readshape(q['brep']),[1451,0,2022],[0,0,1],[0,1,0],[-1,0,0]);hits=[];bb=b.ex.bb(s)
 for a in O:
  if a['source'] not in ['R14','R17']:continue
  ss=W[a['occurrence']]
  if broad(bb,b.ex.bb(ss)):
   v=volume(s,ss)
   if v>.001:hits.append(dict(instance=a['occurrence'],mm3=v))
 shapes[q['pn']]=s;records.append(dict(weld=q['pn'],new_dry_support_hits=hits,source='R16a4depositedrootweld, rigidO1primetransform only',meaning='FormerF620blockerretiredandreplaced; unknownPproducthostnotqualified'))
b.dump(b.OUT/'evidence/R17_ROOT_WELD_RECHECK.json',records);b.dump(b.OUT/'native/R17_P_ROOT_WELD_MATERIAL.json',[dict(pn=k,brep=b.brep(s),bbox=b.ex.bb(s)) for k,s in shapes.items()]);b.ex.export_step('AT_DMP_R17_P_ROOT_WELD_BOUNDARY',[dict(definition=k,occurrence=k,scope='P') for k in shapes],shapes)
b.cw('R17_FACTORY_DATA_RETURN.csv',[dict(item=k,actual_revision='',key_dimensions='',assembly_problem='',raw_measurement_file='',engineering_disposition='',P1_replacement='',P2_change='') for k in ['ECO17_D886_keyphase','ECO17_G900_endholes','ECO17_TF903_TF925_fit','ECO17_G903_clearance','WS17_receiver_flatness','WS17_floor_contact_10feet','WS17_shaft_centre_tilt','WS17_clamp_step_force','WS17_actual_mass_CG','TF900_closed_endpoint_deflection','W1_01_material_dimensions','G843_feedback_capture_HOLD']])
print('ROOT',len(records),'newhits',sum(len(x['new_dry_support_hits']) for x in records))
