import json,sys,itertools,math
import numpy as np
import build_c02 as b
from r17_check import states,broad,is_rotating
from r11_common import volume
tag=sys.argv[1];E=b.OUT/'evidence';O,W0=states(tag,0);B0={k:b.ex.bb(s) for k,s in W0.items()};om={q['occurrence']:q for q in O}
def grp(q):
 if q['source']=='R12' and q.get('moving'):return q['moving']
 if q['source']=='R14' and is_rotating(q):return 'R1' if tag=='R' else 'P1' if q['rig_local_origin'][0]>82.5 else 'P2'
 return 'FIXED'
groups={q['occurrence']:grp(q) for q in O};moving=[q for q in O if groups[q['occurrence']]!='FIXED'];static=[q for q in O if groups[q['occurrence']]=='FIXED'];pairs=[]
for a in moving:
 for c in O:
  if groups[a['occurrence']]==groups[c['occurrence']]:continue
  if groups[c['occurrence']]!='FIXED' and c['occurrence']<a['occurrence']:continue
  # Reuse unchanged wet/wet relationships from the frozen product; all dry/new vs fullobstacles checked.
  if a['source']=='R12' and c['source']=='R12':continue
  pairs.append((a,c))
angles=sorted(set(list(range(0,91,5))+[.1,1,89,89.9]));out=[];baseline={}
for angle in angles:
 _,W=states(tag,angle);BB={k:b.ex.bb(s) for k,s in W.items()};hits=[];tested=0
 for a,c in pairs:
  ka,kc=a['occurrence'],c['occurrence']
  if not broad(BB[ka],BB[kc]):continue
  tested+=1;v=volume(W[ka],W[kc])
  if v<=.001:continue
  key=ka+'|'+kc
  if key not in baseline:baseline[key]=volume(W0[ka],W0[kc]) if broad(B0[ka],B0[kc]) else 0
  old=baseline[key];hits.append(dict(a=ka,b=kc,PN=[a['pn'],c['pn']],mm3=v,baseline_mm3=old,new_or_increased=v>old+.001))
 stop=None
 if tag=='P':
  a=next(q for q in O if q['pn']=='D886');c=next(q for q in O if q['pn']=='TF900');sa=W[a['occurrence']];sc=W[c['occurrence']];stop=dict(volume_mm3=volume(sa,sc),minimum_distance_mm=sa.distance(sc))
 rec=dict(angle_deg=angle,boolean_pairs=tested,hits=hits,new_or_increased=sum(q['new_or_increased'] for q in hits),stop=stop);out.append(rec);b.dump(E/f'R17_{tag}_MOTION.json',dict(config=tag,positions=out,pairs_per_position=len(pairs),scope='23 discrete whole-obstacle positions, <=5deg grid plus nearends; unchanged wet/wet pairs inherited, no continuous/tolerance/load certification'))
 print(tag,angle,'bool',tested,'new',rec['new_or_increased'],'stop',stop,flush=True)
