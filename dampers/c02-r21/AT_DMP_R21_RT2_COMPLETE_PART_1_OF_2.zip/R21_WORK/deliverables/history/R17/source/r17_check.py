import json,math,sys,itertools,collections
import numpy as np
import build_c02 as b
from r11_common import volume
ROOT=b.ROOT.parent;E=b.OUT/'evidence';N=b.OUT/'native'
P=json.loads((N/'R17_PARTS.json').read_text());pm={p['pn']:p for p in P};S={pn:b.ex.readshape(p['brep']) for pn,p in pm.items()}
frames=json.loads((N/'R17_COORDINATE_FRAMES.json').read_text())
axes={'P1':[83,0,1583],'P2':[-82,0,1583],'R1':[-82,0,1583]}
rotating={'D870','D871','D872','D873','D894','D884','D885','D886','D887','D888','D521_R14','D530','D892','D896','H14_PIN5','H14_SPLIT','BUY504','BUY_R13_BK2','BUY520','BUY521','BUY531','HW_R13_M4TIP','H14_M8X25','H14_W8','H14_M6X20'}
def is_rotating(q):
 if q['pn']=='H14_W8':return abs(q['rig_local_origin'][2]-177)<1e-6
 return q['pn'] in rotating
def states(tag,angle):
 O=json.loads((N/f'R17_{tag}_OCCURRENCES.json').read_text());W={}
 for q in O:
  s=b.tr(S[q['pn']],q['o'],q['u'],q['v'],q['n']);a=0;axis=None
  if q['source']=='R12' and q.get('moving'):
   key=q['moving'];axis=axes[key];a=angle*(-1 if key=='P2' else 1)
  if q['source']=='R14' and is_rotating(q):
   x=q['rig_local_origin'][0];key='R1' if tag=='R' else 'P1' if x>82.5 else 'P2';axis=axes[key];a=angle*(-1 if key=='P2' else 1)
  if axis and a:s=s.rotate(axis,[axis[0],-1,axis[2]],a)
  W[q['occurrence']]=s
 return O,W
def broad(a,c):return all(min(a[k+3],c[k+3])-max(a[k],c[k])>1e-5 for k in range(3))
if __name__=='__main__':
 tag=sys.argv[1];output=[]
 for angle in [0,45,90]:
  O,W=states(tag,angle);BB={k:b.ex.bb(s) for k,s in W.items()};dry=[q for q in O if q['source']=='R14'];wet=[q for q in O if q['source']=='R12'];hits=[];tested=0
  for a,c in itertools.product(dry,wet):
   aa,cc=a['occurrence'],c['occurrence']
   if not broad(BB[aa],BB[cc]):continue
   tested+=1;v=volume(W[aa],W[cc])
   if v>.001:hits.append(dict(a=aa,b=cc,PN=[a['pn'],c['pn']],mm3=v,classification='UNAPPROVED_CROSS_BRANCH',bbox=b.ex.bb(W[aa].intersect(W[cc]))))
  # All pairs touching trimmed rotor within retained wet assembly. Existing weld integral solids are one assembly, no child duplicate.
  trim=[]
  for a in wet:
   if a['pn']!='B200_R13':continue
   for c in wet:
    if c is a:continue
    aa,cc=a['occurrence'],c['occurrence']
    if not broad(BB[aa],BB[cc]):continue
    v=volume(W[aa],W[cc])
    if v>.001:trim.append(dict(a=aa,b=cc,PN=[a['pn'],c['pn']],mm3=v,classification='REQUIRES_CONTACT_INTERPRETATION'))
  rec=dict(config=tag,angle_deg=angle,cross_pairs=len(dry)*len(wet),boolean_pairs=tested,cross_hits=hits,trim_hits=trim,scope='All new R14/R12 pairs and actual trimmed rotors at three discrete poses. Internal R14 motion, full continuous sweeps and all inherited wet pairs not recertified.')
  output.append(rec);b.dump(E/f'R17_{tag}_CROSS_BRANCH.json',output);print(tag,angle,'cross',len(hits),'trim',len(trim),flush=True)
  if angle==0:
   b.dump(E/f'R17_{tag}_WORLD_BOUNDS.json',[dict(instance=q['occurrence'],PN=q['pn'],bbox=BB[q['occurrence']],volume=W[q['occurrence']].Volume(),center=W[q['occurrence']].Center().toTuple(),source=q['source']) for q in O])

