from pathlib import Path
import json,csv,hashlib,zipfile,datetime,shutil
R=Path(__file__).resolve().parents[2]; W=R/'R17_WORK'; D=W/'deliverables'; O=W/'delivery'; O.mkdir(exist_ok=True)
now=datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0)
lp=W/'EXECUTION_LEDGER.json'; ledger=json.loads(lp.read_text(encoding='utf-8-sig'))
if ledger['status']=='ACTIVE':
 ledger['engineering_frozen_utc']=now.isoformat().replace('+00:00','Z');ledger['rounds'][-1]['end_utc']=ledger['engineering_frozen_utc'];ledger['status']='ENGINEERING_FROZEN';ledger['actual_iterations']=len(ledger['rounds']);ledger['engineering_minutes']=(now-datetime.datetime.fromisoformat(ledger['t0_utc'].replace('Z','+00:00'))).total_seconds()/60;lp.write_text(json.dumps(ledger,indent=2))
report='''AT-DMP02-MFG-C02-R17 — ENGINEERING RETURN — 12 OCTOBER 2026
PARTIAL / NOT_FOR_MANUFACTURE for the complete valve. Named batches below are P1_FABRICATION_CANDIDATE, NOT L1 RELEASED.

FIRST DECISION: 21 MAKE PN / 224 pieces submitted for loose-piece fabrication review.
ECO17: D886(1), G900(2), TF903(1), G903(1): 4 PN / 5 pieces.
WS17: TF920P(1), TF920R(1), TF921L(1), TF921R(1), TF922(4), TF923(1), TF924(8), TF925(2), TF926(4), TF927(4), TF908(4 additional): 11 PN / 31 pieces.
W1-01: F602(92), F603(58), P104(4), R104(4), S311(10), S313(20): 6 PN / 188 pieces. The other 35 W1 PN are not proposed for release. PTFE free-state/process ambiguities remain isolated.
Quantities use one sequentially shared dry test rig; do not sum P/R configured BOMs as a purchase order. Previously released 111 PN / 359 pieces retain their exact release scope. Factory completion and as-built revisions are unknown. Four new purchased fastener types are defined but not ordered.

READING ORDER
1. This report and the 11-page ENGINEERING_REVIEW_EN.pdf.
2. tables/R17_CANDIDATE_BATCHES.csv and the 29-page FACTORY_CANDIDATES_EN.pdf.
3. Selected part STEP and nine exact-face DXFs; drawings control tolerances, threads, materials and process.
4. Configured P/R assemblies and evidence. Native catalog includes non-active alternatives: never manufacture the entire catalog.
5. Signed R17 source and scripts/provenance in the complete package.

DESIGN AND MANUFACTURING
The entire P assembly is transformed into O1-prime: x=-z+1451, y=y, z=x+2022. P1/P2 retain identity; P2(-82,1583), P1(83,1583), centres 165 mm. R centre(-82,1583); floor Z744. P107B is retained at its real elevation, with no 9 mm shim. F620-F623 are retired only from this test branch after definition of the replacement wet stand and positive clamps/ties.
The wet table uses real 20 mm receiver plates, RHS80x80x5 rails/legs, four additional TF908 feet, compression sleeves, positive edge blocks and two deck ties. There are TEN floor contacts for the combined stand and dry rig. P and R receiver support fractions are 78.5102086% and 68.2956882%; neither is treated as a rigid full-area plane. Original flange screws and seals remain; access holes follow actual screws. New frame weld locations/process are defined, but deposited weld solids for the new frame are not delivered. Six inherited transformed P root weld solids are supplied and checked.
D886 is rebuilt with a single +Y keyseat and +Y arm at valve zero; an instance rotation or a second keyway in the old part is not authorized. Tall TF900 is the CLOSED stop and remains geometrically unchanged. G901 and front TF909 move dryward 45.5 mm without BRep change. G900 is shortened; TF903 gets actual new holes/fasteners. Companion G903 front fixing holes are additionally changed and explicitly included in ECO17. Existing-part rework requires revision and dimensional inspection.
Upper tie screws enter from ABOVE, resolving four blocked underside tool entries. Sleeve bolt protrusion is nominal 6 mm. Detailed machining datums, tolerances, threads and inspection are in the factory PDF. No undocumented hand grinding of key fits, sealing faces, effective threads or capture parts is permitted. Purchased actuator remains a placeholder and contributes no installed mass or qualified safety function.

SAME-REVISION CHECKS
P 1506 / R 1073 active occurrences. Exactly four inherited BReps changed: D886, G900, TF903, G903; 347 other inherited BReps unchanged.
31 STEP files independently read back in fresh processes: 25 individual parts (21 MAKE + 4 BUY), two full assemblies, two wet-support subsets, one six-solid root-weld boundary and one 32-position tool set. Solid validity/counts, bounding boxes and two-way material differences checked. Nine DXFs audited. All 40 PDF pages rendered and visually reviewed.
Scoped nominal static unapproved hard pairs: P0/R0. Raw P22/R24 contacts are individually registered thread-proxy pairs with bounded volumes; there is no blanket PN exemption.
23 discrete angular positions per P/R, including near-end positions, produced no new or increased hard pairs in the stated changed/dry-motion scope. D886/TF900 overlap volume is zero; near-stop gaps at 0.1 and 1 degree are 0.087251 and 0.871097 mm. Thirty-two tool entry positions are clear. These are discrete nominal checks, not continuous swept-volume, tolerance, deformation or physical demonstrations. Inherited wet/wet contact families are not recertified by these checks.

LOADS, LIMITS AND DECISIONS STILL OPEN
Estimated configured masses: P623.574336283508 kg, R592.0782634066783 kg; wet P70.102345583 kg/R41.024176210 kg. Density and purchased proxies are used; not weighed; weld deposit, cables and actuator excluded.
The whole-rig floor free body includes ten feet and wet mass. Normal 78/38 Nm and 200 Nm operator cases are separated; internal reactions are not double-counted. Local 70.74 N/10 Nm interface allocations are not independent whole-rig external loads. Pressure cases 500/1500/2000 Pa remain separate.
At 200 Nm/60 mm the tall stop fixed-root screen gives 3333.33 N, 95.679 MPa nominal, Kt=2 screen191.358 MPa, deflection0.255409808 mm and angle0.243898401 deg. A conservative 50 mm contact-radius/full-height case gives4000 N,0.306491770 mm,0.351213697 deg. Root/floor flexibility is not validated. ENDPOINT_DEFLECTION_HOLD; no 200 Nm operation release.
G903 to P107 nominal gap is only1.0 mm: tolerance/loaded clearance HOLD. Nominal G901 stud gap5.0 mm, BK2 gap5.5 mm and radial gap3 mm are not loaded qualifications.
G1 loaded contact, feedback root/capture (G843 uncredited), receiver flexibility/seal response, actual floor stiffness/anchorage, full maintenance support transfer/capture, hot sealing/preload and pressure operation remain HOLD. No installed or load-ready acceptance is requested. Existing independently released loose-piece scopes are not revoked by the overall HOLD.

FACTORY/TEST RETURN
Use tables/R17_FACTORY_DATA_RETURN.csv: record actual revision/material, critical dimensions, flange bearing/gaps, clamp contact and unbacked spans, tool access, deck ties/foot seating, mass, stop radius/angle, raw measurements and disposition. Begin with separately authorized loose parts and unloaded dimensional fit. Any loading requires a separately approved boundary, independent stop/protection and recorded fixture/floor capability; do not rely on unqualified feedback as the sole protection.

PROVENANCE AND REPRODUCTION
Signed input ZIP:32628 bytes SHA256 6e23a6a69d76e6d5c9969943aa6ada30b9053b96b7b0354eb2d46ac5dca774ab;15 members/14 manifest entries verified.
R16 archive reference:26361962 bytes SHA256 cbfe74c5b1b18c1617e2fe116691417c75029354d77d5ecaa82c368060086c8a. Relevant baseline native data are included in the complete package; prior manufacturing releases remain controlled by their original signed files.
Source dependencies use CadQuery2.8/OCP7.9.3, NumPy/SciPy, reportlab,pypdf,ezdxf and Poppler. Rebuild geometry with r17_build, then r17_specs and r17_manufacturing to apply final shop notes; use the named clearance/contact/motion/tools/statics/root/export/final-QA scripts for scoped checks. Archive layout preserves workspace-relative source dependencies. Runtime binaries are not bundled.
Local ZIP CRC and per-member SHA256/size verification establish this local delivery. Library upload UI confirmation will be recorded separately; no remote download/re-hash or L1 engineering acceptance is claimed.
User directly authorized R17-R21 continuation: after formal R17 return, schedule one R18 claim at completion+40 minutes; do not reread L1 during this order. Stop after R21.
'''
report+=f"\nCLOCK: T0 {ledger['t0_utc']}; engineering frozen {ledger['engineering_frozen_utc']}; {ledger['actual_iterations']} iterations; engineering {ledger['engineering_minutes']:.6f} minutes. Formal return completion is recorded separately after successful transmission.\n"
(D/'RETURN_REPORT_EN.txt').write_text(report,encoding='utf-8')
(D/'00_START_R17_EN.txt').write_text('Read RETURN_REPORT_EN.txt first. Candidate fabrication only, not a release. Complete C02 PARTIAL / NOT_FOR_MANUFACTURE. Use named candidate quantities, never the whole native catalog or sum of P/R BOMs.\n',encoding='utf-8')
rows=list(csv.DictReader((D/'tables/R17_CANDIDATE_BATCHES.csv').open(encoding='utf-8-sig')))
def sha(x):return hashlib.sha256(x).hexdigest()
def pack(name,files):
 entries={name:p.read_bytes() for name,p in files}; manifest=[{'path':n,'size':len(x),'sha256':sha(x)} for n,x in sorted(entries.items())]
 entries['MANIFEST_SHA256.json']=json.dumps(manifest,indent=2).encode(); out=O/name
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n,x in sorted(entries.items()):z.writestr(n,x)
 with zipfile.ZipFile(out) as z:
  assert z.testzip() is None
  for m in json.loads(z.read('MANIFEST_SHA256.json')):
   x=z.read(m['path']);assert len(x)==m['size'] and sha(x)==m['sha256']
 return {'file':str(out),'bytes':out.stat().st_size,'sha256':sha(out.read_bytes()),'members':len(entries),'manifest_entries':len(manifest),'CRC_and_manifest':'PASS'}
factory=[(p.relative_to(D).as_posix(),p) for p in D.rglob('*') if p.is_file() and (p.suffix=='.txt' or p.parent.name in ['tables','dxf','parts','purchase'] or p.name=='AT_DMP_R17_FACTORY_CANDIDATES_EN.pdf')]
receipts=[pack('AT_DMP_P1_R17_ECO_WS_W1_FACTORY_CANDIDATES_20261012.zip',factory)]
full=[(p.relative_to(R).as_posix(),p) for base in [D,W/'source',R/'R17_INPUT'] for p in base.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ['.pyc']]
full.append((lp.relative_to(R).as_posix(),lp))
for rel in ['R16_WORK/deliverables/native/R16_PARTS.json','R16_WORK/deliverables/native/R16_P_OCCURRENCES.json','R16_WORK/deliverables/native/R16_R_OCCURRENCES.json','R16_WORK/deliverables/native/R16_P_ROOT_WELD_MATERIAL.json','R16_WORK/deliverables/tables/R16_CONFIGURED_MANUFACTURING_GAPS.csv','R14_WORK/deliverables/evidence/R14_MASS_AND_FLOOR.json']:
 p=R/rel
 if not p.exists():raise FileNotFoundError(p)
 full.append((rel,p))
receipts.append(pack('AT_DMP02_C02_R17_ENGINEERING_RETURN_20261012.zip',full))
for p in [D/'RETURN_REPORT_EN.txt',*D.glob('drawings/*.pdf')]:shutil.copy2(p,O/p.name)
(O/'LOCAL_RECEIPT.json').write_text(json.dumps({'packages':receipts,'engineering':ledger,'remote_verification':'NOT_PERFORMED'},indent=2))
print(json.dumps(receipts,indent=2))
