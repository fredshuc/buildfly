import json,math,html,csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import HexColor
import build_c02 as b
from r17_check import pm,S,states
DR=b.OUT/'drawings';E=b.OUT/'evidence';rows=json.loads((E/'R17_CANDIDATES.json').read_text());W,H=1190,842;page=0
def lines(s,axes):
 out=[]
 for e in s.Edges():
  pts=[e.positionAt(float(t)).toTuple() for t in np.linspace(0,1,2 if e.geomType()=='LINE' else 65)];out.append([(p[axes[0]],p[axes[1]]) for p in pts])
 return out
def view(pn):
 s=S[pn];bb=b.ex.bb(s);fig,axs=plt.subplots(1,3,figsize=(14,4.1))
 for ax,ab in zip(axs,[(0,1),(0,2),(1,2)]):
  ax.add_collection(LineCollection(lines(s,ab),colors='#153c50',linewidths=.7));ax.autoscale();ax.set_aspect('equal',adjustable='datalim');a,c=ab
  ax.set_xlabel('XYZ'[a]+' / mm');ax.set_ylabel('XYZ'[c]+' / mm');ax.set_title('XYZ'[a]+'-'+'XYZ'[c]+' projection');ax.grid(alpha=.2)
  ax.text(.02,.98,f'{bb[a]:.3f} .. {bb[a+3]:.3f}\n{bb[c]:.3f} .. {bb[c+3]:.3f}',transform=ax.transAxes,va='top',fontsize=8,bbox=dict(facecolor='white',alpha=.9,edgecolor='none'))
 fig.suptitle(pn+' / actual BRep orthographic edges / coordinates in mm');fig.tight_layout();fig.savefig(DR/f'{pn}_VIEWS.png',dpi=150);plt.close(fig)
def head(title,sub):
 global page,y
 page+=1;c.setFillColor(HexColor('#123749'));c.rect(0,H-90,W,90,fill=1,stroke=0);c.setFillColorRGB(1,1,1);c.setFont('Helvetica-Bold',23);c.drawString(40,H-40,title);c.setFont('Helvetica',11);c.drawString(40,H-65,sub);y=H-115
def para(txt,size=12):
 global y
 st=ParagraphStyle('p',fontName='Helvetica',fontSize=size,leading=size*1.35);p=Paragraph(html.escape(txt),st);ww,hh=p.wrap(W-80,700)
 if y-hh<55:raise ValueError(('overflow',page,txt[:45],y,hh))
 p.drawOn(c,40,y-hh);y-=hh+10
def table(rr,widths,size=11):
 global y
 st=ParagraphStyle('t',fontSize=size,leading=size*1.25);cells=[[Paragraph(html.escape(str(v)),st) for v in row] for row in rr];t=Table(cells,colWidths=widths);t.setStyle(TableStyle([('GRID',(0,0),(-1,-1),.3,HexColor('#b8c7ce')),('BACKGROUND',(0,0),(-1,0),HexColor('#deebef')),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]));ww,hh=t.wrap(1110,700)
 if y-hh<55:raise ValueError(('tableoverflow',page,y,hh))
 t.drawOn(c,40,y-hh);y-=hh+12
def end():
 c.setFont('Helvetica',10);c.setFillColor(HexColor('#4b5f68'));c.drawString(40,28,'R17 / P1 FABRICATION CANDIDATE - L1 release required. No loaded, pressure or hot test authorization.');c.drawRightString(W-40,28,str(page));c.showPage()
c=canvas.Canvas(str(DR/'AT_DMP_R17_FACTORY_CANDIDATES_EN.pdf'),pagesize=(W,H))
head('R17 / Named loose-part manufacturing candidates','AirTransformer AT-DMP02 C02 / 12 October 2026 / metric / drawing dimensions take precedence over scaling')
para('21 PN / 224 pieces are submitted: ECO17 revised interfaces, WS17 wet support loose parts and W1-01 six stable PN / 188 pieces. This is a review candidate, not a factory order. Existing parts and signed release scopes remain; manufacture and arrival are UNCONFIRMED.')
table([['Batch','PN / pieces','Manufacturing boundary'],['ECO17','D886 x1; G900 x2; TF903 x1; G903 x1','D886 new manufacture only. Explicit trimming/drilling instructions for the other three parts. Existing D886 remains held.'],['WS17','11 PN /31 pieces','Wet support, interchangeable receivers and four additional feet. Existing dry frame is reused sequentially; no duplicate six-foot order. Welded assembly/load testing requires separate acceptance.'],['W1-01','F602 x92; F603 x58; P104 x4; R104 x4; S311 x10; S313 x20','Loose blanks, spacers and covers only. No welded shell or rotor assembly and no seal performance acceptance.']],[180,410,520],12)
para('References: one native part record, one AP242 part STEP and the sheet for each PN. STEP threaded cylinders are manufacturing envelopes; thread class, complete engagement and gauges on the drawing govern. Tool pockets and through windows are real cut geometry. Product and test datums are separate.')
para('Dimensional acceptance: inspect material certificates, critical face/step sizes and every new hole coordinate; dry fit without forcing or undocumented grinding. Record actual revision, key phase, stop zero, flange stack height, floor contact and part measurements. No substitution of G843 root acceptance or feedback as a safety channel.');end()
for q in rows:
 pn=q['PN'];p=pm[pn];view(pn);head(pn+' / '+p['name'],f"Revision {q['revision']} / process {q['process_revision']} / quantity {q['quantity']} / {q['batch']} / {p['material']}")
 c.drawImage(str(DR/f'{pn}_VIEWS.png'),40,y-320,width=1110,height=320,preserveAspectRatio=True,anchor='c');y-=332
 for note in p['notes']:para(note,11)
 para('All dimensions mm. Do not scale. Inspect to stated tolerances; unspecified noncritical edges +/-0.2 for machined parts and +/-0.3 for sheet. Contact faces and functional bore/thread specifications above override. Single authoritative geometry: '+pn+'_R17.stp.',10);end()
 # Exact full receiver hole list; accessholes are actual pockets, not copiednominalringarea.
 if pn in ['TF920P','TF920R']:
  holes=next(f['holes'] for f in p['features'] if f['type']=='hole_table');head(pn+' / Access-hole coordinate table','TEST global X/Y; diameter24 THROUGH20; position +/-0.10; original receiver holes remain unchanged')
  rr=[['No.','X','Y','No.','X','Y']]
  for i in range(0,len(holes),2):
   vals=[]
   for j in [i,i+1]:vals+=([j+1,f'{holes[j][0]:.6f}',f'{holes[j][1]:.6f}'] if j<len(holes) else['','',''])
   rr.append(vals)
  table(rr,[60,200,200,60,200,200],10);end()
 if pn in ['TF921L','TF921R','TF923']:
  allholes=[]
  for pp in ['TF920P','TF920R']:allholes+=next(f['holes'] for f in pm[pp]['features'] if f['type']=='hole_table')
  unique=set();local=[];x0=-250 if pn=='TF921L' else 171
  for x,y,dd in allholes:
   if pn=='TF923':ok=-182<x<183 and -87<y<17;xx=y+75;zz=x+170
   else:ok=x0-12<x<x0+92 and -722<y<17;xx=x-x0;zz=5-y
   if ok and (round(xx,6),round(zz,6)) not in unique:unique.add((round(xx,6),round(zz,6)));local.append((xx,zz))
  head(pn+' / Retained fastener access pockets','Local X/Z; diameter24 depth8 from TOP localY80, cutY72..80. Edge breakout is intentional.')
  rr=[['No.','Local X','Local Z','No.','Local X','Local Z']]
  for i in range(0,len(local),2):
   vals=[]
   for j in [i,i+1]:vals+=([j+1,f'{local[j][0]:.6f}',f'{local[j][1]:.6f}'] if j<len(local) else['','',''])
   rr.append(vals)
  table(rr,[60,200,200,60,200,200],10);para('Other sleeve and clamp-tip holes are on the primary sheet. Access pockets do not create any new hole in the valve or its static seal.',11);end()
 if pn=='TF903':
  head('TF903 / Complete drilling schedule','All holes THROUGH localY; coordinates refer to unchanged R14 deck origin; R17 additions identified')
  table([['Diameter','X positions','Z positions','Function'],['17','-145,310','-75,195','Common support mount (4)'],['17','-75,275','300,500,700,960','Input rail (8)'],['32','-110,275','-35,155,190','Nut tool access (6)'],['28','-65,82.5,230','-15,99.5','Support foot tools (6)'],['14','-27,27,138,192','12,83','Service access (8)'],['9','-135,315','-203,863','Old front tie / unchanged rear guard (4)'],['9 NEW','-135,315','-157.5','Relocated front post (2)']],[150,230,270,460],12);para('Each X combines with each listed Z within its row. Existing part: verify full schedule and flatness before adding the two new holes. Old front holes are occupied by TF925 ties; do not plug or weld them closed.');end()
head('Wet frame / Weld assembly and fit sequence','WS17 parts are loose-part candidates; welded assembly and loaded use remain separate decisions')
table([['Joint','Physical weld / acceptance'],['TF922 legs to rails','Two a5 x80mm fillets at front and back leg top edges, where rail underside extends beyond leg. Fully seated end; no invented fillet on flush side walls.'],['TF922 legs to TF908 feet','Four a5 x80mm accessible perimeter fillets per foot. Feet must remain co-planar after balanced welding.'],['TF923 crossbeam to rails','At each end: a5 along two vertical80mm edges and lower80mm edge. Top bearing plane kept free of weld.'],['TF927 sleeves to rail','a3 circumference both ends; dress bearing faces flush. Inspect continuous weld and bore11 after welding.'],['TF926 edge locators','Two a4 x60mm fillets in lower20mm contacting rail side. Fit0.10..0.30mm receiver clearance; record final locator position.']],[260,850],12)
para('Frame origins: left/right rail (-250,5,1388)/(171,5,1388), length axis -Y; four vertical legs at X -250/171,Y -630/-75,Z756; feet datum Z744. Crossbeam origin(-170,-75,1388), length +X. Receiver top1488; original P107B/R107 lower face1488. Fit the two TF925 ties to the existing deck only after independent supports are level. No infinite-rigid floor or receiver assumption.')
para('All welds: compatible certified S355 consumable/process selected by qualified fabricator; clean bearing/contact areas, balanced sequence,100% visual inspection, no cracks or undercut>0.5mm. Measure receiver face, bolt axes and all ten feet after weld. No field grinding of seal/shaft/capture surfaces. Weld deposition is defined here; a fully modelled deposited-weld layer is not delivered for the new frame.');end()
c.save();b.dump(E/'R17_FACTORY_PDF_INFO.json',dict(pages=page,file='AT_DMP_R17_FACTORY_CANDIDATES_EN.pdf'));print('FACTORY PDF',page,flush=True)

