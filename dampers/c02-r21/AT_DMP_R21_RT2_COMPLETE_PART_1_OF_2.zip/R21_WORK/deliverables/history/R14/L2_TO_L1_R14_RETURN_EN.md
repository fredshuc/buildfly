# R14 engineering return / cold fabrication candidates

{
  "SP02": {
    "PN": 14,
    "pieces": 37
  },
  "SP03": {
    "PN": 29,
    "pieces": 66
  }
}

SP02: D870 x2, D871 x2, D872 x2, D873 x5, D874 x1, D875 x1, D876 x2, D879 x2, D877 x2, TF881L x4, TF881R x4, TF882 x4, TF883 x4, D894 x2

SP03: D884 x2, D885 x1, D886 x1, D887 x1, D888 x1, TF900 x1, D521_R14 x1, D530 x1, D889 x1, D890 x1, D891 x1, D893 x1, D892 x1, D896 x1, D895 x1, TF901 x1, TF902 x8, TF903 x1, TF904 x12, TF905 x2, TF906 x3, TF907 x6, TF908 x6, TF909 x4, G900 x2, G901 x1, G902 x1, G903 x1, G904 x2

The two independent batch ZIPs contain same-version drawings, part STEP and the complete quantity/procurement table. L1 issuance is required; no loaded/hot/powered operation is released. SP01 three parts remain byte-identical, credited once. A01/A02/B01/E01 plus SP01 remain34 PN122 pieces already issued. Full C02 PARTIAL / NOT_FOR_MANUFACTURE.

Actual P272/R249/service206 instances;79 independent part STEP and3 assembly readbacks passed. Nominal cold all-pair checks36856/30876/21115: zero unapproved overlaps after spatial thread clipping. Three conservative continuous envelopes and four tubular nut-tool envelopes are clear under documented preconditions. Full input dismantling, real transfer, supplier tool access and loaded joints remain HOLD. No whole-valve four-state rerun.

DOCUMENTARY ERRATA (takes precedence over review PDF): final TF904 is46x46x10, not50. Final geometric mass P467.837063kg,R449.098180kg,S411.377227kg; the review PDF mass table retains the prior pad mass by0.361728kg. The two-plane diagnostic is in R14_TWO_PLANE_DEFLECTION_SENSITIVITY.json: weak spring cases retain radial centre change0.109827mm and tilt up to4.863355mrad. Relative tangential displacement is not first-order centre-distance change. G1 NOT_CLOSED. The first beam identity check had reversed arguments and failed; retained as negative evidence. Corrected identity error7.81e-18mm. No supplier hot/contact acceptance inferred.

R15 receives44 signed reaction rows at78/38Nm normal inputs, pressure3/5,500,1500,2000Pa and jam/stop cases; wet near reaction approximately1.50kN is retained. Wet displacement/rotation remains NOT_SOLVED, requiring R15 contact model. DB thermal axial/radial signs corrected, no hot qualification.

TIME EXCEPTION: T0 08:16:56Z; engineering deadline09:26:56Z, formal delivery target09:46:56Z. At09:42:04Z the clock overrun was detected and engineering stopped. Final PDFs finished09:42:29Z. This return does NOT claim compliance with70minute engineering cutoff. Three documented iterations only; no sixth or borrowed allowance. Remaining work is explicitly held; no new engineering after detection. Round1/2 boundary08:40 is reconstructed, not instrumented.

Known holds by use: D521_R14 loaded clamp zone; input/stop dynamic calibration and capture/joint proof; frame weld/slip/prying/floor proof; guard reach/containment; full wet capture and service load transfer; wet interface displacement/seal contact. Independent cold parts remain candidates. No D540 handle supplied by this batch. Actuator remains purchased placeholder.

Measurement return: actual PN/revision, material, journal/bore/thread dimensions, ring orientation, selected ring thickness,20C +/-20N endplay10..30um, drag, two-plane bearing/gear indicators, input endplay0.05..0.15, clamp/witness movement, stop angles, floor contact, mass, raw loading/unloading data. Quarantine failed features; no undocumented machining of bearing/seal/thread/capture features. Loaded measurement needs separate signed release; B feedback is never sole protection.
