import pathlib,subprocess,json
from PIL import Image,ImageDraw
from pypdf import PdfReader
root=pathlib.Path(__file__).resolve().parents[1];out=root/'qa';out.mkdir(exist_ok=True)
exe=r'C:\Users\Gebruiker\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdftoppm.exe'
results=[]
for f in (root/'deliverables/drawings').glob('*.pdf'):
 name='review' if 'REVIEW' in f.name else ('sp02' if 'SP02' in f.name else 'sp03');prefix=out/name;subprocess.run([exe,'-r','65','-png',str(f),str(prefix)],check=True)
 pages=sorted(out.glob(name+'-*.png'));n=len(PdfReader(str(f)).pages)
 if len(pages)!=n:raise ValueError(('rendercount',f,len(pages),n))
 for k in range(0,len(pages),6):
  canvas=Image.new('RGB',(1800,1320),'white');d=ImageDraw.Draw(canvas)
  for i,p in enumerate(pages[k:k+6]):
   im=Image.open(p).convert('RGB');im.thumbnail((885,410));x=(i%2)*900;y=(i//2)*440;canvas.paste(im,(x,y+25));d.text((x+10,y+5),p.name,fill='black')
  target=out/f'{name}_montage_{k//6+1}.jpg';canvas.save(target,quality=88);print(target,flush=True)
 results.append(dict(file=f.name,pages=n,rendered=n))
(root/'deliverables/evidence/R14_PDF_RENDER_RECEIPT.json').write_text(json.dumps(results,indent=2));print(results)

