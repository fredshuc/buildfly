import json,collections
import build_c02 as b
f=b.OUT/'native/R14_PARTS.json';P=json.loads(f.read_text(encoding='utf-8-sig'))
for p in P:
 if p['kind']=='MAKE' and p['pn'] not in ['D878','TF880','TF884']:p['drawing']='AT-DMP-R14-'+p['pn']
 if p['pn']=='D521_R14':
  p['features']=[dict(type='shaft',d=30,z0=13,L=59,fit='h6'),dict(type='flange',od=110,z0=72,t=12,pilot_id=75,pilot_depth=9,fit='H7'),dict(type='hole_pattern',pcd=85,count=8,d=6.5,z0=72)]
  p['notes']=['42CrMo4+QT650MPa;30h6shaftZ13..72 (59length),Ra0.8,radialrunout0.03 toflangepilot. OD110 flangeZ72..84,t12+/-0.03;75H7 pilot fromZ75to84,9deep,coax0.03. Eight6.5THRU PCD85 at0/45/...degrees. Faceflat0.02,axiallocations+/-0.03,ordinaryoutline+/-0.2. Turn/mill afterQT and finish functional faces.', 'Worldstart177, leadingtip190 clearsM8head186.6 by3.4. Primarybody177..244 gives54mm physicalinsertion,>=48 nominalgrip. ExactMayr clampingzone and screws must be confirmed before load; cold metal candidate only. Secondary8M6x20class12.9,12mm flange+8mm supplierthread. No torque rating inferred from proxy.']
 if p['pn']=='D530':p['notes']=['42CrMo4+QT650MPa.30h6shaftZ0..146;26h6stubZ146..189,43long; overall189+/-0.05. Commonaxisdatum; runout0.02,journalRa0.8,shoulderperpendicular0.02,edgeR0.4max. TurnafterQT,finishjournals. Main30segment fitsMayr andD891plainbush;26stub fitsBK2/300/125/26/26. Axialcapture reliesonacceptedpurchasedclamps; no newshaftcrosshole.']
 if p['pn']=='TF904':
  s=b.box(46,10,46).translate((-23,0,-23)).cut(b.cyl(17,12,(0,-1,0),(0,1,0)));p.update(brep=b.brep(s),bbox=b.ex.bb(s),volume_mm3=s.Volume(),notes=['S355JR46x46x10;17THRUalongY atcentre. LocalX/Z+/-23,Y0..10. Facesflat0.1;outline+/-0.2,hole+0.2/0. Minimumedge23. Twelve M16 loadspreaders underdeck; 2mm edge reduction clears service M12nutcorners. Loadedjointprying notqualified.'])
 if p['pn']=='H14_M6X20':p['material']='Class12.9';p['notes']=['ISO4762 M6x20 class12.9 for Mayr flanges, supplier approved torque/locking required;12mm flange+8mm engagement,threaddepth9. Verify supplier drawing before loaded use.']
 if p['pn'] in ['D874','D875','D876','D879']:p['notes']=[n.replace('throughhole56+0.05/0','throughhole55.90+/-0.02').replace('R0.5max','R0.4max').replace('R0.5 max','R0.4 max') for n in p['notes']]
b.dump(f,P)
for cfg in ['P','R','S']:
 f=b.OUT/f'native/R14_{cfg}_ASSEMBLY.json';rows=json.loads(f.read_text());count=collections.Counter()
 for o in rows:count[o['pn']]+=1;o['occurrence']=f'R14_{cfg}_{o["pn"]}_{count[o["pn"]]:03d}'
 b.dump(f,rows)
print('FINALIZE_METADATA_AND_PAD',flush=True)
