"""Boolean failure is not clearance. Only positive independent separation proves zero overlap."""
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
records=[]
def volume(a,b):
 try:return abs(a.intersect(b).Volume())
 except ValueError as exc:
  d=BRepExtrema_DistShapeShape(a.wrapped,b.wrapped);d.Perform()
  if not d.IsDone() or d.Value()<=1e-6:raise
  records.append(dict(boolean_error=str(exc),independent_min_distance_mm=d.Value(),decision='POSITIVE_SEPARATION_ZERO_OVERLAP'))
  return 0.0
