import json,collections,hashlib
import build_c02 as b
E=b.OUT/'evidence';P=json.loads((b.OUT/'native/R14_PARTS.json').read_text());S={p['pn']:b.ex.readshape(p['brep']) for p in P};checks=[]
for p in P:
 pn=p['pn'];s=S[pn];f=b.OUT/'step/parts'/f'{pn}_R14.stp';f.parent.mkdir(parents=True,exist_ok=True);b.cq.exporters.export(s,str(f),exportType="STEP");a=b.cq.importers.importStep(str(f)).val();diff=[abs(s.cut(a).Volume()),abs(a.cut(s).Volume())];bd=max(abs(v-w) for v,w in zip(b.ex.bb(s),b.ex.bb(a)));ok=a.isValid() and len(a.Solids())==len(s.Solids()) and max(diff)<max(.001,s.Volume()*1e-8) and bd<.001
 if not ok:raise ValueError((pn,diff,bd))
 checks.append(dict(PN=pn,valid=a.isValid(),solids=len(a.Solids()),difference_mm3=diff,bounds_error_mm=bd,passed=ok,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
b.dump(E/'R14_PART_STEP_READBACK.json',checks);print('PARTS',len(checks),flush=True)
counts={};rec=[]
for cfg in ['P','R','S']:
 occ=json.loads((b.OUT/f'native/R14_{cfg}_ASSEMBLY.json').read_text());counts[cfg]=collections.Counter(o['pn'] for o in occ);ids=[q['occurrence'] for q in occ]
 if len(set(ids))!=len(ids):raise ValueError(('duplicate',cfg))
 defs={o['occurrence']:b.tr(S[o['pn']],o['o'],o['u'],o['v'],o['n']) for o in occ};rows=[dict(definition=o['occurrence'],occurrence=o['occurrence'],scope='DRIVE') for o in occ];rec.append(b.ex.export_step('AT_DMP_R14_'+cfg+'_COLD_CANDIDATE',rows,defs))
b.dump(E/'R14_STEP_EXPORTS.json',rec)
sp02={'D870','D871','D872','D873','D874','D875','D876','D877','D879','D894','TF881L','TF881R','TF882','TF883'}
bom=[]
for p in P:
 pn=p['pn'];q=max(counts[cfg][pn] for cfg in counts);credit=int(pn in ['D878','TF880','TF884']);batch='SP01_ALREADY_RELEASED' if credit else 'SP02' if pn in sp02 else 'SP03' if p['kind']=='MAKE' else 'PROCUREMENT_OR_REFERENCE'
 bom.append(dict(PN=pn,batch=batch,kind=p['kind'],P_qty=counts['P'][pn],R_qty=counts['R'][pn],service_total_qty=counts['S'][pn],shared_sequential_total=q,SP01_credit=credit,new_required_qty=max(0,q-credit),material=p['material'],release='L1_F01_ALREADY_RELEASED' if credit else 'CANDIDATE_NOT_RELEASED',drawing=p.get('drawing',''),notes='P/R sequential same rig; maximum count, not sum; reference wet stub not procurement' if pn!='REF_WET_STUB' else 'REFERENCE_ONLY_DO_NOT_MAKE'))
b.cw('R14_BOM.csv',bom);b.dump(E/'R14_BATCH_BOM.json',bom)
old={p['pn']:p for p in json.loads((b.ROOT.parent/'R13_WORK/deliverables/native/R13_PARTS.json').read_text())};w=[]
for pn in ['D878','TF880','TF884']:
 a=next(p for p in P if p['pn']==pn);same=a['brep']==old[pn]['brep'];w.append(dict(PN=pn,byte_identical_BRep=same,sha256=hashlib.sha256(a['brep'].encode()).hexdigest()))
 if not same:raise ValueError(('SP01changed',pn))
b.dump(E/'R14_SP01_IMMUTABILITY.json',w);print('EXPORT_COMPLETE',flush=True)

