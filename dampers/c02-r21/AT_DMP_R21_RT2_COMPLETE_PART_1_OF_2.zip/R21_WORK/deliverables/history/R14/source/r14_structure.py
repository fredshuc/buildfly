import json,math,copy
import build_c02 as b
E=b.OUT/'evidence';P=json.loads((b.OUT/'native/R14_PARTS.json').read_text());O=json.loads((b.OUT/'native/R14_P_CORE_OCCURRENCES.json').read_text());pm={p['pn']:p for p in P};S={p['pn']:b.ex.readshape(p['brep']) for p in P};A=[];F=[];G=[]
def ring(od,di,L,z=0):return b.cyl(od,L,(0,0,z)).cut(b.cyl(di,L+2,(0,0,z-1)))
def put(pn,name,s,notes,material='S355JR certified yield345MPa for t>16mm;355MPa t<=16mm',kind='MAKE',batch='SP03'):
 if not s.isValid() or (kind=='MAKE' and len(s.Solids())!=1):raise ValueError((pn,len(s.Solids())))
 p=dict(pn=pn,name=name,kind=kind,material=material,revision='R14',brep=b.brep(s),bbox=b.ex.bb(s),volume_mm3=s.Volume(),features=[],notes=notes,drawing='AT-DMP-R14-'+pn,status=batch+'_FABRICATION_CANDIDATE_COLD_ONLY');P.append(p);pm[pn]=p;S[pn]=s
def add(rows,pn,o=(0,0,0),u=(1,0,0),v=(0,1,0),n=(0,0,1),note=''):
 rows.append(dict(pn=pn,occurrence='R14_'+pn+'_'+str(sum(q['pn']==pn for q in O+A+F+G+rows)+1),o=list(o),u=list(u),v=list(v),n=list(n),scope='FIXTURE',note=note))
def bolt(pn,d,L):
 hd={4:7,5:8.5,6:10,8:13,10:16,12:18,16:24}[d];hh=d;s=b.cyl(d,L).fuse(b.cyl(hd,hh,(0,0,-hh)))
 put(pn,f'M{d}x{L} socket screw',s,[f'ISO4762 class8.8 M{d}x{L}; thread major-envelope model; actual threaded length must cover named effective engagement. Torque after friction-controlled shop instruction. Not a solid pin.'],'8.8','BUY')
for pn,d,L in [('H14_M8X25',8,25),('H14_M8X30',8,30),('H14_M8X40',8,40),('H14_M4X12',4,12),('H14_M6X20',6,20),('H14_M10X45',10,45),('H14_M12X110',12,110),('H14_M16X90',16,90),('H14_M16X110',16,110)]:bolt(pn,d,L)
for pn,od,di,t in [('H14_W8',16,8.4,1.6),('H14_W4',9,4.3,1.2),('H14_W16',30,17,3)]:put(pn,pn,ring(od,di,t),[f'ISO7089 washer {od}/{di}x{t},200HV.'],'200HV','BUY')
put('H14_N16','M16 nut',b.cq.Workplane('XY').polygon(6,24/math.cos(math.pi/6)).extrude(13).val().cut(b.cyl(14,15,(0,0,-1))),['ISO4032 M16 class8,13high;>=12 complete engagement,>=2 full threads protruding.'],'Class8','BUY')
put('D894','Output axial stack spacer',ring(36.1,30.2,9),['42CrMo4+QT;OD36.10+/-0.02,ID30.20+0.05/0,L9.00+/-0.02; facesparallel0.01,Ra0.8. AssemblyZ119..128 against rear nut. Remove before nut tool. Not bearing contact.'],'42CrMo4+QT',batch='SP02')
key=b.box(8,7,32).translate((-4,11,132))
put('D884','Dry output parallel key',key,['DIN6885-type rectangular key8h9x7h11x32, C45. STEP square ends; shaft slotmayhaveR4 ends only with matchingkeyrounding. AssembledfloorY11,Z132..164. No wetshaft key. Deburr0.1.'],'C45')
hub=b.cyl(50,46,(0,0,128)).fuse(b.cyl(110,12,(0,0,174)))
hub=hub.cut(b.cyl(30.03,46.2,(0,0,128))).cut(b.cyl(9,3,(0,0,174))).cut(b.cyl(75,9,(0,0,177))).cut(b.box(8.05,7.35,34).translate((-4.025,11,131)))
for a in range(0,360,45):hub=hub.cut(b.cyl(6.5,14,(42.5*math.cos(math.radians(a)),42.5*math.sin(math.radians(a)),173)))
hubnotes=['42CrMo4+QT certifiedyield650MPa. Integral sleeveOD50 Z128..174,flangeOD110 Z174..186. Bore30.02..30.04 todepth46.20 fromZ128; centreM8 clearance9 throughwebZ174..177. Pilot75H7 Z177..186 depth9,coax0.03 to30bore. Eight6.5THRU PCD85 at0/45/... degrees. Frontfaceflat0.02.',
'Keyway8JS9width,roofY18.35+/-0.03,Z131..165;8x7x32key seatedonD870. SleevefaceZ128 seatsD894; M8x25 axial screw through1.6washer onZ177 gives20.4mmpenetration,20mmcompleteengagement; torque22+/-2Nm. Use medium-strength removablethreadlockingcompound toitsmanufacturer cure instruction; witnessmark aftertorque. Coldfitinspection eachassembly; positivecapture is actualM8screw, no unmodeledwire routedthroughMayr.',
'Mayr pressureflange pilot entersZ177..186, eightM6x20 fromZ174 toward+Z:12mm flange then8mm supplier thread <=9. Class12.9 required for these eight screws; use only manufacturerapproved locking/torque. No unloadedassembly authority to operate.']
put('D885','Keyed P input adapter to Mayr flange',hub,hubnotes,'42CrMo4+QT Rp0.2>=650MPa')
stopHub=b.cyl(60,46,(0,0,128)).cut(b.cyl(30.03,46.2,(0,0,128))).fuse(b.cyl(60,3,(0,0,174))).cut(b.cyl(9,3,(0,0,174))).cut(b.box(8.05,7.35,34).translate((-4.025,11,131)))
arm=b.box(80,20,16).translate((0,-10,140));stopHub=stopHub.fuse(arm).cut(b.cyl(30.03,46.2,(0,0,128))).cut(b.cyl(9,3,(0,0,174))).cut(b.box(8.05,7.35,34).translate((-4.025,11,131)))
put('D886','Keyed P positive stop arm',stopHub,['42CrMo4+QT,650MPa. SleeveOD60,bore30.02..30.04,Z128..174. Frontweb3 with9THRU; keyway asD885. ArmX0..80,Y-10..10,Z140..156,integral or machinedfromsolid (NO unspecified weld). Datum shaftaxis, armcentreline;90degree travel betweenlowerY=-10 andleftX=-10 contacts.',
'UseD894 andD884, capturedM8x25+washer atZ177,>=20completeengagement,22Nm plusremovablethreadlockerandwitness. Stopsdesignedfor200Nmstatic/3333.3N at60mm; not impactqualification. Keep arm installed during input isolation; remove only afterwetrotor separatelycaptured for rearplate service.'],'42CrMo4+QT Rp0.2>=650MPa')
put('D887','R gear replacement spacer',ring(36.1,30.2,58.5),['42CrMo4+QT OD36.10+/-0.02,ID30.20+0.05/0,L58.50+/-0.01;parallel0.01. Replaces one wholegear/hub atZ20..78.5 in SINGLE-AXIS R bench configuration. No meshing load. Not additive to P gear quantity.'],'42CrMo4+QT Rp0.2>=650MPa')
put('D888','R input adapter with integral stop arm',hub.fuse(arm).cut(b.cyl(30.03,46.2,(0,0,128))).cut(b.box(8.05,7.35,34).translate((-4.025,11,131))),hubnotes+['R-only integral80x20x16stoparm samecontactasD886; localaxis0. P input module translatesX-165 for R; do notrunP/Rsimultaneously.'],'42CrMo4+QT Rp0.2>=650MPa')
# Attach P output adapter and stop; no changes to SP01 holes.
for x,pn in [(165,'D885'),(0,'D886')]:
 add(A,pn,(x,0,0));add(A,'D894',(x,0,119));add(A,'D884',(x,0,0));add(A,'H14_W8',(x,0,177));add(A,'H14_M8X25',(x,0,178.6),v=(0,-1,0),n=(0,0,-1))
stop=b.box(425,25,36).translate((-130,-100,130)).fuse(b.box(30,65,36).translate((55,-75,130))).fuse(b.box(30,155,36).translate((-70,-75,130))).fuse(b.box(30,30,36).translate((-40,50,130)))
for x in [-110,275]:stop=stop.cut(b.cyl(13,27,(x,-101,155),(0,1,0)))
put('TF900','Common static stop receiving bracket',stop,['S355JR certified345MPa. Singlemachinedsolid:baseX-130..295,Y-100..-75,Z130..166; startpostX55..85,Y-75..-10; endpostX-70..-40,Y-75..80 plusheadX-40..-10,Y50..80, both36axialthickness. Two13THRUalongY X-110/275,Z155. No new SP01holes.',
'Replaceonlytwo rear M12x80withM12x110,originalwashers/nuts; upperwasherseatsY-75. ContactplanesY-10 andX-10; nominal0/90stop, machine finalangle+/-0.1degree afterunloadedgauging. Keep200Nmstatic/3333Nscreen separatefromimpact. Removebracketbefore rearplateextraction afterinputisolationandcapturingwetrotors.'])
add(A,'TF900')
for q in O:
 if q['pn']=='HW_R13_M12X80' and q['o'][2]==155:q['pn']='H14_M12X110';q['o'][1]+=25
 if q['pn']=='HW_R13_W12' and q['o'][2]==155 and q['o'][1]>-125:q['o'][1]+=25
# Real serial input components, shifted -33 from R13 reference to new adapter flange.
IP=json.loads((R13:=b.ROOT.parent/'R13_WORK/deliverables'/'native/R13_INPUT_REFERENCE_PARTS.json').read_text());IM={p['pn']:p for p in IP}
for pn in ['BUY520','BUY521','D521','D530','BUY531','BUY530']:
 q=copy.deepcopy(IM[pn]);q['status']='SP03_PURCHASE_OR_REUSED_INTERFACE_CANDIDATE';P.append(q);pm[pn]=q;S[pn]=b.ex.readshape(q['brep'])
# Relieve original intermediate shaft tip for captured adapter bolt, retain54mm insertion.
q=pm['D521'];ss=S['D521'].cut(b.box(200,200,13).translate((-100,-100,0)));q.update(pn='D521_R14',revision='R14',brep=b.brep(ss),bbox=b.ex.bb(ss),volume_mm3=ss.Volume(),notes=q['notes']+['R14 tip relief removeslocalZ0..13 only. Remaining shaftZ13..72, withinprimary67mmbody insertion54mm>=48mmminimum. Leadingtipworld190 clearsadapterbolthead186.6 by3.4mm. ActualMayr clampzone confirmation required beforeloading.']);pm['D521_R14']=q;S['D521_R14']=ss
for pn,z in [('BUY520',177),('D521_R14',177),('BUY521',252),('D530',252),('BUY531',398),('BUY530',529),('BUY531',607)]:add(A,pn,(165,0,z))
for z in [174,249]:
 for a in range(0,360,45):add(A,'H14_M6X20',(165+42.5*math.cos(math.radians(a)),42.5*math.sin(math.radians(a)),z))
pm['H14_M6X20']['material']='12.9';pm['H14_M6X20']['notes']=['ISO4762M6x20class12.9. EightperMayrpressureflange; through12mmadapter,8mmeffective<=9mm supplierdepth. Manufacturerlocking/torquerequired.']
# Independent plain-bearing input supports; no unmountable25mm bearing on26mm leading shaft.
def housing(pn,L,z,bore):
 s=b.box(130,165,L).translate((-65,-100,0)).cut(b.cyl(bore,L+2,(0,0,-1)))
 for x in [-45,45]:s=s.cut(b.cyl(8.5,23,(x,-100,L/2),(0,1,0)))
 put(pn,pn,s,[f'S355JR stressrelieved.130wide x165high x{L}thick; localX-65..65,Y-100..65,Z0..{L}. Bore{bore}H7 at0,0; perpendicular0.02 tobase. BottomtwoM10-6H effective20/drill23,X+/-45,Z{L/2}. Fitboreafterboltingtobase. Datum bottom and boreaxis; generaloutline+/-0.2.',f'Assemblyaxis165,stationZ{z}; R translateX-165. Coldmanual-only plainbearing; lubricationanddragrecord required. Not automatically hot-rated.'])
housing('D889',30,368,34);housing('D890',22,742,34)
put('D891','Input front bronze bush',ring(34,30.05,30),['CuSn12 continuouscast bronze,OD34s6,ID30.04..30.07 afterpressfit,L30.00+/-0.03;Ra0.8bore. Oilbeforecoldfit,verifyfreefullrotationwithouttorquechain. StationZ368..398. No axialload function.'],'CuSn12')
rearBush=ring(34,30.05,22,2).fuse(ring(42,30.05,2))
put('D893','Input rear flanged bronze bush',rearBush,['CuSn12 bronze,bodyOD34s6x22 after2mmOD42flange;ID30.04..30.07 afterpressfit. Total24; station740..764,flange740..742. Endfacesflat0.02. Coldmanualinputaxialcaptureonly,withD873nutandD892shoulder; measuredendplay0.05..0.15,do notpreload.'],'CuSn12')
shaft=b.cyl(26,43).fuse(b.cyl(30,32,(0,0,43))).fuse(b.cyl(38,30,(0,0,75)))
shaft=shaft.cut(b.cq.Workplane('XY').rect(19.1,19.1).extrude(20).val().translate((0,0,85))).cut(b.cyl(5,40,(-20,0,97.5),(1,0,0)))
put('D892','Captured manual input shaft',shaft,['42CrMo4+QT650MPa;26h6Z0..43 forBK2,30h6journalZ51..75,38hubZ75..105; female19.10+0.05/0squaredepth20from105; crosspin5H11alongX atZ97.5. M30x1.5-6gZ43..51,complete43.5..50.5. D873frontnut at43..51, bearing-sidecounterborefaces+Z. D893flange begins51; adjust0.05..0.15endplay bynut,lockM4andwitness. Do notclampbronze axiallyhard.',
'StationstartZ689. Leading26mmstub passes34mmhousingbeforebronzeinstallation; assemblybronzeover26stub thenonto30journal. Hub38andnut45positivelycaptureaxialtravel. No sealedrollingbearinghiddeninthisplainbearingdefinition.'],'42CrMo4+QT Rp0.2>=650MPa')
add(A,'D889',(165,0,368));add(A,'D891',(165,0,368));add(A,'D890',(165,0,742));add(A,'D893',(165,0,740));add(A,'D892',(165,0,689));add(A,'D873',(165,0,732));add(A,'HW_R13_M4TIP',(180,0,736),u=(0,1,0),v=(0,0,1),n=(1,0,0))
ext=b.box(19.05,19.05,15).translate((-9.525,-9.525,0)).fuse(b.cyl(26,85,(0,0,15))).fuse(b.cyl(40,25,(0,0,100)))
ext=ext.cut(b.cq.Workplane('XY').rect(19.1,19.1).extrude(20).val().translate((0,0,105))).cut(b.cyl(5,22,(-11,0,7.5),(1,0,0)))
put('D896','Guard-through manual extension',ext,['42CrMo4+QT.19.05-0.02/0squarex15,26shaft85from15to100,40hub25from100to125;female19.1squaredepth20. Cross5pinthroughX at7.5 matesD892. AssemblyZ779..904, passesrear guard at873..876 with3mmradialclearance. Upstreamofbothlimiters only. Noimpact/extensionpipes.'],'42CrMo4+QT')
put('H14_PIN5','Positive manual connector pin',b.cyl(5,46).fuse(b.cyl(9,3,(0,0,-3))).cut(b.cyl(1.6,7,(-3.5,0,43),(1,0,0))),['5h9x46headedpin,head9x3;1.6crossholeat43 with1.6splitpin. Remove only isolatedandunloaded. Pin transmitsretention, squaretransmitstorque.'],'C45','BUY')
put('H14_SPLIT','Split pin envelope',b.cyl(1.6,12),['ISO1234 splitpin1.6x12; spreadlegsafterinstall. Modelstraightenvelope only.'],'Stainless','BUY')
add(A,'D896',(165,0,779));add(A,'H14_PIN5',(143,0,786.5),u=(0,1,0),v=(0,0,1),n=(1,0,0));add(A,'H14_SPLIT',(186,-6,786.5),u=(1,0,0),v=(0,0,-1),n=(0,1,0))
# HBK base support is a real bridge, carrying stator only.
bridge=b.box(110,72,60).translate((-55,-100,537)).cut(b.box(80,66,64).translate((-40,-100,536)))
for x in [-20,20]:
 for z in [544,586]:bridge=bridge.cut(b.cyl(4.5,8,(x,-35,z),(0,1,0)))
for x in [-47.5,47.5]:bridge=bridge.cut(b.cyl(6.8,21,(x,-100,568),(0,1,0)))
put('D895','HBK stator independent bridge',bridge,['S355JR;110wide,60longZ537..597,topY-28,bottomY-100. Cutcentral80widepocketY-100..-34,leaving6topand15sidelegs. Four4.5THRUalongY,X+/-20,Z544/586;M4x12+1.2washer intoHBK4.8mm<=5. TwofootM8effective18/drill21,X+/-47.5,Z568.',
'Topflat0.03; alignsensoraxiswithin0.02coldbymeasuredshim; noforcedsidepullfromcouplings. Statornotatorque-reactionclamp. Factorymachiningfromsolid acceptableforfirstunit; no unspecifiedweld.'])
add(A,'D895',(165,0,0))
for x in [145,185]:
 for z in [544,586]:add(A,'H14_W4',(x,-35.2,z),u=(1,0,0),v=(0,0,-1),n=(0,1,0));add(A,'H14_M4X12',(x,-35.2,z),u=(1,0,0),v=(0,0,-1),n=(0,1,0))
# Common P/R switchable input rail, mounting holes for both axis0 and165.
rail=b.box(400,25,720).translate((-100,-125,270))
for axis in [0,165]:
 for z in [383,753]:
  for x in [axis-45,axis+45]:rail=rail.cut(b.cyl(11,27,(x,-126,z),(0,1,0)))
 for x in [axis-47.5,axis+47.5]:rail=rail.cut(b.cyl(9,27,(x,-126,568),(0,1,0)))
for x in [-75,275]:
 for z in [300,500,700,960]:rail=rail.cut(b.cyl(17,27,(x,-126,z),(0,1,0)))
put('TF901','P/R switchable input rail',rail,['S355JR25thk. X-100..300,Y-125..-100,Z270..990. Eight17THRUalongY atX-75/275,Z300/500/700/960;30mmtubularspacers todeck. Inputfoot11THRU ataxis0or165 plusX+/-45,Z383/753;HBKfoot9THRU ataxis+/-47.5,Z568. Onlyoneaxisstationpopulatedatonce.',
'Topflat0.05;coaxialinputalignmentbymeasuredshimandpinsafterfit. Generaloutline+/-0.2,holes+0.2/0,locations+/-0.1. Pinputaxis165; Raxis0 aftercompleteisolationandsupportedtransfer. No newSP01holes.'])
put('TF902','Input rail stand-off',ring(32,17,30),['S355JR OD32,ID17+0.2/0,L30.00+/-0.03;faceparallel0.03. EightbetweenrailY-125anddeckY-155.'],'S355JR')
add(F,'TF901')
for z in [383,753]:
 for x in [120,210]:add(A,'H14_M10X45',(x,-127,z),u=(1,0,0),v=(0,0,-1),n=(0,1,0));add(A,'HW_R13_W10',(x,-127,z),u=(1,0,0),v=(0,0,-1),n=(0,1,0))
for x in [117.5,212.5]:add(A,'H14_M8X40',(x,-126.6,568),u=(1,0,0),v=(0,0,-1),n=(0,1,0));add(A,'H14_W8',(x,-126.6,568),u=(1,0,0),v=(0,0,-1),n=(0,1,0))
# Defined steel table with throughbolts/backplates. Ground contact remains a measuredcondition.
deck=b.box(1000,12,1350).translate((-400,-167,-250));mounts=[(x,z,90) for x in [-145,310] for z in [-75,195]]+[(x,z,110) for x in [-75,275] for z in [300,500,700,960]]
for x,z,L in mounts:deck=deck.cut(b.cyl(17,14,(x,-168,z),(0,1,0)))
for x in [-110,275]:
 for z in [-35,155,190]:deck=deck.cut(b.cyl(32,14,(x,-168,z),(0,1,0)))
for x in [-65,82.5,230]:
 for z in [-15,99.5]:deck=deck.cut(b.cyl(28,14,(x,-168,z),(0,1,0)))
for x in [-27,27,138,192]:
 for z in [12,83]:deck=deck.cut(b.cyl(14,14,(x,-168,z),(0,1,0)))
for x in [-135,315]:
 for z in [-203,863]:deck=deck.cut(b.cyl(9,14,(x,-168,z),(0,1,0)))
put('TF903','Steel test table deck',deck,['S355JR12plate,X-400..600,Y-167..-155,Z-250..1100. Four17holesX-145/310,Z-75/195forTF880; eight17X-75/275,Z300/500/700/960forinputrail. Four9guardholesX-135/315,Z-203/863. Six32nutclearancesX-110/275,Z-35/155/190;six28foottoolholesX-65/82.5/230,Z-15/99.5;eight14serviceaccessX-27/27/138/192,Z12/83. AllTHRUY,location+/-0.1,outline+/-0.5,topflat0.2 afterweld/spotface. Do notdrillreleasedTF880.',
'WelddecktoRHSframe witha4 continuousfilletsalongaccessiblebearingedges,balancedsequence; inspect100percentvisual, no cracks/undercut>0.5. Functionalboltingpadsfinishafterweld. No ratedliftingholes.'])
add(F,'TF903')
back=b.box(50,10,50).translate((-25,0,-25)).cut(b.cyl(17,12,(0,-1,0),(0,1,0)))
put('TF904','M16 underside load spreader',back,['S355JR50x50x10;17THRUalongY atcentre. Bottom/topflat0.1;minimumedgedistance25. Underdeckfor12M16mounts.'])
for x,z,L in mounts:
 if L==110:add(F,'TF902',(x,-155,z),u=(1,0,0),v=(0,0,-1),n=(0,1,0))
 add(F,'TF904',(x,-177,z));add(F,'H14_W16',(x,-180,z),u=(1,0,0),v=(0,0,-1),n=(0,1,0));add(F,'H14_N16',(x,-193,z),u=(1,0,0),v=(0,0,-1),n=(0,1,0));add(F,'H14_W16',(x,-100 if L==110 else -125,z),u=(1,0,0),v=(0,0,-1),n=(0,1,0));add(F,'H14_M16X'+str(L),(x,-97 if L==110 else -122,z),u=(1,0,0),v=(0,0,1),n=(0,-1,0))
def rhs(pn,L):
 s=b.box(80,80,L).cut(b.box(70,70,L+2).translate((5,5,-1)))
 if pn=='TF906':
  for zz in [185,635]:s=s.cut(b.cyl(28,82,(33,-1,zz),(0,1,0)))
 put(pn,'RHS80x80x5 length'+str(L),s,[f'EN10219S355JRH RHS80x80x5,length{L}+/-0.5,squareends0.3; actualcorner radii frommill acceptableoutsideinterfacepads. Sawcut/deburr, no unapprovedtorchcut. Framejoin a5allaccessible perimeterfillet, endbuttsfullyseated; inspect100percentvisual. TF906 only:two28THRUYtoolholesatlocalX33,Z185/635, throughbothwalls. No liftingbyopenRHS.'],'S355JRH RHS')
rhs('TF905',1350);rhs('TF906',840);rhs('TF907',580)
for x in [-400,520]:add(F,'TF905',(x,-247,-250))
for z in [-250,380,1020]:add(F,'TF906',(-320,-247,z),u=(0,0,1),v=(0,1,0),n=(-1,0,0))
# crossmembers need +X direction and right-handedbasis
for q in F:
 if q['pn']=='TF906':q['u']=[0,0,-1];q['v']=[0,1,0];q['n']=[1,0,0];q['o'][2]+=80
foot=b.box(160,12,160).translate((-40,0,-40))
put('TF908','Free-standing frame foot plate',foot,['S355JR160x160x12;leg80centrallyseated, a5continuousfillet. No flooranchor assumed. Sixfeet must contactlevelverifiedconcretefloor; slipqualificationrequiresmeasuredfriction>=0.30 or separatelyapprovedanchors. No castors.'])
for x in [-400,520]:
 for z in [-250,380,1020]:add(F,'TF907',(x,-247,z),u=(1,0,0),v=(0,0,1),n=(0,-1,0));add(F,'TF908',(x,-839,z))
# Full contact guard withactualposts/fasteners; no containmentratingclaimed.
post=b.box(20,260,20)
for yy in [75,235]:
 post=post.cut(b.cyl(4.2,18,(0,yy,10),(1,0,0))).cut(b.cyl(4.2,18,(10,yy,0),(0,0,1)))
post=post.cut(b.cyl(4.2,18,(10,260,10),(0,-1,0))).cut(b.cyl(6.8,20,(10,0,10),(0,1,0)))
put('TF909','Guard corner post',post,['S355JR20x20x260;bottomM8effective18 at10/10,topM5effective16,sideM5atY75/235 centred10 fromfaces. Mirroredinstallationperassembly. Coldcontactguard only; impact/reachqualificationstillrequired.'])
for x in [-145,305]:
 for z in [-213,853]:
  # holes arefromouterfaces for right/rear via transformedpost.
  ux=1 if x<0 else -1;nz=1 if z<0 else -1
  # explicit makepostallfour sides tapped avoidsreflectiontransform
  add(G,'TF909',(x,-155,z));add(G,'H14_M8X30',(x+10,-168.6,z+10),u=(1,0,0),v=(0,0,-1),n=(0,1,0));add(G,'H14_W8',(x+10,-168.6,z+10),u=(1,0,0),v=(0,0,-1),n=(0,1,0))
# Opposite-face blind taps also needed; no orthogonaltapcollision atsamecentre accepted: throughM5.
ps=post
for yy in [75,235]:ps=ps.cut(b.cyl(4.2,22,(-1,yy,10),(1,0,0))).cut(b.cyl(4.2,22,(10,yy,-1),(0,0,1)))
pm['TF909'].update(brep=b.brep(ps),bbox=b.ex.bb(ps),volume_mm3=ps.Volume());S['TF909']=ps;pm['TF909']['notes']=['S355JR20x20x260;bottomM8effective18 centre10/10;topM5effective16. SideM5THRU alongX andZ atY75/235,centre10. Atcornerscrossdrillsintersect: outerpanel screwsM5x10,engagement7max so their tips stayoutsidecrossingcentre. General+/-0.2; postbottomflat0.1.']
bolt('H14_M5X10',5,10)
side=b.box(3,225,1086)
for yy in [40,200]:
 for z in [10,1076]:side=side.cut(b.cyl(5.5,5,(-1,yy,z),(1,0,0)))
for zz in [122,392]:side=side.cut(b.box(5,22,32).translate((-1,0,zz)))
put('G900','Long side contact guard',side,['S235JR3sheet,225highx1086long. Four5.5THRUalongX atY40/200,Z10/1076. AssemblybottomY-120,frontZ-213; sidesX-148..-145 and325..328. Twoopenbottomnotches32longx22highatlocalZ122/392 forplatenM16heads. M5x10effective7. Deburr0.3; no sharpcorners. Lower35mmdeckgap reachassessmentisnotclosed; no powereduse.'],'S235JR')
for x in [-148,325]:
 add(G,'G900',(x,-120,-213))
 for y in [-80,80]:
  for z in [-203,863]:add(G,'H14_M5X10',(x if x<0 else x+3,y,z),u=(0,1,0),v=(0,0,1 if x<0 else -1),n=(1 if x<0 else -1,0,0))
for pn,z,di in [('G901',-216,36),('G902',873,32)]:
 pan=b.box(476,225,3).translate((-148,-120,0))
 for x in [0,165]:pan=pan.cut(b.cyl(di,5,(x,0,-1)))
 for x in [-135,315]:
  for y in [-80,80]:pan=pan.cut(b.cyl(5.5,5,(x,y,-1)))
 if pn=='G902':pan=pan.cut(b.box(400,21,5).translate((-100,-120,-1)))
 put(pn,'End contact guard',pan,[f'S235JR3sheet X-148..328,Y-120..105;two{di}holesatX0/165,Y0;four5.5atX-135/315,Y-80/80. AssemblyZ{z}. Activefeedthroughonly; unusedholecoveredbyG904 andtwoM4. RearG902hasrailclearanceX-100..300,Y-120..-99; reachqualificationrequired. Coldcontactguard, nofragmentcontainmentrating.'],'S235JR')
 add(G,pn,(0,0,z))
 for x in [-135,315]:
  for y in [-80,80]:add(G,'H14_M5X10',(x,y,z if z<0 else z+3),v=(0,1 if z<0 else -1,0),n=(0,0,1 if z<0 else -1))
top=b.box(476,3,1092).translate((-148,0,-216))
for x in [-135,315]:
 for z in [-203,863]:top=top.cut(b.cyl(5.5,5,(x,-1,z),(0,1,0)))
put('G903','Removable top contact guard',top,['S235JR476x1092x3;four5.5THRUalongY atX-135/315,Z-203/863. AssemblyY105. FourM5x10; removeonlyisolate/unloaded. No guardinterlockqualificationclaimed.'],'S235JR');add(G,'G903',(0,105,0))
for x in [-135,315]:
 for z in [-203,863]:add(G,'H14_M5X10',(x,108,z),u=(1,0,0),v=(0,0,1),n=(0,-1,0))
# Closed spare-port blank: two M4 bolts throughendpanel; coldprototype addexplicit port holes.
blank=b.cyl(52,3)
for x in [-21,21]:blank=blank.cut(b.cyl(4.5,5,(x,0,-1)))
put('G904','Spare shaft port blank',blank,['S235JR52ODx3;two4.5THRUatX+/-21,Y0. BolttoendpanelwithtwoM4x12andnuts. Always coverunusedport; RfrontandPbackdifferentports.'],'S235JR')
for pn in ['G901','G902']:
 ss=S[pn]
 for x in [-21,21,144,186]:ss=ss.cut(b.cyl(4.5,5,(x,0,-1)))
 pm[pn].update(brep=b.brep(ss),bbox=b.ex.bb(ss),volume_mm3=ss.Volume());pm[pn]['notes'].append('Four4.5blankfixingholesatX-21,21,144,186,Y0; activeporthasunoccupied4.5holes.');S[pn]=ss
put('H14_N4','M4 guard nut',b.cq.Workplane('XY').polygon(6,7/math.cos(math.pi/6)).extrude(3.2).val().cut(b.cyl(3.3,5,(0,0,-1))),['ISO4032M4class8 plusprevailinglockorwitness;3.2height.'],'Class8','BUY')
add(G,'G904',(0,0,876))
for x in [-21,21]:add(G,'H14_M4X12',(x,0,879),v=(0,-1,0),n=(0,0,-1));add(G,'H14_N4',(x,0,869.8))
# R single-axis configuration reuses sameplates,base,rail andframe sequentially.
R=[]
for q in O:
 if q['pn'] in ['D870','D871','D872','D873','D877','BUY_R13_7206','D876','D879','HW_R13_M4TIP','BUY_R13_BK2','REF_WET_STUB'] and q['o'][0]>100:continue
 if q['pn']=='BUY504':continue
 if q['pn']=='HW_R13_M5X20' and q['o'][0]>100:continue
 R.append(copy.deepcopy(q))
add(R,'D887',(0,0,20))
for q in A:
 if q['pn']=='D886':continue
 if q['pn'] in ['D894','D884','H14_W8','H14_M8X25'] and q['o'][0]==0:continue
 qq=copy.deepcopy(q)
 if q['pn']!='TF900':qq['o'][0]-=165
 if q['pn']=='D885':qq['pn']='D888'
 R.append(qq)
R+=copy.deepcopy(F)
RG=copy.deepcopy(G)
for q in RG:
 if q['pn'] in ['G904','H14_M4X12','H14_N4']:q['o'][0]+=165
# frontRunusedport165 addoneblank atfront withseparatebolts
add(RG,'G904',(165,0,-219))
for x in [144,186]:add(RG,'H14_M4X12',(x,0,-219));add(RG,'H14_N4',(x,0,-213))
# Empty bearing station guarded by externalenclosure; no fakeunusedbearings.
b.dump(b.OUT/'native/R14_PARTS.json',P);b.dump(b.OUT/'native/R14_P_CORE_OCCURRENCES.json',O);b.dump(b.OUT/'native/R14_INPUT_OCCURRENCES.json',A);b.dump(b.OUT/'native/R14_FRAME_OCCURRENCES.json',F);b.dump(b.OUT/'native/R14_GUARD_OCCURRENCES.json',G);b.dump(b.OUT/'native/R14_P_ASSEMBLY.json',O+A+F+G);b.dump(b.OUT/'native/R14_R_ASSEMBLY.json',R+RG)
print('STRUCTURE',len(P),'PN','P',len(O+A+F+G),'R',len(R+RG),flush=True)
