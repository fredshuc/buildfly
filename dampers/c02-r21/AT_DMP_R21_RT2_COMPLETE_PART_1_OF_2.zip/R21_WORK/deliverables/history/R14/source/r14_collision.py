import json,itertools,math
import build_c02 as b
from r11_common import volume
E=b.OUT/'evidence';P=json.loads((b.OUT/'native/R14_PARTS.json').read_text());S={p['pn']:b.ex.readshape(p['brep']) for p in P}
def thread_zone(a,c):
 # Spatial clipping, never accept a complete PN pair without a named axial/radial zone.
 pair={a['pn'],c['pn']};host=None;bolt=None
 if 'D873' in pair:
  nut=a if a['pn']=='D873' else c;other=c if nut is a else a
  if other['pn'] in ['D870','D892']:
   return b.tr(b.cyl(30.001,7,(0,0,0)),nut['o'],nut['u'],nut['v'],nut['n']),'M30_MAJOR_ENVELOPE_LOCAL_NUT_Z0..7;COMPLETE0.5..6.5'
  if other['pn']=='HW_R13_M4TIP':
   return b.tr(b.cyl(4.001,8),other['o'],other['u'],other['v'],other['n']),'M4_NUT_RADIAL_THREAD_8MM'
 # Host/fastener combinations still require actual volume contained in the screw shank.
 hosts={'D874':{'HW_R13_M5X20':5,'HW_R13_M10X45':10},'D875':{'HW_R13_M5X20':5,'HW_R13_M10X45':10},'D870':{'H14_M8X25':8},'D889':{'H14_M10X45':10},'D890':{'H14_M10X45':10},'D895':{'H14_M8X40':8},'BUY530':{'H14_M4X12':4},'BUY520':{'H14_M6X20':6},'BUY521':{'H14_M6X20':6},'TF909':{'H14_M5X10':5,'H14_M8X30':8},'H14_N16':{'H14_M16X90':16,'H14_M16X110':16},'H14_N4':{'H14_M4X12':4},'HW_R13_N12':{'H14_M12X110':12,'HW_R13_M12X80':12},'TF881L':{'HW_R13_M5X40':5},'TF881R':{'HW_R13_M5X40':5}}
 for h,f in [(a,c),(c,a)]:
  if h['pn'] in hosts and f['pn'] in hosts[h['pn']]:host=h;bolt=f;diam=hosts[h['pn']][f['pn']];break
 if host:
  # actual threaded host zones; coordinates local to fastener from its bearing face
  length={'HW_R13_M5X20':20,'HW_R13_M10X45':45,'H14_M8X25':25,'H14_M10X45':45,'H14_M8X40':40,'H14_M4X12':12,'H14_M6X20':20,'H14_M5X10':10,'H14_M8X30':30,'H14_M16X90':90,'H14_M16X110':110,'H14_M12X110':110,'HW_R13_M12X80':80,'HW_R13_M5X40':40}[bolt['pn']]
  zone=b.tr(b.cyl(diam+.001,length),bolt['o'],bolt['u'],bolt['v'],bolt['n'])
  if host['pn']=='D870':zone=zone.intersect(b.box(100,100,21).translate((host['o'][0]-50,-50,153)))
  if host['pn'] in ['BUY520','BUY521']:zone=zone.intersect(b.box(150,150,9).translate((host['o'][0]-75,-75,host['o'][2]+9)))
  return zone,'NAMED_SCREW_SHANK_AND_HOST_THREAD_ZONE'
 return None,None
import sys
for config in (sys.argv[1:] or ['P','R','S']):
 O=json.loads((b.OUT/f'native/R14_{config}_ASSEMBLY.json').read_text());W=[b.tr(S[o['pn']],o['o'],o['u'],o['v'],o['n']) for o in O];BB=[b.ex.bb(s) for s in W];hits=[]
 for i,j in itertools.combinations(range(len(O)),2):
  aa,cc=BB[i],BB[j]
  if not all(min(aa[k+3],cc[k+3])-max(aa[k],cc[k])>1e-5 for k in range(3)):continue
  common=W[i].intersect(W[j]);v=abs(common.Volume())
  if v<.001:continue
  zone,reason=thread_zone(O[i],O[j]);outside=abs(common.cut(zone).Volume()) if zone is not None else v
  hits.append(dict(a=O[i]['occurrence'],b=O[j]['occurrence'],PN=[O[i]['pn'],O[j]['pn']],volume_mm3=v,outside_declared_thread_mm3=outside,classification=reason if outside<.001 else 'UNAPPROVED'))
 bad=[q for q in hits if q['classification']=='UNAPPROVED'];b.dump(E/f'R14_{config}_COLLISION.json',dict(instances=len(O),pairs=len(O)*(len(O)-1)//2,hits=hits,unapproved=bad,scope='Nominalcoldconfiguration; purchaseinterfaceproxies,notallvalvestates'))
 print(config,'PAIRS',len(O)*(len(O)-1)//2,'HITS',len(hits),'BAD',bad,flush=True)

