"""R14 delta from exact R13 final build+service state; no reset of released holes."""
import json,math,copy
import build_c02 as b
R13=b.ROOT.parent/'R13_WORK/deliverables';E=b.OUT/'evidence'
P=json.loads((R13/'native/R13_PARTS.json').read_text());O=json.loads((R13/'native/R13_OCCURRENCES.json').read_text());SR=json.loads((R13/'native/R13_SERVICE_OCCURRENCES.json').read_text());pm={p['pn']:p for p in P};S={p['pn']:b.ex.readshape(p['brep']) for p in P}
def ring(od,di,L,z=0):return b.cyl(od,L,(0,0,z)).cut(b.cyl(di,L+2,(0,0,z-1)))
def update(pn,s,notes):
 if not s.isValid() or len(s.Solids())!=1:raise ValueError((pn,len(s.Solids())))
 S[pn]=s;pm[pn].update(brep=b.brep(s),bbox=b.ex.bb(s),volume_mm3=s.Volume(),revision='R14',notes=notes,status='SP02_COLD_FABRICATION_CANDIDATE')
# Front complete external thread extended; end relief moved to bearing end.
s=S['D870'].fuse(ring(30,29.1,1,-28)).cut(ring(30.2,29.1,1,-22)).fuse(b.cyl(30,3,(0,0,171)))
s=s.cut(b.box(8,8,32).translate((-4,11,132))).cut(b.cyl(6.8,24,(0,0,150)))
s=s.fuse(ring(36.1,36,5,-5))
update('D870',s,['42CrMo4+QT certified Rp0.2>=650MPa. Overall254.00+/-0.05, Z-80..174. DatumA common bearing axes, datumB shoulderZ-5. JournalsZ-21..-5 and95..111:29.995..30.000,Ra0.4,cyl0.005. ShoulderOD36.10+/-0.02; radius<=0.4, no cage contact.',
'FrontM30x1.5-6g declaredZ-30..-21; complete teethZ-29.5..-22.5, bearing-end reliefZ-22..-21 diameter29.10+/-0.05. RearM30x1.5Z111..125; complete112.5..124.5, relief111..112. Thread roots symbolic in STEP; inspect with ring gauge and axial complete-tooth witness.',
'GearZ20..78.5 and couplingZ-80..-37:30h7,Ra0.8. OutputZ125..174:30h6; keyseat8N9 width, floorY11.00+/-0.03, Z132..164,32 length; end radius4 permitted with matching rounded key. EndM8-6H axial tap effective20 fromZ174; drill6.8 depth24. No wet-axis change.',
'Integral shoulderZ-5..0. Gear/spacer stack unchanged. D894 ringZ119..128 seats against rear locknut; input hub seatsZ128..174, terminal M8 screw captures it. Remove input hub andD894 before rear nut tool. Verify six complete M30 teeth-length mm minimum; do not count chamfers.'])
for pn,z,L in [('D871',0,20),('D872',78.5,16.5)]:
 update(pn,ring(36.1,30.2,L),[f'42CrMo4+QT. OD36.10+/-0.02 (min36.08>=NSK36), ID30.20+0.05/0, length{L:.2f}+/-0.005; localZ0..{L}; assembledZ{z}..{z+L}. Faces flat0.005,parallel0.01,Ra0.4. Inner edge relief0.4max; do not contact cage. Grind faces; measure each piece. Datum bore axis and bearing face.'])
# One nut definition, bearing-side counterbore. Rear instance reversed.
s=S['D873'].cut(b.cyl(30.2,1.01,(0,0,7)))
update('D873',s,['42CrMo4+QT; OD45, thickness8.00+/-0.03; M30x1.5-6H through nominal minor28.38; complete internal teeth localZ0.5..6.5. Bearing-side counterbore30.20+0.05/0 localZ7..8; 0.5 transition/incomplete tooth at6.5..7. Datum bearing faceZ8, flat0.01,Ra0.8.',
'Front instance originZ-29,face+Z at-21. Rear instance originZ119,axis-Z,face at111. Each conservative full tooth engagement6.0mm. Front permitted overlapZ-29..-22, rear112..119 only; no whole-PN interference exemption.',
'Four3x5 radial slots per STEP. M4 radial locking brass-tip screw, effective6, drill3.3; torque nut30+/-3Nm to solid inner stack, then M4 lock0.8Nm and witness. Not a bearing preload setting. Tubular tool installed beforeD894/output hub; inspect locking tip and removal access.'])
for q in O:
 if q['pn']=='D873' and q['o'][2]>0:q['o'][2]=119;q['v']=[0,-1,0];q['n']=[0,0,-1]
for pn,z,L in [('D874',-25,4),('D875',88,4)]:
 s=S[pn]
 for x in [0,165]:s=s.fuse(ring(56,55.9,L,z).translate((x,0,0)))
 notes=[n.replace('shoulderthroughhole56+0.05/0','shoulderthroughhole55.90+/-0.02').replace('filletR0.5max','filletR0.4max').replace('Rp0.2 >=355','Rp0.2 >=345') for n in pm[pn]['notes']]
 notes+=['R14 bearing shoulder bore55.90+/-0.02,max55.92<=NSK56. Bore62.000..62.015; corner radius<=0.4. No drawing scaling; coordinate bores in one clamping. S355JR 20/23mm stock: minimumyield345MPa unlesscertifiedhigher. Generaloutline+/-0.2, holes+0.2/0,coordinates+/-0.1 except165+/-0.015 centres andcoax0.010.']
 update(pn,s,notes);pm[pn]['material']='S355JR, thickness-dependent minimum yield345MPa, certificate'
for pn,L in [('D876',6),('D879',6.7)]:
 s=S[pn].fuse(ring(56,55.9,L))
 notes=[n.replace('ID56+0.05/0','ID55.90+/-0.02').replace('ID56','ID55.90+/-0.02') for n in pm[pn]['notes']]
 notes+=['R14 contact opening55.90+/-0.02, actual max55.92<56; radial corner<=0.4. Inner spacer maxOD36.12 leaves9.89mm minimum radial clearance. Confirm bearing wide/narrow side from supplier marking; proxy annulus is not a rolling-race section.']
 update(pn,s,notes)
update('D877',ring(61.98,55.9,3),['42CrMo4+QT ground outer adjustment ring. OD61.97..61.99, ID55.90+/-0.02; nominal3.000,select2.8..3.2 in measured0.01 increments,finishselected thickness+/-0.005,facesparallel0.005. LocalZ0..3; assemblyZ92..95. Cold20C axial endplay10..30um at+/-20N only. Record all actual thickness/temperature. No hot preload qualification.'])
# Preserve released SP01 BRep exactly; adopt signed process overrides.
f01=json.loads((b.ROOT.parent/'R14_INPUT/signed/SP01_PROCESS_OVERRIDES.json').read_text())
for q in f01['parts']:
 p=pm[q['pn']];p['material']=q['material'];p['status']=q['scope'];p['process_revision']='R13-L1-F01';p['notes']=['Geometry and manufacturing requirements governed by signed SP01 R13-L1-F01 four-page PDF; original BRep unchanged. Already released quantity1; DO NOT ORDER AGAIN. Unloaded dimensional preparation only.']
# Enlarged36.1spacer requires lower nominal shim to retain bottom contact.
for q in SR:
 if q['pn'] in ['TF881L','TF881R','TF882']:q['o'][1]=.20
 if q['pn']=='HW_R13_M5X40' and q['o'][1]>0:q['o'][1]=25.20
s=b.box(70,.20,8).translate((-35,0,0))
for x in [-27,27]:s=s.cut(b.cyl(5.5,2,(x,-1,4),(0,1,0)))
update('TF883',s,['304L shimstock70x8x0.20 nominal; two5.5 holesX+/-27,Z4. For36.10spacer, borecentreY0.20 gives nominal lower contact and upper0.40mm clearance. Select0.10..0.50 aftermeasurement; never pullshaft down withcap. Recordshim to0.01.'])
for pn in ['TF881L','TF881R','TF882']:
 pm[pn]['notes']=[v.replace('0.25','0.20').replace('OD36spacer','OD36.10spacer').replace('nominal0.5mm','nominal0.4mm') for v in pm[pn]['notes']];pm[pn]['revision']='R14';pm[pn]['status']='SP02_COLD_FABRICATION_CANDIDATE'
b.dump(b.OUT/'native/R14_PARTS.json',P);b.dump(b.OUT/'native/R14_P_CORE_OCCURRENCES.json',O);b.dump(b.OUT/'native/R14_SERVICE_OCCURRENCES.json',SR)
b.dump(E/'R14_CORE_CONTRACT.json',dict(front_thread_complete=[-29.5,-22.5],rear_thread_complete=[112.5,124.5],nut_complete_local=[.5,6.5],minimum_engagement_mm=6,shaft_abutment_min_mm=36.08,housing_abutment_max_mm=55.92,physical_planes=[-13,103],catalogue_a_mm=27.3,loadline='Reference face/orientation confirmation required; physical planes used in current static screens. No unqualified a offset.',thermal='Withdraw R13 scalar gap-deltaL binding claim. DB axial inner-spacing growth relieves preload; radial inner-ring growth increases preload. Cold-only manufacture; combined hot contact not solved.'))
print('R14_CORE',len(P),len(O),len(SR),flush=True)
