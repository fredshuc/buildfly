# R19-L1-F06 / prototype fabrication and weld-process release

## Supply and permitted work

Use the existing material. Convert the 13 F05 S0 targets (40 pieces). Prepare the edges of eight existing P104/R104 pieces. Make P100F, P100B, R100F and R100B once each, subject to the coupon and first-piece checkpoints in the released PDF. Two existing TF921 rails receive groove preparation. Four TF927 sleeves and four TF926 retainers remain the existing pieces.

No new set of 48 pieces is ordered. Weld assemblies are process operations on their listed components. The 82 tool positions are not 82 tools to purchase. Prior F04/F05 material and rotor/riser releases remain in force for their stated uses.

This issue permits machining, process coupons, welding after the stated checkpoints, paired post-weld finishing and factory dimensional inspection. It does not permit valve-weight support on the new stand, spring preload, torque/pressure/thermal tests, lifting qualification or installed operation. Use separately suitable shop fixtures and handling equipment for fabrication itself.

## File priority

1. F06 release pages and `R19_L1_F06_PROCESS_AND_SCOPE_OVERRIDES.json`.
2. Current released shell and WS17 PDFs.
3. Named current STEP and PROFILE_ONLY DXF, interpreted with the groove and process sections.
4. Prior F04/F05 files only for their identified inherited parts. Their old weld routes do not override F06.

The original geometry is unchanged in F06. PREWELD is the machining/preparation state. FINAL_PARTITION is the intended finished material envelope; do not install both. A fusion partition is not proof that a real weld is fused. Coupon sections and first-piece inspection provide that evidence.

## Required checkpoints

Record actual materials and thicknesses, groove/root dimensions, actual WPS and tooling, sectioned weld coupons, finished wall/throat dimensions, free-state distortion, hole axes and matched-pair identity. Start product welding only after the applicable coupon succeeds. A qualified first-piece route may continue without another design iteration when all written checks pass. Stop on nonconformance or a proposed design/process-window change.

For the shell, full fusion means full actual wall thickness; minimum retained wall is 2.90 mm. For WS17 sleeve rings, the minimum effective throat after flush finishing is 1.30 mm and the remaining rail wall is at least 2.80 mm. These are different joints and require their own process records.

M3 nut coverage of 4.00 mm is a nominal envelope dimension. Confirm the actual usable threads and prevailing-lock feature before final tightening. Current tool envelopes exclude the handle and hands. Use the stated externally supported first-assembly sequence; do not remove a loaded gland to obtain tool access.

Send actual revision, material heat, measurements, coupon/WPS records, photographs of any deviation and the proposed disposition. No purchase, machining or test completion is presumed by this file.
