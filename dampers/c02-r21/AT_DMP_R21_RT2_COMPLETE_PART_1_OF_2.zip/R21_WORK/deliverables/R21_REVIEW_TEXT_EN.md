# AT-DMP02 R21 P1 manufacturing and RT-2 review

## 1. Decision boundary and the smallest remaining work
R21_P1_MASTER_AND_RT2_REVIEW_PACKAGE_READY. This package contains the current P1 manufacturing entry and two actual cold-test configurations. It is not P1_COMPLETE, a rated valve, or permission to apply torque, pressure, preload, heat or a lifted load.
Available now | Still required before the dependent use
E01/F01-F07 named machining and conditional weld stages; F07 adds13 product PN /144pieces. | Actual shop fixtures, positive rotor capture and witnessed load transfer to qualified receiver/ground chain.
172PN/allocation entries and243 current inherited drawing pages; exact STEP and process provenance. | 88 current gap rows:67 procurement contracts,12 feedback product/capture,6 product interfaces,2 films and1 custom fastener definition.
F06 same-stock shell/WS17 processing; J401/J407 matched press and finish-bore perF07. | Film end-lip retention, G1/stop/receiver/seal compliance and separately qualified test instrumentation.
Factory and measured status remain UNCONFIRMED. Stable parts need not wait for life or cosmetic optimisation. | Obtain actual material, coupon, first-piece and dimensional returns. Do not write estimated PASS results.
R21 changes no installed BRep or placement. One accounting omission is corrected: F05 already issued the single G903_R18 replacement, previously hidden by a G903 index alias. Configured credit is689, unissued1576. No new guard, commercial order or use authorization is created.

## 2. Design intent and the factory contract
The P valve uses two parallel rotor axes at165 mm centres; the R valve uses one. Three finished rotor assemblies are needed across the two products. Wet shaft/seal interfaces stay separate from the dry short-shaft support, purchased coupling and finite input chain. The dry support box aims to reduce gear-centre and angular disturbance without making the gland itself carry every overturning load.
Current wet shaft diameter is30 mm; the two bearing-land centres are667 mm apart, whereas the wall-face separation is637 mm. The compactness target has been relaxed for P1: external dry support, removable receivers, shims and replaceable adapters are allowed. These arrangements still require real load paths and capture. A CAD proxy of a coupling or actuator is not a manufactured interface approval.
Manufacturing assumptions are conventional cutting, drilling/tapping, local milling/turning, controlled welding, matched machining and inspection. Supplier capability is not presumed from nominal one-week turnaround. Confirm actual machine envelope, fixture access, bore alignment, material certification, WPS/coupon capability and metrology. If a critical capability is absent, outsource that named process or return the interface for revision; do not silently relax fits or hand-grind journals, seal tracks, full threads or capture surfaces.
Material / process | Project control
Wet structure | 304L / EN1.4307 per released page; weld same-material/thickness coupons and inspect first P and R free states.
Dry supports / shaft parts | Use each page material/heat treatment; S355JR thickness-dependent yield and42CrMo4+QT requirements cannot be replaced by generic mild steel.
Soft material | Free EPDM/foam/PTFE thickness differs from installed compressed CAD. Cut only the released free-state pattern. Film cutting remains HOLD.
Purchased drive / instrumentation | Exact manufacturer version and interfaces required. Actuator remains an external supplier placeholder; no final electrical pinout or machine control qualification is asserted.

## 3. P complete current cold-test configuration
1506 actual placed native instances are shown; products, purchases and the common facility are all retained. Open step/R20_P_COMPLETE_COLD_REFERENCE.stp separately. P and R are sequential alternatives, not simultaneous loads or duplicate common frames.
The STEP and native assembly bytes are inherited unchanged from R20 with exact hashes and independent R20 readback evidence. R21 generated these views from all placed native solids; it did not rerun complete interference or loaded histories. Internal detail must be examined in CAD.

## 4. R complete current cold-test configuration
1073 actual placed native instances are shown; products, purchases and the common facility are all retained. Open step/R20_R_COMPLETE_COLD_REFERENCE.stp separately. P and R are sequential alternatives, not simultaneous loads or duplicate common frames.
The STEP and native assembly bytes are inherited unchanged from R20 with exact hashes and independent R20 readback evidence. R21 generated these views from all placed native solids; it did not rerun complete interference or loaded histories. Internal detail must be examined in CAD.

## 5. Coordinate frames, loads and evidence limits
Definition | Exact boundary
P installed to P_TEST_O1PRIME | x_test=-z_inst+1451; y_test=y_inst; z_test=x_inst+2022. Inverse is stored in native/R21_COORDINATE_FRAMES.json.
R installed to R_TEST | Identity for retained product coordinates; additional test supports are distinct facility components.
Common dry local frame | Origin(-82,-970.5,1583); u=(1,0,0),v=(0,0,1),n=(0,-1,0). Global=origin+uX+vY+nZ.
Axis checkpoints | P1 X83/P2 X-82; R X-82; all test axes Z1583. Axial direction is global-Y. Wet s=-726.5-worldY.
Named historical inputs | Normal P78Nm/R38Nm; jam200Nm and selected pressure/leaf-contact rows are calculation inputs, not permitted operations. Screening0.10mm centre change/1mrad angle is project screening, not vendor whole-machine rating.
Orientation restriction | P O1prime changes gravity relative to installed product. Test feedback, seal and hot behaviour cannot automatically qualify original orientation. There is no approved lifting/flipping procedure.
Coupling of diagnostics | R14 two-plane support and R15 wet/radial and far-normal histories have different prescribed/surrogate boundaries. They are not a jointly equilibrated thermal-contact model.
Historical full-valve hard-intersection counts9/9/23/23 remain historical. R19 closed the specified204 weld-neighbour relations; that is a separate scope and does not erase the older full-valve register. No whole-valve zero-collision or G1 acceptance is claimed.

## 6. One current manufacturing entry, with explicit precedence
Priority / file | How to use
1. tables/R21_CURRENT_FACTORY_ENTRY_INDEX.csv | 172PN+allocation rows. Use the exact packet and current_PDF_pages. The same PN in independent station and product scopes can have different quantities and process instructions.
2. factory/R21_CURRENT_ISSUED_PAGES.pdf | 243 pages:214 exact R20 current-source pages plus29 signedF07 pages. No wholesale redrafting. Shared page applies only to indexed PN/allocation.
3. Mandatory process scopes | F06 process corrections govern actual shell/WS17 welds, wall thickness and thread acceptance; F07 product pocket thickness and product144piece allocation override old SP06 candidate notes.
4. Exact geometry changes already accepted | F05 continuous P110/R110 U-frames supersede disconnected scraps; G903_R18 is the one replacement, not an extra original G903. H03/F02 scopes and independent F03 remain as signed.
5. Native and complete STEP | Accurate review geometry. Some catalogue notes are historical; native/R21_METADATA_OVERRIDES.json points to current manufacturing authority. A whole STEP is not a blanket machining release.
6. Original issued ZIPs | Read-only provenance under factory/reference_issued_archives_DO_NOT_BATCH_PRODUCE. Do not extract every stock/process state as another material order.
Use PDF viewer page indices from current_PDF_pages; printed original page numbers are retained as provenance. RAW / PREWELD / FINAL_PARTITION / FREE are manufacturing stages or free material. A labour assembly and its child stock must not both become raw material orders. Tool poses are not tool quantities.

## 7. Quantity reconciliation and the corrected guard identity
Metric | Current value | Meaning
Stage issued names / pieces | 161 /822 | Named manufacturing stages; not manufacturing completion.
PN + allocation entries | 172 | Separate product and independent specimen uses.
Current configuration identities / net BOM rows | 2265 /220 | Deduplicated sequential common facility; includes3 rotor labour nodes.
Named released-use credit / unissued identities | 689 /1576 | Scope credit, not received or tested parts.
Gap rows | 88 | 67procurement;12feedback product/capture;6product interfaces;2films;1custom fastener.
Guard correction | +1credit, -1gap row | F05_ISSUED_STAGES.csv explicitly G903_R18 quantity1 REPLACEMENT. Actual P/R each use same sequential common guard. Current STEP hash matches F05 byte-for-byte.
Before this accounting correction | 688 /1577 /89 | L1 F07 starting view, preserved as source. No design change or new release was needed.
F06 converts13S0 definitions/40existing pieces and prepares8existing P104/R104 pieces; it does not buy48more blanks. Three rotor labour nodes use6B201 blades and3shaft blanks. R100S uses2R112+2R113. WS17 is one common frame with50weld records. TF908 issued quantities6+4=10. B01/E01 and SP04 specimen stock is not automatically credited to installed products.

## 8. Functional completeness 1 / 2
Function | Manufacturing definition | First assembly / use boundary | Next action
Shell and R100S | F05/F06 manufacturing stages issued | Coupon + first P and R shell unclamp/match/post-machine gates; fixture acceptance missing; Pressure and operational leakage not released | Same-material restrained coupon sections and recorded first-piece dimensions
Three B200 rotors | F05 6 blades +3 shaft blanks; 3 labour identities not extra material | Finished journal and positive external capture acceptance required; Wet loaded rotation not released | Inspect each welded/finished shaft and qualify external cradle/end catch
Six glands and thrust | F07 13MAKE144; four BUY families183 supplier HOLD | Matched J401/J407 process released; fixed/floating allocation explicit; unloaded support only; Preload, torque, hot and rotor load transfer HOLD | F07 inspection then exact purchased seals/springs and actual station checks
Dynamic foam/PTFE/U-frame | Foam/shims and one-piece frames retain signed scopes; films4P+4R not cut-released | Film end lip/corner retention known gap; Seal motion/leakage/life HOLD | Retained end-detail before film release; blank uncut PTFE stock only if ordered separately
Short shaft/bearings/couplings | F01/F02/F04 machining scopes plus functional supplier confirmation | Match bores/shafts and captures; G1 compliance unresolved; Normal78/38 Nm and jam200 Nm not qualified operations | Actual bearing/coupling identity and measured supported compliance
Availability of a manufacturing page, a completed part and an accepted loaded function are three different states. Missing performance evidence does not recall unrelated issued pieces. Known geometry/capture failures still stop their dependent operation.

## 9. Functional completeness 2 / 2
Function | Manufacturing definition | First assembly / use boundary | Next action
Input/limiters/stops | Finite input architecture and manufactured adapters; purchased units unconfirmed | Independent support and stopped/isolated fitting only; Dynamic peaks and stop deflection HOLD | Exact limiter calibration and combined support/stop acceptance
Guards/feedback root | A01/A02 panels issued; product roots/feedback capture remain specific gaps | No powered motion before capture and hand-access closure; Feedback accuracy and thermal retention HOLD | Close root-specific receiver and independent capture; reuse stable panels
Shared dry frame/WS17/receivers | Sequential common facility; F06 50-weld fabrication only | Ground anchors, foot contact and full valve transfer not qualified; Valve weight/preload/torque HOLD | As-built floor/anchor/frame and dedicated transfer proof
Assembly and measurement tools | Issued local tools and independent SP04/B01/E01 allocations | Actual shop platen/capture and complete handle trial absent; SP04 four-channel proposal only | Fixture and instrumentation acceptance records, surrogate stop/overshoot checks
Availability of a manufacturing page, a completed part and an accepted loaded function are three different states. Missing performance evidence does not recall unrelated issued pieces. Known geometry/capture failures still stop their dependent operation.

## 10. Targeted manufacturing requirements: wet stations
Item | Current instruction / inspection
F07 product quantities | J401,J402_FREE_R15,J407 each6;F60424;J403,J404,STD05B,A709 each3;J4066;J405,STD03C,STD04C each12;J40848. Total144.
J401/J407 | Matched press fit and post-press finish-bore are issued manufacturing processes. Measure seat, select bushing OD per signed page, keep pair serial, inspect bearing land/relief and finish. No force inferred from press fit alone.
J404 | Total4.00+/-0.02; pocket1.50+/-0.02. Worst dimensional subtraction2.46; actual local remaining metal>=2.45mm, including form error.
A709 | Total6.00+/-0.02; pocket1.50+/-0.02. Worst dimensional subtraction4.46; actual local remaining metal>=4.45mm. Current roundD48 opening and continuous seats; no new thrust or feedback-load qualification.
J402 / F604 | J402 free0.80+/-0.10mm, installed nominal0.50 with actual hard-stop/gap verification. F604 is wall/gasket hard stop, not an interchangeable dry spring washer.
Spring stack | Each of24heads: two groups of3parallel SCHNORR002700A, groups inseries; J408 hard seats at ends.144springs; do not substitute feedback001500A. Old one-group3disc/dry1.6washer instruction withdrawn for this scope.
Tightening boundary | Historical1450-1470N and CAD compression heights are not tightening commands. Preload/reverse-play/torque/hot tests require separate acceptance.

## 11. Targeted manufacturing requirements: welding and threads
F06 manufacture may advance through explicit stops; the shop need not wait for all long-term valve performance data. The actual joint and demonstrable procedure control the welded result. CAD fusion layers establish material placement, not physical fusion quality.
Process | Mandatory retained condition
304L half-shells | Same material, measured wall, restraint and orientation coupons for J1/J2 ends and J3 corners; include starts/stops, turn and nearby end holes. Macrosection must show full fusion through actual measured wall. VT/PT alone cannot prove a hidden root.
Thickness / preparation | Plate3.00+/-0.10mm; final parent>=2.90. Prep2.50+/-0.05 and root0.50+/-0.05 must sum consistently with actual wall, not independent incompatible extremes. Stop if the joint window cannot be met.
First P and first R | Cool/unclamp and record free flatness, diagonals, windows, holes and remaining finish allowance separately. Match/pair and post-machine only under signed requirements. No forced closure by structural studs.
WS17 rails | TF921L localX20, TF921R X60;Z185/405. D24x2deep preparation, measured remaining wall>=2.80; flush full-circle effective throat>=1.30. Independent correct-steel coupon, not304L substitution.
WS17 TF926 | Actual lowera4x60 plus two sidesa4x20; no imaginary top weld.50total routes. Weld fabrication is not valve-weight or anchor acceptance.
M3 interface | 4.00mm nominal overlap does not prove complete thread. Inspect full engagement, chamfer/first-full-thread, locking zone and>=2complete pitch protrusion. No new tightening torque issued.

## 12. Thin-film branch: topology improves, retention remains open
The only R21 geometry branch converts the tangent endD5 holes to deliberately open slots without shrinking hole radius. P and R diagnostic imports are valid, one solid, general DXF audit clean and bidirectional material difference0. Each removes1.341261mm3 from the inherited0.25mm film. This diagnostic is excluded from factory files and is not installed in either complete configuration.
Actual F05 frame spans film-localX0..46.774, behind the film atZ-1..0; foam extendsX0..87 atZ-4.45..0. Its nominal metal shadow in each full87x5end strip is224.7908mm2 of435mm2. This is a partial projected support diagnostic, not clamping force, continuous capture, peel strength or a motion test. The remaining end region is not closed by restoring disconnected metal scraps.
Second decision: stop this branch. A connected retained end interface or exact sufficient existing capture proof is needed before a final cutting candidate. No0/45/90 or control-angle motion qualification was run for the rejected variant. Old and diagnostic DXFs remain non-production; only uncut PTFE stock can be considered pending a signed contour.

## 13. First cold assembly: A0 to A1
A0 / Matched shell manufacture
Support / retain | Tool, exit and stopping condition
F05/F06 exact child stock; independent shop platen and restraints No rotor/soft seal installed; retain platen clamps until cooled and stable | Weld tool then actual M3/M6 tool trial; F06 coupons, macrosections, first P and first R unclamped measurements; pair post-machining on defined spacers STOP: Shop platen/fixture rating and clamp-release trial missing; no WS17 load credit
A1 / Rotor preparation and fixture acceptance
Support / retain | Tool, exit and stopping condition
Each finished B200 on two non-seal D30 10mm bands; captive yokes + bilateral independent end catches; no grip on blade, BK2, seal track Maintain two lateral restraints and bilateral axial capture; support each shell separately | Serial, journal, endplay component and fixture acceptance before fitting glands; install threaded-through components before closing obstructing catches where possible STOP: Actual independent fixture identity, connection and catch geometry not supplied; STOP before rotor handling under this procedure

## 14. First cold assembly: A2 to A3
A2 / Fixed and float end threading
Support / retain | Tool, exit and stopping condition
Main cradles stay locked. If a gland must cross a cradle/catch, a second qualified capture/support path engages before opening the first J401 on both ends, fixed J403/STD05B/pins and necessary studs retained once installed; A709 is not thrust stop | Sequential individual gland/pin installation; witness both new support and catch before release of any obstructing clamp STOP: Alternate support/catch must be demonstrated with dimensional surrogate; no moment with one unqualified support or free axial rotor
A3 / Pair shells and thin-head access
Support / retain | Tool, exit and stopping condition
Separate qualified half-shell supports plus rotor captures carry weight Retain J401/J404/A709 and required pins/studs; do not use studs to straighten shell | Counterhold24 STD03C/STD04C heads with D542 at0,5,10,15,20,25mm recorded outward positions; TF903 and listed foam/shims absent during this stage STOP: 144 positions inherited geometry only; no continuous/hand/torque/preload permission

## 15. First cold assembly: A4 to A5
A4 / Soft seals and body hardware
Support / retain | Tool, exit and stopping condition
Rotor/shell external supports remain After tools exit, install exact later-member lists; never remove loaded studs | F07 free J402 and issued foam/shim dimensions; actual gap controls compression; P109/R109 film route HOLD. Nine named body tool obstructions fitted after tool removal STOP: Film cannot be represented as finished seal; missing retained end detail stops seal-complete assembly, not bare dimensional mating
A5 / Cold assembly move to receiver
Support / retain | Tool, exit and stopping condition
Qualified receiving support and independent safety catch both attached before donor support unloads Donor supports stay available; dry/input subgroup independently supported; retain all wet captures | Match TF920P/R, TF921-927, TF908 and actual flange; witness contact, anchor and reaction acceptance before any donor load reduction STOP: Full wet assembly mass/CG and as-built support proof required; current complete reference masses include facility and are NOT lifted payload

## 16. First cold assembly: A6 to A7
A6 / Dry connection, input and protection
Support / retain | Tool, exit and stopping condition
Independent dry unit support and locked finite input; actuator remains purchased placeholder Install short shafts/bearings/couplings/stops and guard; feedback/root capture independent of sensor | Use current F01/F02/F04/F05 drawings and exact purchased interfaces; inspect disengaged/isolated assembly, complete threads and actual tool/hand access STOP: G1, receiver/floor/seal compliance, dynamic stop, root capture and supplier contracts remain use-specific HOLD
A7 / Dimensional inspection and subsequent application
Support / retain | Tool, exit and stopping condition
Maintain qualified supports and isolation; no reliance on feedback signal for safety No removal of primary supports merely because dimensions pass | Record serial/current revision, journals, gaps, seats, actual thread engagement and tool withdrawal. Submit separate SP04 or valve test application STOP: No torque, preload, pressure, hot operation, lifting or maintenance release by R21

## 17. External rotor fixture: an enquiry specification, not a built tool
Each rotor nominal mass6.185329kg and CG Y-430.6097; D30 bands are10mm long atY-813/-35,778mm apart. P axes are165mm apart; all test axesZ1583. Separate positive axial catches must restrain both directions without friction-only credit. Wet load selection500N transverse/250N axial is distinct from short-shaft200/50N tooling.
Minimum selection requirements: each station>=600N resultant transverse and>=300N bilateral axial; system>=1000N transverse/>=500N axial. Supplier must evaluate combined force, moment, self-weight, attachment/platen and alternate support state, not independently quote two scalar ratings. These numbers are not measured capacities.
Required delivered evidence: dimensioned support/yoke/end-catch and attachment; lock retention; non-damaging contact; material/rating/proof record; actual full-gland threading trial with alternate catches engaged before any primary release. No fixture has been selected or qualified. Current complete P/R masses623.064703/591.568630kg include facility; they are not payloads for a move or lifting permit.

## 18. SP04 controlled measurement application 1 / 2
Item | Required implementation | Still absent
Four independent force channels | Four calibrated0..2kN minimum head channels, displayed and recorded separately; resolution<=5N proposed. Traceable in-situ force path calibration including hard seat and alignment. No total-force divided by4. | Actual model/serial/range/calibration not received
Uncertainty and head threshold | Report standard uncertainty uc from calibration, alignment, drift, thermal, resolution and sample timing; expanded U=k*uc with declared k and coverage basis. k=2 approx95% only when justified. Ftrip_i <=1800-U_i-O_i-M_i N. Use worst credible simultaneous-channel uncertainty. | U and coverage not established;1500N trip/1400N plan are examples only
Dynamic overshoot and finite input | Measure worst O_i after trigger for real actuator stiffness, speed, stored energy, sampling/latency and channel fault using safe surrogate. Independent hardware trip any channel plus mechanically limited stroke and positive capture. Static stop alone does not bound force overshoot. | Actual force/stroke devices, energy limit and surrogate evidence missing
Channel or power failure | Dropout, saturation, stale sample or any trip stops energy input to all heads. Maintain mechanical capture/restraint without power; do not automatically release the failed head while other3 remain loaded. Barrier stays closed. Recover redundant calibrated force/displacement indication before controlled unloading. | Failsafe restraint and independent trip architecture need equipment proof
No equipment is operated by this task. F03 is a fabrication scope. This application requires actual devices, independent protection and a separate signed test permit; it does not permit even a nominally small torque or force trial.

## 19. SP04 controlled measurement application 2 / 2
Item | Required implementation | Still absent
Displacement and protection | Four local displacement channels range>=5mm/resolution<=0.01mm proposed; common synchronized record. Captive TF912 mandrel and independent enclosure contain credible released pieces; stand and shield must be rated for actual stored energy. | Stroke collision limit, stop loads, enclosure material/attachments not qualified
Loading and progressive unloading | Only after separately signed permit. Establish zero with capture active; incremental synchronized loading and dwell while watching each head. On normal unload reduce all four in small recorded rounds, maintaining validated imbalance bound. Any unexplained jump/asymmetry: stop and retain; no one-head sudden release. | Step/imbalance/energy acceptance to be set from surrogate capability; no test conducted
Evidence and disposition | Record serials, time, four forces/displacements, temperature, max/min/imbalance, trigger and stop timestamps, overshoot, residual loads and damage inspection. Failed run quarantined; cause and revision reviewed before restart. | Application only; F03 fabrication is not test authorization
No equipment is operated by this task. F03 is a fabrication scope. This application requires actual devices, independent protection and a separate signed test permit; it does not permit even a nominally small torque or force trial.

## 20. Procurement and mechatronic interface requests
tables/R21_PURCHASE_TECHNICAL_ENQUIRIES.csv contains71family/PN rows with inherited feature contracts, material/grade and net quantity.67current missing-scope rows are procurement contracts, not67new mechanical defects. These are drafts for review; no supplier message, quotation, order or lead time is invented.
Enquiry group | Required response before dependent use
Standard fasteners / small hardware | Exact standard/product code and revision, pitch/tolerance, full-thread length and first-thread/chamfer, grade/hardness/coating, washer thickness, locking geometry and samples. CAD envelope or kind=BUY is not interchangeability.
Gears / bearings / couplings | Actual manufacturer drawing, bore/shoulder/face and fit, stiffness/misalignment, duty and temperature, lubrication and mounting instructions. CAD proxies are interfaces, never internal manufacturing drawings.
Primary and independent second limiter | Exact range and reset behaviour; bidirectional static calibration and dynamic peak for actual speed/inertia; independence under one failure. Old nominal settings remain requirements, not commissioned values.
Springs and elastomers | 002700A wet versus001500A feedback batch identity; complete stack curves/hysteresis/relaxation and guide geometry. EPDM formulation/dimensions/water/temperature/compression set traceability.
Feedback / external actuator | Actual electrical supply/output/pinout, encoder shaft/root/coupling and end limits remain supplier interfaces. Isolation, independent finite input/stop and fault detection must not depend solely on unverified position feedback.
Instrumented station | Four force and displacement channels; traceability, uncertainty, latency, failure state, trip/finite stroke and actual guard energy capacity. No expensive instrument purchase is authorized here.

## 21. RT-1 to RT-2: what changed and what did not
RT-1 issue | Current disposition
Guard/columns, stop key and test posture | R17 moved the named dry interfaces, providedD886 phase/key definition andP O1prime. R18 replacedG903 and defined actual stop contact50..80mm. Cold geometry evidence does not bound deflected clearance or dynamic stops.
R wet support / P retained receiver | R17 actual TF920-927/TF908 frame replaces retired test supports; P107B remains. F06 later defines50weld routes. Ten floor contacts/anchors and actual receiving compliance are not qualified.
P host/root and G843 | Product host uncertainty isolated; trial fixture does not validate original host. Expensive G843 is deferred, not quietly restored as a load-bearing receiver; thin-wall/root counterexamples remain relevant.
Welded shell and tool access | R19 fixes specified204weld intersections and32washer/32nut0.5mm seating errors. F06 clarifies actual-wall fusion and full-thread evidence. Current body-tool after-list has9members, not7.
Supply and measurement | F07 adds144product wet pieces. SP04 andB01/E01 remain independent specimens. R21 exposes exact scopes and device evidence rather than claiming favorable unknown parameters as measured.
Maintenance / optimisation | First assembly is separated from rear plate85mm and input/bearing removal. Capture handoff is still missing. P2 compactness/cost changes remain secondary to evidenced P1 faults.
The original ten RT-1 findings and L1 dispositions are included under history/RT1_L1_DISPOSITION. No new external review was commissioned by this task.

## 22. RT-2 decisions 1 and 2
RT2-01 / CONDITIONAL_MANUFACTURE_OR_MEASURE / Manufacturing master / all172allocation entries
Do the current pages and material/labour quantities define the issued work without double stock or specimen credit?
Evidence / counterexample | Requested decision
F07 adds144 products; G903_R18 alias now credited once underF05. 161stage names822pieces,2265config identities. Sources: R21 index/net BOM; F06/F07 overrides; original signed archives | Approve scoped manufacture or identify exact PN/page missing, not a blanket completeness percentage.
RT2-02 / CONDITIONAL_MANUFACTURE_OR_MEASURE / F06 four shells, three F05 rotors, WS17
Are real joint preparations and stop records adequate to proceed with coupons/first-pieces?
Evidence / counterexample | Requested decision
204 historical shell weld collisions closed inR19/L1 review; actual full-thickness fusion still needs section evidence. WS17 has50weld routes. Sources: F05/F06 signed drawings, R19 geometry/weld evidence | Specify missing joint or measurement; preserve stable machining and coupon work.

## 23. RT-2 decisions 3 and 4
RT2-03 / MUST_FIX_BEFORE_NAMED_USE / First rotor support and full assembly transfer
Can a selected fixture maintain two-point support and bilateral capture while each gland crosses its supports, then transfer to the actual ground chain?
Evidence / counterexample | Requested decision
D30bands and selection loads exist; no real capture device/platen/anchor proof. Complete test configuration mass is not payload. Sources: R21 fixture spec and stages A1-A5; R20 actual CG/support records | Require actual fixture/attachment/alternate-catch trial before handling or transfer; do not cancel loose parts.
RT2-04 / MUST_FIX_BEFORE_NAMED_USE / G1, D878/D886, G900-902 and limiters
Which minimum combined support/stop evidence permits intended finite input?
Evidence / counterexample | Requested decision
R14 P_driven_jam/bench k25000/20000: relativeX0.109827mm, transverse vector norm0.323603mm and angle norm0.484775mrad; not a pure centre-distance change. Other cases are separate named rows. R17 stop0.243898/0.351214deg are ideal/conservative screens; suppliers unconfirmed. Sources: R14/R17 diagnostics and exact purchased interfaces | Name stiffness/stop/limiter acceptance before planned torque; no fresh favourable unmeasured spring assumptions.

## 24. RT-2 decisions 5 and 6
RT2-05 / CONDITIONAL_MANUFACTURE_OR_MEASURE / Six wet stations J401-J408/J404/A709
Are F07 matching/finish inspection and fixed/float allocation sufficient for unloaded mating while coupled load/thermal proof stays open?
Evidence / counterexample | Requested decision
F07 remaining metal2.45/4.45measured; two3parallel groups inseries;1000Nproxy canreachzero contact inhistory. Sources: F07 signed pages; R15 signed wet/contact diagnostics | Separate machining approval from preload/load/hot use; name required actual measurements.
RT2-06 / MUST_FIX_BEFORE_NAMED_USE / P109/R109 and P110/R110 seal ends
What smallest connected retained end detail permits film cutting/installation and later motion?
Evidence / counterexample | Requested decision
Old tangent DXF invalid. Open-slot diagnostic imports valid withzero materialdiff but actual endframe shadow224.7908/435mm2; no end-lip capture demonstration. Sources: R21 exact diagnostic, baseline film/foam/frame placements; F05 continuous frames | Do not cut old or diagnostic film. Decide one removable keeper/contact detail or exact sufficient existing capture proof.

## 25. RT-2 decisions 7 and 8
RT2-07 / MUST_FIX_BEFORE_NAMED_USE / A703/A704/B850-B853 feedback root; guards and access
Which product-root capture and hand/tool boundaries must close before powered motion?
Evidence / counterexample | Requested decision
Stable hood panels released; independent B01/E01 not product quantities or accuracy qualification. Hardware/tool pose excludes complete hand/handle. Sources: Native P/R, original release scopes, current classified gaps | Isolate exact root/capture/guard issue; do not recall self-contained stable panels.
RT2-08 / CONDITIONAL_MANUFACTURE_OR_MEASURE / SP04 fixed-end four-head instrumented station
Can the proposed application be qualified using actual devices, uncertainty and failed-channel handling?
Evidence / counterexample | Requested decision
No force/preload permit;1500/1400examples contingent on U/overshoot/reserve. Sources: R21 SP04 missing evidence sheet and F03 specimen pages | Specify minimum surrogate/device evidence and safe progressive unloading before separate test permit.

## 26. RT-2 decisions 9 and 10
RT2-09 / MUST_FIX_BEFORE_NAMED_USE / Input withdrawal / rear plate85mm / bearing locknuts
What support must engage before each connection releases?
Evidence / counterexample | Requested decision
First-build144D542/82body positions do not prove complete maintenance. J401/pins/studs cannot be removed to make room for an unloaded tool. Sources: R14 continuous local envelopes and R20/R21 dependency lists | Defer unqualified maintenance; give one real load-handoff sequence for future acceptance.
RT2-10 / P2_OPTIMISATION / Compactness, special pieces and presentation
Which changes are supported by first-unit evidence rather than assumed lower cost?
Evidence / counterexample | Requested decision
P1 allows external support/adapters/shims; no factory measurements received. Sources: Current module architecture and factory return form | Keep visual/cost/noncritical tolerance changes off current release gates.

## 27. Factory return, failure handling and next minimum actions
No actual factory return was supplied. Use one record per physical version/serial and process: actual revision; material/critical dimension; fit/tool issue; raw measurement file; engineering disposition; P1 supplement; P2 change. Do not convert an unfilled field into a pass. Already issued manufacture may proceed through its exact process gates without waiting for this entire review to become green.
If this happens | Required action
Incorrect material, pocket wall or journal/fit | Quarantine named serial; report actual measurements and instrument uncertainty. Correct drawing/replace part before its dependent assembly. No unrecorded local grinding of critical surface.
Coupon lacks root/sidewall fusion or first-piece distorts | Stop corresponding batch/joint process. Retain coupon sections and free-state measurements. Revise qualified procedure or geometry; do not increase weld volume into tool/fastener interfaces.
Fixture cannot thread a gland with capture maintained | Stop that assembly stage. Provide alternate positive-catch/support arrangement and physical trial; do not remove J401 or pins from a loaded rotor.
Sensor dropout, asymmetric load or overshoot | Stop energy input; retain all captures and shield. No sudden one-head release while others remain loaded. Diagnose with redundant qualified indication and approved gradual unload.
Ordinary standard component uncertainty | Resolve exact supplier interface, sample and grade locally to that item. Do not reopen stable unrelated sheet/shaft manufacturing scopes.

## 28. Evidence manifest, reproduction and final stopping point
The full RT-2 archive includes native BReps and all current placements, both actual complete STEP files, the current manufacturing entry with signed original archives, source/evidence snapshots, and the limited R21 diagnostics. Nothing essential is provided only as an expiring link. No standalone font files are included.
R21 checks: exact input archive CRC/manifest/size/SHA; current page-source text binding; indexed file existence; unchanged native and complete STEP hashes; G903 exact F05 identity; classified quantity reconciliation; film diagnostic DXF validity/solid count/material equivalence. Complete STEP readback and unchanged historical engineering checks are inherited at their stated scope, not claimed as newly executed.
Run source/reproduce_current.py from the extracted R21_WORK tree for current native validity, counts and hashes. Runtime versions are recorded. historical_reproduction contains original two-plane/wet source and minimum inputs for reviewer use; these diagnostic solvers were not run in R21 and cannot establish a combined hot equilibrium. The broader history source snapshots provide context, not a claim that every older script can execute without its entire earlier worktree.
C02 remains PARTIAL / NOT_FOR_MANUFACTURE as a whole. Named existing fabrication scopes remain usable. R21 formal return ends the user-authorized cycle: automation PAUSED, no R22 claim, no further40-minute read and no new red-team window. The user manually transfers the external RT-2 package.
