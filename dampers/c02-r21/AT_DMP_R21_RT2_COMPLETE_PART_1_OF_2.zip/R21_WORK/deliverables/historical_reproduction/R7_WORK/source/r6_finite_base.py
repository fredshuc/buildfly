"""Coupled transverse Euler beam, finite-length radial contact, preloaded gland joints.
N/mm/MPa, mm and radians. Sensitivity model, not a calibrated contact FEA.
Two transverse coordinates share the radial contact law. All contact stations feed
force AND moment into shaft, gland, disc and common receiver unknowns.
"""
import json,math,time
from pathlib import Path
import numpy as np
from scipy.linalg import solve
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'deliverables/evidence'
E=185000.;I=math.pi*30**4/64
MASS_FILE=OUT/'R6_EXACT_ROTOR_MASS.json'
MASS_DATA=json.loads(MASS_FILE.read_text()) if MASS_FILE.exists() else None

def beamk(L,EI):
 return EI/L**3*np.array([[12,6*L,-12,6*L],[6*L,4*L*L,-6*L,2*L*L],[-12,-6*L,12,-6*L],[6*L,2*L*L,-6*L,4*L*L]])

class Model:
 def __init__(self,n=6,gb=.04,gd=.08,kb=100000.,kd=100000.,kr=100000.,krot=1e8,mu=.12,bridge=False,bridge_k=100000.,bridge_rot=1e8,capture_gap=.02,gear_sign=1,secondary=False,throat=True,stop_x=155.5,alpha=0.,preload=1400.,contact=True,near_length=30.,dry_shift=30.,spring_k=4200.,rear_preload=None,gland_length=10.,throat_gap=.1,carrier_E_factor=1.,clamp_k=1e6):
  self.par=locals().copy();self.par.pop('self');self.par['model']='R1_BASELINE' if not bridge else 'PROPOSED_DRY_RECEIVER';self.stations=[]
  bf=np.linspace(10,10+gland_length,n+1);br=np.linspace(-647-gland_length,-647,n+1);bd=np.linspace(152.5+dry_shift,158.5+dry_shift,n+1);bn=np.linspace(80.,110.,n+1);bn2=np.linspace(175.,205.,n+1);bh=np.linspace(143.,171.5,n+1)
  xs=sorted(set([*[float((a+b)/2) for bounds in [bn2,bh] for a,b in zip(bounds[:-1],bounds[1:])],-700.,0.,-637.,68.,94.75,129.5+dry_shift,177.+dry_shift,-318.5,.5,1.5,2.5,7.7,8.7,9.7,-637.5,-638.5,-639.5,-644.7,-645.7,-646.7,float(stop_x),*np.linspace(-637,0,13),*[(a+b)/2 for a,b in zip(bf[:-1],bf[1:])],*[(a+b)/2 for a,b in zip(br[:-1],br[1:])],*[(a+b)/2 for a,b in zip(bd[:-1],bd[1:])],*[(a+b)/2 for a,b in zip(bn[:-1],bn[1:])],-10.,-20.,-30.,-328.5,-308.5,*np.linspace(-627,-10,13)]))
  self.x=np.array(xs);self.node={v:i for i,v in enumerate(xs)};self.ns=len(xs)*4
  # gland front/rear: 2 translations, 2 slopes, 1 axial opening; disc and common frame: 4 each.
  self.gf=self.ns;self.gr=self.gf+5;self.disc=self.gr+5;self.near=self.disc+4;self.near2=self.near+4;self.gear=self.near2+4;self.frame=self.gear+4;self.nd=self.frame+4
  self.K=np.zeros((self.nd,self.nd));self.contacts=[];self.joints=[];self.shear=[];self.capture=[]
  def addk(ids,k):self.K[np.ix_(ids,ids)]+=k
  for i,L in enumerate(np.diff(self.x)):
   for d in [0,1]:addk([4*i+d,4*i+d+2,4*(i+1)+d,4*(i+1)+d+2],beamk(L,E*I))
  # Common bridge to immutable host is a compliant boundary, never hard-fixed.
  for d in [0,1]:self.K[self.frame+d,self.frame+d]+=kr;self.K[self.frame+d+2,self.frame+d+2]+=krot
  # Four D509 beams of 77.5mm plus rigid10mm plate-centre offset.
  for d,lever in [(0,78.),(1,70.)]:
   B=np.zeros((4,self.nd));B[0,self.frame+d]=1;B[1,self.frame+d+2]=1;B[2,self.disc+d]=1;B[2,self.disc+d+2]=-10;B[3,self.disc+d+2]=1
   self.K+=B.T@beamk(77.5+dry_shift,4*200000*math.pi*32**4/64)@B
   # axial forces in off-axis posts resist disc/frame relative tilt.
   v=np.zeros(self.nd);v[self.disc+d+2]=1;v[self.frame+d+2]=-1
   self.K+=4*200000*(math.pi*32**2/4)/(77.5+dry_shift)*lever**2*np.outer(v,v)
  for start,L,bounds,k,g,origin in [(self.gf,gland_length,bf,kb,gb,0),(self.gr,gland_length,br,kb,gb,-637),(self.disc,6,bd,kd,gd,155.5+dry_shift)]:
   if start==self.disc and (not contact or secondary):continue
   for a,b in zip(bounds[:-1],bounds[1:]):
    xx=float((a+b)/2);A=np.zeros((2,self.nd));idx=4*self.node[xx]
    for d in [0,1]:A[d,idx+d]=1;A[d,start+d]=-1;A[d,start+d+2]=-(xx-origin)
    self.contacts.append((A,k*(b-a)/L,g,np.array([alpha*(xx-origin),0]),dict(group='D543' if start==self.disc else 'FRONT_BUY401' if start==self.gf else 'REAR_BUY401',x=xx,dx=b-a,diameter=52 if start==self.disc else 30)))
  # J401 metal throat is not an intended bearing. Include as a diagnostic contact,
  # so a calculated shaft/metal touch is reported rather than ignored.
  if throat:
   for gland,coords,origin in [(self.gf,[.5,1.5,2.5,7.7,8.7,9.7],0),(self.gr,[-637.5,-638.5,-639.5,-644.7,-645.7,-646.7],-637)]:
    for xx in coords:
     A=np.zeros((2,self.nd));idx=4*self.node[float(xx)]
     for d in [0,1]:A[d,idx+d]=1;A[d,gland+d]=-1;A[d,gland+d+2]=-(xx-origin)
     self.contacts.append((A,1e6/6,throat_gap,np.zeros(2),dict(group='THROAT_FRONT' if gland==self.gf else 'THROAT_REAR',x=xx,dx=1,diameter=30)))
  for gland,origin,sgn in [(self.gf,0,1),(self.gr,-637,-1)]:
   # face bolt pattern square48. Receiver deformation is common to both gland and bridge at front.
   for a in [-24,24]:
    for b in [-24,24]:
     v=np.zeros(self.nd);v[gland+4]=1;v[gland+2]=a;v[gland+3]=b
     v[self.frame+2]=-a;v[self.frame+3]=-b
     self.joints.append((v,1/(1/(185000*20.1/(63.59 if gland==self.gf else 53.50))+1/spring_k),250000.,(preload if gland==self.gf or rear_preload is None else rear_preload),dict(gland='FRONT' if gland==self.gf else 'REAR',a=a,b=b)))
   A=np.zeros((2,self.nd))
   for d in [0,1]:
    A[d,gland+d]=1
    A[d,self.frame+d]=-1;A[d,self.frame+d+2]=68-origin # frame reference atx68 toface0
   self.shear.append((A,dict(gland='FRONT' if gland==self.gf else 'REAR')))
   if bridge and gland==self.gf:
    # Finite-length rectangular capture, x20..36. Effective frame+arm compliance
    # is included in each spring, not an imposed zero gland reaction.
    for xx in np.linspace(21,35,8):
     for d in [0,1]:
      v=np.zeros(self.nd);v[gland+d]=1;v[gland+d+2]=xx;v[self.frame+d]=-1;v[self.frame+d+2]=-(xx-68)
      self.capture.append((v,bridge_k/8,capture_gap,dict(x=float(xx),axis=d)))
  if not secondary:
   for d,lever in [(0,78.),(1,70.)]:
    B=np.zeros((4,self.nd));B[0,self.frame+d]=1;B[1,self.frame+d+2]=1;B[2,self.near+d]=1;B[3,self.near+d+2]=1
    self.K+=B.T@beamk(27.,4*200000*math.pi*32**4/64)@B
    v=np.zeros(self.nd);v[self.near+d+2]=1;v[self.frame+d+2]=-1
    self.K+=4*200000*(math.pi*32**2/4)/27.*lever**2*np.outer(v,v)
  for a,bb in zip(bn[:-1],bn[1:]):
   xx=float((a+bb)/2);A=np.zeros((2,self.nd));idx=4*self.node[xx]
   for d in [0,1]:A[d,idx+d]=1;A[d,self.near+d]=-1;A[d,self.near+d+2]=-(xx-95.)
   self.contacts.append((A,200000.*(bb-a)/3.,.0305,np.zeros(2),dict(group='NEAR_D547',x=xx,dx=bb-a,diameter=30)))
  # Rear plate is joined to the front by the actual two10x292 rails.
  # Shear-flexible beam stiffness; one primary cage link, not multiplied by shafts.
  if not secondary:
   Erail=185000*carrier_E_factor;G=Erail/2.6;area=2*10*292;LL=95.
   for d,II in [(0,2*292*10**3/12),(1,2*10*292**3/12)]:
    phi=12*Erail*II/((5/6)*G*area*LL**2)
    k=Erail*II/(LL**3*(1+phi))*np.array([[12,6*LL,-12,6*LL],[6*LL,(4+phi)*LL**2,-6*LL,(2-phi)*LL**2],[-12,-6*LL,12,-6*LL],[6*LL,(2-phi)*LL**2,-6*LL,(4+phi)*LL**2]])
    B=np.zeros((4,self.nd));B[0,self.near+d]=1;B[1,self.near+d+2]=1;B[2,self.near2+d]=1;B[3,self.near2+d+2]=1;self.K+=B.T@k@B
  for a,bb in zip(bn2[:-1],bn2[1:]):
   xx=float((a+bb)/2);A=np.zeros((2,self.nd));idx=4*self.node[xx]
   for d in [0,1]:A[d,idx+d]=1;A[d,self.near2+d]=-1;A[d,self.near2+d+2]=-(xx-190.)
   self.contacts.append((A,200000.*(bb-a)/3.,.0405,np.zeros(2),dict(group='NEAR2_D547',x=xx,dx=bb-a,diameter=30)))
  # Rigid gear/hub has4DOF. Finite no-clearance distributed radial shaft coupling.
  # Its stiffness is an explicit sensitivity input, not a vendor certification.
  for a,bb in zip(bh[:-1],bh[1:]):
   xx=float((a+bb)/2);A=np.zeros((2,self.nd));idx=4*self.node[xx]
   for d in [0,1]:A[d,idx+d]=1;A[d,self.gear+d]=-1;A[d,self.gear+d+2]=-(xx-157.25)
   self.contacts.append((A,clamp_k*(bb-a)/28.5,0.,np.zeros(2),dict(group='HUB_TRANSFER',x=xx,dx=bb-a,diameter=30)))
  # Composite Simpson contact quadrature includes physical bearing endpoints.
  # Hermite interpolation maps every quadrature force and moment into the same beam field.
  upgraded=[]
  for A,k,g,off,meta in self.contacts:
   if meta['group'] not in ['NEAR_D547','NEAR2_D547']:
    upgraded.append((A,k,g,off,meta));continue
   st,origin=(self.near,95.) if meta['group']=='NEAR_D547' else (self.near2,190.)
   for shift,weight in [(-.5,1/6),(0.,4/6),(.5,1/6)]:
    xx=meta['x']+shift*meta['dx'];j=max(0,min(len(self.x)-2,int(np.searchsorted(self.x,xx)-1)));LL=self.x[j+1]-self.x[j];t=(xx-self.x[j])/LL
    N=[1-3*t*t+2*t**3,LL*(t-2*t*t+t**3),3*t*t-2*t**3,LL*(-t*t+t**3)];AA=np.zeros((2,self.nd))
    for d in [0,1]:
     for ix,w in zip([4*j+d,4*j+d+2,4*(j+1)+d,4*(j+1)+d+2],N):AA[d,ix]=w
     AA[d,st+d]=-1;AA[d,st+d+2]=-(xx-origin)
    upgraded.append((AA,k*weight,g,off,{**meta,'x':xx,'dx':meta['dx']*weight,'quadrature':'Simpson endpoint/midpoint','segment_dx':meta['dx']}))
  self.contacts=upgraded
  self.mu=mu;self.preload=preload
  # rotations are represented as displacement over100mm to improve conditioning.
  self.scale=np.ones(self.nd)
  for i in range(len(xs)):self.scale[4*i+2:4*i+4]=.01
  for st in [self.gf,self.gr,self.disc,self.near,self.near2,self.gear,self.frame]:self.scale[st+2:st+4]=.01
 def eval(self,u,f,details=False):
  grad=np.asarray(self.K.astype(np.longdouble)@u.astype(np.longdouble)-f,dtype=float);H=self.K.copy();energy=.5*u@self.K@u-u@f;con=[];bolts=[];shears=[];caps=[]
  def radial(A,k,g,offset=None):
   nonlocal grad,H,energy
   v=A@u+(offset if offset is not None else 0);rr=np.linalg.norm(v)
   if g==0:
    ff=k*v;grad+=A.T@ff;H+=k*A.T@A;energy+=.5*k*float(v@v);return ff
   if rr<=g:return np.zeros(2)
   nh=v/rr;ff=k*(rr-g)*nh;h=k*((1-g/rr)*np.eye(2)+g/rr*np.outer(nh,nh));grad+=A.T@ff;H+=A.T@h@A;energy+=.5*k*(rr-g)**2;return ff
  for A,k,g,offset,meta in self.contacts:
   ff=radial(A,k,g,offset);con.append(dict(**meta,force=ff.tolist(),force_norm=float(np.linalg.norm(ff)),relative_mm=(A@u+offset).tolist(),gap_mm=g,pressure_projected_MPa=float(np.linalg.norm(ff))/(meta['diameter']*meta['dx'])))
  for v,kb,kc,P,meta in self.joints:
   w=float(v@u);B=max(0,P+kb*w);C=max(0,P-kc*w);q=B-C
   h=(kb if B>0 else 0)+(kc if C>0 else 0);grad+=q*v;H+=h*np.outer(v,v)
   # potential difference from preloaded equilibrium
   energy+=(B*B-P*P)/(2*kb)+(C*C-P*P)/(2*kc)
   bolts.append(dict(**meta,opening_mm=w,total_tension_N=B,compression_N=C,separated=C==0))
  for A,meta in self.shear:
   v=A@u;rr=np.linalg.norm(v);ks=100000.;cap=self.mu*4*min(1000,self.preload);y=cap/ks
   if rr>1e-15:
    nh=v/rr;ff=min(ks*rr,cap)*nh;h=ks*np.eye(2) if rr<y else cap/rr*(np.eye(2)-np.outer(nh,nh));grad+=A.T@ff;H+=A.T@h@A;energy+=.5*ks*rr**2 if rr<y else cap*(rr-.5*y)
   else:ff=np.zeros(2);H+=ks*A.T@A
   ff2=radial(A,4000.,.25);shears.append(dict(**meta,relative_mm=rr,friction_N=float(np.linalg.norm(ff)),shank_bearing_N=float(np.linalg.norm(ff2)),slipped=rr>y))
  for v,k,gap,meta in self.capture:
   d=float(v@u);f=k*max(0,abs(d)-gap)*np.sign(d);grad+=v*f
   if abs(d)>gap:H+=k*np.outer(v,v)
   energy+=.5*k*max(0,abs(d)-gap)**2;caps.append(dict(**meta,force_N=float(f),relative_mm=d,gap_mm=gap))
  if details:return con,bolts,shears,caps
  return energy,grad,H
 def load(self,tag='P',angle=0,sign=1,kind='STOP',stop_x=155.5,pressure=0):
  f=np.zeros(self.nd);direction=np.array([math.cos(math.radians(angle)),math.sin(math.radians(angle))])*sign
  loads=[]
  def at(x,v,name,target='shaft'):
   if target=='shaft' and float(x) not in self.node:
    # Consistent cubic beam loading at exact CG; avoid an artificial sub-mm mesh element.
    j=int(np.searchsorted(self.x,x)-1);L=self.x[j+1]-self.x[j];r=(x-self.x[j])/L
    N=[1-3*r*r+2*r**3,L*(r-2*r*r+r**3),3*r*r-2*r**3,L*(-r*r+r**3)]
    for d in [0,1]:
     ids=[4*j+d,4*j+d+2,4*(j+1)+d,4*(j+1)+d+2]
     for ix,w in zip(ids,N):f[ix]+=w*v[d]
   else:
    st=4*self.node[float(x)] if target=='shaft' else self.disc;f[st:st+2]+=v
   loads.append(dict(x=x,force=v.tolist(),name=name,target=target))
  if kind in ['STOP','STOP_WITH_OUTPUT'] and not self.par['secondary']:
   stop_torque=200 if kind=='STOP' else 200-(78 if tag=='P' else 38)
   force=stop_torque*1000/60*direction;at(stop_x,force,'stop force on hub/shaft');at(stop_x,-force,'equal opposite stop force on D505','disc');f[self.disc+2:self.disc+4]+=-(stop_x-155.5-self.par['dry_shift'])*force
  gear=38000/82.5 if tag=='P' and kind!='STOP' else 0
  at(94.75,np.array([gear*sign*self.par['gear_sign'],-gear*math.tan(math.radians(20))*self.par['gear_sign']]),'gear mesh P1; reverse tangent with input sign')
  mass=MASS_DATA['mass_kg'] if MASS_DATA else 813655.1281788213*7.93e-6
  weight_s=MASS_DATA['shaft_station_s_mm'] if MASS_DATA else -318.5
  at(weight_s,np.array([0,-mass*9.81]),'R5 native exact rotor self weight at native CG' if MASS_DATA else 'R4 mass diagnostic only')
  if tag=='P':at(94.75,np.array([0,-739399.2374874066*7.85e-6*9.81]),'gear weight')
  if pressure:at(-318.5,pressure*.630*.154*direction,'one blade pressure resultant')
  return f,loads
 def solve(self,**case):
  f,loads=self.load(**case);u=np.zeros(self.nd);sc=self.scale;iterations=0
  for iterations in range(220):
   en,g,H=self.eval(u,f);norm=float(np.max(np.abs(g*sc)))
   if norm<2e-5:break
   HH=H*sc[:,None]*sc[None,:]
   # Temporary tangent regularization only; residual uses original equations.
   try:step=solve(HH+np.eye(self.nd)*1e-7,-g*sc,assume_a='sym')*sc
   except Exception:step=np.linalg.lstsq(HH,-g*sc,rcond=1e-13)[0]*sc
   ratio=1
   while ratio>2**-30:
    ee,_,_=self.eval(u+ratio*step,f)
    if ee<=en+1e-4*ratio*g@step+1e-9:break
    ratio*=.5
   u+=ratio*step
  en,g,H=self.eval(u,f);con,bolts,shear,capture=self.eval(u,f,True);groups={}
  for name in ['FRONT_BUY401','REAR_BUY401','D543','THROAT_FRONT','THROAT_REAR']:
   cc=[c for c in con if c['group']==name];v=np.sum([c['force'] for c in cc],axis=0) if cc else np.zeros(2);mv=np.sum([c['x']*np.array(c['force']) for c in cc],axis=0) if cc else np.zeros(2)
   groups[name]=dict(force_N=v.tolist(),first_moment_Nmm=mv.tolist(),absolute_contact_N=sum(c['force_norm'] for c in cc),max_projected_pressure_MPa=max([c['pressure_projected_MPa'] for c in cc],default=0))
  # Free body of shaft: applied point forces minus all bearing reactions.
  forces=sum((np.array(x['force']) for x in loads if x['target']=='shaft'),np.zeros(2));mom=sum((x['x']*np.array(x['force']) for x in loads if x['target']=='shaft'),np.zeros(2))
  forces-=sum((np.array(c['force_N']) for c in groups.values()),np.zeros(2));mom-=sum((np.array(c['first_moment_Nmm']) for c in groups.values()),np.zeros(2))
  result=dict(case=case,parameters=self.par,converged=float(np.max(np.abs(g*sc)))<1e-3,iterations=iterations,residual_scaled_N=float(np.max(np.abs(g*sc))),shaft_force_residual_N=forces.tolist(),shaft_moment_residual_Nmm=mom.tolist(),groups=groups,bolts=bolts,max_total_tie_N=max(q['total_tension_N'] for q in bolts),max_face_opening_mm=max(q['opening_mm'] for q in bolts),shear=shear,frame_translation_mm=u[self.frame:self.frame+2].tolist(),frame_slope_rad=u[self.frame+2:self.frame+4].tolist(),disc_translation_mm=u[self.disc:self.disc+2].tolist(),disc_slope_rad=u[self.disc+2:self.disc+4].tolist(),shaft_max_deflection_mm=float(max(np.linalg.norm(u[4*i:4*i+2]) for i in range(len(self.x)))),loads=loads,contacts=con,capture=capture,shaft_nodes_x_mm=self.x.tolist(),shaft_dofs=u[:self.ns].reshape((-1,4)).tolist())
  return result

def run_baseline():
 out=[]
 for name,params in [('nominal',{}),('large_clearance',dict(gb=.0685,gd=.124445)),('zero_gap',dict(gb=0,gd=0)),('D543_no_contact',dict(contact=False)),('soft_receiver',dict(kr=1000,krot=1e6)),('hard_receiver',dict(kr=1e7,krot=1e10)),('soft_contact',dict(kb=10000,kd=10000)),('hard_contact',dict(kb=1e6,kd=1e6)),('coincident_plane',dict(stop_x=155.5)),('stop_front_edge',dict(stop_x=145.5)),('stop_rear_edge',dict(stop_x=165.5)),('mesh12',dict(n=12)),('mesh24',dict(n=24))]:
  m=Model(**params);q=m.solve(tag='P',angle=45,sign=1,kind='STOP',stop_x=params.get('stop_x',155.5));q['test']=name;out.append(q);print(name,q['converged'],q['max_total_tie_N'],q['max_face_opening_mm'],q['shaft_force_residual_N'],flush=True)
  (OUT/'R2_COMMON_BASELINE.json').write_text(json.dumps(out,indent=2,default=lambda x:x.item() if hasattr(x,"item") else str(x)))
if __name__=='__main__':run_baseline()
