"""AirTransformer AT-DMP02 C02. Explicit mm parameters; manufacturing REVIEW branch.
Run with the Codex primary Python (CadQuery/OCP). No input archive is modified.
"""
from pathlib import Path
import sys, json, math, io, csv, hashlib, collections
import numpy as np
import cadquery as cq
from OCP.gp import gp_Trsf
from OCP.BRepTools import BRepTools
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'deliverables'
import step_io as ex
ex.OUT=OUT
for k,c in {'P':(.13,.52,.63,1),'R':(.89,.47,.13,1),'SEAL':(.22,.27,.28,1),'DRIVE':(.52,.33,.60,1),'FIXTURE':(.50,.56,.61,1),'PURCHASE':(.65,.68,.7,1),'REFERENCE':(.8,.82,.85,.25)}.items():ex.COLORS[k]=c
for d in ['step/parts','step/purchase','native','tables','evidence','drawings','dxf','internal','scripts']:(OUT/d).mkdir(parents=True,exist_ok=True)
PARTS={};OCC=[];WELDS={};KITS={}
ACTIVE_CONFIG='MANUAL'
REV='C02'; STATUS='ENGINEERING_REVIEW_WITH_LOCAL_HOLDS'
def vec(x):return cq.Vector(*x)
def box(x,y,z):return cq.Solid.makeBox(x,y,z)
def cyl(d,h,p=(0,0,0),axis=(0,0,1)):return cq.Solid.makeCylinder(d/2,h,vec(p),vec(axis))
def comp(ss):return cq.Compound.makeCompound(ss)
def cut(s,tool):return s.cut(tool).clean()
def tr(s,o=(0,0,0),u=(1,0,0),v=(0,1,0),n=(0,0,1)):
    g=gp_Trsf();g.SetValues(u[0],v[0],n[0],o[0],u[1],v[1],n[1],o[1],u[2],v[2],n[2],o[2]);return s.moved(cq.Location(g))
def register(pn,name,s,kind='MAKE',material='EN 1.4307 / 304L',features=None,notes=None,group='body'):
    assert pn not in PARTS,pn
    assert s.isValid(),pn
    PARTS[pn]=dict(pn=pn,name=name,kind=kind,material=material,features=features or [],notes=notes or [],shape=s,group=group)
    return pn
def plate(pn,name,w,h,t,holes=(),window=None,kind='MAKE',material='EN 1.4307 / 304L',notes=(),group='body'):
    s=box(w,h,t);f=[dict(type='blank',width=w,height=h,thickness=t)]
    if window:
        x,y,a,b=window;s=cut(s,box(a,b,t+2).translate((x,y,-1)));f.append(dict(type='window',x=x,y=y,w=a,h=b))
    for x,y,d in holes:s=cut(s,cyl(d,t+2,(x,y,-1)));f.append(dict(type='hole',x=x,y=y,d=d,depth='THRU'))
    return register(pn,name,s,kind,material,f,list(notes),group)
def add(pn,o=(0,0,0),u=(1,0,0),v=(0,1,0),n=(0,0,1),group='P',moving=None,note=''):
    idx=sum(x['pn']==pn for x in OCC)+1
    OCC.append(dict(pn=pn,occurrence=f'{pn}_{idx:03d}',o=o,u=u,v=v,n=n,scope=group,moving=moving,note=note))
    return OCC[-1]
def holes_ring(w,h,m=12,pitch=100,d=6.5):
    nx=math.ceil((w-2*m)/pitch);ny=math.ceil((h-2*m)/pitch)
    pts=[(m+(w-2*m)*i/nx,y,d) for y in [m,h-m] for i in range(nx+1)]
    pts += [(x,m+(h-2*m)*i/ny,d) for x in [m,w-m] for i in range(1,ny)]
    return pts
def brep(s):
    b=io.BytesIO();BRepTools.Write_s(s.wrapped,b);return b.getvalue().decode()
def dump(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2,default=lambda x:x.item() if hasattr(x,"item") else list(x)))
def cw(name,rows):
    with (OUT/'tables'/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def fourbar(theta):
    r=40.;L=165.;c=math.sqrt(L*L+2*r*r);a=math.radians(theta-45)
    A=np.array([r*math.cos(a),r*math.sin(a)]);B=np.array([0.,L]);d=np.linalg.norm(A-B);e=(A-B)/d
    q=(r*r-c*c+d*d)/(2*d);h=math.sqrt(max(0,r*r-q*q));p=B+q*e
    p1=p+h*np.array([-e[1],e[0]]);p2=p-h*np.array([-e[1],e[0]])
    C=min([p1,p2],key=lambda p:p[0]);beta=math.degrees(math.atan2(C[1]-L,C[0]))
    if beta<0:beta+=360
    return A,C,beta-225

def build_parts():
    # Welded split casings. Split faces -1/+1 about the shaft. Three mm flanges.
    for tag,W,H in [('P',630.,345.),('R',630.,180.)]:
        endholes=holes_ring(W+76,H+76,19,70,9)
        plate(f'{tag}101',f'{tag}端法兰',W+76,H+76,3,endholes,(38,38,W,H),notes=['激光下料；密封面平面度 0.15/300、全长 0.30。','焊后再复核孔位；孔位置度直径0.5，相对于孔口中心线。'])
        sh=holes_ring(W+40,H+40,10,60,6.5)
        axial_stations=([90,255] if tag=='P' else [90]);drive_stations=[18,162]
        sh=[p for p in sh if not ((p[0]<20 or p[0]>W+20) and (any(abs(p[1]-20-a)<40 for a in axial_stations) or any(abs(p[1]-20-a)<20 for a in drive_stations)))]
        pn=plate(f'{tag}102',f'{tag}中分法兰',W+40,H+40,3,sh,(20,20,W,H),notes=['两半合拢后加工轴穿孔；孔中心位于本件厚度方向 z=-1。','轴孔直径38，不作轴承孔；壳体半总成焊后加工。'])
        axes=[H/2-82.5,H/2+82.5] if tag=='P' else [H/2]
        # Local x = Y span, y = chord direction, z = flow direction.
        for a in axes:
            PARTS[pn]['shape']=cut(PARTS[pn]['shape'],cyl(38,W+42,(-1,a+20,-1),(1,0,0)))
            PARTS[pn]['features'].append(dict(type='crossbore',axis='X',x=-1,y=a+20,z=-1,d=38,depth=W+42))
        for side_x in [0,W+20]:
            for center_y in [a+20 for a in axes]:
                PARTS[pn]["shape"]=cut(PARTS[pn]["shape"],box(20,64,5).translate((side_x,center_y-32,-1)))
                PARTS[pn]["features"].append(dict(type="mount_notch",x=side_x,y=center_y-32,w=20,h=64,depth="THRU; bearing gland seals across cutout"))
            for yy in ([H/2-82.5-72+20,H/2-82.5+72+20] if tag=="P" else [H/2-72+20,H/2+72+20]):
                PARTS[pn]["shape"]=cut(PARTS[pn]["shape"],box(20,24,5).translate((side_x,yy-12,-1)))
                PARTS[pn]["features"].append(dict(type="mount_notch",x=side_x,y=yy-12,w=20,h=24,depth="THRU; drive foot gasket required"))
        # Two side-wall handed patterns. Local x=axial length, y=port height.
        for hand in ['F','B']:
            pn=plate(f'{tag}103{hand}',f'{tag}半壳侧板-{hand}',83,H,3,notes=['端口边与端法兰连续角焊 a=2；中分边与中分法兰连续角焊 a=2。','两侧成对装夹，轴孔中心线同轴度直径0.10；本图孔口半圆随焊总成精修。'])
            for a in axes:
                PARTS[pn]['shape']=cut(PARTS[pn]['shape'],cyl(38,5,(87,a,-1)))
                PARTS[pn]['features'].append(dict(type='hole',x=87,y=a,d=38,depth='THRU / EDGE'))
                for dx in [-24,24]:
                    # Only holes that fall in this half's wall; others fall in the opposite half.
                    x=87+dx
                    if 0<x<83:
                        for dy in [-24,24]:
                            PARTS[pn]['shape']=cut(PARTS[pn]['shape'],cyl(6.5,5,(x,a+dy,-1)))
                            PARTS[pn]['features'].append(dict(type='hole',x=x,y=a+dy,d=6.5,depth='THRU'))
            seat_y=([12,H-12] if tag=='P' and hand=='F' else [H/2]) if tag=='P' else [12,H-12]
            for yy in seat_y:
                # Seat block screws at axial x=87-14.0125. Adjustment slots along x.
                for dy in [-6,6]:
                    x=63.079;y=yy+dy
                    slot=cyl(5.5,5,(x-2,y,-1)).fuse(cyl(5.5,5,(x+2,y,-1)),box(4,5.5,5).translate((x-2,y-2.75,-1))).clean()
                    PARTS[pn]['shape']=cut(PARTS[pn]['shape'],slot)
                    PARTS[pn]['features'].append(dict(type='slot',x=x,y=y,length=9.5,width=5.5,axis='X'))
        plate(f'{tag}104',f'{tag}半壳端壁',83,636,3,notes=['每半壳用2件；板宽636跨覆侧板；连续封焊 a=2。'])
        # Split seam gasket, installation thickness; free thickness on drawing.
        pn=plate(f'{tag}105',f'{tag}中分静密封',W+40,H+40,2,[(x,y,12.2) for x,y,d in sh],(20,20,W,H),material='Rogers BISCO HT-870 3.18 mm',notes=['CAD为安装厚度2.00；自由标称3.18；入料每点2.90–3.50。整体刀模切，不拼接。','入料压缩范围按C02共同间隙链；M6位置放金属限位套；轴孔缺口被轴封座静垫连续跨接。'],group='seal')
        for a in axes:
            PARTS[pn]['shape']=cut(PARTS[pn]['shape'],cyl(38,W+42,(-1,a+20,1),(1,0,0)))
            PARTS[pn]['features'].append(dict(type='crossbore',axis='X',x=-1,y=a+20,z=1,d=38,depth=W+42))
        plate(f'{tag}106',f'{tag}外接静垫',W+76,H+76,2,[(x,y,16.2) for x,y,d in endholes],(38,38,W,H),material='Rogers BISCO HT-870 3.18 mm',notes=['自由标称3.18；入料每点2.90–3.50；限位2.00±0.03；夹紧后全密封路径实测1.95–2.05。整片切割；禁用密封胶补主密封。'],group='seal')
        # Receiver retains machine-side external face; new local hole pattern only.
        plate(f'{tag}107',f'{tag}局部接收框',W+76,H+76,3,endholes,(38,38,W,H),notes=['仅承本阀；新孔仅在本地接收件，不授权修改机侧母板。','机侧连接沿用接收框夹紧边界；本轮试装由独立工装支承。'],group='fixture')
        # Side pads comprise two mirrored halves; foam support covers the seam.
        for stem,t,mat,desc in [('108',4.45,'Rogers BISCO HT-870 6.35 mm','侧密封泡棉'),('109',.25,'Virgin PTFE skived sheet, 0.25±0.03 mm','侧密封滑动面'),('111',1.80,'304L precision shim','侧封背垫')]:
            pn=plate(tag+stem,tag+desc,87,H-6,t,material=mat,notes=['自由泡棉标称6.35，入料分档6.20–6.80；本图厚度为名义安装态。','逐片测厚 t；背垫厚度 s=6.50-0.25-0.70t，采用编号量片组合背垫，成品厚度按对应泡棉编号记录，名义1.80；冷态各测点28%–32%装配压缩，冷热允许10%–50%。','侧封在轴径处连续贴合；配合口直径30.20；四周用压框夹持，不用胶粘。'],group='seal')
            for a in axes:
                PARTS[pn]['shape']=cut(PARTS[pn]['shape'],cyl(30.2,t+2,(87,a-3,-1)))
                PARTS[pn]['features'].append(dict(type='hole',x=87,y=a-3,d=30.2,depth='THRU / EDGE'))
        # U retainer strip; inner sweep radius >=82. No bar across split line.
        pn=plate(tag+'110',tag+'侧封U压框',87,H-6,1,window=(7,5,82,H-16),notes=['开口朝轴中分面；工作面不得高出叶片端面；相对端面留0.50以上。','压框M3每80最大间距；头径≤5.5、头高≤1.5，外侧M3锁紧螺母；孔在5mm边带中线，见孔表；框边倒圆R0.5。'],group='seal')
        hh=[(3.5,10+i*(H-26)/math.ceil((H-26)/80),3.4) for i in range(math.ceil((H-26)/80)+1)]
        hh += [(20,2.5,3.4),(65,2.5,3.4),(20,H-8.5,3.4),(65,H-8.5,3.4)]
        for x,y,d in hh:
            PARTS[pn]['shape']=cut(PARTS[pn]['shape'],cyl(d,3,(x,y,-1)));PARTS[pn]['features'].append(dict(type='hole',x=x,y=y,d=d,depth='THRU'))
        for yy in [0,H-30]:
            PARTS[tag+"110"]["shape"]=cut(PARTS[tag+"110"]["shape"],box(38,24,3).translate((46.774,yy,-1)))
            PARTS[tag+"110"]["features"].append(dict(type="mount_notch",x=46.774,y=yy,w=38,h=24,depth="THRU; seat beam clearance"))
        for stem in ["108","109","111"]:
            for cy in [-3+12,H-3-12]+([H/2-3] if tag=="P" else []):
                PARTS[tag+stem]["shape"]=cut(PARTS[tag+stem]["shape"],box(32.2,24.2,10).translate((46.979,cy-12.1,-1)))
                PARTS[tag+stem]["features"].append(dict(type="mount_notch",x=46.979,y=cy-12.1,w=32.2,h=24.2,depth="THRU; physical seat rail clearance"))
        # Exact matching retainer holes in wall and soft stack. Through bolts, sealed externally.
        # End points at x65 in seat notches are removed from every layer.
        for x,y,d in hh:
            if x==65: continue
            for hand in ["F","B"]:
                pn=tag+"103"+hand
                PARTS[pn]['shape']=cut(PARTS[pn]['shape'],cyl(3.4,5,(x,y+3,-1)))
                PARTS[pn]['features'].append(dict(type='hole',x=x,y=y+3,d=3.4,depth='THRU; M3 side-pad clamp, external bonded washer'))
            for stem in ['108','109','111']:
                pn=tag+stem;t=PARTS[pn]['features'][0]['thickness']
                PARTS[pn]['shape']=cut(PARTS[pn]['shape'],cyl(3.4,t+2,(x,y,-1)))
                PARTS[pn]['features'].append(dict(type='hole',x=x,y=y,d=3.4,depth='THRU'))
        # Hard shim ends clear the full beam + clamp stack; soft film makes the corner lap.
        for cy in [-3+12,H-3-12]+([H/2-3] if tag=="P" else []):
            PARTS[tag+'111']['shape']=cut(PARTS[tag+'111']['shape'],box(39,24.4,4).translate((46.979,cy-12.1,-1)))
            PARTS[tag+'111']['features'].append(dict(type='mount_notch',x=46.979,y=cy-12.1,w=39,h=24.4,depth='THRU; clamp clearance'))
        PARTS[tag+'110']['features']=[f for f in PARTS[tag+'110']['features'] if not(f.get('type')=='hole' and f.get('x')==65)]
    # Original R seat riser reconstructed as four sheet blanks, unchanged port and height.
    plate('R112','R抬高段长边',630,20,1.5,notes=['2件；20mm高度沿用原R_SEAT_RISER；顶面与R107连续a=1封焊。','底面Z1468与原R_ROOF接口；未授权改变母板。接口焊接工艺由L1结构包接收。'])
    plate('R113','R抬高段端边',183,20,1.5,notes=['2件跨覆长边；四角连续a=1封焊，ER308L。','组合外形183×633×20，净口180×630；与输入r2抬高段实体等体积。'])
    # Rotor blank and shaft. Actual joints represented by deposited weld metal.
    plate('B201','半叶片下料',617,61.9,2.5,notes=['板厚2.50±0.12；617±0.15，61.90±0.10；端边Ra1.6，端面垂直度0.10。','去毛刺R0.3；焊装后完整轮廓617×154；叶片外侧工作面平面度0.25。'],group='rotor')
    s=cut(cyl(30,876),cyl(6.8,22))
    # keyseat at drive end; local shaft axis z. Closed blade plane contains local X axis.
    key=box(8,8,34).translate((-4,11,9)).fuse(cyl(8,8,(0,11,9),(0,1,0)),cyl(8,8,(0,11,43),(0,1,0))).clean();s=cut(s,key)
    s=cut(s,cyl(6,32,(0,-16,129.5),(0,1,0)))
    register('B202','转子轴',s,features=[dict(type='shaft',d=30,length=876),dict(type='thread',axis='Z+',z0=0,thread='M8-6H',effective=18,drill_depth=22),dict(type='keyseat',width=8,depth=4,z0=5,length=42,ends_R=4),dict(type='crossbore',axis='Y',x=0,y=-16,z=129.5,d=6,fit='H6',depth=32)],notes=['棒料304L；焊前留磨量0.15；焊后两轴颈直径30 h8 (0/-0.033)。','轴颈z=135.5–165.5及822.5–852.5，Ra0.6–0.8；轴封轨迹Ra0.4无导程。','键槽8.000–8.015，槽深4.00±0.02；A=两轴颈共同轴线，B=驱动端Z0；各功能段相对A圆跳动0.03。输入段z0–48：30h7，Ra1.6。KHK夹持z51.5–110：30h7，Ra1.6；连续无键槽。轴封轨迹z168.9–171.9、816.1–819.1：30h8，Ra0.4无导程。','焊后全长直线度0.10；轴孔129.5为固定端轴环销孔，沿本件Y轴/阀板法向，必须与J403及STD05同轴，不得按旧X向钻。'],group='rotor')
    # Weld assembly centered chord across y; span x. Shaft z mapped to span.
    shaft=tr(s,(-185.5,0,0),(0,1,0),(0,0,1),(1,0,0))
    b1=PARTS['B201']['shape'].translate((0,15.1,-1.25))
    b2=tr(PARTS['B201']['shape'],(617,-15.1,1.25),(-1,0,0),(0,-1,0),(0,0,1))
    # second transform above keeps normal +Z; thickness needs -1.25 to +1.25
    b2=PARTS['B201']['shape'].translate((0,-77,-1.25))
    ss=[shaft,b1,b2]
    for sy in [-1,1]:
        for sz in [-1,1]:
            pts=[(sy*14.3,sz*1.20),(sy*17.1,sz*1.20),(sy*14.3,sz*4.0)]
            w=cq.Workplane('YZ').polyline(pts).close().extrude(617).val();ss.append(w)
    rotor=ss[0].fuse(*ss[1:]).clean()
    register('B200','叶片轴焊接总成',rotor,kind='WELD_ASSEMBLY',features=[dict(type='assembly',span=617,chord=154,plate=2.5,shaft=30,axis_x=-185.5,axis_end=690.5)],notes=['组成B202×1+B201×2；四条连续a=2角焊，ER308L填丝，TIG。','根隙0.15–0.25；分段对称跳焊，热输入与校形用见工艺页。','总成质量包含焊缝；焊前轴与板无任意重叠；焊缝实体为名义沉积包络。','成品转子617±0.15×154±0.10；相对共同轴线A，全部工作硬边旋转包络半径≤77.10；两项均检验。'],group='rotor');WELDS['B200']={'B202':1,'B201':2}
    # Common terminal seat rails, adjustable laterally by wall slots.
    s=box(630,24,32)
    for x,sgn in [(0,1),(630,-1)]:
        for y in [6,18]:s=cut(s,cyl(4.2,14,(x,y,16),(sgn,0,0)))
    # Three exact machining variants; tapping from the inward face z=0.
    for suf,ys in [("A",[13.5]),("B",[10.5]),("C",[9,15])]:
        q=s
        for yy in ys:
            for x in list(range(15,616,50)):q=cut(q,cyl(1.6,10,(x,yy,0)))
        register("S301"+suf,"密封座梁-"+suf,q,features=[dict(type="blank",width=630,height=24,thickness=32),dict(type="thread_pattern",axis="X",ends="0,630",y="6,18",z=16,thread="M5-6H",effective=10,drill_depth=14),dict(type="thread_pattern",axis="Z+",x="15,65,…,615 (p=50)",y=ys,thread="M2-6H",effective=7,drill_depth=10)],notes=["密封工作面为z=0；Ra1.6，全长直线度0.10。","端部M5配侧壁沿气流方向±2长孔；按实测自由厚度设置30%压缩再锁紧。"],group="seal")
    plate("S302","端边密封泡棉条",630,9,6.671,material="Rogers BISCO HT-870 9.53 mm",notes=["自由厚9.53；入料每点8.40–10.00；宽9±0.10；4mm夹持根部，0.5mm隔离带，4.5mm工作边。","冷态闭位以实际叶片和阀座调校；各≤50mm测点实测26%–34%，名义30%；工作允许10%–50%。锁销只作停机保持，不替代逐点测量。","端部与侧封压接0.5±0.2；端头按侧封实测修切，仅软料，不调整硬件。"],group="seal")
    plate("S303","端边密封压条",630,4,3,holes=[(x,2,2.4) for x in list(range(15,616,50))],notes=["M2×12 A4-80内六角螺钉13件/条，头径≤3.8，初始扭矩0.15Nm；有效啮合≥4。","压条距叶片硬边≥0.5名义；根部4mm夹持；不以该压条承载压力合力。"],group="seal")
    # Bearing / gland body, axis Z; cylinder bores fully specified.
    s=box(64,64,40)
    s=cut(s,cyl(30.2,42,(32,32,-1)))
    s=cut(s,cyl(34,30,(32,32,10)))
    s=cut(s,cyl(35.2,4.2,(32,32,3)))
    for x in [8,56]:
        for y in [8,56]:s=cut(s,cyl(6.5,42,(x,y,-1)))
    register('J401','衬套轴封座',s,features=[dict(type='blank',width=64,height=64,thickness=40),dict(type='bore',x=32,y=32,d=30.2,depth='THRU'),dict(type='counterbore',x=32,y=32,d=34,z=10,depth=30,fit='H7 0/+0.025'),dict(type='groove',x=32,y=32,d=35.2,z=3,width=4.2),*[dict(type='hole',x=x,y=y,d=6.5,depth='THRU') for x in [8,56] for y in [8,56]]],notes=['座孔34 H7；轴封喉口30.20+0.05/0；槽底Ra1.6。','轴封选30×3 EPDM70，沟槽35.20+0.05/0×4.20±0.05，名义挤压13.3%；候选低速摆动槽，寿命待验证。','座面平面度0.05；轴线对安装面垂直度0.05/40；配J402薄垫。'],group='bearing')
    plate('J402','轴封座静垫',64,64,.5,holes=[(32,32,38)]+[(x,y,12.2) for x in [8,56] for y in [8,56]],material='Solid EPDM70 sheet 0.8±0.1',notes=['自由0.8，安装0.5；四角配0.50限位垫片；不堵塞38轴穿孔。'],group='seal')
    s=cut(cyl(34,30),cyl(30.02,32,(0,0,-1)))
    register('BUY401','igus XSM-3034-30',s,kind='BUY',material='iglidur X',features=[dict(type='tube',od=34,id=30.02,length=30)],notes=['精确型号；压装后ID=30.020–30.104；H7座；禁止再铰塑料孔。'],group='purchase')
    s=cq.Solid.makeTorus(33/2,1.5)
    register('BUY402','EPDM70-P AT-OR-01 O-ring 30×3',s,kind='BUY',material='EPDM70 peroxide cured',features=[dict(type='oring',id=30,cs=3)],notes=['按AT-OR-01进料：过氧化物硫化EPDM，硬度70±5 Shore A；30±0.25×3.00±0.08；70°C水浸168h体积变化±5%、硬度变化±5；70°C压缩25%/168h永久变形≤25%；批次与配方不可混用。','薄涂与EPDM相容硅脂；候选摆动轴封，不假定500k寿命。'],group='purchase')
    # Fixed-end collar positive cross pin; yoke plates sit outside bearing.
    s=cut(cyl(50,10),cyl(30.05,12,(0,0,-1)));s=cut(s,cyl(6,52,(-26,0,5),(1,0,0)))
    register('J403','固定端销接轴环',s,features=[dict(type='tube',od=50,id=30.05,length=10),dict(type='crossbore',axis='X',x=-26,y=0,z=5,d=6,fit='H6',depth=52)],notes=['轴环端面间距10.00±0.01，两端平行0.01。','与B202均铰Ø6H6(6.000–6.008)，配STD05 Ø6h6(5.992–6.000)光杆，轴向间隙链含两孔最大0.032及异种材料热增量。以M6穿销螺栓锁定轴向，不依赖紧定螺钉摩擦；螺母机械防松。'],group='bearing')
    plate('J404','固定端止推盖',64,64,4,holes=[(32,32,31)]+[(x,y,6.5) for x in [8,56] for y in [8,56]],notes=['与座外端面形成12.09mm间隔；轴环10.00±0.01，PTFE两片配对总厚2.00±0.02；冷态实测端隙0.05–0.13。'],group='bearing')
    s=cut(cyl(12,12.09),cyl(6.5,14,(0,0,-1)))
    register('J405','止推盖隔套',s,features=[dict(type='tube',od=12,id=6.5,length=12.09)],notes=['长12.09±0.01；四件等高差≤0.01；两端面平行0.01。'],group='bearing')
    s=cut(cyl(50,1),cyl(30.2,3,(0,0,-1)))
    register('J406','止推垫',s,material='Virgin PTFE 1.00±0.03',features=[dict(type='tube',od=50,id=30.2,length=1)],notes=['每固定端2件；测厚选配两片总厚2.00±0.02，随轴环/隔套实测冷态端隙0.05–0.13；不现场研磨PTFE。远端不设轴向挡圈；可浮动≥1.2。'],group='seal')
    # KHK SSG3-55F30B, freely phased friction bush. Involute proxy is not a cutting definition.
    m=3.;teeth=55;rp=82.5;rb=rp*math.cos(math.radians(20));ra=85.5;rf=78.75
    invp=math.tan(math.radians(20))-math.radians(20);half=math.pi/(2*teeth)-.18/(2*rp)
    pts=[]
    for j in range(teeth):
        center=2*math.pi*j/teeth
        angle_base=half+invp
        pts.append((rf*math.cos(center-angle_base),rf*math.sin(center-angle_base)))
        for rr in np.linspace(rb,ra,10):
            phi=math.acos(rb/rr);ang=center-(half+invp-(math.tan(phi)-phi));pts.append((rr*math.cos(ang),rr*math.sin(ang)))
        for rr in np.linspace(ra,rb,10):
            phi=math.acos(rb/rr);ang=center+(half+invp-(math.tan(phi)-phi));pts.append((rr*math.cos(ang),rr*math.sin(ang)))
        pts.append((rf*math.cos(center+angle_base),rf*math.sin(center+angle_base)))
    g=cq.Workplane("XY").polyline(pts).close().extrude(30).val().fuse(cyl(90,20,(0,0,30)),cyl(52,8.5,(0,0,50))).clean()
    g=cut(g,cyl(30,60,(0,0,-1)))
    register("BUY504","KHK SSG3-55F30B",g,kind="BUY",material="KHK S45C / hardened tooth",features=[dict(type="spur_gear_proxy",module=3,teeth=55,pressure_angle=20,pitch_d=165,tip_d=171,face=30,hub_d=90,hub_length=20,total_length=58.5,bore=30,friction_bush_d=52)],notes=["准确采购型号；齿面不得再加工；本代理不作为齿轮制造图。","F30B允许任意装配相位。M5×18紧固8.8Nm，10只；参考滑移410Nm，C02夹持段无键槽，410Nm仅厂家参考，不作限矩。","轴夹持段30h7，Ra1.6；按厂家表面/上油要求装配，不涂含MoS2润滑剂。","参照SSG3-55：齿根421Nm、齿面423Nm；必须按实际工作制复核，非500k寿命证明。"],group="purchase")
    # Manual torque-input hubs and removable handle; fixed sector pins carry holding torque.
    s=cyl(160,12).fuse(cyl(52,72)).clean()
    s=cut(s,cyl(30,46,(0,0,0)))
    s=cut(s,box(18.4,8.010,46).translate((0,-4.005,0)))
    s=cut(s,box(19.10,19.10,22).translate((-9.55,-9.55,50)))
    s=s.fuse(cyl(28,20,(60,0,-20))).clean()
    s=cut(s,cyl(10.2,14,(60,0,-21)))
    s=cut(s,cyl(18,21,(60,0,-8)))
    s=cut(s,cyl(13,1,(60,0,-9)))
    s=cut(s,cyl(10,14,(-50,0,-1)))
    s=cut(s,cyl(8.5,6,(0,0,45)))
    register("D503","手动方榫接头及锁位盘",s,features=[dict(type="disc_hub",od=160,t=12,hub_od=52,hub_length=72,bore=30,bore_depth=46),dict(type="keyway",width=8.010,width_upper=8.025,total_height=18.4,top_tolerance=.03,angle_from_X=0,depth=46),dict(type="square_socket",across_flats=19.10,depth=22,z0=50,corner_Rmax=.3),dict(type="boss",x=60,y=0,d=28,z=-20,length=20),dict(type="relief",x=60,y=0,d=13,z=-9,depth=1),dict(type="counterbore",x=60,y=0,d=18,z=-8,depth=20,fit="H7"),dict(type="thread",x=60,y=0,z=-20,thread="M12-6H",effective=12,depth="THRU to shoulder bore"),dict(type="hole",x=-50,y=0,d=10,depth="H7 THRU"),dict(type="axial_retainer",d=8.5,z0=46,depth=4,bolt="M8x20",washer_t=1.6)],notes=["孔30H7，键槽宽8.010–8.025；槽顶距轴心18.40±0.03；配DIN6885-A 8×7×40，进料宽7.990–8.000、高6.985–7.000；闭端19.10+0.03/0方孔，深22；D520插入10；内部M8轴向保持螺钉+1.6垫圈，螺钉顶与榫端净距2.4mm；禁止绕过限矩器直接接工具。","手动正常输入限100Nm；结构筛查200Nm；使用独立校准双向传感器读取实际输入。","M8×20穿4mm隔壁拧入B202轴端16.4mm；机械防脱，键承担传扭；取消顶丝和轴端配窝。","C02手动链为D530、BUY531、HBK T210与D532；严禁在此输入未限矩扳杆。"],group="drive")
    # Complete hand tool is purchased; simplified envelope is excluded from fitted state.
    register("BUY503","HAZET 5123-3CT 参考手柄",box(628,50,35),kind="BUY",material="Supplier steel/tool",features=[dict(type="tool_envelope",length=628,width=50,height=35,square=12.7)],notes=["长度628为厂家数据；50×35为服务包络假设，不作采购外形。","60–320Nm，右旋精度±3%；反向操作只能配独立双向转矩测量，不作为已确认双向限矩器。"],group="purchase")
    s=cut(cyl(240,20),cyl(62,22,(0,0,-1)))
    for x,y in [(-50,0),(0,-50)]+[(a,b) for a in [-78,78] for b in [-70,70]]:s=cut(s,cyl(10 if x*y==0 else 8.5,22,(x,y,-1)))
    # Closed circular slot composed of exact annular sector and circular end caps.
    ring=cut(cyl(138.5,22,(0,0,-1)),cyl(101.5,24,(0,0,-2)))
    slot=ring.intersect(box(70,70,24).translate((0,0,-2))).fuse(cyl(18.5,22,(60,0,-1)),cyl(18.5,22,(0,60,-1))).clean()
    s=cut(s,slot)
    register("D505","固定止挡及锁位板",s,features=[dict(type="disc",od=240,id=62,t=20),dict(type="arc_slot",radius=60,width=18.5,angle_start=0,angle_end=90),dict(type="hole",x=-50,y=0,d=10,depth="H7 THRU"),dict(type="hole",x=0,y=-50,d=10,depth="H7 THRU"),*[dict(type="hole",x=x,y=y,d=8.5,depth="THRU") for x in [-78,78] for y in [-70,70]]],notes=["圆弧槽与D511肩销形成0/90硬止挡；几何角隙约±0.24°。","锁销孔独立，满插锁定关闭保持；不得用密封泡棉当止挡。","四M8支柱接D510跨梁；共用手动/自动反力基准，新增四A704输入支柱孔。"],group="drive")
    s=cyl(10,40).fuse(cyl(18,5,(0,0,40)))
    s=cut(s,cyl(2.5,20,(-10,0,42.5),(1,0,0)))
    register("D506","端位锁销",s,features=[dict(type="steppedshaft",d=10,length=40,head_d=18,head_t=5),dict(type="crossbore",axis="X",x=-10,y=0,z=42.5,d=2.5,depth="THRU; lanyard")],notes=["10g6、Ra0.8；满插有效承压长度≥12；固定板20+间隔4+运动盘12。","17-4PH H1150，头部系防脱索；动作前拔出，动作后插回。"],material="17-4PH H1150",group="drive")
    s=cyl(18,46).fuse(cyl(12,26,(0,0,46)),cyl(28,5,(0,0,-5)))
    ed=[e for e in s.Edges() if e.geomType()=="CIRCLE" and abs(e.Center().z-46)<1e-6 and abs(e.radius()-6)<1e-6]
    if ed:s=s.fillet(.5,ed)
    s=cut(s,cq.Workplane("XY").polygon(6,6/math.cos(math.pi/6)).extrude(4).val().translate((0,0,-5)))
    register("D511","止挡肩销",s,features=[dict(type="steppedshaft",d=18,length=46,thread="M12-6g",thread_length=26,root_R=.5,head_d=28,head_t=5),dict(type="hex_socket",across_flats=6,z=-5,depth=4)],notes=["Ø18h8肩部穿固定板弧槽并插入D503的18H7孔20mm；M12仅轴向保持；肩部跨20mm固定板、4mm间隔及外側2mm间隙。","17-4PH H1150；按200Nm输入反力计算；机械锁母/防松垫。"],material="17-4PH H1150",group="drive")
    s=box(22,22,125.5)
    for z,sgn in [(0,1),(125.5,-1)]:s=cut(s,cyl(6.8,20,(11,11,z),(0,0,sgn)))
    register("D509","手动止挡板支柱",s,features=[dict(type="blank",width=22,height=22,thickness=125.5),dict(type="thread_pattern",axis="Z",x=11,y=11,ends="0,125.5",thread="M8-6H",effective=16,drill_depth=20)],notes=["四柱一组，长度等高差0.05；两端面平行度0.05；304L。"],group="drive")
    plate("D510","侧板驱动反力横梁",174,32,20,holes=[(15,16,8.5),(159,16,8.5)],notes=["每驱动2件；两端与前后端法兰内面接触，双侧a3连续角焊，每端有效长2×32；支柱反力经本梁传到端法兰和接收面，不依赖3mm侧壁局部悬臂。","新孔纳入本地侧板图，不修改母板；薄板局部承载须见计算。"],group="drive")
    plate("D512","驱动加强条静垫",174,24,.5,holes=[(15,12,16.2),(159,12,16.2)],material="Solid EPDM70 0.8±0.1 mm",notes=["安装0.50，由角部限位垫控制；连续跨过中分法兰缺口。"],group="seal")
    # Universal clamp bar and hard compression stop. Do not drill protected mother wall.
    for pn,od,id,L in [('F602',16,8.5,2),('F603',12,6.5,2),('F604',12,6.5,.5),('F605',16,8.5,.5)]:
        register(pn,'静垫压缩限位套',cut(cyl(od,L),cyl(id,L+2,(0,0,-1))),features=[dict(type='tube',od=od,id=id,length=L)],notes=[f'长度{L:.2f}±0.03；去毛刺；与密封材料同批装配检查压缩。'],group='fixture')
    plate("F620","P试装立肋",100,492,8,notes=["两件焊于P接收框背面与脚板；连续a=3角焊。","仅装入/孔位工装；不以其加强接收框的效果证明装机密封或受力性能。"],group="fixture")
    plate("F621","R试装侧肋",706,320,8,notes=["两件连接R接收框底面与脚板，连续a=3角焊；四角落地夹紧。","仅装入/孔位工装；用于泄漏试验前必须按机侧实际支承复建压力台架。"],group="fixture")
    plate("F622","试装脚板",280,100,8,holes=[(x,y,11) for x in [20,140] for y in [20,80]],notes=["P/R各2块；M10压紧到刚性台面，不作整机安装件。"],group="fixture")

def define_connected_cut_parts():
    """Separate disconnected flat blanks into individually drawable PNs; kit geometry stays exact."""
    for kit in ['P102','P105','R102','R105']:
        parent=PARTS[kit];solids=sorted(parent['shape'].Solids(),key=lambda q:tuple(round(v,5) for v in ex.bb(q)[:3]));unique=[];members=[]
        parent['kind']='KIT_ASSEMBLY';parent['name']+='分片套件'
        parent['notes']=[n.replace('整体刀模切，不拼接。','各分片独立切割，按套件定位；跨接处由轴封座静垫密封。').replace('整片切割','按独立分片图切割') for n in parent['notes']]
        parent['notes'].append('本PN为分片套件，不是一个连续下料件。组成、位姿见KITS_C02与独立子件图；报价避免套件/子件重复。')
        for solid in solids:
            lo=ex.bb(solid)[:3];local=solid.translate(tuple(-v for v in lo));pn=None;ang=0;rotmin=[0,0,0]
            # Identical flat profiles rotated in their plane share one cutting PN.
            for angle in [0,90,180,270]:
                trial=local.rotate((0,0,0),(0,0,1),angle);off=ex.bb(trial)[:3];trial=trial.translate(tuple(-v for v in off))
                for old,q in unique:
                    if max(abs(a-c) for a,c in zip(ex.bb(q),ex.bb(trial)))<1e-5 and abs(q.Volume()-trial.Volume())<.001:
                        if abs(q.cut(trial).Volume())<.001 and abs(trial.cut(q).Volume())<.001:pn=old;ang=angle;rotmin=off;break
                if pn:break
            if pn is None:
                pn=kit+chr(65+len(unique));unique.append((pn,local));bb=ex.bb(local)
                planar=[f for f in local.Faces() if f.geomType()=='PLANE' and abs(f.normalAt().z)>.99]
                face=min(planar,key=lambda f:abs(f.Center().z));features=[dict(type='blank',width=bb[3],height=bb[4],thickness=bb[5])]
                for edge in face.Edges():
                    if edge.geomType()=='CIRCLE':
                        cen=edge.arcCenter();features.append(dict(type='circle_edge',x=round(cen.x,6),y=round(cen.y,6),radius=round(edge.radius(),6),closed=edge.IsClosed(),x1=round(edge.startPoint().x,6),y1=round(edge.startPoint().y,6),x2=round(edge.endPoint().x,6),y2=round(edge.endPoint().y,6),arc_length=round(edge.Length(),6)))
                    else:
                        a=edge.startPoint();z=edge.endPoint();features.append(dict(type='contour_line',x1=round(a.x,6),y1=round(a.y,6),x2=round(z.x,6),y2=round(z.y,6)))
                register(pn,parent['name'].replace('分片套件','')+'-分片'+pn[-1],local,material=parent['material'],features=features,notes=['本件为'+kit+'的独立连续下料片；所有边线及孔圆在坐标特征表中逐一列出。','基准为本件STP最小X/Y/Z面；套件装配平移见KITS_C02，不按套件总外框再次下料。']+parent['notes'][:-1],group=parent['group'])
            a=math.radians(-ang);u=(math.cos(a),math.sin(a),0);v=(-math.sin(a),math.cos(a),0);n=(0,0,1)
            translation=list(np.array(lo)+np.array(u)*rotmin[0]+np.array(v)*rotmin[1]+np.array(n)*rotmin[2])
            members.append(dict(pn=pn,translation=translation,u=u,v=v,n=n,angle_deg=-ang))
        KITS[kit]=members

    # Exact cross-valve duplicate blanks: one shared drawing / purchase quantity.
    for duplicate,shared in [('R102B','P102B'),('R105A','P105A')]:
        a=PARTS[duplicate]['shape'];z=PARTS[shared]['shape']
        if not(abs(a.cut(z).Volume())<.001 and abs(z.cut(a).Volume())<.001):continue
        for members in KITS.values():
            for m in members:
                if m['pn']==duplicate:m['pn']=shared
        PARTS[shared]['notes'].append('P/R共用；原'+duplicate+'已合并到本PN，数量按各父套件组成累计。')
        del PARTS[duplicate]

def build_occ():
    # Common body frame local U=Y, V=Z (P) or -X (R), N=X (P) or Z (R).
    for tag,ctr,H in [('P',(-439,-408,1450.5),345),('R',(-82,-408,1583),180)]:
        U=np.array([0.,1.,0.]);V=np.array([0.,0.,1.]) if tag=='P' else np.array([-1.,0.,0.]);N=np.cross(U,V);C=np.array(ctr)
        def pos(u,v,n):return tuple(C+U*u+V*v+N*n)
        for sign,hand in [(-1,'F'),(1,'B')]:
            # end/split flanges face inward; choose orientation right handed by flipping U.
            uu=U*sign;vv=V;nn=N*sign
            def pp(u,v,n):return tuple(C+uu*u+vv*v+nn*n)
            add(tag+'101',pp(-353,-H/2-38,87),tuple(uu),tuple(vv),tuple(nn),group=tag)
            add(tag+'102',pp(-335,-H/2-20,1),tuple(uu),tuple(vv),tuple(nn),group=tag)
            for side in [-1,1]:
                # sidewall local x axial toward center, y vertical, n side outward.
                o=pos(side*315,-H/2,sign*87)
                ax=-sign*N;vy=V;normal=np.cross(ax,vy)
                if np.dot(normal,U)*side<0:
                    o=pos(side*315,H/2,sign*87);vy=-V;normal=np.cross(ax,vy)
                add(tag+'103'+hand,o,tuple(ax),tuple(vy),tuple(normal),group=tag)
            for top in [-1,1]:
                ax=-sign*N;vy=U*sign*top;normal=np.cross(ax,vy)
                o=pos(-sign*top*318,top*(H/2+3),sign*87)
                add(tag+'104',o,tuple(ax),tuple(vy),tuple(normal),group=tag)
        add(tag+'105',pos(-335,-H/2-20,-1),tuple(U),tuple(V),tuple(N),group='SEAL')
        # main external gasket on upstream P face and downstream machine face; R lower only.
        faces=[-1,1] if tag=='P' else [-1]
        for sign in faces:
            add(tag+'106',pos(-353,-H/2-38,sign*90 if sign>0 else -92),tuple(U),tuple(V),tuple(N),group='SEAL')
            # downstream P original receiver -338..-335; R receiver1488..1491.
            if tag=='P' and sign==1:add(tag+'107',pos(-353,-H/2-38,92),tuple(U),tuple(V),tuple(N),group=tag)
            if tag=='R':add(tag+'107',pos(-353,-H/2-38,-95),tuple(U),tuple(V),tuple(N),group=tag)
        for sign in faces:
            for hx,hy,_ in holes_ring(630+76,H+76,19,70,9):
                add("F602",pos(hx-353,hy-H/2-38,90 if sign>0 else -92),tuple(U),tuple(V),tuple(N),group=tag)
        for hx,hy,_ in holes_ring(670,H+40,10,60,6.5):
            ay=hy-20
            excluded=(hx<20 or hx>650) and (any(abs(ay-v)<40 for v in ([90,255] if tag=="P" else [90])) or any(abs(ay-v)<20 for v in ([18,162] if tag=="P" else [18,162])))
            if not excluded:add("F603",pos(hx-335,hy-H/2-20,-1),tuple(U),tuple(V),tuple(N),group=tag)
        # P inlet companion fixture flange matching original outer interface.
        if tag=='P':add('P107B',pos(-353,-H/2-38,-95),tuple(U),tuple(V),tuple(N),group=tag)
        # side pads, split at shaft plane. Foam nominal installed, film begins at blade end.
        for side in [-1,1]:
            for half in [-1,1]:
                ax=-half*N;vy=V;norm=np.cross(ax,vy)
                # normal must point inward from case side
                if np.dot(norm,U)*side>0:vy=-V;norm=np.cross(ax,vy)
                offv=-H/2+3 if np.dot(vy,V)>0 else H/2-3
                for pn,depth in [(tag+'111',315),(tag+'108',315-1.8),(tag+'109',308.75),(tag+'110',309.75)]:
                    add(pn,pos(side*depth,offv,half*87),tuple(ax),tuple(vy),tuple(norm),group='SEAL')
        # seat beams positions in V; signs specify upstream/downstream contact.
        seats=[(-H/2+12,-1,"A"),(0,1,"C"),(H/2-12,-1,"B")] if tag=="P" else [(-H/2+12,-1,"A"),(H/2-12,1,"A")]
        for cv,sgn,variant in seats:
            u=U;v=V*sgn;n=np.cross(u,v)
            add("S301"+variant,pos(-315,cv-sgn*12,sgn*7.921),tuple(u),tuple(v),tuple(n),group=tag)
            if tag=="P":
                if cv<0:pairs=[(-163.5-0.5,-163.5-0.5)]
                elif cv>0:pairs=[(155.5-0.5,160.5-0.5)]
                else:pairs=[(-10,-5),(1,1)]
            else:
                pairs=[(-81.5,-81.5)] if cv<0 else [(72.5,77.5)]
            # unified +V strip direction, inbound normal; reverse span as needed.
            su=-sgn*U;sv=V;sn=-sgn*N;start=315*sgn
            for sealv,clampv in pairs:
                add("S302",pos(start,sealv,sgn*7.921),tuple(su),tuple(sv),tuple(sn),group="SEAL")
                add("S303",pos(start,clampv,sgn*4.976),tuple(su),tuple(sv),tuple(sn),group="SEAL")
        axes=[-82.5,82.5] if tag=='P' else [0]
        for i,av in enumerate(axes):
            ctr_axis=pos(0,av,0)
            moving=f'P{i+1}' if tag=='P' else 'R1'
            # Rotor local span X along Y; chord Y along V; thickness Z along N.
            add('B200',pos(-308.5,av,0),tuple(U),tuple(V),tuple(N),group=tag,moving=moving)
            for side in [-1,1]:
                # gland body local z points outwards along Y; central axis follows shaft.
                gu=N;gv=V*(-side);gn=np.cross(gu,gv)
                base=pos(side*318.5,av,0)-32*gu-32*gv
                add('J401',tuple(base),tuple(gu),tuple(gv),tuple(gn),group=tag)
                add('J402',tuple(np.array(pos(side*318,av,0))-32*gu-32*gv),tuple(gu),tuple(gv),tuple(gn),group='SEAL')
                for da in [-24,24]:
                    for dv in [-24,24]:add('F604',pos(side*318,av+dv,da),tuple(gu),tuple(gv),tuple(gn),group=tag)
                add('BUY401',pos(side*328.5,av,0),tuple(gu),tuple(gv),tuple(gn),group='PURCHASE')
                add('BUY402',pos(side*323.6,av,0),tuple(gu),tuple(gv),tuple(gn),group='PURCHASE')
            # fixed thrust geometry uses axis Y negative. Shaft pin y=-768.
            u=N;v=V;n=np.cross(u,v)
            add('J403',pos(-359.5,av,0),tuple(u),tuple(v),tuple(n),group=tag,moving=moving)
            add('J406',pos(-358.5,av,0),tuple(u),tuple(v),tuple(n),group='SEAL')
            add('J406',pos(-369.5,av,0),tuple(u),tuple(v),tuple(n),group='SEAL')
            add('J404',tuple(np.array(pos(-370.59,av,0))-32*u-32*v),tuple(u),tuple(v),tuple(n),group=tag)
            for du in [-24,24]:
                for dv in [-24,24]:add('J405',pos(-358.5,av+dv,du),tuple(u),tuple(v),tuple(n),group=tag)
            if tag=="P":
                # 55 odd teeth: tooth/gap phase aligns naturally at vertical line of centres.
                ga=math.pi/55 if i==1 else 0
                gu=N*math.cos(ga)+V*math.sin(ga);gv=-N*math.sin(ga)+V*math.cos(ga)
                add("BUY504",pos(-384,av,0),tuple(gu),tuple(gv),tuple(-U),group="PURCHASE",moving=moving)
            if i==0:
                add('D503',pos(-448,av,0),tuple(N),tuple(V),tuple(-U),group='DRIVE',moving=moving)
                add('D505',pos(-464,av,0),tuple(N),tuple(V),tuple(-U),group='DRIVE')
                # removable handle shown in separate tool file, not fitted for motion scan.
                add('D506',pos(-437,av,-50),tuple(N),tuple(V),tuple(-U),group='DRIVE',moving=moving,note='remove before movement')
                add('D511',pos(-486,av,60),tuple(N),tuple(-V),tuple(U),group='DRIVE',moving=moving)
                for dv in [-70,70]:
                    add('D510',tuple(np.array(pos(-318.5,av+dv,0))-87*N-16*V),tuple(N),tuple(V),tuple(-U),group='DRIVE')
                    add('D512',tuple(np.array(pos(-318,av+dv,0))-87*N-12*V),tuple(N),tuple(V),tuple(-U),group='SEAL')
                    for du in [-78,78]:
                        add('F605',pos(-318,av+dv,du),tuple(N),tuple(V),tuple(-U),group=tag)
                        add('D509',tuple(np.array(pos(-338.5,av+dv,du))-11*N-11*V),tuple(N),tuple(V),tuple(-U),group='DRIVE')
    for xx in [-173.5,8]:add('R112',(xx,-723,1468),(0,1,0),(0,0,1),(1,0,0),group='R')
    for yy in [-723,-91.5]:add('R113',(-173.5,yy,1468),(1,0,0),(0,0,1),(0,-1,0),group='R')
    # Two independent fit-check fixtures. Butt contacts, not overlapping tube proxies.
    for yy in [-742,-66]:add("F620",(-335,yy,1168),(1,0,0),(0,0,1),(0,-1,0),group="FIXTURE")
    for xx in [-210,38]:add("F621",(xx,-761,1168),(0,1,0),(0,0,1),(1,0,0),group="FIXTURE")
    for xx in [-500,-210]:
        for yy in [-786,-110]:add("F622",(xx,yy,1160),group="FIXTURE")

def axis_for(m):
    return {'P1':(-439,0,1368),'P2':(-439,0,1533),'R1':(-82,0,1583)}[m]
def state_shapes(theta,expand_kits=False):
    upper=-theta
    shapes={};rows=[];kidcounts=collections.Counter()
    for o in OCC:
        if ACTIVE_CONFIG not in o.get('configs',['MANUAL','AUTO']):continue
        s=tr(PARTS[o['pn']]['shape'],o['o'],o['u'],o['v'],o['n'])
        a={'P1':theta,'P2':upper,'R1':90-theta}.get(o['moving'],0)
        if o['moving']:
            c=axis_for(o['moving']);s=s.rotate(c,(c[0],-1,c[2]),a)
        k=o['occurrence']
        if expand_kits and o['pn'] in KITS:
            for m in KITS[o['pn']]:
                pn=m['pn'];kidcounts[pn]+=1;key=f'{pn}_{kidcounts[pn]:03d}'
                cs=tr(PARTS[pn]['shape'],m['translation'],m['u'],m['v'],m['n']);cs=tr(cs,o['o'],o['u'],o['v'],o['n'])
                shapes[key]=cs;rows.append(dict(definition=key,occurrence=key,scope=o['scope']))
        else:shapes[k]=s;rows.append(dict(definition=k,occurrence=k,scope=o['scope']))
    return rows,shapes

def weld_notes(pn):
    common=['本件STP使用整机坐标；禁止将其原点误作子件下料原点。','总成报价只填焊装/校形/检验费用；子件材料和加工另列，避免重复计价。']
    if pn=='R100S':
        return common+['四角连续角焊a=1，ER308L；R抬高段接口母板未改动。','接口焊后全长平面度0.30；按子件坐标和焊总成校形。']
    if pn.startswith('F'):
        return common+['工装接缝连续角焊a=3，ER308L；先装夹定位，对称施焊并校形。','接收面焊后全长平面度0.30；底脚共面度0.30。载荷与约束资格见工程记录，不能由本图推定已通过。']
    return common+['阀壳接缝连续角焊a=2，ER308L。','焊后法兰面全长平面度0.30，轴孔与安装面按J401座精校；中分面对角差≤0.40。']

def make_weld_defs():
    groups={}
    for tag in ['P','R']:
        for hand,ix in [('F',1),('B',2)]:
            groups[tag+'100'+hand]=[f'{tag}101_{ix:03d}',f'{tag}102_{ix:03d}',f'{tag}103{hand}_001',f'{tag}103{hand}_002',f'{tag}104_{2*ix-1:03d}',f'{tag}104_{2*ix:03d}']
    groups['R100S']=['R112_001','R112_002','R113_001','R113_002']
    groups['F600P']=['P107_001','F620_001','F620_002','F622_001','F622_002']
    groups['F600R']=['R107_001','F621_001','F621_002','F622_003','F622_004','F623_001','F623_002']
    groups['F650P']=['F630P_001','F630P_002','F631_001','F632_001']
    groups['F650R']=['F630R_001','F630R_002','F631_002','F632_002']
    om={o['occurrence']:o for o in OCC}
    for pn,ks in groups.items():
        pieces=[tr(PARTS[om[k]['pn']]['shape'],om[k]['o'],om[k]['u'],om[k]['v'],om[k]['n']) for k in ks]
        fs=[dict(type='assembly_datum',coordinate='machine XYZ, mm')]+[dict(type='component',pn=om[k]['pn'],occurrence=k,origin=om[k]['o'],u=om[k]['u'],v=om[k]['v'],normal=om[k]['n']) for k in ks]
        register(pn,'R抬高段焊接总成' if pn=='R100S' else '半阀壳焊接总成' if pn[0] in 'PR' else '独立试装工装焊接总成',comp(pieces),kind='WELD_ASSEMBLY',features=fs,notes=weld_notes(pn),group='weldassembly')
    return groups

_base_build_parts=build_parts
_base_build_occ=build_occ
def build_parts():
    _base_build_parts()
    import c02_extensions
    c02_extensions.parts(sys.modules[__name__])
def build_occ():
    _base_build_occ()
    import c02_extensions
    c02_extensions.occurrences(sys.modules[__name__])
