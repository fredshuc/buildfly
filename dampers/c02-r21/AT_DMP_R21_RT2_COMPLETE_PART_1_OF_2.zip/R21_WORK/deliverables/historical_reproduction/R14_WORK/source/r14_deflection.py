import json,math,ast
import numpy as np
import build_c02 as b
E=b.OUT/'evidence';src=(b.ROOT.parent/'R7_WORK/source/r6_finite_base.py').read_text();node=next(n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef) and n.name=='beamk');exec(ast.get_source_segment(src,node))
P=json.loads((b.OUT/'native/R14_PARTS.json').read_text());pm={p['pn']:p for p in P};m=json.loads((E/'R14_MASS_AND_FLOOR.json').read_text())['part_masses'];cg=b.ex.readshape(pm['D870']['brep']).Center().z
zz=sorted(set([-58.5,-13,35,39.4632622903,cg,103,148]));N=len(zz);nd=4*N;EI=200000*math.pi*30**4/64
# R13 common-platen matrix retained as a declared surrogate; new floorframe not inferred rigid.
CB=np.array(json.loads((b.ROOT.parent/'R13_WORK/deliverables/evidence/R13_COMPLIANCE_THERMAL.json').read_text())['common_platen_compliance_mm_N']);rows=[]
for name,T,stop,pose in [('P_driven_jam',200,None,'bench'),('P_driven_jam',200,None,'installed'),('P_stop0',200,'Y','bench'),('P_stop90',200,'X','bench')]:
 for kb,kl in [(25000,20000),(100000,100000)]:
  C=CB+np.eye(4)*(1/kb+1/kl);dis=[];loads=[]
  for plane in ['X','Y']:
   K=np.zeros((nd,nd));F=np.zeros(nd)
   def idx(shaft,z):return shaft*2*N+2*zz.index(z)
   def load(s,z,f,moment=0):F[idx(s,z)]+=f;F[idx(s,z)+1]+=moment
   for s in [0,1]:
    for a,bb in zip(zz[:-1],zz[1:]):
     ix=[idx(s,a),idx(s,a)+1,idx(s,bb),idx(s,bb)+1];K[np.ix_(ix,ix)]+=beamk(bb-a,EI)
    # opposite mesh force; same signed coupling allocation is one named diagnostic, not extrema envelope
    load(s,35,(-1 if s==0 else 1)*(T*1000/82.5)*(math.tan(math.radians(20)) if plane=='X' else 1))
    grav=(plane=='Y' and pose=='bench') or (plane=='X' and pose=='installed')
    if grav:load(s,39.4632622903,m['BUY504']*9.81);load(s,cg,m['D870']*9.81)
    if plane=='Y':load(s,-58.5,70.74,10000-70.74*41)
   if (plane=='Y' and pose=='bench') or (plane=='X' and pose=='installed'):load(1,148,10*9.81*(383-220)/(383-148))
   if stop==plane:load(0,148,200000/60)
   si=[idx(0,-13),idx(1,-13),idx(0,103),idx(1,103)];K[np.ix_(si,si)]+=np.linalg.inv(C);u=np.linalg.solve(K,F);r=np.linalg.inv(C)@u[si]
   dis.append(dict(plane=plane,relative_at_gear_mm=float(u[idx(1,35)]-u[idx(0,35)]),relative_angle_mrad=float((u[idx(1,35)+1]-u[idx(0,35)+1])*1000),common_plus_local_support_displacements_mm=u[si].tolist(),support_reactions_N=r.tolist(),linear_residual_N=float(max(abs(K@u-F)))))
  rows.append(dict(case=name,pose=pose,bearing_k=kb,local_plate_k=kl,planes=dis,relative_transverse_norm_mm=math.hypot(*[q['relative_at_gear_mm'] for q in dis]),relative_angle_norm_mrad=math.hypot(*[q['relative_angle_mrad'] for q in dis]),scope='Conditional two-plane linear surrogate, constant30mmshaft, signed allocation only, no clearances/contact/hot bearing stiffness/frame lower bound. Not G1 acceptance.'))
b.dump(E/'R14_TWO_PLANE_DEFLECTION_SENSITIVITY.json',dict(rows=rows,common_platen_compliance=CB.tolist(),limits=['R13 common-base offdiagonal compliance reused, appears once. Unmeasured bearing/plate springs remain sensitivities.','Couplingoverhang converted to force/moment atshaftgrip-58.5; couplingangularmoment10Nm isallocation.','Not a maximum overallloadsigns or contacthistories; R15wetdisplacements remainunsolved.']));print('DEFLECTION',[(r['case'],r['relative_transverse_norm_mm'],r['relative_angle_norm_mrad']) for r in rows],flush=True)
