# R21 - start here

Status: R21_P1_MASTER_AND_RT2_REVIEW_PACKAGE_READY.
Whole C02: PARTIAL / NOT_FOR_MANUFACTURE. This does not cancel named E01/F01-F07 fabrication scopes.

For the external red team, the full RT2 ZIP is self-contained. Start with R21_WORK/deliverables/drawings/AT_DMP_R21_P1_MASTER_AND_RT2_REVIEW_EN.pdf (28 pages). Files below are relative to R21_WORK/deliverables in that ZIP, or the root of the separate manufacturing ZIP.

1. tables/R21_CURRENT_FACTORY_ENTRY_INDEX.csv is the only current PN/allocation entry. Use factory/R21_CURRENT_ISSUED_PAGES.pdf and its PDF viewer page indices (original printed page numbers retained). 172 entries /243 pages. Check mandatory_process and F07_PRODUCT scope before manufacture.
2. tables/R21_NET_NEED_BOM.csv:220rows,2265configured identities,689released-use credit,1576unissued. tables/R21_CLASSIFIED_GAPS.csv:88rows with next actions. Stage161names/822pieces is a different statistic. No factory/order/measurement completion is claimed.
3. G903_R18 is the one F05 replacement shared sequentially. The old G903 index alias missed its released quantity; R21 corrects that single credit. Do not order an additional guard.
4. Both step/R20_P_COMPLETE_COLD_REFERENCE.stp and step/R20_R_COMPLETE_COLD_REFERENCE.stp are actual separate configurations. Open one at a time. Native R20_PARTS and P/R occurrence JSON are byte-identical current definitions/placements, named for provenance. R21_COORDINATE_FRAMES and R21_METADATA_OVERRIDES explain test orientation and current manufacturing priority. Complete STEP is not whole-unit manufacturing release.
5. factory/reference_issued_archives_DO_NOT_BATCH_PRODUCE contains actual E01/F01-F07 signed archives. RAW/PREP/FINAL/FREE and labour nodes are not extra purchased layers. Independent B01/E01/SP04 specimens are not product credit.
6. R21_FIRST_COLD_ASSEMBLY_CHAIN, EXTERNAL_FIXTURE_PURCHASE_SPEC, BODY_TOOL_NINE_LATER_MEMBERS and D542_EXACT_LATER_MEMBERS give the stage dependencies. Fixture specifications are not evidence that rated hardware exists; no actual load transfer is released.
7. R21_PURCHASE_TECHNICAL_ENQUIRIES is a draft only. R21_SP04_APPLICATION_MISSING_EVIDENCE is an application only. No commercial or physical action is performed.
8. R21_RT2_TEN_DECISIONS asks10specific questions in3decision classes. Known capture/geometry issues block their named use. Conditional manufacturing/measurement and P2 optimisation are separate.
9. Diagnostic open-slot film DXFs are ONLY in diagnostics in the full engineering ZIP. They import valid but have no accepted end-lip retention; neither they nor the old tangent DXFs belong in factory cutting. No new film/keeper is installed.
10. source/reproduce_current.py at R21_WORK/source independently reads current native validity/placement and exact hashes. Runtime versions are in evidence. historical_reproduction holds original R14two-plane/R15wet sources and minimal exact inputs for independent review; not executed in R21. history/source snapshots otherwise retain their original earlier dependencies.

The root MANIFEST_SHA256.json covers actual attached bytes; no standalone font is included. The full RT2 ZIP already contains the manufacturing files; the separate manufacturing ZIP is a convenient subset, not another material order. The external reviewer needs only the full ZIP.

User manually transfers to the external red team. R21 formal return terminates the cycle: PAUSED; no R22, no40-minute re-read and no red-team chat created.
